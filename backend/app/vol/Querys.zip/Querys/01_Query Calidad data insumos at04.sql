
--------------------------
	TRUNCATE TABLE TB_CarteraNoDirigidaFINAL
	UPDATE 	 TB_CARTERANODIRIGIDA 
	SET 	REFERENCIA = CONVERT(DECIMAL,LTRIM(RTRIM(REFERENCIA))),
			PROVISION = CONVERT(DECIMAL(18,2),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(PROVISION,',',''),'-','0'),'%','')))),
			DEBITO = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(DEBITO,'-','0'))),',','')),
			CREDITO = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(CREDITO,'-','0'))),',','')),
			SALDO = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(SALDO,'-','0'))),',','')),
			RendimientosCobrarReestructurados = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(RendimientosCobrarReestructurados,'-','0'))),',','')),
			RendimientosCobrarEfectosReporto = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(RendimientosCobrarEfectosReporto,'-','0'))),',','')),
			RendimientosCobrarLitigio = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(RendimientosCobrarLitigio,'-','0'))),',','')),
			InteresesEfectivamenteCobrados = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(InteresesEfectivamenteCobrados,'-','0'))),',','')),
			PorcentajeComisionFLAT = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(REPLACE(PorcentajeComisionFLAT,'%',''),'-','0'))),',','')),
			MontoComisionFLAT = CONVERT(DECIMAL(18,2),LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(MontoComisionFLAT,',',''),'-','0'),'%','')))),
			PeriodicidadPagoEspecialCapital = CONVERT(DECIMAL,LTRIM(RTRIM(REPLACE(REPLACE(PeriodicidadPagoEspecialCapital,'-','0'),',','.')))),
			FechaCambioEstatusCredito = REPLACE(convert(varchar(10),convert(datetime,FechaCambioEstatusCredito,105),111),'/',''),
			FechaRegistroVencidaLitigioCastigada = REPLACE(convert(varchar(10),convert(datetime,FechaRegistroVencidaLitigioCastigada,105),111),'/',''),
			FechaExigibilidadPagoUltimaCuotaPagada = REPLACE(convert(varchar(10),convert(datetime,FechaExigibilidadPagoUltimaCuotaPagada,105),111),'/',''),
			FechaEmisionCertificacionBeneficiarioEspecial = REPLACE(convert(varchar(10),convert(datetime,FechaEmisionCertificacionBeneficiarioEspecial,105),111),'/',''),
			FechaFinPeriodoGraciaPagoInteres = REPLACE(convert(varchar(10),convert(datetime,FechaFinPeriodoGraciaPagoInteres,105),111),'/',''),
			FechaCambioEstatusCapitalTransferido = REPLACE(convert(varchar(10),convert(datetime,FechaCambioEstatusCapitalTransferido,105),111),'/','')

--MODIFICO EL INSUMO SOLO CON LOS CAMPOS QUE NECESITO Y CON REGISTROS UNICOS 
--ELIMINO TABLA TEMPORAL
DROP TABLE DUPLICATE_TABLE

--INSERTO EN LA TB TEMPORAL LOS REGISTROS DUPLICADOS
SELECT	Referencia ,
		Provision ,
		InteresesEfectivamenteCobrados,
		MontoComisionFLAT,
		PeriodicidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigioCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido 
INTO	DUPLICATE_TABLE
FROM	TB_CarteraNoDirigida
	GROUP BY	Referencia ,
				Provision ,
				InteresesEfectivamenteCobrados,
				MontoComisionFLAT,
				PeriodicidadPagoEspecialCapital,
				FechaCambioEstatusCredito,
				FechaRegistroVencidaLitigioCastigada,
				FechaExigibilidadPagoUltimaCuotaPagada,
				CapitalTransferido,
				FechaCambioEstatusCapitalTransferido 
	HAVING COUNT(Referencia)>1
 --LIMPIO LA TABLA DEL INSUMO ORIGINAL     
 DELETE TB_CarteraNoDirigida
 WHERE Referencia IN (SELECT Referencia FROM DUPLICATE_TABLE)

 --INSERT EN LA TABLA DEL INSUMO ORIGINAL LOS REGISTROS DUPLICADOS (SOLO UNO DE CADA UNO)    								          
 INSERT INTO TB_CarteraNoDirigidaFINAL (
				Referencia ,
				Provision ,
				InteresesEfectivamenteCobrados,
				MontoComisionFLAT,
				PeriodicidadPagoEspecialCapital,
				FechaCambioEstatusCredito,
				FechaRegistroVencidaLitigioCastigada,
				FechaExigibilidadPagoUltimaCuotaPagada,
				CapitalTransferido,
				FechaCambioEstatusCapitalTransferido)
 SELECT 
				Referencia,
				Provision,
				InteresesEfectivamenteCobrados,
				MontoComisionFLAT,
				PeriodicidadPagoEspecialCapital,
				FechaCambioEstatusCredito,
				FechaRegistroVencidaLitigioCastigada,
				FechaExigibilidadPagoUltimaCuotaPagada,
				CapitalTransferido,
				FechaCambioEstatusCapitalTransferido
FROM	DUPLICATE_TABLE 
--INSERTO EL RESTO DE LOS REGISTROS 
INSERT INTO TB_CarteraNoDirigidaFINAL (
				Referencia ,
				Provision ,
				InteresesEfectivamenteCobrados,
				MontoComisionFLAT,
				PeriodicidadPagoEspecialCapital,
				FechaCambioEstatusCredito,
				FechaRegistroVencidaLitigioCastigada,
				FechaExigibilidadPagoUltimaCuotaPagada,
				CapitalTransferido,
				FechaCambioEstatusCapitalTransferido)
 SELECT 
				Referencia,
				Provision,
				InteresesEfectivamenteCobrados,
				MontoComisionFLAT,
				PeriodicidadPagoEspecialCapital,
				FechaCambioEstatusCredito,
				FechaRegistroVencidaLitigioCastigada,
				FechaExigibilidadPagoUltimaCuotaPagada,
				CapitalTransferido,
				FechaCambioEstatusCapitalTransferido
FROM TB_CarteraNoDirigida 
				
			
--CRE
--------------------------
	UPDATE  TB_DCAT04_04 
	SET REFERNO = CONVERT(DECIMAL,REFERNO)

--------------------------
-- Insumo VNP003T
--------------------------
	
	UPDATE TB_DCAT04_03  SET TNBFEE  = CASE 
			WHEN SUBSTRING(TNBFEE,1,1)  = '-'  THEN
				CONVERT(DECIMAL,REPLACE(TNBFEE,'-','')) * -1 
			ELSE 
				 CONVERT(DECIMAL,TNBFEE)
			END

	UPDATE TB_DCAT04_03  SET DACCTA  = CONVERT(DECIMAL,DACCTA)where DACCTA IS NOT NULL
	
	---TB_DCAT04_03
	UPDATE  TB_DCAT04_03
	SET DACCTA = CONVERT(DECIMAL,DACCTA)


--------------------------
-- Insumo REPORTE SIF
--------------------------
UPDATE  TB_DCAT04_01
SET RATE = '0.0000001'
WHERE Rate = '1.0e-07'


UPDATE  TB_DCAT04_01
SET Monto_Comision_Flat  = '0.00'
WHERE  Monto_Comision_Flat LIKE  '%e-0%'
------
	UPDATE TB_DCAT04_01  SET Amt30DPD  =  '0' where Amt30DPD is null
	UPDATE TB_DCAT04_01  SET Amt60DPD  =  '0' where Amt60DPD is null
	UPDATE TB_DCAT04_01  SET Amt90DPD  =  '0' where Amt90DPD is null
	UPDATE TB_DCAT04_01  SET Amt120DPD  =  '0' where Amt120DPD is null
	UPDATE TB_DCAT04_01  SET Amt150DPD  =  '0' where Amt150DPD is null
	UPDATE TB_DCAT04_01  SET Amt180DPD  =  '0' where Amt180DPD is null
	UPDATE TB_DCAT04_01  SET Amt210DPD  =  '0' where Amt210DPD is null
	UPDATE TB_DCAT04_01  SET SaldoCastigado  =  '0' where SaldoCastigado is null
	UPDATE TB_DCAT04_01  SET SaldoCapital  =  '0' where SaldoCapital is null
	UPDATE TB_DCAT04_01  SET PrincipalBalance  =  '0' where PrincipalBalance is null
	UPDATE TB_DCAT04_01  SET SaldoRendimientos  =  '0' where SaldoRendimientos is null
	UPDATE TB_DCAT04_01  SET Mora  =  '0' where Mora is null
	UPDATE TB_DCAT04_01  SET Purchases  =  '0' where Purchases is null
	UPDATE TB_DCAT04_01  SET FeePaid  =  '0' where FeePaid is null
	UPDATE TB_DCAT04_01  SET FeePaid  =  '0' where FeePaid is null
	
	UPDATE TB_DCAT04_01  SET Amt30DPD  =  '0' where Amt30DPD = ''
	UPDATE TB_DCAT04_01  SET Amt60DPD  =  '0' where Amt60DPD = ''
	UPDATE TB_DCAT04_01  SET Amt90DPD  =  '0' where Amt90DPD = ''
	UPDATE TB_DCAT04_01  SET Amt120DPD  =  '0' where Amt120DPD = ''
	UPDATE TB_DCAT04_01  SET Amt150DPD  =  '0' where Amt150DPD = ''
	UPDATE TB_DCAT04_01  SET Amt180DPD  =  '0' where Amt180DPD = ''
	UPDATE TB_DCAT04_01  SET Amt210DPD  =  '0' where Amt210DPD = ''
	UPDATE TB_DCAT04_01  SET SaldoCastigado  =  '0' where SaldoCastigado = ''
	UPDATE TB_DCAT04_01  SET SaldoCapital  =  '0' where SaldoCapital = ''
	UPDATE TB_DCAT04_01  SET PrincipalBalance  =  '0' where PrincipalBalance = ''
	UPDATE TB_DCAT04_01  SET SaldoRendimientos  =  '0' where SaldoRendimientos = ''
	UPDATE TB_DCAT04_01  SET Mora  =  '0' where Mora = ''
	UPDATE TB_DCAT04_01  SET Purchases  =  '0' where Purchases = ''
	UPDATE TB_DCAT04_01  SET FeePaid  =  '0' where FeePaid = ''
	UPDATE TB_DCAT04_01  SET FeePaid  =  '0' where FeePaid = ''
	UPDATE TB_DCAT04_01  SET FECHA_CAMBIO_STATUS = '19000101' WHERE 	FECHA_CAMBIO_STATUS = '0';		
	---
	UPDATE  tb_dcat04_01 SET BranchId = null WHERE  BranchId =''
	UPDATE  tb_dcat04_01 SET Acct = null WHERE  Acct =''
	UPDATE  tb_dcat04_01 SET OrigOpenDate = null WHERE  OrigOpenDate =''
	UPDATE  tb_dcat04_01 SET OpenDate = null WHERE  OpenDate =''
	UPDATE  tb_dcat04_01 SET DaysPastDue = null WHERE  DaysPastDue =''
	UPDATE  tb_dcat04_01 SET RecordDate = null WHERE  RecordDate =''
	UPDATE  tb_dcat04_01 SET MaturityDate = null WHERE  MaturityDate =''
	UPDATE  tb_dcat04_01 SET CreditLimit = null WHERE  CreditLimit =''
	UPDATE  tb_dcat04_01 SET Rate = null WHERE  Rate =''
	UPDATE  tb_dcat04_01 SET NumPmtsPastDue = null WHERE  NumPmtsPastDue =''
	UPDATE  tb_dcat04_01 SET AmtPmtPastDue = null WHERE  AmtPmtPastDue =''
	UPDATE  tb_dcat04_01 SET Amt30DPD = null WHERE  Amt30DPD =''
	UPDATE  tb_dcat04_01 SET Amt60DPD = null WHERE  Amt60DPD =''
	UPDATE  tb_dcat04_01 SET Amt90DPD = null WHERE  Amt90DPD =''
	UPDATE  tb_dcat04_01 SET Amt120DPD = null WHERE  Amt120DPD =''
	UPDATE  tb_dcat04_01 SET Amt150DPD = null WHERE  Amt150DPD =''
	UPDATE  tb_dcat04_01 SET Amt180DPD = null WHERE  Amt180DPD =''
	UPDATE  tb_dcat04_01 SET Amt210DPD = null WHERE  Amt210DPD =''
	UPDATE  tb_dcat04_01 SET LoanStatus = null WHERE  LoanStatus =''
	UPDATE  tb_dcat04_01 SET SaldoCastigado = null WHERE  SaldoCastigado =''
	UPDATE  tb_dcat04_01 SET CloseDate = null WHERE  CloseDate =''
	UPDATE  tb_dcat04_01 SET BlockCodeId1 = null WHERE  BlockCodeId1 =''
	UPDATE  tb_dcat04_01 SET BlockReason1 = null WHERE  BlockReason1 =''
	UPDATE  tb_dcat04_01 SET BlockCode1Date = null WHERE  BlockCode1Date =''
	UPDATE  tb_dcat04_01 SET PrincipalBalance = null WHERE  PrincipalBalance =''
	UPDATE  tb_dcat04_01 SET TypeId = null WHERE  TypeId =''
	UPDATE  tb_dcat04_01 SET Gender = null WHERE  Gender =''
	UPDATE  tb_dcat04_01 SET FullName = null WHERE  FullName =''
	UPDATE  tb_dcat04_01 SET ActivityId = null WHERE  ActivityId =''
	UPDATE  tb_dcat04_01 SET OccupationId = null WHERE  OccupationId =''
	UPDATE  tb_dcat04_01 SET ProfessionId = null WHERE  ProfessionId =''
	UPDATE  tb_dcat04_01 SET RelId = null WHERE  RelId =''
	UPDATE  tb_dcat04_01 SET DivisionTypeId = null WHERE  DivisionTypeId =''

	UPDATE TB_DCAT04_01  SET 	Creditlimit  =  CONVERT(DECIMAL(15,4),REPLACE(Creditlimit  ,'Bs.S','')),
								Rate  =  CONVERT(DECIMAL(15,4),REPLACE(Rate  ,',','.')),
								Amt30DPD  =  CONVERT(DECIMAL(15,4),REPLACE(Amt30DPD  ,'Bs.S','')),
								Amt60DPD  =  CONVERT(DECIMAL(15,4),REPLACE(Amt60DPD  ,'Bs.S','')),
								Amt90DPD  =  CONVERT(DECIMAL(15,4),REPLACE(Amt90DPD  ,'Bs.S','')),
								Amt120DPD  =  CONVERT(DECIMAL(15,4),REPLACE(Amt120DPD  ,'Bs.S','')),
								Amt150DPD  =  CONVERT(DECIMAL(15,4),REPLACE(Amt150DPD  ,'Bs.S','')),
								Amt180DPD  =  CONVERT(DECIMAL(15,4),REPLACE(Amt180DPD  ,'Bs.S','')),
								Amt210DPD  =  CONVERT(DECIMAL(15,4),REPLACE(Amt210DPD  ,'Bs.S','')),
								SaldoCastigado  =  CONVERT(DECIMAL(15,4),REPLACE(SaldoCastigado  ,'Bs.S','')),
								PrincipalBalance  =  CONVERT(DECIMAL(15,4),REPLACE(PrincipalBalance  ,'Bs.S','')),
								SaldoCapital  =  CONVERT(DECIMAL(15,4),REPLACE(SaldoCapital  ,'Bs.S','')),
								SaldoRendimientos  =  CONVERT(DECIMAL(18,2),REPLACE(RTRIM(LTRIM(SaldoRendimientos))  ,'Bs.S','')),
								Mora  =  CONVERT(DECIMAL(15,4),REPLACE(Mora  ,'Bs.S','')),
								Purchases  =  CONVERT(DECIMAL(15,4),REPLACE(Purchases  ,'Bs.S','')),
								FeePaid  =  CONVERT(DECIMAL(15,4),REPLACE(FeePaid  ,'Bs.S','')),
								DireccionH  =  LEFT(REPLACE(LTRIM(RTRIM(UPPER(DireccionH))),'''','�'),200),
								FECHA_REG_VENC_LIT_CAST = REPLACE(CONVERT(VARCHAR(10),CONVERT(DATETIME,FECHA_REG_VENC_LIT_CAST,105),111),'/',''),
								FECHA_EXIGIBILIDAD_PAGO_ULT_CUOTA = REPLACE(CONVERT(VARCHAR(10),CONVERT(DATETIME,FECHA_EXIGIBILIDAD_PAGO_ULT_CUOTA,105),111),'/',''),
								FECHA_FIN_PERIODO_GRACIA_PAGO_INTERES = REPLACE(CONVERT(VARCHAR(10),CONVERT(DATETIME,FECHA_FIN_PERIODO_GRACIA_PAGO_INTERES,105),111),'/',''),
								FECHA_CAMBIO_CAPITAL_TRANSFERIDO = REPLACE(CONVERT(VARCHAR(10),CONVERT(DATETIME,FECHA_CAMBIO_CAPITAL_TRANSFERIDO,105),111),'/',''),
								FECHA_CAMBIO_STATUS = ISNULL(REPLACE(CONVERT(VARCHAR(10),CONVERT(DATETIME,FECHA_CAMBIO_STATUS,105),111),'/',''),'19000101'),
								[%COMSION_FLAT] = CONVERT(DECIMAL(18,2),REPLACE(RTRIM(LTRIM([%COMSION_FLAT])),',','')) ,
								MONTO_COMISION_FLAT = CONVERT(DECIMAL(18,2),REPLACE(RTRIM(LTRIM(MONTO_COMISION_FLAT)),',','')) 
	
	--/* LO QUE ESTA EN CALIDAD DE DATA 2 */	
	UPDATE jf77062.TB_DMAT04 SET FechaCambioEstatusCredito ='19000101' WHERE FechaCambioEstatusCredito = ''	OR FechaCambioEstatusCredito = '0'
	UPDATE jf77062.TB_DMAT04 SET FechaRegistroVencidaLitigiooCastigada ='19000101' WHERE FechaRegistroVencidaLitigiooCastigada = ''	OR FechaRegistroVencidaLitigiooCastigada = '0'	
	UPDATE jf77062.TB_DMAT04 SET FechaExigibilidadPagoUltimaCuotaPagada ='19000101' WHERE FechaExigibilidadPagoUltimaCuotaPagada = ''	OR FechaExigibilidadPagoUltimaCuotaPagada = '0'	
	UPDATE jf77062.TB_DMAT04 SET FechaEmisionCertificacionBeneficiarioEspecial ='19000101' WHERE FechaEmisionCertificacionBeneficiarioEspecial = ''	OR FechaEmisionCertificacionBeneficiarioEspecial = '0'	
	UPDATE jf77062.TB_DMAT04 SET FechaFinPeriodoGraciaPagoInteres ='19000101' WHERE FechaFinPeriodoGraciaPagoInteres = ''	OR FechaFinPeriodoGraciaPagoInteres = '0'	
	UPDATE jf77062.TB_DMAT04 SET FechaCambioEstatusCapitalTransferido ='19000101' WHERE FechaCambioEstatusCapitalTransferido = ''	OR FechaCambioEstatusCapitalTransferido = '0'	
	
	/*Staff */
	UPDATE TB_DCAT04_01  
	SET Staff = CASE   Staff
					WHEN '1' THEN '2' --si
					WHEN '0' THEN '1' --no
				ELSE 	'0' --no defecto
				END
/*Genero */
	UPDATE TB_DCAT04_01  
	SET Gender = CASE   UPPER(Gender)
					WHEN 'M' THEN '2' -- masculino
					WHEN 'F' THEN '1' --femenino
				ELSE 	'2' --masculino defecto
				END
--				
	UPDATE TB_DCAT04_01  
	SET BlockCode1Date = SUBSTRING(RIGHT(RTRIM(BlockCode1Date),13),1,4)  + '/' + --A�O
						---MES
						CASE CHARINDEX('/',SUBSTRING(BLOCKCODE1DATE,4,2)) 	
							WHEN 0 THEN SUBSTRING(BLOCKCODE1DATE,4,2) 
							ELSE  (CASE CHARINDEX('/',SUBSTRING(RIGHT(RTRIM(BLOCKCODE1DATE),16),1,2))
								WHEN 0 THEN SUBSTRING(RIGHT(RTRIM(BLOCKCODE1DATE),16),1,2)
								ELSE '0' + SUBSTRING(RIGHT(RTRIM(BLOCKCODE1DATE),16),2,1) END) END   + '/' + 
						--DIA		
						CASE CHARINDEX('/',SUBSTRING(BLOCKCODE1DATE,1,2)) 	
							WHEN 0 THEN SUBSTRING(BLOCKCODE1DATE,1,2) 
							ELSE  '0' + SUBSTRING(BLOCKCODE1DATE,1,1) END 
						

	UPDATE TB_DCAT04_01  
	SET OrigOpenDate=
		     /* A�o */
		     SUBSTRING(RIGHT(RTRIM(OrigOpenDate),13),1,4)  + '/' + 
		     /* Mes */
		     case charindex('/',SUBSTRING(OrigOpenDate,4,2)) 	
			when 0 then SUBSTRING(OrigOpenDate,4,2) 
			 else  (CASE CHARINDEX('/',SUBSTRING(RIGHT(RTRIM(OrigOpenDate),16),1,2))
					when 0 then SUBSTRING(RIGHT(RTRIM(OrigOpenDate),16),1,2)
					 else '0' + SUBSTRING(RIGHT(RTRIM(OrigOpenDate),16),2,1) end) end   + '/' + 
		     /* Dia */
		     case charindex('/',SUBSTRING(OrigOpenDate,1,2)) 	
						when 0 then SUBSTRING(OrigOpenDate,1,2) 
						else  '0' + SUBSTRING(OrigOpenDate,1,1) end 

	UPDATE TB_DCAT04_01  SET CloseDate=
				 /* A�o */
				 SUBSTRING(RIGHT(RTRIM(CloseDate),13),1,4)  + '/' + 
				 /* Mes */
				 case charindex('/',SUBSTRING(CloseDate,4,2)) 	
				when 0 then SUBSTRING(CloseDate,4,2) 
				 else  (CASE CHARINDEX('/',SUBSTRING(RIGHT(RTRIM(CloseDate),16),1,2))
						when 0 then SUBSTRING(RIGHT(RTRIM(CloseDate),16),1,2)
						 else '0' + SUBSTRING(RIGHT(RTRIM(CloseDate),16),2,1) end) end   + '/' + 
				 /* Dia */
				 case charindex('/',SUBSTRING(CloseDate,1,2)) 	
							when 0 then SUBSTRING(CloseDate,1,2) 
							else  '0' + SUBSTRING(CloseDate,1,1) end 
						
	UPDATE TB_DCAT04_01  SET RecordDate=
				 /* A�o */
				 SUBSTRING(RIGHT(RTRIM(RecordDate),13),1,4)  + '/' + 
				 /* Mes */
				 case charindex('/',SUBSTRING(RecordDate,4,2)) 	
				when 0 then SUBSTRING(RecordDate,4,2) 
				 else  (CASE CHARINDEX('/',SUBSTRING(RIGHT(RTRIM(RecordDate),16),1,2))
						when 0 then SUBSTRING(RIGHT(RTRIM(RecordDate),16),1,2)
						 else '0' + SUBSTRING(RIGHT(RTRIM(RecordDate),16),2,1) end) end   + '/' + 
				 /* Dia */
				 case charindex('/',SUBSTRING(RecordDate,1,2)) 	
							when 0 then SUBSTRING(RecordDate,1,2) 
							else  '0' + SUBSTRING(RecordDate,1,1) end 

	UPDATE TB_DCAT04_01  SET MaturityDate =
				 /* A�o */
				 SUBSTRING(RIGHT(RTRIM(MaturityDate),13),1,4)  + '/' + 
				 /* Mes */
				 case charindex('/',SUBSTRING(MaturityDate,4,2)) 	
				when 0 then SUBSTRING(MaturityDate,4,2) 
				 else  (CASE CHARINDEX('/',SUBSTRING(RIGHT(RTRIM(MaturityDate),16),1,2))
						when 0 then SUBSTRING(RIGHT(RTRIM(MaturityDate),16),1,2)
						 else '0' + SUBSTRING(RIGHT(RTRIM(MaturityDate),16),2,1) end) end   + '/' + 
				 /* Dia */
				 case charindex('/',SUBSTRING(MaturityDate,1,2)) 	
							when 0 then SUBSTRING(MaturityDate,1,2) 
							else  '0' + SUBSTRING(MaturityDate,1,1) end 
							
	UPDATE TB_DCAT04_01  SET OpenDate=
				 /* A�o */
				 SUBSTRING(RIGHT(RTRIM(OpenDate),13),1,4)  + '/' + 
				 /* Mes */
				 case charindex('/',SUBSTRING(OpenDate,4,2)) 	
				when 0 then SUBSTRING(OpenDate,4,2) 
				 else  (CASE CHARINDEX('/',SUBSTRING(RIGHT(RTRIM(OpenDate),16),1,2))
						when 0 then SUBSTRING(RIGHT(RTRIM(OpenDate),16),1,2)
						 else '0' + SUBSTRING(RIGHT(RTRIM(OpenDate),16),2,1) end) end   + '/' + 
				 /* Dia */
				 case charindex('/',SUBSTRING(OpenDate,1,2)) 	
							when 0 then SUBSTRING(OpenDate,1,2) 
							else  '0' + SUBSTRING(OpenDate,1,1) end 	
	
--------------------------
-- Insumo lnp860
--------------------------
	--TRIGGER de TB_DCAT04_02
	UPDATE TB_DCAT04_02  SET P8RPCV  =  CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(P8RPCV,LEN(P8RPCV)-2))) + '.' + RIGHT(P8RPCV,2);
	---P8PRAN
	UPDATE  TB_DCAT04_02
	SET P8PRAN = CONVERT(DECIMAL,P8PRAN)
	---P8NOTE
	UPDATE  TB_DCAT04_02
	SET P8NOTE = CONVERT(DECIMAL,P8NOTE)

 -- Insumo Sobregiros Consumer
--------------------------

UPDATE TMP_SobregirosConsumer 
SET Fecha_Cambio_Capital_Transferido = REPLACE(convert(varchar(10),convert(datetime,Fecha_Cambio_Capital_Transferido,105),111),'/',''),
	Fecha_Cambio_Estatus_Cr�dito = REPLACE(convert(varchar(10),convert(datetime,Fecha_Cambio_Estatus_Cr�dito,105),111),'/',''),
	recorddate = REPLACE(convert(varchar(10),convert(datetime,recorddate,105),111),'/',''),
	opendate = REPLACE(convert(varchar(10),convert(datetime,opendate,105),111),'/',''),
	Fecha_Exigibilidad_Pago_�ltima_cuota_pagada = REPLACE(convert(varchar(10),convert(datetime,Fecha_Exigibilidad_Pago_�ltima_cuota_pagada,105),111),'/',''),
	Fecha_Registro_Vencida_Litigio_Castigada = REPLACE(convert(varchar(10),convert(datetime,Fecha_Registro_Vencida_Litigio_Castigada,105),111),'/',''),
	Capital_Transferido = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(Capital_Transferido,'-','0'))),',','')),
	Overdraft = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(replace(Replace(Overdraft,'Bs.S',''),',',''),'-','0'))),',','')),
	MinBalance = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(replace(Replace(MinBalance,'Bs.S',''),',',''),'-','0'))),',','')),
	Balance = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(replace(Replace(Balance,'Bs.S',''),',',''),'-','0'))),',',''))
	
-- Insumo DIRIGIDAS
--------------------------
---DIRIGIDAS

	UPDATE  RPT_STG_DIRIGIDAS_AGRICOLA_CONSUMER 
	SET NUM_CREDITO = CONVERT(DECIMAL,NUM_CREDITO), 
		RENDIMIENTOS_X_COBRAR = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR,',','')),
		RENDIMIENTOS_X_COBRAR_VENCIDOS = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR_VENCIDOS,',',''))
		

	UPDATE RPT_STG_DIRIGIDAS_AGRICOLA_CONSUMER
	SET NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '0'
	WHERE 	NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = 'NO APLICA' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA IS NULL
			
	UPDATE  RPT_STG_DIRIGIDAS_AGRICOLA_CORPORATE 
	SET NUM_CREDITO = CONVERT(DECIMAL,NUM_CREDITO),
		RENDIMIENTOS_X_COBRAR = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR,',','')),
		RENDIMIENTOS_X_COBRAR_VENCIDOS = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR_VENCIDOS,',',''))
	
	UPDATE RPT_STG_DIRIGIDAS_AGRICOLA_CORPORATE
	SET NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '0'
	WHERE 	NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = 'NO APLICA' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA IS NULL
			
	UPDATE  RPT_STG_DIRIGIDAS_HIPOTECARIO_CORTO_PLAZO 
	SET NUM_CREDITO = CONVERT(DECIMAL,NUM_CREDITO),
		RENDIMIENTOS_X_COBRAR = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR,',','')),
		RENDIMIENTOS_X_COBRAR_VENCIDOS = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR_VENCIDOS,',',''))

	UPDATE RPT_STG_DIRIGIDAS_HIPOTECARIO_CORTO_PLAZO
	SET NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '0'
	WHERE 	NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = 'NO APLICA' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA IS NULL	

	UPDATE  RPT_STG_DIRIGIDAS_HIPOTECARIO_LARGO_PLAZO 
	SET NUM_CREDITO = CONVERT(DECIMAL,NUM_CREDITO),
		RENDIMIENTOS_X_COBRAR = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR,',','')),
		RENDIMIENTOS_X_COBRAR_VENCIDOS = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR_VENCIDOS,',',''))
	
	UPDATE RPT_STG_DIRIGIDAS_HIPOTECARIO_LARGO_PLAZO
	SET NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '0'
	WHERE 	NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = 'NO APLICA' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA IS NULL

	UPDATE  RPT_STG_DIRIGIDAS_MANUFACTURA 
	SET NUM_CREDITO = CONVERT(DECIMAL,NUM_CREDITO),
		RENDIMIENTOS_X_COBRAR = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR,',','')),
		RENDIMIENTOS_X_COBRAR_VENCIDOS = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR_VENCIDOS,',',''))
	
	UPDATE RPT_STG_DIRIGIDAS_MANUFACTURA
	SET NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '0'
	WHERE 	NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = 'NO APLICA' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA IS NULL
			
	UPDATE  RPT_STG_DIRIGIDAS_MICROFINANCIERO 
	SET NUM_CREDITO = CONVERT(DECIMAL,NUM_CREDITO),
		RENDIMIENTOS_X_COBRAR = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR,',','')),
		RENDIMIENTOS_X_COBRAR_VENCIDOS = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR_VENCIDOS,',',''))
	
	UPDATE RPT_STG_DIRIGIDAS_MICROFINANCIERO
	SET NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '0'
	WHERE 	NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = 'NO APLICA' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA IS NULL
			
	UPDATE  RPT_STG_DIRIGIDAS_TURISMO 
	SET NUM_CREDITO = CONVERT(DECIMAL,NUM_CREDITO),
		RENDIMIENTOS_X_COBRAR = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR,',','')),
		RENDIMIENTOS_X_COBRAR_VENCIDOS = CONVERT(DECIMAL(18,2),REPLACE(RENDIMIENTOS_X_COBRAR_VENCIDOS,',',''))
	
	UPDATE RPT_STG_DIRIGIDAS_TURISMO
	SET NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '0'
	WHERE 	NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = 'NO APLICA' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA = '' OR
			NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA IS NULL	

-- Insumo RENDIMIENTOS CONSUMER
--------------------------
	UPDATE TMP_Rendimiento 
	SET SaldoRendXcobrar = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(SaldoRendXcobrar,',',''))), 'Bs.S', '')),
		SaldoRendXcobrarVenc = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(SaldoRendXcobrarVenc,',',''))), 'Bs.S', '')),
		SaldoRendCuentaOrden = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(SaldoRendCuentaOrden,',',''))), 'Bs.S', '')),
		SaldoRendXMora = CONVERT(DECIMAL(18,2),REPLACE(LTRIM(RTRIM(REPLACE(SaldoRendXMora,',',''))), 'Bs.S', ''))






----------------------------------------

	


