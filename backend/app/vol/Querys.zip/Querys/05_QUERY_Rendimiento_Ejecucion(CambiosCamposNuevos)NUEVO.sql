-------------------Provision Espefica-------------------------
UPDATE
  JF77062.TB_DMAT04
SET
  ProvisionEspecifica = '0.00'
where
  ProvisionEspecifica = ''
UPDATE
  JF77062.TB_DMAT04
SET
  ProvisionEspecifica = '0.00'
where
  ProvisionEspecifica is NULL ------------****************INICIO RENDIMIENTOS MUNDO CONSUMER*************-----------------
UPDATE
  TMP_Rendimiento
SET
  SaldoRendXcobrar = REPLACE(SaldoRendXcobrar, 'Bs ', ''),
  SaldoRendXcobrarVenc = REPLACE(SaldoRendXcobrarVenc, 'Bs ', ''),
  SaldoRendXMora = REPLACE(SaldoRendXMora, 'Bs ', '') -- --Verificacion de si la data esta repetida por acct en la data complemento TMP_Rendimiento
  -- select acct, count (acct) from TMP_Rendimiento
  -- group by  acct
  -- having count (acct)>1
  -- --Verificacion de si la data esta repetida por Numerocredito en la base
  -- select Numerocredito, count (Numerocredito) from jf77062.tb_dmat04
  -- group by  Numerocredito
  -- having count (Numerocredito)>1
  --order by 2 desc
  --Ejecucion de los UPDATE OJO estar atento de los casos varios (Universo NO MIGRADO y Universo MIGRADO)
  ------------------------------Acontinuacion Universo NO MIGRADO---------------------------------------
update
  jf77062.tb_dmat04
set
  RendimientosCobrar = A.SaldoRendXcobrar,
  RendimientosCobrarVencidos = A.SaldoRendXcobrarVenc,
  RendimientosCobrarMora = A.SaldoRendXMora,
  RendimientosCobrarReestructurados = CASE
    WHEN B.CodigoContable like '132%' THEN a.SaldoRendXcobrar
    ELSE '0.00'
  END,
  RendimientosCobrarAfectosReporto = '0.00',
  RendimientosCobrarLitigio = '0.00'
from
  jf77062.tb_dmat04 B
  inner join TMP_Rendimiento A on A.acct = B.Numerocredito
where
  b.tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') --67329
  ---------Acontinuacion se aplica 0,00 a todos aquellos que no hicieron cruce con rendimientos-------------
update
  jf77062.tb_dmat04
set
  RendimientosCobrar = '0.00',
  RendimientosCobrarVencidos = '0.00',
  RendimientosCobrarMora = '0.00',
  RendimientosCobrarReestructurados = '0.00',
  RendimientosCobrarAfectosReporto = '0.00',
  RendimientosCobrarLitigio = '0.00'
where
  ltrim(rtrim(Numerocredito)) not in (
    select
      ltrim(rtrim(acct)) as acct
    from
      TMP_Rendimiento nolock
  )
  and tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') ---------------------------------Acontinuacion Universo MIGRADO----------------------------------------
update
  jf77062.tb_dmat04
set
  RendimientosCobrar = r.SaldoRendXcobrar,
  RendimientosCobrarVencidos = r.SaldoRendXcobrarVenc,
  RendimientosCobrarMora = r.SaldoRendXMora,
  RendimientosCobrarReestructurados = CASE
    WHEN dm.CodigoContable like '132%' THEN r.SaldoRendXcobrar
    ELSE '0.00'
  END,
  RendimientosCobrarAfectosReporto = '0.00',
  RendimientosCobrarLitigio = '0.00'
from
  jf77062.tb_dmat04 dm
  inner join TMP_Migrados M on M.oldacct = dm.Numerocredito
  inner join TMP_Rendimiento R on r.acct = m.newacct
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') --283
  -----------------Acontinuacion CASOS BORDES LOS CUALES SE ATACAN INDIVIDUALMENTE-----------------------
  -----------------Peeguntar a Jos.
-- update
--   jf77062.tb_dmat04
-- set
--   RendimientosCobrar = A.SaldoRendXcobrar,
--   RendimientosCobrarVencidos = A.SaldoRendXcobrarVenc,
--   RendimientosCobrarMora = A.SaldoRendXMora,
--   RendimientosCobrarReestructurados = CASE
--     WHEN B.CodigoContable like '132%' THEN a.SaldoRendXcobrar
--     ELSE '0.00'
--   END,
--   RendimientosCobrarAfectosReporto = '0.00',
--   RendimientosCobrarLitigio = '0.00'
-- from
--   jf77062.tb_dmat04 B
--   inner join TMP_Rendimiento A on A.acct = '6900000371'
-- where
--   B.Numerocredito = '6000000371'
--   And b.tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') --1
  ------------------------------------------------------------------------------------------------------------
  ---verificar que no tenga valores basura 'Bs %'
UPDATE
  jf77062.tb_dmat04
SET
  RendimientosCobrar = REPLACE(RendimientosCobrar, 'Bs.S', ''),
  RendimientosCobrarVencidos = REPLACE(RendimientosCobrarVencidos, 'Bs.S', ''),
  RendimientosCobrarMora = REPLACE(RendimientosCobrarMora, 'Bs.S', ''),
  RendimientosCobrarReestructurados = REPLACE(RendimientosCobrarReestructurados, 'Bs.S', '')
WHERE
  RendimientosCobrar LIKE ('Bs%') ---verificacion de que todos los reg tengan valor
  -- select
  -- 	Numerocredito, RendimientosCobrar, RendimientosCobrarVencidos, RendimientosCobrarMora
  -- from
  -- 	jf77062.tb_dmat04 dm
  -- where
  -- 	tipodc in ('1','2','3','4','5','6','9','12','14','15')--37392
  ------------******************FIN RENDIMIENTOS MUNDO CONSUMER*************-----------------
  ---------------------------------------------------****************INICIO RENDIMIENTOS MUNDO CORPORATIVO*************-------------------------------------------------
  -- select referencia, count(*)
  -- from dbo.TMP_Rendimientos_Corporativo RC group by referencia
  -- having count (referencia)>1
  -------------------------------RENDIMIENTOS VIGENTES--------------------------------------
UPDATE
  jf77062.tb_dmat04
SET
  RendimientosCobrar = RC.Saldo,
  RendimientosCobrarVencidos = '0',
  RendimientosCobrarMora = '0'
from
  jf77062.tb_dmat04 DM
  Inner join TMP_Rendimientos_Corporativo RC on RC.referencia = DM.NumeroCredito
where
  RC.Descripcion in ('Vigente', 'Reestructurado')
  and tipodc in ('8', '11', '10', '7', '13', '16') -------------------------------RENDIMIENTOS VENCIDOS--------------------------------------
UPDATE
  jf77062.tb_dmat04
SET
  RendimientosCobrar = '0',
  RendimientosCobrarVencidos = RC.Saldo,
  RendimientosCobrarMora = '0'
from
  jf77062.tb_dmat04 DM
  Inner join TMP_Rendimientos_Corporativo RC on RC.referencia = DM.NumeroCredito
where
  RC.Descripcion = 'Vencido'
  and tipodc in ('8', '11', '10', '7', '13', '16') -------------------------------RENDIMIENTOS MORA--------------------------------------
UPDATE
  jf77062.tb_dmat04
SET
  RendimientosCobrar = '0',
  RendimientosCobrarVencidos = '0',
  RendimientosCobrarMora = RC.Saldo
from
  jf77062.tb_dmat04 DM
  Inner join TMP_Rendimientos_Corporativo RC on RC.referencia = DM.NumeroCredito
where
  RC.Descripcion = 'Mora'
  and tipodc in ('8', '11', '10', '7', '13', '16') -------------------------------RENDIMIENTOS REESTRUCTURADOS--------------------------------------777
UPDATE
  jf77062.tb_dmat04
SET
  RendimientosCobrarReestructurados = ISNULL(RC.Saldo, '0')
from
  jf77062.tb_dmat04 DM
  Inner join TMP_Rendimientos_Corporativo RC on RC.referencia = DM.NumeroCredito
where
  RC.Descripcion = 'Reestructurado'
  and tipodc in ('8', '11', '10', '7', '13', '16') -------------------------------RENDIMIENTOS AFECTOS REPORTO--------------------------------------777
UPDATE
  jf77062.tb_dmat04
SET
  RendimientosCobrarAfectosReporto = ISNULL(RC.Saldo, '0')
from
  jf77062.tb_dmat04 DM
  Inner join TMP_Rendimientos_Corporativo RC on RC.referencia = DM.NumeroCredito
where
  RC.Descripcion = 'Efectos'
  and tipodc in ('8', '11', '10', '7', '13', '16') -------------------------------RENDIMIENTOS RendimientosCobrarLitigio--------------------------------------777
UPDATE
  jf77062.tb_dmat04
SET
  RendimientosCobrarLitigio = ISNULL(RC.Saldo, '0')
from
  jf77062.tb_dmat04 DM
  Inner join TMP_Rendimientos_Corporativo RC on RC.referencia = DM.NumeroCredito
where
  RC.Descripcion = 'Litigio'
  and tipodc in ('8', '11', '10', '7', '13', '16') -------------------------------CUANDO NO SE CONSIGA EN EL INSUMO DETALLE143--------------------------------------
update
  jf77062.tb_dmat04
set
  RendimientosCobrar = '0.00',
  RendimientosCobrarVencidos = '0.00',
  RendimientosCobrarMora = '0.00'
where
  ltrim(rtrim(Numerocredito)) not in (
    select
      ltrim(rtrim(referencia)) as acct
    from
      TMP_Rendimientos_Corporativo
  )
  and tipodc in ('7', '8', '10', '13', '11') --84
  ------------******************FIN RENDIMIENTOS MUNDO CORPORATIVO*************-----------------