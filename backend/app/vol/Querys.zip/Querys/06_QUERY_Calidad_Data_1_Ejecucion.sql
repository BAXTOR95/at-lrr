declare @UltFecha as varchar(20)
set
  @UltFecha = '2019/11/30' ---mes a reportar -----------------------FECHA CAMBIAR OJO !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  declare @PenFecha as varchar(20)
Set
  @Penfecha = substring(@UltFecha, 1, 8) + convert(
    varchar(20),(convert(numeric(10), substring(@UltFecha, 9, 2)) -1)
  )
select
  @ultfecha as ultfecha,
  @penfecha as pencha into #fechasup
SELECT
  * INTO #TEMP_AT04_MesAnterior FROM jf77062.TB_DMAT04_TransmitidoOctubre2019 -- OJO Cambiar tabla !!!
  /*Detectar si hay registros repetidos en el reporte*/
  --no debe dar
  -- select Numerocredito, count(Numerocredito)
  -- from jf77062.TB_DMAT04
  -- group by Numerocredito
  -- having count(Numerocredito) > 1
  --Verificamos que NO debe existir codigocontable 9999999999, de ser asi correr el delete
Delete from jf77062.tb_dmat04
where
  codigocontable like('99999%') ---------------------------------------------------------------------------------------------------
  -- update jf77062.tb_dmat04 set NombreGrupoEconomicoFinanciero ='BAKER HUGHES 01'
  -- where numerocredito in ('8160050309')
  -- update jf77062.tb_dmat04 set NombreGrupoEconomicoFinanciero ='DIAGEO'
  -- where numerocredito in ('8161390303')
  -- update jf77062.tb_dmat04 set NombreGrupoEconomicoFinanciero ='HONEYWELL INTERNATIONAL INC'
  -- where numerocredito in ('8161470301')
  -- update jf77062.tb_dmat04 set NombreGrupoEconomicoFinanciero ='FMC TECHNOLOGIE'
  -- where numerocredito in ('8160430305')
  -- update jf77062.tb_dmat04 set NombreGrupoEconomicoFinanciero ='HUAWEI INVEST01'
  -- where numerocredito in ('8160490313')
  -- update jf77062.tb_dmat04 set NombreGrupoEconomicoFinanciero ='NABORS INDUSTRIES LTD'
  -- where numerocredito in ('8160550307')
  -- update jf77062.tb_dmat04 set NombreGrupoEconomicoFinanciero ='GRUPO BELCORP'
  -- where numerocredito in ('8170400309')
  -- update jf77062.tb_dmat04 set NombreGrupoEconomicoFinanciero ='BAYER AG'
  -- where numerocredito in ('8170470309')
  -- update jf77062.tb_dmat04 set NombreGrupoEconomicoFinanciero ='TECHINT GROUP'
  -- where numerocredito in ('8170540319')
  -- update jf77062.tb_dmat04 set NombreGrupoEconomicoFinanciero ='HUAWEI INVEST01'
  -- where numerocredito in ('8170550308')
  ---------------------------------------------------------------------------------------------------
  --Query para arreglar los rif de cliente ALSTOM VENEZUELA S.A.
  ---------------------------------------------------------------------------------------------------
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '000737320',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '000737320'
  -- where numerocredito in ('8132550305',
  -- '8132700301',
  -- '8132770306',
  -- '8132810301',
  -- '8132950303',
  -- '8133110309',
  -- '8133390306',
  -- '8140170303',
  -- '8133260313',
  -- '8141140310',
  -- '8140980301',
  -- '8140940301',
  -- '8141290320',
  -- '8141540311',
  -- '8141920308',
  -- '8141950314',
  -- '8143030311',
  -- '8143040313',
  -- '8142810301',
  -- '8142810302',
  -- '8142810304')
  -- --CONVECA
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '070069279',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '070069279'
  -- where numerocredito = '1181721015'
  -- --
  -- -- TOTALOILANDG .
  -- update jf77062.tb_dmat04 set
  -- TipoCliente='J',
  -- IdentificacionCliente='301653645',
  -- TipoClienteRIF='J',
  -- IdentificacionTipoClienteRIF='301653645'
  -- where numerocredito in ('1188081033')
  -- -- ALICE NEUMAT  .
  -- update jf77062.tb_dmat04 set
  -- TipoCliente='J',
  -- IdentificacionCliente='000146780',
  -- TipoClienteRIF='J',
  -- IdentificacionTipoClienteRIF='000146780'
  -- where numerocredito in ('553941012')
  -- -- ZURICHSEGURO.
  -- update jf77062.tb_dmat04 set
  -- TipoCliente='J',
  -- IdentificacionCliente='000340242',
  -- TipoClienteRIF='J',
  -- IdentificacionTipoClienteRIF='000340242'
  -- where numerocredito in ('281071052')
  -- --SERV ONLINE
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '000526621',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '000526621'
  -- where numerocredito = '1222311018'
  -- --XLVENEZUELA
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '002602449 ',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '002602449 '
  -- where numerocredito in ('288581023','288581015')
  -- --TRANSPORTADO
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '301848802',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '301848802'
  -- where numerocredito = '1199411039'
  -- ---COMERC.LUELU
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '070139412',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '070139412'
  -- where numerocredito = '1196771013'
  -- --BAPTISTA GARCIA INGRID MARIELIS
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'V',
  -- 	IdentificacionCliente = '11201212',
  -- 	TipoClienteRIF = 'V',
  -- 	IdentificacionTipoClienteRIF = '11201212'
  -- where numerocredito = '1001324872'
  -- --SAMSUNG ENGI
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '296218994',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '296218994'
  -- where numerocredito = '1215261014'
  -- --UNILEVER ANDINA VENEZUELA SA
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '000564868',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '000564868'
  -- where numerocredito = '289581036'
  -- --SILGANWHITE
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '301753151',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '301753151'
  -- where numerocredito = '1193381014'
  -- --CONSTRUCTORA SANDIMO CA
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '313448478',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '313448478'
  -- where numerocredito = '1221151018'
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '000737320',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '000737320'
  -- where numerocredito = '8141350317'
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '304638841',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '304638841'
  -- where numerocredito = '1182891028'
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '300950204',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '300950204'
  -- where numerocredito = '1173621023'
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '085007482',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '085007482'
  -- where numerocredito = '1055251024'
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '000347980',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '000347980'
  -- where numerocredito = '297051042'
  -- update jf77062.tb_dmat04
  -- set 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '002647647',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '002647647'
  -- where numerocredito = '1105901012'
  -- UPDATE jf77062.tb_dmat04
  -- SET 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '002605766',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '002605766'
  -- where numerocredito = '1218481011'
  -- UPDATE jf77062.tb_dmat04
  -- SET 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '075581164',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '075581164'
  -- where numerocredito = '1212571013'
  -- UPDATE jf77062.tb_dmat04
  -- SET 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '303098118',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '303098118'
  -- where numerocredito = '1213781023'
  ---------------------------------------------------------------------------------------------------
UPDATE jf77062.tb_dmat04
SET
  MontoOriginal = CapitalCastigado,
  MontoInicial = CapitalCastigado
FROM jf77062.tb_dmat04 DM
INNER JOIN TB_dcat04_09 AcctH on AcctH.Acct = DM.NumeroCredito
  and APPID = '50' --account history
WHERE
  DM.EstadoCredito = '3'
  AND CONVERT(DECIMAL(12, 4), DM.MontoLineaCredito) = 0.0000
  AND DM.tipodc in ('1', '2', '3', '4', '9', '14', '15')
  AND NumeroCredito NOT LIKE ('4858%') ---------------------------------------------------------------------------------------------------
  ---VERIFICACION del campo saldo con valores 0 o negativos para ser reportados al usuario
  --solo es permitido cuando el estadocredito =2, situacioncredito = 0 y codigocontable comience 131
  -- select  Saldo, numerocredito, estadocredito, codigocontable,situacioncredito , tipodc
  -- FROM jf77062.tb_dmat04
  -- where 	convert(decimal(18,2), Saldo) <= 0.00 and
  -- 		estadocredito <> '2' and
  -- 		situacioncredito <> '0' and
  -- 		codigocontable not like ('131%')
  ---------------------------------------------------------------------------------------------------
  --------------PENDIENTE----------------------
update jf77062.tb_dmat04
set
  FechaVencimientoUltimaCoutaCapital = FechaLiquidacion,
  FechaVencimientoUltimaCuotaInteres = FechaLiquidacion
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and estadocredito = '3' ---------------------------------------------------------------------------------------------------
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaCapital = '1900/01/01',
  UltimaFechaCancelacionCuotaIntereses = '1900/01/01'
where
  estadocredito = '1' --190
  and tipodc in ('0', '1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and saldo = MontoInicial ---------------------------------------------------------------------------------------------------
  --verificar que UltimaFechaCancelacionCuotaIntereses sea 19000101
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaIntereses = '1900/01/01'
where
  tipodc in ('13')
  and saldo = Montooriginal
  and convert (int, PeriodicidadPagoInteresCredito) < '1024'
  and UltimaFechaCancelacionCuotaIntereses <> '1900/01/01' ---------------------------------------------------------------------------------------------------
  --Verificar que tipocredito = '1' cuando  tipodc in ('3') and codigocontable = '1330510102'
  -- correr query de no cumplirse que tipocredito = '1' cuando  tipodc in ('3') and codigocontable = '1330510102'
update jf77062.tb_dmat04
set
  tipocredito = '1'
where
  tipodc in ('3')
  and codigocontable = '1330510102'
  and tipocredito <> '1' ---------------------------------------------------------------------------------------------------
  --verificar que clasificacionriesgo = 0
update jf77062.tb_dmat04
set
  clasificacionriesgo = '0'
where
  tipodc in ('5')
  and estadocredito in ('2', '3')
  and clasificacionriesgo <> '0' ---------------------------------------------------------------------------------------------------
  --Verificar que tipocredito = '0' cuando  estadocredito = '3'
  -- correr query de no cumplirse que tipocredito = '0' cuando  estadocredito = '3'
update jf77062.tb_dmat04
set
  tipocredito = 0
where
  estadocredito = '3'
  and tipocredito <> '0' ---------------------------------------------------------------------------------------------------
  --verificar que estadocredito = 3 , tipocredito = 0 y SituacionCredito = 0
  --CUANDO tipodc in ('5') and codigocontable = '8190310100' sino se setean esos valores para dichos campos
update jf77062.tb_dmat04
set
  estadocredito = '3'
where
  tipodc in ('5')
  and codigocontable = '8190310100'
  and estadocredito <> '3' ---*****----
update jf77062.tb_dmat04
set
  tipocredito = '0'
where
  tipodc in ('5')
  and codigocontable = '8190310100'
  and tipocredito <> '0' ---*****----
update jf77062.tb_dmat04
set
  SituacionCredito = '0'
where
  tipodc in ('5')
  and codigocontable = '8190310100'
  and SituacionCredito <> '0' ---------------------------------------------------------------------------------------------------
  --verificar que si el tipodc in ('12') estadocredito <> 1 , tipocredito = 0
  --el campo NombreProyectoUnidadProduccion = '' sino se setearlo
update jf77062.tb_dmat04
set
  NombreProyectoUnidadProduccion = ''
where
  tipodc in ('12')
  and estadocredito <> '1'
  or tipocredito = '0'
  and (
    NombreProyectoUnidadProduccion is not null
    or NombreProyectoUnidadProduccion <> ''
  ) ---------------------------------------------------------------------------------------------------
  --Buscar en meses anteriores el campo DomicilioFiscal CUANDO el DM del mes contenga valore NULL
update jf77062.tb_dmat04
set
  DomicilioFiscal = AT04_ANT.DomicilioFiscal
FROM jf77062.tb_dmat04 DM
inner join #TEMP_AT04_MesAnterior AT04_ANT on  DM.numerocredito = AT04_ANT.numerocredito
where
  DM.DomicilioFiscal is null
  OR DM.DomicilioFiscal = '' --info faltante de DOMICIO FISCAL se setea a el domicilio por defecto
update jf77062.tb_dmat04
set
  DomicilioFiscal = 'Av. Casanova Centro Comercial el Recreo Torre Norte Citibank'
where
  DomicilioFiscal is null
  OR DomicilioFiscal = '' ---------------------------------------------------------------------------------------------------
  --Verifica que el campo DireccionProyectoUnidadProduccion para estas carteras se encuentre llenas
  --se llena DireccionProyectoUnidadProduccion cuando es null con el campo DomicilioFiscal
update jf77062.tb_dmat04
set
  DireccionProyectoUnidadProduccion = DomicilioFiscal
where
  tipodc in ('8', '11', '12')
  and DireccionProyectoUnidadProduccion is null ---------------------------------------------------------------------------------------------------
  --Verificar que deben ser null de no ser asi correr el update
update jf77062.tb_dmat04
set
  DireccionProyectoUnidadProduccion = '',
  NombreProyectoUnidadProduccion = ''
where
  tipodc not in ('8', '11', '12')
  and (
    DireccionProyectoUnidadProduccion <> ''
    or NombreProyectoUnidadProduccion <> ''
  ) ---------------------------------------------------------------------------------------------------
  --Verificar que deben ser 0 de no ser asi correr el update
update jf77062.tb_dmat04
set
  NumeroRegistro_ConstanciaMPPAT = '0'
where
  tipodc not in ('11', '12')
  and tipocredito <> '4'
  and NumeroRegistro_ConstanciaMPPAT <> '0' ---------------------------------------------------------------------------------------------------
  --verificacion de data duplicada en el card account
  -- select acct, count (acct)
  -- from TMP_CARD_ACCOUNT_AT04
  -- group by  acct
  -- having count (acct)>1
update jf77062.tb_dmat04
set
  FechaVencimientoUltimaCoutaCapital = CardAcct.Duedate,
  FechaVencimientoUltimaCuotaInteres = CardAcct.Duedate
from jf77062.tb_dmat04 DM
Inner join TMP_CARD_ACCOUNT_AT04 CardAcct on CardAcct.Acct = DM.Numerocredito --card account
where
  tipodc in ('5')
  and FechaVencimientoUltimaCoutaCapital is NULL ---------------------------------------------------------------------------------------------------
  --verificacion de data duplicada en el TMP_ATAR_AT04
  -- select cardnumber, count(*)
  -- from TMP_ATAR_AT04
  -- group by cardnumber
  -- order by 2 desc
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaCapital = CONVERT(VARCHAR(10), convert (datetime, Atar.Paydate), 111),
  UltimaFechaCancelacionCuotaIntereses = CONVERT(VARCHAR(10), convert (datetime, Atar.Paydate), 111)
from jf77062.tb_dmat04 DM
Inner join TMP_ATAR_AT04 Atar on Atar.cardnumber = DM.Numerocredito
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') ---------------------------------------------------------------------------------------------------
  --verificar que no existan fechas en null
update jf77062.tb_dmat04
set
  FechaVencimientoUltimaCoutaCapital = '1900/01/01'
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and FechaVencimientoUltimaCoutaCapital is null
update jf77062.tb_dmat04
set
  FechaVencimientoUltimaCoutaCapital = '1900/01/01'
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and FechaVencimientoUltimaCoutaCapital like ('0000/00/00')
update jf77062.tb_dmat04
set
  FechaVencimientoUltimaCuotaInteres = '1900/01/01'
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and FechaVencimientoUltimaCuotaInteres is null
update jf77062.tb_dmat04
set
  FechaVencimientoUltimaCuotaInteres = '1900/01/01'
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and FechaVencimientoUltimaCuotaInteres like ('0000/00/00')
update jf77062.tb_dmat04
set
  FechaCancelacionTotal = '1900/01/01'
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and FechaCancelacionTotal is null
update jf77062.tb_dmat04
set
  FechaCancelacionTotal = '1900/01/01'
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and FechaCancelacionTotal like ('0000/00/00')
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaIntereses = '1900/01/01'
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and UltimaFechaCancelacionCuotaIntereses is null
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaIntereses = '1900/01/01'
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and UltimaFechaCancelacionCuotaIntereses like ('0000/00/00')
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaCapital = '1900/01/01'
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and UltimaFechaCancelacionCuotaCapital = ''
  or UltimaFechaCancelacionCuotaCapital is null
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaCapital = '1900/01/01'
where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and UltimaFechaCancelacionCuotaCapital like ('0000/00/00') ---------------------------------------------------------------------------------------------------
  --Verificamos que cuadno sea el mundo consumer y Saldo = MontoInicial y EstadoCredito = '1'
  --los campos UltimaFechaCancelacionCuotaCapital / UltimaFechaCancelacionCuotaIntereses deben ser '1900/01/01'
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaCapital = '1900/01/01',
  UltimaFechaCancelacionCuotaIntereses = '1900/01/01'
where
  tipodc in ('0', '1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and convert(decimal(18, 2), Saldo) = convert(decimal(18, 2), MontoInicial)
  and EstadoCredito = '1' ---------------------------------------------------------------------------------------------------
  --Realiza el cruce con la informacion de AcctH (ACCOUNT HISTORY) para obtener LastRcvdPmtDate
  --***--
UPDATE jf77062.tb_dmat04
SET
  UltimaFechaCancelacionCuotaCapital = replace(CONVERT(VARCHAR(10), LastRcvdPmtDate, 111), '-', '/')
FROM jf77062.tb_dmat04 DM
INNER JOIN TB_dcat04_09 AcctH on AcctH.Acct = DM.NumeroCredito
  and APPID = '50'
  and LastRcvdPmtDate is not null
  AND LastRcvdPmtDate <> 'NULL' --JC
WHERE
  DM.tipodc in ('5')
  and UltimaFechaCancelacionCuotaCapital = '1900/01/01' --***--
UPDATE jf77062.tb_dmat04
SET
  UltimaFechaCancelacionCuotaIntereses = replace(CONVERT(VARCHAR(10), LastRcvdPmtDate, 111), '-', '/')
FROM jf77062.tb_dmat04 DM
INNER JOIN TB_dcat04_09 AcctH on AcctH.Acct = DM.NumeroCredito
  and APPID = '50'
  and LastRcvdPmtDate is not null
  AND LastRcvdPmtDate <> 'NULL' --JC
WHERE
  DM.tipodc in ('5')
  and UltimaFechaCancelacionCuotaIntereses = '1900/01/01' ---------------------------------------------------------------------------------------------------
  --Verificar que el campo UltimaFechaCancelacionCuotaCapital = 1900/01/01 cuando se cumpla la condicion
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaCapital = '1900/01/01'
where
  tipodc in ('13')
  and convert(decimal(18, 2), Saldo) = convert(decimal(18, 2), MontoInicial)
  and UltimaFechaCancelacionCuotaCapital <> '1900/01/01' ---------------------------------------------------------------------------------------------------
  --Verificar que si traer informacion esta seleccion se debe crear el UPDATE en el cual se le seteara
  --en el campo UltimaFechaCancelacionCuotaIntereses y el campo UltimaFechaCancelacionCuotaCapital
  --el valor del campo FechaLiquidacion
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaIntereses = FechaLiquidacion
where
  tipodc in ('13')
  and convert(decimal(18, 2), Saldo) <> convert(decimal(18, 2), MontoInicial) --
  and UltimaFechaCancelacionCuotaIntereses = '1900/01/01'
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaCapital = FechaLiquidacion
where
  tipodc in ('13')
  and convert(decimal(18, 2), Saldo) <> convert(decimal(18, 2), MontoInicial) --
  and UltimaFechaCancelacionCuotaCapital = '1900/01/01' ---------------------------------------------------------------------------------------------------
  --tipodc 11
  --definicion:
  --si el valor del campo Saldo es igual al campo Monto Original,
  --y el valor del campo Codigo Contable empiece por (133,134),
  --y el valor del campo Modalidad Hipotecaria es distinto de 2,
  --y el valor del campo Tipo de Credito es distinto de 6
  --Entonces debe cumplirse que el
  --valor del campo 47. Ultima Fecha de Cancelacion de la Cuota Capital  sea igual a 19000101
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaCapital = '1900/01/01'
where
  tipodc in ('11')
  and convert(decimal(18, 2), Saldo) = convert(decimal(18, 2), MontoOriginal) --
  and CodigoContable like ('133%')
  and ModalidadHipoteca <> '2'
  and TipoCredito <> '6'
update jf77062.tb_dmat04
set
  UltimaFechaCancelacionCuotaCapital = '1900/01/01'
where
  tipodc in ('11')
  and convert(decimal(18, 2), Saldo) = convert(decimal(18, 2), MontoOriginal) --
  and CodigoContable like ('134%')
  and ModalidadHipoteca <> '2'
  and TipoCredito <> '6' ---------------------------------------------------------------------------------------------------
  ---Verificacion del campo saldo mayor que MontoOriginal y MontoInicial
update jf77062.tb_dmat04
set
  MontoOriginal = Saldo,
  MontoInicial = Saldo
where
  convert(decimal(18, 2), Saldo) > convert(decimal(18, 2), MontoOriginal)
  and convert(decimal(18, 2), Saldo) > convert(decimal(18, 2), MontoInicial) ---------------------------------------------------------------------------------------------------
  ----VERIFICACION CAMPO SALDO CUANDO ES NULL
  --VERIFICACION DEL CAMPO SALDO, ESTE NO DEBE SER NULL DE SERLO INVESTIGAR(POSIBLEMENTE SEAN CASOS MIGRADOS)
  --Para los casos migrados con ESTADO CREDITO = 1 siguiente query:
update jf77062.tb_dmat04
set
  Saldo = CONVERT(DECIMAL(15, 4), LDWH.SaldoCapital)
from jf77062.tb_dmat04 DM
inner join TMP_Migrados M on M.oldacct = DM.numerocredito
inner join tb_dcat04_01 LDWH on LDWH.acct = M.newacct
Where
  tipodc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15')
  and DM.ESTADOCREDITO = '1' --283
  --Para los casos migrados con ESTADO CREDITO = 2 siguiente query:
update jf77062.tb_dmat04
set
  Saldo = 0
from jf77062.tb_dmat04 DM
inner join TMP_Migrados M on M.oldacct = DM.numerocredito
inner join tb_dcat04_01 LDWH on LDWH.acct = M.newacct
Where
  DM.ESTADOCREDITO = '2' --Para los casos migrados con ESTADO CREDITO = 3 siguiente query:
update jf77062.tb_dmat04
set
  Saldo = CONVERT(DECIMAL(15, 4), LDWH.SaldoCastigado)
from jf77062.tb_dmat04 DM
inner join TMP_Migrados M on M.oldacct = DM.numerocredito
inner join tb_dcat04_01 LDWH on LDWH.acct = M.newacct
Where
  DM.ESTADOCREDITO = '3' ----------------------------CASOS BORDES QUE SON ATACADOS INDIVIDUALMENTE--------------------------------
  -- update jf77062.tb_dmat04 set Saldo= CONVERT(DECIMAL(15,4),LDWH.SaldoCapital)
  -- from jf77062.tb_dmat04 DM
  -- inner join tb_dcat04_01 LDWH on LDWH.acct  = '6900000371'
  -- Where DM.Numerocredito = '6000000371'
  -- 	AND tipodc in ('1','2','3','4','5','6','9', '12', '14','15')
  -- 	and DM.ESTADOCREDITO = '1'
  ----VERIFICACION CAMPO SALDO CUANDO ES NULL PARA TDC
  --POR DEFINICIONES SE LE DEBE COLOCAR EL VALOR DEL CAMPO MORA Y SETEAR TAMBIEN EL CAMPO SituacionCredito = 3
UPDATE jf77062.tb_dmat04
SET
  SituacionCredito = '3',
  saldo = LDWH.MORA
FROM jf77062.tb_dmat04 DM
inner join tb_dcat04_01 LDWH on LDWH.acct = DM.NUMEROCREDITO
where
  tipodc in ('5') --- TDC
  and SALDO IS NULL ------------------------------------------------------------------------------------------------------
  --Actualizacion del RIF a la cartera SOBREGIROS
UPDATE jf77062.tb_dmat04
SET
  TipoClienteRIF = TipoCliente,
  IdentificacionTipoClienteRIF = CASE
    WHEN TipoCliente IN ('V', 'E') THEN SUBSTRING(
      dbo.GetRif(TipoCliente + IdentificacionCliente),
      2,
      20
    )
    ELSE IdentificacionCliente
  END
WHERE
  tipodc = '16' ------------------------------------------------------------------
  --AJUSTE QUERY SOBRE CAMPO RIF
UPDATE jf77062.tb_dmat04
SET
  TipoClienteRIF = TipoCliente,
  IdentificacionTipoClienteRIF = CASE
    WHEN TipoCliente IN ('V', 'E') THEN SUBSTRING(
      dbo.GetRif(TipoCliente + IdentificacionCliente),
      2,
      20
    )
    ELSE IdentificacionCliente
  END
WHERE
  SUBSTRING(identificaciontipoclienterif, 1, 1) in ('J', 'V', 'E', 'G', 'I', 'P') ---------------------------------------------------------------------------------------------------
  --Actualizacion del CODIGO DE PARROQUIA a la cartera SOBREGIROS
  --casos especial
  --cuando sea oficina 10 verificar si aplica esta definicion de poner 3
update jf77062.tb_dmat04
set
  oficina = '3'
where
  tipodc = '16'
  and oficina = '10' -----------------------------------------------------------------
UPDATE jf77062.tb_dmat04
SET
  CodigoParroquia = CASE
    WHEN oficina = '2' THEN '010109'
    WHEN oficina = '3' THEN '150701'
    WHEN oficina = '4' THEN '081407'
    WHEN oficina = '5' THEN '231308'
    WHEN oficina = '6' THEN '150701'
    WHEN oficina = '7' THEN '030801'
    WHEN oficina = '8' THEN '032101'
    ELSE ''
  END
WHERE
  tipodc = '16' ---------------------------------------------------------------------------------------------------
  --VERIFICAMOS QUE EL ESTADO DEL CREDITO = 3 CUANDO CODIGOCONTABLE COMIENCE POR 133
  --DE NO CUMPLIR EL COMENTARIO ANTERIOR CORRER EL UPDATE
UPDATE jf77062.tb_dmat04
SET
  EstadoCredito = '3'
WHERE
  tipodc = '13'
  AND CODIGOCONTABLE LIKE ('133%')
  AND EstadoCredito <> '3' ---------------------------------------------------------------------------------------------------
  ----------**************CALIDAD CORPORATIVO NO DIRIGIDO***************--------------------
  --INSUMO COMPLEMENTOS CORPORATIVO NO DIRIGIDO
  --ACTUALIZACION DE CAMPOS SEGUN COMPLEMENTOS
UPDATE jf77062.tb_dmat04
SET
  ClasificacionRiesgo = C.Clase_Riesgo,
  ActividadCliente = c.Actividad_Cliente,
  TipoGarantiaPrincipal = c.TIPO_GARANTIA,
  NombreGrupoEconomicoFinanciero = c.GRUPO_ECONOMICO,
  DestinoCredito = 'XXX' --hasta nueva definicion
from jf77062.tb_dmat04 DM
inner join TMP_CORPORATIVO_NO_DIRIGIDO_AT04 C on C.Numero_Credito = DM.numerocredito
WHERE
  tipodc = '13' ------------------------------------------------------------------------------
  --DM
  --verificacion de data duplicada en la TMP_VZDWAMBS_AT04
  -- select acct, count(acct)
  -- from TMP_VZDWAMBS_AT04
  -- group by acct --order by 2 desc
  -- having count (acct)>1
  --REALIZAMOS LA ACTUALIZACION -----------------------------------------------------------------------------------------------------------------------------------------
UPDATE jf77062.tb_dmat04
SET
  MontoOriginal = convert(varchar (20), LASTCRLIM),
  MontoInicial = convert(varchar (20), LASTCRLIM),
  FechaVencimientoUltimaCoutaCapital = CONVERT(VARCHAR(10), DATEPMTDUE, 111),
  FechaVencimientoUltimaCuotaInteres = CONVERT(VARCHAR(10), DATEPMTDUE, 111)
from jf77062.tb_dmat04 DM
inner join TMP_VZDWAMBS_AT04 VZ on VZ.acct = DM.numerocredito
where
  tipodc in ('5', '9') --CUANDO EL EN AMBS NOS TRAIGA FECHAS NULL
  --REALIZAMOS LA ACTUALIZACION
UPDATE jf77062.tb_dmat04
SET
  FechaVencimientoUltimaCoutaCapital = CONVERT(
    VARCHAR(10),
    CONVERT(DATETIME, FechaLiquidacion) + 20,
    111
  )
from jf77062.tb_dmat04 DM
inner join TMP_VZDWAMBS_AT04 VZ on VZ.acct = DM.numerocredito
WHERE
  tipodc in ('5', '9')
  and FechaVencimientoUltimaCoutaCapital is null
UPDATE jf77062.tb_dmat04
SET
  FechaVencimientoUltimaCuotaInteres = CONVERT(
    VARCHAR(10),
    CONVERT(DATETIME, FechaLiquidacion) + 20,
    111
  )
from jf77062.tb_dmat04 DM
inner join TMP_VZDWAMBS_AT04 VZ on VZ.acct = DM.numerocredito
WHERE
  tipodc in ('5', '9')
  and FechaVencimientoUltimaCuotaInteres is null ------------------------------------------------------------------------------------------------------------
  --ACTUALIZACION DEL CAMPO RELACION CREDITICIA cuando sea null
  --REALIZAMOS LA ACTUALIZACION
UPDATE jf77062.tb_dmat04
SET
  RelacionCrediticia = CASE
    WHEN cfg.staff = '0' THEN 1
    WHEN cfg.staff = '1' THEN 2
    ELSE ''
  END
from jf77062.tb_dmat04 DM
inner join TMP_Migrados M on M.oldacct = DM.Numerocredito
inner join tb_dcat04_01 LDWH on LDWH.acct = M.NEWacct
INNER JOIN TB_CFGTypeSiF CFG ON CFG.Typeid = LDWH.Typeid
where
  tipodc = '6'
  and RelacionCrediticia is null ------------------------------------------------------------------------------------------------------------
  ------------------------------------------------------------------------------------------------------------
  --Verifica PocentajeProvisionEspecifica tenga valores de null
update jf77062.tb_dmat04
set
  PocentajeProvisionEspecifica = CASE
    clasificacionriesgo
    WHEN 'A' THEN '0'
    WHEN 'B' THEN '10'
    WHEN 'C' THEN '15'
    WHEN 'D' THEN '60'
    WHEN 'E' THEN '99'
    ELSE '0'
  END
where
  PocentajeProvisionEspecifica is null
  AND TIPODC IN ('5') --,'13') MODIFICADO JF77062 02/01/2014
  ------------------------------------------------------------------------------------------------------------
  --Verifica ProvisionEspecifica tenga valores de null
UPDATE jf77062.tb_dmat04
SET
  ProvisionEspecifica =(
    CONVERT(
      DECIMAL(18, 2),
      ISNULL(PocentajeProvisionEspecifica, 0)
    ) * CONVERT(DECIMAL(18, 2), ISNULL(Saldo, 0)) / 100
  ) * -1
WHERE
  TipoDC in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') -- '13' MODIFICADO SE QUITO LA CARTERA 13 JF77062 02/01/2014
  AND ClasificacionRiesgo NOT IN ('A', '0')
UPDATE jf77062.tb_dmat04
SET
  ProvisionEspecifica = '0'
WHERE
  TipoDC in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') -- '13' MODIFICADO SE QUITO LA CARTERA 13 JF77062 02/01/2014
  AND ClasificacionRiesgo IN ('A', '0')
UPDATE jf77062.tb_dmat04
SET
  ProvisionEspecifica = '0'
WHERE
  TipoDC in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') -- '13' MODIFICADO SE QUITO LA CARTERA 13 JF77062 02/01/2014
  AND EstadoCredito in ('2', '3') ------------------------------------------------------------------------------------------------------------
  --Verifica ProvisionRendimientoCobrar tenga valores de null
  --Error de Forma (Error Nro. 3): Error en el campo PROVISION_DEL_RENDIMIENTO_POR_COBRAR: El campo no es un n�mero decimal v�lido JF77062
  -- select ProvisionRendimientoCobrar, RendimientosCobrarVencidos,PocentajeProvisionEspecifica , tipodc
  -- from jf77062.tb_dmat04
  -- where ProvisionRendimientoCobrar is null  --16012
  -- 	 and TipoDC in ('1','2','3','4','5','6','9', '12', '13', '14','15')
UPDATE jf77062.tb_dmat04
SET
  ProvisionRendimientoCobrar = CASE
    WHEN convert(decimal(15, 4), RendimientosCobrarVencidos) = 0.0000 THEN '0'
    WHEN CONVERT(DECIMAL(15, 4), RendimientosCobrarVencidos) > 0.0000
    AND CONVERT(DECIMAL(15, 4), PocentajeProvisionEspecifica) = 0 THEN -0.01
    WHEN CONVERT(DECIMAL(15, 4), RendimientosCobrarVencidos) > 0.0000 THEN CONVERT(
      DECIMAL(18, 2),(
        CONVERT(
          DECIMAL(17, 4),
          ISNULL(RendimientosCobrarVencidos, 0)
        ) * (
          CONVERT(decimal(12, 4), PocentajeProvisionEspecifica) / 100
        ) * -1
      )
    )
    WHEN CONVERT(DECIMAL(15, 4), RendimientosCobrarVencidos) < 0.0000 THEN CONVERT(
      DECIMAL(18, 2),(
        CONVERT(
          DECIMAL(17, 4),
          ISNULL(RendimientosCobrarVencidos, 0)
        ) * (
          CONVERT(decimal(12, 4), PocentajeProvisionEspecifica) / 100
        )
      )
    )
  END
WHERE
  ProvisionRendimientoCobrar is null
  and TipoDC in (
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '9',
    '12',
    '13',
    '14',
    '15'
  )
update jf77062.tb_dmat04
set
  ProvisionRendimientoCobrar = convert(decimal(18, 2), PROVISIONRENDIMIENTOCOBRAR)
  /* ESTO SOLO PARA CALIDAD DE DATA POST CUADRE CONTABLE*/
  /*Como el valor del campo RENDIMIENTO POR COBRAR VENCIDOS es mayor que 0 por lo menos una de las siguientes afirmaciones deber�a cumplirse: 
  -  Como el valor del campo CODIGO CONTABLE es distinto de 1321810101 entonces deber�a cumplirse que 
  el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR sea menor que 0 
  -  Como el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR es menor o igual que 0 entonces deber�a cumplirse que 
  el valor del campo CODIGO CONTABLE sea igual a 1321810101 */
  --ESTO ES SIEMPRE DESPUES DEL AJUSTE CONTABLE JF77062
update jf77062.tb_dmat04
set
  ProvisionRendimientoCobrar = '-0.01'
where
  CONVERT(DECIMAL(18, 4), RendimientosCobrarVencidos) > 0
  and CONVERT(DECIMAL(15, 4), ProvisionRendimientoCobrar) = 0 ------------------------------------------------------------------------------------------------------------
update jf77062.tb_dmat04
set
  Montoliquidadomes = '0.00'
where
  Montoliquidadomes is null ------------------------------------------------------------------------------------------------------------
  --definicion 0.0000
update jf77062.tb_dmat04
set
  tasasinterescobrada = '0.0000'
where
  tasasinterescobrada is null ------------------------------------------------------------------------------------------------------------
  --definicion poner 1
update jf77062.tb_dmat04
set
  indicadortasapreferencial = '1'
where
  indicadortasapreferencial is null ------------------------------------------------------------------------------------------------------------
  --de manera definitiva se le va a colocar el valor 0,00
update jf77062.tb_dmat04
set
  comisionescobradas = '0'
where
  comisionescobradas is null ------------------------------------------------------------------------------------------------------------
  --microcreditos / turismo
update jf77062.tb_dmat04
set
  montovencer30dias = '0.00',
  montovencer60dias = '0.00',
  montovencer90dias = '0.00',
  montovencer120dias = '0.00',
  montovencer180dias = '0.00',
  montovencerunano = '0.00',
  montovencermasunano = '0.00'
from jf77062.tb_dmat04 DM
where
  montovencer30dias is null ------------------------------------------------------------------------------------------------------------
  --definicion dada por negocio para modificar este error de insumo
update jf77062.tb_dmat04
set
  TasasInteresCobrada = '0.0000',
  TasasInteresActual = '0.0000'
where
  tasasinterescobrada = '1.0e-07' -----------------------------------------------------------------------------------------------------
  --AJUSTE CAMPOS naturalezacliente POR CAMBIO DE DEFINICION
UPDATE jf77062.tb_dmat04
SET
  naturalezacliente = CASE
    WHEN SUBSTRING(tipocliente, 1, 1) IN ('V', 'E', 'P') THEN '1'
    WHEN SUBSTRING(tipocliente, 1, 1) IN ('J') THEN '2'
    ELSE '3'
  END
where
  naturalezacliente = '2'
  and tipocliente not in ('J', 'I', 'G', 'X') ---------------------------------------------------------------------------------------------------------
  --AJUSTE CAMPOS FECHAREESTRUCTURACION POR CAMBIO DE DEFINICION
UPDATE jf77062.tb_dmat04
SET
  FECHAREESTRUCTURACION = '1900/01/01'
WHERE
  CODIGOCONTABLE NOT LIKE ('132%')
  AND FECHAREESTRUCTURACION <> '1900/01/01' ---------------------------------------------------------------------------------------------------------
  --AJUSTE CAMPOS FECHAREESTRUCTURACION POR CAMBIO DE DEFINICION
UPDATE jf77062.tb_dmat04
SET
  oficina = '2'
where
  oficina = '-1' ------------------------------------------------------------------------------------------------------------
  ---cambio de los rif individualmente
  ---RIF CON PROBLEMA J3018025
  -- UPDATE jf77062.tb_dmat04
  -- SET 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '301802527',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '301802527'
  -- where IdentificacionCliente = '3018025'
  -- ---TipoCliente CON PROBLEMA E79401882 numero credito 22179401882 debe ser P
  -- UPDATE jf77062.tb_dmat04
  -- SET 	TipoCliente = 'P',
  -- 	TipoClienteRIF = 'P'
  -- where numerocredito = '22179401882'
  -- ---RIF CON PROBLEMA J30401911 numero credito 1110157
  -- UPDATE jf77062.tb_dmat04
  -- SET 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '304019114',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '304019114'
  -- where Numerocredito = '1110157'
  -- ---RIF CON PROBLEMA J07572970 numero credito 119657
  -- UPDATE jf77062.tb_dmat04
  -- SET 	tipocliente = 'J',
  -- 	IdentificacionCliente = '75729706',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '75729706'
  -- where Numerocredito = '119657' --IdentificacionCliente = ''
  -- ---RIF CON PROBLEMA J3021090 numero credito 156626
  -- UPDATE jf77062.tb_dmat04
  -- SET 	TipoCliente = 'J',
  -- 	IdentificacionCliente = '302109000',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '302109000'
  -- where Numerocredito = '156626' --IdentificacionCliente = ''
  -- ---RIF CON PROBLEMA J3038434 numero credito 153086
  -- UPDATE jf77062.tb_dmat04
  -- SET TipoCliente = 'J',
  -- 	IdentificacionCliente = '303843409',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '303843409'
  -- where Numerocredito = '153086' --IdentificacionCliente = ''
  -- ---RIF CON PROBLEMA J3027937 numero credito 158250
  -- UPDATE jf77062.tb_dmat04
  -- SET TipoCliente = 'J',
  -- 	IdentificacionCliente = '302793726',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '302793726'
  -- where Numerocredito = '158250' --IdentificacionCliente = ''
  -- ---RIF CON PROBLEMA J301802527 numero credito 18986
  -- UPDATE jf77062.tb_dmat04
  -- SET TipoCliente = 'J',
  -- 	IdentificacionCliente = '301802527',
  -- 	TipoClienteRIF = 'J',
  -- 	IdentificacionTipoClienteRIF = '301802527'
  -- where Numerocredito = '18986' --IdentificacionCliente = ''
  -- UPDATE jf77062.tb_dmat04 SET
  -- TIPOCLIENTE='J',
  -- IDENTIFICACIONCLIENTE='003636916',
  -- TIPOCLIENTERIF='J',
  -- IDENTIFICACIONTIPOCLIENTERIF='003636916'
  -- WHERE NUMEROCREDITO='1218951018'
  -- UPDATE jf77062.tb_dmat04 SET
  -- TIPOCLIENTE='J',
  -- IDENTIFICACIONCLIENTE='316351777',
  -- TIPOCLIENTERIF='J',
  -- IDENTIFICACIONTIPOCLIENTERIF='316351777'
  -- WHERE NUMEROCREDITO='1218251011'
  -- UPDATE jf77062.tb_dmat04 SET
  -- TIPOCLIENTE='J',
  -- IDENTIFICACIONCLIENTE='310915903',
  -- TIPOCLIENTERIF='J',
  -- IDENTIFICACIONTIPOCLIENTERIF='310915903'
  -- WHERE NUMEROCREDITO='1214231019'
  -- UPDATE jf77062.tb_dmat04 SET
  -- TIPOCLIENTE='J',
  -- IDENTIFICACIONCLIENTE='000068607',
  -- TIPOCLIENTERIF='J',
  -- IDENTIFICACIONTIPOCLIENTERIF='000068607'
  -- WHERE NUMEROCREDITO='1190701011'
  -- UPDATE jf77062.tb_dmat04 SET
  -- TIPOCLIENTE='J',
  -- IDENTIFICACIONCLIENTE='000129266',
  -- TIPOCLIENTERIF='J',
  -- IDENTIFICACIONTIPOCLIENTERIF='000129266'
  -- WHERE NUMEROCREDITO='309551028'
  ---------------------------------------------------------------------------------------------------------
  ----POR DEFINICIONES PONER "XXX" CUANDO SEA VACIO O NULL
update jf77062.tb_dmat04
set
  DESTINOCREDITO = 'XXX'
where
  tipodc = '10'
  AND (
    DESTINOCREDITO IS NULL
    OR DESTINOCREDITO = ''
  ) ---------------------------------------------------------------------------------------------------------
  ----VERIFICACION DE PROBLEMAS DE DATA CON MONTOSVENCIDOS A 120 DIAS PARA CUENTAS 131
  -- select * from jf77062.tb_dmat04
  -- where codigocontable like'%131%'
  -- and convert(decimal(18,2),montovencido120dias) > 0
  --Posible solucion despues de consultar a Liliana
  /*
  update jf77062.tb_dmat04 set montovencido30dias=convert(decimal(18,4),montovencido30dias)+convert(decimal(18,4),montovencido120dias),
  		     montovencido120dias='0.00',
  		     numerocuotasvencidas=convert(decimal,numerocuotasvencidas)-1
  where numerocredito in ('Numerodecredito')
  */
  ----VERIFICACION DE PROBLEMAS DE DATA CON BUCKETS VENCIDOS PARA CUENTAS 132
  -- select * from jf77062.tb_dmat04
  -- where (codigocontable like'%132%') and
  -- (convert(decimal(18,2),montovencido30dias)>0 OR
  -- convert(decimal(18,2),montovencido60dias)>0 OR
  -- convert(decimal(18,2),montovencido90dias)>0 OR
  -- convert(decimal(18,2),montovencido120dias)>0 )
  ---- Revision de personas sobregiradas en TDC (no castigados)
  -- select numerocredito,tipodc,montooriginal,montoinicial,convert(decimal(18,2),saldo)+convert(decimal(18,2),montovencido30dias)+convert(decimal(18,2),montovencido60dias)+convert(decimal(18,2),montovencido90dias) as 'buckets vencidos' from jf77062.tb_dmat04
  -- where montooriginal < convert(decimal(18,2),saldo)+convert(decimal(18,2),montovencido30dias)+convert(decimal(18,2),montovencido60dias)+convert(decimal(18,2),montovencido90dias) and
  --  montoinicial <convert(decimal(18,2),saldo)+convert(decimal(18,2),montovencido30dias)+convert(decimal(18,2),montovencido60dias)+convert(decimal(18,2),montovencido90dias) and
  -- tipodc=5 and
  -- codigocontable not like '%819%'
  /*Como el valor del campo ESTADO DEL CREDITO es igual a 2, y el valor del campo 
  FECHA DE CANCELACION TOTAL es mayor que el valor del campo FECHA DE LIQUIDACION 
  entonces deber�a cumplirse que el valor del campo FECHA DE CANCELACION TOTAL sea
   menor o igual que la fecha final del per�odo reportado */
  -- select fechacancelaciontotal,* from jf77062.TB_DMAT04
  -- where 	estadocredito = '2' and
  -- 	fechacancelaciontotal >  fechaliquidacion and --FactualizarU
  -- 	fechacancelaciontotal > '2017/06/30' ----ajustar fecha
  --se revisaron las fechas desde los insumos
  ----Cambios solicitados por FINCON y por Jocelyn (Query realizado por abraham)
  ---MONTOS POR VENCER
  --CONSUMER
UPDATE jf77062.tb_dmat04
SET
  MONTOVENCER30DIAS = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 0
    AND 29 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCER60DIAS = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 30
    AND 59 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCER90DIAS = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 60
    AND 89 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCER120DIAS = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 90
    AND 119 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCER180DIAS = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 120
    AND 179 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCERUNANO = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 179
    AND 365 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCERMASUNANO = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) > 365 THEN SALDO
    ELSE '0'
  END
WHERE
  TIPODC IN (12, 6, 1, 3, 2, 4, 5, 14, 15, 16) --CORPORATE
UPDATE jf77062.tb_dmat04
SET
  MONTOVENCER30DIAS = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 0
    AND 29 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCER60DIAS = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 30
    AND 59 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCER90DIAS = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 60
    AND 89 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCER120DIAS = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 90
    AND 119 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCER180DIAS = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 120
    AND 179 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCERUNANO = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) BETWEEN 179
    AND 365 THEN SALDO
    ELSE '0'
  END,
  MONTOVENCERMASUNANO = CASE
    WHEN DATEDIFF(
      DAY,
      DATEADD(s, -1, DATEADD(mm, DATEDIFF(m, 0, GETDATE()), 0)),
      CONVERT(DATETIME, FECHAVENCIMIENTOACTUAL)
    ) > 365 THEN SALDO
    ELSE '0'
  END
WHERE
  TIPODC IN (8, 11, 10, 7, 9, 13)
  AND TIPOCLIENTE IN ('E', 'P', 'V', 'I') ---GARANTIAS
UPDATE jf77062.tb_dmat04
SET
  TIPOGARANTIAPRINCIPAL = '10'
WHERE
  TIPOGARANTIAPRINCIPAL = '12' --ACTUALIZACION REALIZADA POR ORDEN DE JULYCER GONZALEZ
  --�	Cartera 13. Cartera No Dirigida: la informaci�n correspondiente al campo �Provisi�n Especifica� y �Porcentaje de Provisi�n Especifica�
  --se estar� suministrando para el quinto d�a h�bil de mes, en el insumo de Cartera No Dirigida. Mantener condiciones para el campo
  --�Provisi�n de Rendimientos por Cobrar�.
  --Porcentaje de Provisi�n Especifica
UPDATE jf77062.tb_dmat04
SET
  PocentajeProvisionEspecifica = L.PROVISION --PENDIENTE AL CARGAR
from jf77062.tb_dmat04 DM
inner join TB_CarteraNoDirigidaFINAL L on L.REFERENCIA = DM.numerocredito
where
  DM.tipodc = '13'