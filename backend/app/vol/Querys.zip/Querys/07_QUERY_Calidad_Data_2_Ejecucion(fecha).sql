-- declare @UltFecha as varchar(20)
-- set @UltFecha='2019/10/31' ---mes a reportar -----------------------FECHA CAMBIAR OJO !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

-- declare @PenFecha as varchar(20)
-- Set @Penfecha = substring(@UltFecha,1,8)  + convert(varchar(20),(convert(numeric(10),substring(@UltFecha,9,2))-1))

-- select @ultfecha as ultfecha, @penfecha as pencha into #fechasup
-- SELECT * INTO #TEMP_AT04_MesAnterior FROM jf77062.TB_DMAT04_TransmitidoSeptiembre2019 -- OJO Cambiar tabla !!!

-- drop table #fechasup
-- DROP TABLE #TEMP_AT04_MesAnterior

----------- ACTUALIZACION DE RIF ---------------FF

-- update jf77062.TB_DMAT04 set 
-- NombreGrupoEconomicoFinanciero ='DAIMLER AG'
-- where 
-- IdentificacionCliente='294424953'

-- update jf77062.TB_DMAT04 set 
-- NombreGrupoEconomicoFinanciero ='SCANIA DE VENEZUELA SA'
-- where 
-- IdentificacionCliente='305328293'

-- update jf77062.TB_DMAT04 set 
-- NombreGrupoEconomicoFinanciero ='CONSULTORES 2020 CA'
-- where 
-- NumeroCredito='8171800320'

-- --TOYO INGENIE 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='297394397',
-- tipoclienterif='J',
-- identificaciontipoclienterif='297394397'
-- where numerocredito='1214511014' 


-- --DIST.OVEJITA
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='301610326',
-- tipoclienterif='J',
-- identificaciontipoclienterif='301610326'
-- where numerocredito='1193461017' 

-- --GALAXYENTERT 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='302597005',
-- tipoclienterif='J',
-- identificaciontipoclienterif='302597005'
-- where numerocredito='1205431012' 


-- --JANSSENCILAG 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='300425320',
-- tipoclienterif='J',
-- identificaciontipoclienterif='300425320'
-- where numerocredito='1070301014' 



-- --KODAKVENEZUE 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='882894',
-- tipoclienterif='J',
-- identificaciontipoclienterif='882894'
-- where numerocredito='1057391024' 

-- --CTP CTRO DE 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='315240718',
-- tipoclienterif='J',
-- identificaciontipoclienterif='315240718'
-- where numerocredito='1217371015' 

-- --DPT DIST 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='315241188',
-- tipoclienterif='J',
-- identificaciontipoclienterif='315241188'
-- where numerocredito='1217361019'


-- --MICROSOFT 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='003345636',
-- tipoclienterif='J',
-- identificaciontipoclienterif='003345636'
-- where numerocredito='1213451018'
--  --DIVERSEY VEN  
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='309062590',
-- tipoclienterif='J',
-- identificaciontipoclienterif='295232225'
-- where numerocredito='1207901028'


--  --STATOILSINCO  
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='304700873',
-- tipoclienterif='J',
-- identificaciontipoclienterif='304700873'
-- where numerocredito='1193621012'


-- --BAPTISTA GARCIA INGRID MARIELIS

-- update jf77062.TB_DMAT04 set 
-- tipocliente='V',
-- identificacioncliente='11201212',
-- tipoclienterif='V',
-- identificaciontipoclienterif='112012121'
-- where numerocredito='1001324872' 

-- --PAYLINK
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000526621',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000526621'
-- where numerocredito='1208251018' 

-- --DR REDDY�S L
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='316892689',
-- tipoclienterif='J',
-- identificaciontipoclienterif='316892689'
-- where numerocredito='1215551014' 

-- --REGUS VENEZU
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='305837953',
-- tipoclienterif='J',
-- identificaciontipoclienterif='305837953'
-- where numerocredito='1213571018' 


-- --C.A.NCNL. TELEFONOS DE VZLA.
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='001241345',
-- tipoclienterif='J',
-- identificaciontipoclienterif='001241345'
-- where numerocredito='1105331051' 

-- --ARROCERA 4 DE MAYO SA.
-- update jf77062.TB_DMAT04 set 
-- NombreGrupoEconomicoFinanciero ='ARROCERA 4 DE MAYO SA'
-- where 
-- identificacioncliente='303432395'

-- --BAKER HUGHES 01
-- update jf77062.TB_DMAT04 set 
-- NombreGrupoEconomicoFinanciero ='BAKER HUGHES 01'
-- where 
-- identificacioncliente='301255690'

-- --ALIMENTOS LA GIRALDA CA
-- update jf77062.TB_DMAT04 set 
-- NombreGrupoEconomicoFinanciero ='ALIMENTOS LA GIRALDA CA '
-- where 
-- identificacioncliente='001626867'

-- --VENEZUELAN WIRE LINE SERVICES CA
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='070046333',
-- tipoclienterif='J',
-- identificaciontipoclienterif='070046333'
-- where numerocredito='1177831029' 



-- --SCHNEIDER ELECTRIC VENEZUELA, SA
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='001166203',
-- tipoclienterif='J',
-- identificaciontipoclienterif='001166203'
-- where numerocredito='1178081013' 



-- --C. HELLMUND Y CIA., S.A.
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000561729',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000561729'
-- where numerocredito='1190271019' 



-- --CHEVRON CARDON III SA
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='314111817',
-- tipoclienterif='J',
-- identificaciontipoclienterif='314111817'
-- where numerocredito='1212021014' 



-- --CLARIANT P&C    	
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='316558878',
-- tipoclienterif='J',
-- identificaciontipoclienterif='316558878'
-- where numerocredito='1222211012' 

-- --BROOM VENEZU
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='316558878',
-- tipoclienterif='J',
-- identificaciontipoclienterif='316558878'
-- where numerocredito='1218001019' 

-- --IBM DE VENEZ
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000190780',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000190780'
-- where numerocredito='60431042' 
-- --PETROBOSCAN
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='316485021',
-- tipoclienterif='J',
-- identificaciontipoclienterif='316485021'
-- where numerocredito='1219991018' 

-- --BTGLOBALVE
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='309014595',
-- tipoclienterif='J',
-- identificaciontipoclienterif='309014595'
-- where numerocredito='1207911016' 

-- --TEXACO ORIN
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='304547374',
-- tipoclienterif='J',
-- identificaciontipoclienterif='304547374'
-- where numerocredito='1209951029' 

-- update jf77062.TB_DMAT04 set  NombreGrupoEconomicoFinanciero = 'SCHLUMBERGER'
-- where numerocredito = '8151420302'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero = 'BAKER HUGHES 01'
-- where numerocredito = '8151460310'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero =  'REPSOL SA'
-- where numerocredito = '8151331313'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero =  'S.C.JOHNSON'
-- where numerocredito = '8161060312'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero =  'ENGELBERG TRANSP. INT. C.A'
-- where numerocredito = '8172000308'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero =  'DAIMLER AUTOMOTIVE DE VZLA,CA'
-- where numerocredito = '8172120302'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero =  'FLOWSERVE CORP'
-- where numerocredito = '8161061310'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero =  'HONEYWELL INTERNATIONAL INC'
-- where numerocredito = '8161120302'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero =  'FLOWSERVE CORP'
-- where numerocredito = '8161191311'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero =  'REPSOL SA'
-- where numerocredito in ('8161831308',
-- '8161931306')

--DISLIVENCA	
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='304975546',
-- tipoclienterif='J',
-- identificaciontipoclienterif='304975546'
-- where numerocredito='1213271011' 

-- --EDITORIALEX	
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='002935880',
-- tipoclienterif='J',
-- identificaciontipoclienterif='002935880'
-- where numerocredito='1213251019' 

-- --MUEBLES MEPAL

-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='293984220',
-- tipoclienterif='J',
-- identificaciontipoclienterif='293984220'
-- where numerocredito='1213211013'

-- --3G PROMOTORE
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='301817036',
-- tipoclienterif='J',
-- identificaciontipoclienterif='301817036'
-- where numerocredito='1220291014'

-- --LOCKTON VZLA
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='002560894',
-- tipoclienterif='J',
-- identificaciontipoclienterif='002560894'
-- where numerocredito='702481022'
-- --TRANSPORTE CHIRINAVAS C.A : 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='075900596',
-- tipoclienterif='J',
-- identificaciontipoclienterif='075900596'
-- where numerocredito='19930'
-- --Tesoreria Polar : 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='02181265',
-- tipoclienterif='J',
-- identificaciontipoclienterif='02181265'
-- where numerocredito='282061174'
 
 
--  --CONSTRUCTORA : 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='317450264',
-- tipoclienterif='J',
-- identificaciontipoclienterif='317450264'
-- where numerocredito='1219241018'

 
--  --PROYECTOS IN: 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='295232225',
-- tipoclienterif='J',
-- identificaciontipoclienterif='295232225'
-- where numerocredito='1217821019'


--  --Santa Teresa: 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='00325693',
-- tipoclienterif='J',
-- identificaciontipoclienterif='00325693'
-- where numerocredito='1216951019'
 
--  --Cameron: 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='070418818',
-- tipoclienterif='J',
-- identificaciontipoclienterif='070418818'
-- where numerocredito='286201019' 

-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='314873709',
-- tipoclienterif='J',
-- identificaciontipoclienterif='314873709'
-- where numerocredito='1221241017' 

-- --CORPORACION ROCOSME 2012 CA
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='400417570',
-- tipoclienterif='J',
-- identificaciontipoclienterif='400417570'
-- where numerocredito='1218891018' 
-- --DESARROLLO INMOBILIARIO TEN CA	
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='307822422',
-- tipoclienterif='J',
-- identificaciontipoclienterif='307822422'
-- where numerocredito='1215781014' 
-- --ENGELBERG TRANSP. INT. C.A	
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000437246',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000437246'
-- where numerocredito='1215401017' 


-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='295848226',
-- tipoclienterif='J',
-- identificaciontipoclienterif='295848226'
-- where numerocredito='1220201017 ' 

-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000737320',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000737320'
-- where numerocredito='8140800309'

-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000737320',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000737320'
-- where numerocredito='8140870320'

-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000737320',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000737320'
-- where numerocredito='8133260313'

-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='400538653',
-- tipoclienterif='J',
-- identificaciontipoclienterif='400538653'
-- where numerocredito='1219281015'

-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='307901128',
-- tipoclienterif='J',
-- identificaciontipoclienterif='307901128'
-- where numerocredito='1217161018'


-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='002968605',
-- tipoclienterif='J',
-- identificaciontipoclienterif='002968605'
-- where numerocredito='1192981055'


-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='293703662',
-- tipoclienterif='J',
-- identificaciontipoclienterif='293703662'
-- where numerocredito='1217311017'


-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000068607',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000068607'
-- where numerocredito='1190708016'


-- update jf77062.TB_DMAT04 set 
-- identificacioncliente = '075900596',
-- identificaciontipoclienteRIF = '075900596'
-- where numerocredito ='19930'

-- update jf77062.TB_DMAT04 
-- set TipoCliente = 'J',
-- 	identificacioncliente = '000671656',
-- 	TipoClienteRIF = 'J',
-- 	identificaciontipoclienteRIF = '000671656'
-- where numerocredito ='254861028'

-- update jf77062.TB_DMAT04 
-- set TipoCliente = 'J',
-- 	identificacioncliente = '316931935',
-- 	TipoClienteRIF = 'J',
-- 	identificaciontipoclienteRIF = '316931935'
-- where numerocredito ='1212651016'


-- UPDATE jf77062.TB_DMAT04
-- SET 	TipoCliente = 'J',
-- 	IdentificacionCliente = '000671656',
-- 	TipoClienteRIF = 'J',
-- 	IdentificacionTipoClienteRIF = '000671656'
-- Where numerocredito = '0254861028'


-- UPDATE jf77062.TB_DMAT04
-- SET 	TipoCliente = 'J',
-- 	IdentificacionCliente = '001170383',
-- 	TipoClienteRIF = 'J',
-- 	IdentificacionTipoClienteRIF = '001170383'
-- Where numerocredito = '1195721025'

-- UPDATE jf77062.TB_DMAT04
-- SET 	TipoCliente = 'J',
-- 	IdentificacionCliente = '301841743',
-- 	TipoClienteRIF = 'J',
-- 	IdentificacionTipoClienteRIF = '301841743'
-- Where numerocredito = '1173551027'

-- update jf77062.TB_DMAT04
-- set 	TipoCliente = 'J',
-- 	IdentificacionCliente = '000775265',
-- 	TipoClienteRIF = 'J',
-- 	IdentificacionTipoClienteRIF = '000775265'
-- where numerocredito = '1170721017'

-- update jf77062.TB_DMAT04
-- set 	TipoCliente = 'J',
-- 	IdentificacionCliente = '002560894',
-- 	TipoClienteRIF = 'J',
-- 	IdentificacionTipoClienteRIF = '002560894'
-- where numerocredito = '702481014'

-- update jf77062.TB_DMAT04
-- set 	TipoCliente = 'J',
-- 	IdentificacionCliente = '070115076',
-- 	TipoClienteRIF = 'J',
-- 	IdentificacionTipoClienteRIF = '070115076'
-- where numerocredito = '1181101028'

-- update jf77062.TB_DMAT04
-- set 	TipoCliente = 'G',
-- 	IdentificacionCliente = '200103230',
-- 	TipoClienteRIF = 'G',
-- 	IdentificacionTipoClienteRIF = '200103230'
-- where numerocredito = '1219561019'

-- update jf77062.TB_DMAT04
-- set 	TipoCliente = 'J',
-- 	IdentificacionCliente = '308232041',
-- 	TipoClienteRIF = 'J',
-- 	IdentificacionTipoClienteRIF = '308232041'
-- where numerocredito = '1219971017'

-- update jf77062.TB_DMAT04
-- set 	TipoCliente = 'J',
-- 	IdentificacionCliente = '316892689',
-- 	TipoClienteRIF = 'J',
-- 	IdentificacionTipoClienteRIF = '316892689'
-- where numerocredito = '1215551014'


-- update jf77062.TB_DMAT04
-- set 	TipoCliente = 'J',
-- 	IdentificacionCliente = '309034693',
-- 	TipoClienteRIF = 'J',
-- 	IdentificacionTipoClienteRIF = '309034693'
-- where numerocredito = '1219461013'

-- --molinos nacionales monaca jf77062
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000255431',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000255431'
-- where numerocredito='305351045'

-- --laboratorio LABORATORIO EICOPEN CA jf77062

-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='002575212',
-- tipoclienterif='J',
-- identificaciontipoclienterif='002575212'
-- where numerocredito='1219541016'

-- ---AGROPECUARIA ARE CA

-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='303843409',
-- tipoclienterif='J',
-- identificaciontipoclienterif='303843409'
-- where numerocredito='153086' 

-- ---SALAS SOLUCIONES INTEGRALES DE MERCADEO
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='302793726',
-- tipoclienterif='J',
-- identificaciontipoclienterif='302793726'
-- where numerocredito='158250' 
------------------------------------------------
----------------- TASA COMISION NO PUEDE SER 0 SI COMISION COBRADA ES > 0 Y
-- LA CUENTA CONTABLE COMIENZA CON 13106, 13206 O 13306-----------
-- select numerocredito, codigocontable
-- from jf77062.TB_DMAT04
-- where CONVERT(DECIMAL(15,4),tasacomision) = 0 and 
--       CONVERT(DECIMAL(15,4),comisionescobradas) > 0 and 
--       (codigocontable like ('13106%') or
--       codigocontable like ('13206%') or
--       codigocontable like ('13306%') )--2251

------------------------------------------------
----------- AJUSTE DE QUERY PARA REWRITE CAMPO FECHA REESTRUTURACION ----------

--******** AJUSTE PARA CUENTA CONTABLE 132 **********

--OJO: SOLO ES PARA VERIFICACION DE INFORMACION---

UPDATE jf77062.TB_DMAT04 
SET fechareestructuracion = LD.opendate
from jf77062.TB_DMAT04 DM
inner join dbo.TB_DCAT04_01 LD on LD.acct = DM.numerocredito
where DM.codigocontable like ('132%') and DM.tipodc = '4'--54

--******** AJUSTE PARA CUENTA CONTABLE DIFERENTE DE 132 **********

UPDATE jf77062.TB_DMAT04 
SET fechareestructuracion = '1900/01/01'
where Codigocontable NOT like ('132%') and tipodc = '4'--198

-------------------------------------AJUSTE MICROCREDITOS---------------------------------------

update jf77062.TB_DMAT04 set montolineacredito = CASE 
		WHEN DC01.TypeId IN (190,196,610,611,5) THEN CONVERT(DECIMAL(15,4),MI.MONTO_INICIAL) --fz
		WHEN DC01.TypeId IN (16,17) THEN 0
		WHEN DC01.TypeId IN (999) THEN 	0
		ELSE NULL --fz
	END 
from jf77062.TB_DMAT04 DM
inner join tb_dcat04_01 DC01 on DC01.acct = dm.numerocredito 
inner join RPT_STG_Dirigidas_MICROFINANCIERO MI on convert(decimal, mi.num_credito) = dm.numerocredito	
WHERE TIPODC ='9'

------------------------------------AJUSTE CAMPO MONTO LINEA CREDITO ---------------------------
UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13106101%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13106202%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13206101%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13206201%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13206102%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13206202%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13306101%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13306201%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13306102%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13306202%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13406101%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13406201%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13406102%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13406202%')

-------------------------------------------------------------------------
--------Como el valor del campo ESTADO DEL CREDITO es distinto de 2 entonces 
--------deber�a cumplirse que el valor del campo FECHA DE CANCELACION TOTAL sea igual a 19000101 

Update jf77062.TB_DMAT04
SET fechacancelaciontotal = '1900/01/01'
where estadocredito <> '2' and fechacancelaciontotal <> '1900/01/01' and tipodc=5 --13

------------------------------------------------------------------------

UPDATE jf77062.TB_DMAT04 
SET fechavencimientoultimacuotainteres = '1900/01/01'
where 	codigoContable like ('819%') and 
	CONVERT(DECIMAL(15,4),TasasInterescobrada)= 0 and
	CONVERT(DECIMAL(15,4),TasasInteresActual)= 0 

-------------------------------------------------------------------
---Como el valor del campo CODIGO DE LINEA DE CREDITO es igual a 2 
---entonces deber�a cumplirse que el valor del campo MONTO DE LA LINEA DE CREDITO 
---sea mayor que 0
---- CUANDO EL VALOR DEL CAMPO Creditlimit DEL LDWH SEA = 0 SE DEBE DE TOMAR EL VALOR DEL CAMPO
--- LASTCRLIM DEL AMBS

--REALIZAMOS LA ACTUALIZACION 

UPDATE jf77062.TB_DMAT04 
SET montolineacredito = convert(varchar (20),LASTCRLIM)
from jf77062.TB_DMAT04 DM
inner join TMP_VZDWAMBS_AT04 VZ on VZ.acct =  DM.numerocredito
inner join TB_DCAT04_01 LD on LD.acct =  DM.numerocredito
where 	tipodc in ('5') and 
	CONVERT(DECIMAL(15,4),montolineacredito) = 0 and --87
	codigolineacredito = '2'

----------------------------------------------------------------------------
--Error de Fondo (Error Nro. 75): Como el valor del campo CODIGO CONTABLE empieza 
--por algunos de los siguientes valores: (13106101,13106201,13106102,13106202,13206101,
--13206201,13206102,13206202,13306101,13306201,13306102,13306202,13406101,13406201,13406102
--,13406202), y el valor del campo COMISIONES COBRADAS es mayor que 0 entonces deber�a 
--cumplirse que el valor del campo TASA DE LA COMISION sea mayor que 0
-- Se debe colocar TASA DE LA COMISION = 0,0000 y 70. COMISIONES COBRADAS = 0,00 cuando
-- Cuenta contable = (13106 o 13306)  y sea TDC 

UPDATE jf77062.TB_DMAT04
SET tasacomision = '0'
where 	(codigoContable like ('13306%') or 
	codigoContable like ('13106%') )and
	tipodc= 5 and
	CONVERT(DECIMAL(15,4),tasacomision) <> 0 


UPDATE jf77062.TB_DMAT04
SET comisionescobradas = '0'
where 	(codigoContable like ('13306%') or 
	codigoContable like ('13106%') or
	codigoContable like ('13206%'))and
	tipodc= 5 and
	CONVERT(DECIMAL(15,4),comisionescobradas) <> 0

------------------------------------------------
--Campos 53. Monto Original y 54. Monto Inicial  (3533 Errores)
--a.	Si el 53 monto original � (58. Saldo + Montos vencidos 75 al 78) es menor que 
--CERO And  06 Cta contable 13106  entonces
--53. Monto Original y 54. Monto Inicial = (58. Saldo + Montos vencidos 75 al 78)


UPDATE jf77062.TB_DMAT04
SET 	MontoOriginal = CONVERT(DECIMAL(15,2),DM.Saldo)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO30DIAS)+ 
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO60DIAS)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO90DIAS)+
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO120DIAS),
 	
	MontoInicial = CONVERT(DECIMAL(15,2),DM.Saldo)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO30DIAS)+ 
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO60DIAS)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO90DIAS)+
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO120DIAS)
from jf77062.TB_DMAT04 dm
where 	codigocontable like ('13306%') and 
 	(CONVERT(DECIMAL(15,2),DM.MontoOriginal)- 
	(CONVERT(DECIMAL(15,2),DM.Saldo)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO30DIAS)+ 
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO60DIAS)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO90DIAS)+
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO120DIAS))) < 0

---------------------------------------------------------------------------------------
--Si el campo 58 Saldo  < 0 and ESTADO del cr�dito = 3 eliminar del reporte 
--(INSTRUCCI�N DE LEONARDO IVIRMA)

DELETE jf77062.TB_DMAT04 WHERE estadocredito = 3 AND CONVERT(DECIMAL(18,2),Saldo)  < 0

---------- POSEEN SALDO < 0 PERO ED <> 3 ---------------- RECLASIFICACION

/*Update jf77062.TB_DMAT04
SET 	codigocontable = '1330610100',
	Situacioncredito = 3,
	Saldo = MORA
from jf77062.TB_DMAT04 DM
inner join TB_DCAT04_01 LD on LD.acct =  DM.numerocredito
where 	DM.codigocontable = '1310610100' and 
	CONVERT(DECIMAL(15,4),DM.saldo) < 0 and
	DM.estadocredito in ('1','2')--10 --7*/ ---se comento este ajuste debido a que arrojaba un error.
	

-------------------------------------------------------------------------------
/*???CORRE ESTE QUERY CUANDO SE MODIFIQUE EL CAMPO 	*/
-- select provisionespecifica, numerocredito,saldo, PocentajeProvisionEspecifica, TIPODC 
-- from jf77062.TB_DMAT04 
-- where provisionespecifica like ('-%') --AND TIPODC =13
-- order by saldo asc

-- select Saldo, PocentajeProvisionEspecifica, ClasificacionRiesgo,
-- CONVERT(DECIMAL(18,2),(CONVERT(DECIMAL(18,2),ISNULL(PocentajeProvisionEspecifica,0))*CONVERT(DECIMAL(18,2),ISNULL(Saldo,0))/100)*-1)
-- from jf77062.TB_DMAT04 
-- where provisionespecifica like ('-%')-- AND TIPODC =13


-- UPDATE jf77062.TB_DMAT04
-- SET provisionespecifica = '-0.01'
-- WHERE numerocredito in ('4487418354185009')

---------------------------------------------------------------------------------------------------------------
--segun definicion 
--11. Estado del Cr�dito  = 1  y  
--58. Saldo  > Cero  pero en los  campos 53 y 54 no posee valor 
--favor ajustar el valor de estos campos por el valor del campo 
--10. Monto de la L�nea de Cr�dito.

update jf77062.TB_DMAT04 set MONTOORIGINAL = MONTOLINEACREDITO,
		MONTOINICIAL = MONTOLINEACREDITO 
WHERE ESTADOCREDITO =1
	AND CONVERT(DECIMAL(18,2),SALDO) > 0 
	AND (CONVERT(DECIMAL(18,2),MONTOINICIAL) = 0
		or CONVERT(DECIMAL(18,2),MONTOORIGINAL) = 0 ) 

----------------------------------------------------------------------------------------------------------------

UPDATE jf77062.TB_DMAT04 SET FechaVencimientoUltimaCoutaCapital = FechaVencimientoActual
WHERE FechaVencimientoUltimaCoutaCapital ='1900/01/01'


UPDATE jf77062.TB_DMAT04 
SET FechaVencimientoUltimaCuotaInteres = FechaVencimientoUltimaCoutaCapital --105003
---------------------------------------------------------------------------------
--Como el valor del campo CODIGO CONTABLE empieza por algunos de los siguientes 
--valores: (13111,13112,13311,13312,13411,13412,13102,13302,13402,819), y el 
--valor del campo FECHA DE VENCIMIENTO ULTIMA CUOTA INTERES es mayor o igual que
--el valor del campo FECHA DE LIQUIDACION, y el valor del campo FECHA DE VENCIMIENTO 
--ULTIMA CUOTA INTERES es menor o igual que el valor del campo FECHA DE VENCIMIENTO 
--ACTUAL entonces deber�a cumplirse que el valor del campo TASA DE INTERES ACTUAL 
--sea mayor que 0 �el valor del campo TASA DE INTERES COBRADA sea mayor que 0

--Anexo archivo de los 625 cr�ditos castigados sin tasa 
--de inveteres actual favor colocar el valor usado en la transmisi�n del mes 
--de Diciembre (VER EXCEL) 
-- YA LA TABLA jf77062.TB_DMAT04_cuadrecontable2 ESTA CARGADA CON EL REPORTE CORRESPONDIENTE. COMENTARIO DE: JF77062

UPDATE jf77062.TB_DMAT04
SET  tasasinteresactual = REPLACE(CC.tasasinteresactual,',','.')
from jf77062.TB_DMAT04 DM
Inner JOIN #TEMP_AT04_MesAnterior CC on CC.numerocredito = DM.numerocredito
where 	DM.FECHAVENCIMIENTOULTIMACUoTAINTERES >= DM.FECHALIQUIDACION and
	DM.FECHAVENCIMIENTOULTIMACuoTAINTERES <= DM.fechavencimientoactual and
	CONVERT(DECIMAL(18,4),DM.tasasinterescobrada)<= 0 AND
	 (DM.codigocontable like ('819%') OR
	DM.codigocontable like ('13111%') OR
	DM.codigocontable like ('13112%') OR
	DM.codigocontable like ('13311%')  OR
	DM.codigocontable like ('13312%') OR
	DM.codigocontable like ('13102%') OR
	DM.codigocontable like ('13302%'))AND
	 CONVERT(DECIMAL(18,4),DM.tasasinteresactual) = 0 --617

-------------------------------------------------------------------------------------
--Como el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes 
--valores: (13102,13302,13402), y el valor del campo FECHA DE VENCIMIENTO ULTIMA CUOTA
--CAPITAL es mayor o igual que el valor del campo FECHA DE LIQUIDACION entonces deber�a 
--cumplirse que el valor del campo FECHA DE VENCIMIENTO ULTIMA CUOTA CAPITAL sea menor
--o igual que el valor del campo FECHA DE VENCIMIENTO ACTUAL

--SOLUCION: FECHA DE VENCIMIENTO ACTUAL = FECHA DE VENCIMIENTO ULTIMA CUOTA CAPITAL

UPDATE jf77062.TB_DMAT04
SET FECHAVENCIMIENTOULTIMACouTAcapital = FECHAVENCIMIENTOACTUAL
where 	FECHAVENCIMIENTOULTIMACouTAcapital >= FECHALIQUIDACION and
	(codigocontable not like ('13102%') or
	codigocontable not like ('13302%') or
	codigocontable not like ('13402%')) and
	FECHAVENCIMIENTOULTIMACouTAcapital > FECHAVENCIMIENTOACTUAL 
	
-------------------------------------------------------------------------------
--Como el valor del campo CODIGO DE LINEA DE CREDITO es igual a 2 entonces deber�a 
--cumplirse que el valor del campo MONTO DE LA LINEA DE CREDITO sea mayor que 0

UPDATE jf77062.TB_DMAT04
SET montolineacredito = '1.00'
where 	codigolineacredito = '2' and 
	CONVERT(DECIMAL(18,4),montolineacredito) <=0 --7 --3

------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es distinto de 3 entonces deber�a 
--cumplirse que el valor del campo TIPO DE BENEFICIARIO sea igual a 0

UPDATE jf77062.TB_DMAT04
SET tipobeneficiario = '0'
where tipocredito <> '3' and tipobeneficiario <> '0' 

--------------------------------------------------------------------------
--El campo 'NUMERO_EXPEDIENTE_FACTIBILIDAD_SOCIOTECNICA' es obligatorio, 
--por ende no puede estar vac�o Error cr�tico, proceso de validaci�n abortado
--Corregir el campo 101 N�mero de Expediente Conformidad Tur�stica = cero

UPDATE jf77062.TB_DMAT04
SET numeroexpedienteconformidadturistica = '0'
where 	numeroexpedienteconformidadturistica = 'No aplica' or
		numeroexpedienteconformidadturistica = '' or
		numeroexpedienteconformidadturistica is null

--------------------------------------------------------------------------------------------------------------
--Si el valor del campo [Tipo de Cr�dito] es igual que (�6 � Turismo�) y el valor del campo 
--[Estado del Cr�dito] es igual que (�1- Activo�) y el valor del campo 
--[N�mero de Expediente Conformidad Tur�stica] es igual que (�0 � No Aplica�), 
--entonces el valor de este campo debe ser distinto que (�0 � No Aplica�).
--2. Si el valor del campo [Tipo de Cr�dito] es igual que (�6 � Turismo�) y el valor del campo 
--[Estado del Cr�dito] es distinto que (�1- Activo�), entonces el valor de este campo debe ser 
--igual que (�0 � No Aplica�).
--3. Si el valor del campo [Tipo de Cr�dito] es distinto que (�6 � Turismo�), entonces el valor 
--de este campo debe ser igual que (�0 � No Aplica�).

UPDATE jf77062.TB_DMAT04
SET 	NUMEROEXPEDIENTEFACTIBILIDADSOCIOTECNICA = '0'
where 	--NUMEROEXPEDIENTEFACTIBILIDADSOCIOTECNICA <> '0' or
	NUMEROEXPEDIENTEFACTIBILIDADSOCIOTECNICA = 'No aplica' or
	NUMEROEXPEDIENTEFACTIBILIDADSOCIOTECNICA = '' or
	NUMEROEXPEDIENTEFACTIBILIDADSOCIOTECNICA is null


--------------------------------------------------------------------------------------------------------------
--Si el estadocredito es = 2  AND  fechacancelaciontotal = 19000101 entonces  
--a.fechacancelaciontotal = fecha del CIERRE de  mes a reportar (Para este mes  20120630)


update jf77062.TB_DMAT04 
SET fechacancelaciontotal = (select ultfecha from #fechasup)--FactualizarU fecha del CIERRE de  mes a reportar 
where estadocredito ='2' 
	and fechacancelaciontotal = '1900/01/01' 

--------------------------------------------------------------------------------------------------------------

--Existen errores asociados a la sumatoria de SALDO + Bucket vencidos hasta 120  y 
--que estos no puede ser MAYOR a los campos 53 y 54, por favor aplicar la l�gica 
--definida para ello la cual es que el valor del 53 y 54  = SALDO + Bucket vencidos hasta 120  
--SOLO PARA LA 13106 Y 13306
---corri
UPDATE jf77062.TB_DMAT04
SET 	MontoOriginal = CONVERT(DECIMAL(15,2),DM.Saldo)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO30DIAS)+ 
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO60DIAS)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO90DIAS)+
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO120DIAS),
 	
	MontoInicial = CONVERT(DECIMAL(15,2),DM.Saldo)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO30DIAS)+ 
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO60DIAS)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO90DIAS)+
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO120DIAS)
from jf77062.TB_DMAT04 dm
where 	codigocontable like ('13106%') and 
 	(CONVERT(DECIMAL(15,2),DM.MontoOriginal)- 
	(CONVERT(DECIMAL(15,2),DM.Saldo)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO30DIAS)+ 
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO60DIAS)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO90DIAS)+
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO120DIAS))) < 0
--;;;;;
--------------------------------------------------------------------------------------------------------------
--De igual forma ejecuta la l�gica para actualizar el c�digo de oficina 0010 por 0003

UPDATE jf77062.TB_DMAT04 SET OFICINA = '3'
WHERE OFICINA IN ('10')

--------------------------------------------------------------------------------------------------------------
-- update jf77062.TB_DMAT04 set TipoCliente = 'P'
-- where numerocredito in  ('4487414799751000', '5464900016405002')

--------------------------------------------------------------------------------------------------------------
--Si el Campo  12. Tipo del cr�dito <> 3  entonces  135. Saldo del cr�dito al 31-12 =  0

update jf77062.TB_DMAT04 
set saldocredito31_12 = '0'
where tipocredito <> '3' and saldocredito31_12 <> '0' 

--------------------------------------------------------------------------------------------------------------
--Si el Campo 109. Fecha de �ltima inspecci�n = 19000101 
--ENTONCES 110. Porcentaje de ejecuci�n del proyecto = 0,0000

update jf77062.TB_DMAT04 
set Porcentajeejecucionproyecto = '0.0000'
where Fechaultimainspeccion  = '1900/01/01' --
and convert(decimal(15,4), Porcentajeejecucionproyecto) <> 0 

--------------------------------------------------------------------------------------------------------------
--Si el campo 43. Cantidad de renovaciones = 0 ENTONCES 44. Fecha de Ultima renovaci�n = 19000101

update jf77062.TB_DMAT04 
set FechaUltimarenovacion = '1900/01/01'
where Cantidadrenovaciones  = '0' 
and FechaUltimarenovacion <> '1900/01/01'

--------------------------------------------------------------------------------------------------------------
-- Si el 12. Tipo del cr�dito = 4 And 11. Estado del cr�dito <> 1 ENTONCES 116.  N�mero de registro MPPAT = 0  

update jf77062.TB_DMAT04 set Numeroregistro_constanciaMPPAT = '0'
where tipocredito  = '4' 
and estadocredito <> '1'
and Numeroregistro_constanciaMPPAT <> '0' 

---------------------------------------------------------------------------------
-- Verificacion de logica sobre TDC para los registros que posean MORA >0 en LDWH
-- y no tengan el valor de MORA en SALDO del AT04

UPDATE jf77062.TB_DMAT04 
SET saldo = MORA
from jf77062.TB_DMAT04 DM
Inner join tb_dcat04_01 LD on LD.acct = DM.numerocredito
where 	codigocontable = '1330610100' and 
	CONVERT(DECIMAL(18,2),LD.MORA) > 0 and 
	CONVERT(DECIMAL(18,2),LD.MORA) <> CONVERT(DECIMAL(18,2),DM.saldo)--9
---------------------------------------------------------------------------
--Error de Fondo (Error Nro. 10): Como el valor del campo NUMERO DE DESEMBOLSO es 
--igual a 0, y el valor del campo CODIGO DE LINEA DE CREDITO es distinto de 2, y el 
--valor del campo CODIGO CONTABLE empieza por algunos de los siguientes valores: 
--(131,132), y el valor del campo MODALIDAD HIPOTECARIO es distinto de 2, y el valor 
--del campo TIPO DE CREDITO es distinto de 6, y el valor del campo CODIGO CONTABLE 
--no empieza por algunos de los siguientes valores: (13109,13111,13112,13102,13302,13402) 
--entonces deber�a cumplirse que el valor del campo SALDO + el valor del campo MONTO 
--VENCIDO A 30 DIAS + el valor del campo MONTO VENCIDO A 60 DIAS + el valor del campo 
--MONTO VENCIDO A 90 DIAS + el valor del campo MONTO VENCIDO A 120 DIAS sea menor que 
--el valor del campo MONTO ORIGINAL 

UPDATE jf77062.TB_DMAT04
SET 	MONTOORIGINAL = CONVERT(DECIMAL(15,2),Saldo) + 
	CONVERT(DECIMAL(15,2),MONTOVENCIDO30DIAS)+ 
	CONVERT(DECIMAL(15,2),MONTOVENCIDO60DIAS)+ 
	CONVERT(DECIMAL(15,2),MONTOVENCIDO90DIAS)+
	CONVERT(DECIMAL(15,2),MONTOVENCIDO120DIAS),

	MONTOINICIAL = CONVERT(DECIMAL(15,2),Saldo) + 
	CONVERT(DECIMAL(15,2),MONTOVENCIDO30DIAS)+ 
	CONVERT(DECIMAL(15,2),MONTOVENCIDO60DIAS)+ 
	CONVERT(DECIMAL(15,2),MONTOVENCIDO90DIAS)+
	CONVERT(DECIMAL(15,2),MONTOVENCIDO120DIAS)

from jf77062.TB_DMAT04 dm
where 	numerodesembolso = '0' and
	codigolineacredito <> '2' and 
	(codigocontable like ('131%') or codigocontable like ('132%')) and 
	modalidadhipoteca <> '2' and
	(codigocontable not like ('13109%') or 
	codigocontable not like ('13111%') or
	codigocontable not like ('13112%') or
	codigocontable not like ('13102%')) and
 	(CONVERT(DECIMAL(15,2),DM.Saldo)+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO30DIAS)+ 
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO60DIAS)+ 
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO90DIAS)+
	CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO120DIAS)) > 
	CONVERT(DECIMAL(15,2),DM.MONTOORIGINAL) 

--colocar al campo montooriginal = saldo + buckets y montoinicial
----------------------------------------------------------------------------
--Como el valor del campo SALDO + el valor del campo MONTO VENCIDO A 30 DIAS + 
--el valor del campo MONTO VENCIDO A 60 DIAS + el valor del campo MONTO VENCIDO
--A 90 DIAS + el valor del campo MONTO VENCIDO A 120 DIAS es igual a el valor del 
--campo MONTO ORIGINAL, y el valor del campo CODIGO CONTABLE empieza por algunos 
--de los siguientes valores: (131,132), y el valor del campo MODALIDAD HIPOTECARIO 
--es distinto 	 2, y el valor del campo TIPO DE CREDITO es distinto de 6, y el valor 
--del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL es mayor o igual que 19000101 
--entonces deber�a cumplirse que el valor del campo CODIGO CONTABLE empezara por 
--algunos de los siguientes valores: (13106,13206,13102,13302,13402) 

-- SOLUCION: colocar 19000101 al campo ultimafechacancelacioncuotacapital.
/*EN CASO DE CORRESPONDER LA CANTIDAD DE LINEAS EJECUTAR ESTE UPDATE*/

update jf77062.TB_DMAT04
SET ultimafechacancelacioncuotacapital = '1900/01/01'
where  CONVERT(DECIMAL(18,2),SALDO) +  
       CONVERT(DECIMAL(18,2),MONTOVENCIDO30DIAS) +  
       CONVERT(DECIMAL(18,2),MONTOVENCIDO60DIAS) +  
       CONVERT(DECIMAL(18,2),MONTOVENCIDO90DIAS) +  
       CONVERT(DECIMAL(18,2),MONTOVENCIDO120DIAS)  
       = CONVERT(DECIMAL(18,2),MONTOORIGINAL) --
       AND ( CODIGOCONTABLE LIKE ('131%') 
       OR  CODIGOCONTABLE LIKE ('132%') )
       AND MODALIDADHIPOTECA <> '2'
       AND TIPOCREDITO <> '6'
       AND ULTIMAFECHACANCELACIONCUOTACAPITAL >= '19000101'
       AND CODIGOCONTABLE NOT LIKE ('13106%') 
       AND  CODIGOCONTABLE NOT LIKE ('13206%') 
       AND  CODIGOCONTABLE NOT LIKE ('13102%') 
       AND  CODIGOCONTABLE NOT LIKE ('13302%') 
       AND  CODIGOCONTABLE NOT LIKE ('13402%')

---------------------------------------------------------------------------------------------------------------
--Como el valor del campo NUMERO DE DESEMBOLSO es igual a 0, y el valor del campo CODIGO DE LINEA DE CREDITO 
--es distinto de 2, y el valor del campo SALDO + el valor del campo MONTO VENCIDO A 30 DIAS + el valor 
--del campo MONTO VENCIDO A 60 DIAS + el valor del campo MONTO VENCIDO A 90 DIAS + el valor del campo 
--MONTO VENCIDO A 120 DIAS es menor que el valor del campo MONTO ORIGINAL, y el valor del campo 
--CODIGO CONTABLE empieza por algunos de los siguientes valores: (131,132), y el valor del campo 
--MODALIDAD HIPOTECARIO es distinto de 2, y el valor del campo TIPO DE CREDITO es distinto de 6, 
--y el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13109,13111,13112,13102,13302,13402), y el valor del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL 
--es menor o igual que la fecha final del per�odo reportado entonces deber�a cumplirse que el valor del 
--campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL sea mayor o igual que el valor del campo FECHA DE LIQUIDACION

--SOLUCION DADA:
--L�nea 53227  47. Ultima fecha de cancelaci�n de cuota de capital =  2. Fecha de liquidaci�n

update jf77062.TB_DMAT04 set ULTIMAFECHACANCELACIONCUOTACAPITAL = FECHALIQUIDACION
WHERE NUMERODESEMBOLSO = 0
	and CODIGOLINEACREDITO <> '2'
	and (CONVERT(DECIMAL(15,2),Saldo)
		+ CONVERT(DECIMAL(15,2),MONTOVENCIDO30DIAS)
		+ CONVERT(DECIMAL(15,2),MONTOVENCIDO60DIAS)
		+ CONVERT(DECIMAL(15,2),MONTOVENCIDO90DIAS)
		+ CONVERT(DECIMAL(15,2),MONTOVENCIDO120DIAS))< 
		CONVERT(DECIMAL(15,2),MontoOriginal)			
	and (CODIGOCONTABLE like ('131%')
		or CODIGOCONTABLE like ('132%'))
	and MODALIDADHIPOTECA <> '2'
	and TIPOCREDITO <> '6'
	and (CODIGOCONTABLE not like ('13109%')
		or CODIGOCONTABLE not like ('13111%')
		or CODIGOCONTABLE not like ('13112%')
		or CODIGOCONTABLE not like ('13102%')
		or CODIGOCONTABLE not like ('13302%')
		or CODIGOCONTABLE not like ('13402%'))
	and ULTIMAFECHACANCELACIONCUOTACAPITAL <= (select ultfecha from #fechasup) --FACTUALIZARU CAMPO DEPENDIENDO EL MES A REPORTAR
and ULTIMAFECHACANCELACIONCUOTACAPITAL  < FECHALIQUIDACION  --CASO DONDE SE PLANTEA EL ERROR 

---si el error da con el credito 48580100000052203 

--------------------------------------------------------------------------------------------------------------
--Como el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13111,13112,13311,13312,13411,13412,13102,13302,13402,819), y el valor del campo 
--FECHA DE VENCIMIENTO ULTIMA CUOTA INTERES es mayor o igual que el valor del campo 
--FECHA DE LIQUIDACION entonces deber�a cumplirse que el valor del campo FECHA DE VENCIMIENTO 
--ULTIMA CUOTA INTERES sea menor o igual que el valor del campo FECHA DE VENCIMIENTO ACTUAL 
--(el valor del campo TASA DE INTERES ACTUAL sea mayor que 0 , y el valor del campo 
--FECHA DE VENCIMIENTO ULTIMA CUOTA INTERES sea menor o igual que el valor del campo 
--FECHA DE VENCIMIENTO ACTUAL )�(el valor del campo FECHA DE VENCIMIENTO ULTIMA CUOTA INTERES 
--sea menor o igual que el valor del campo FECHA DE VENCIMIENTO ACTUAL , y el valor del campo 
--TASA DE INTERES COBRADA sea mayor que 0 ) 

--SOLUCION DADA: 
--Para los cr�ditos abajo descritos el CAMPO 
--39 Fecha de Vencimiento Actual =  48 Fecha de Vencimiento �ltima Cuota de Intereses

UPDATE jf77062.TB_DMAT04 SET FechaVencimientoActual = FechaVencimientoUltimaCuotaInteres
WHERE (CODIGOCONTABLE NOT like ('13111%')
		or CODIGOCONTABLE NOT like ('13112%')
		or CODIGOCONTABLE NOT like ('13311%')
		or CODIGOCONTABLE NOT like ('13312%')
		or CODIGOCONTABLE NOT like ('13411%')
		or CODIGOCONTABLE NOT like ('13412%')
		or CODIGOCONTABLE NOT like ('13102%')
		or CODIGOCONTABLE NOT like ('13302%')
		or CODIGOCONTABLE NOT like ('13402%')
		or CODIGOCONTABLE NOT like ('819%'))
	and FechaVencimientoUltimaCuotaInteres  >= FECHALIQUIDACION
AND FechaVencimientoUltimaCuotaInteres > FechaVencimientoActual --CASO QUE PLANTEA EL ERROR

--------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
--Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (3,2) 
--entonces deber�a cumplirse que el valor del campo SITUACION DEL CREDITO sea igual a 0 

-- SELECT * FROM JF77062.TB_DMAT04
-- where ESTADOCREDITO in ('2','3')
-- and  SITUACIONCREDITO <> '0'

-- UPDATE jf77062.TB_DMAT04 
-- SET SITUACIONCREDITO = '0'
-- WHERE ESTADOCREDITO IN ('2','3')
-- AND SITUACIONCREDITO <> '0'
-- AND NUMEROCREDITO NOT IN ('8163630311','8163630309','8163630310')


--------------------------------------------------------------------------------------------------------------
--Error en el campo LICENCIA_TURISTICA_NACIONAL: La longitud del campo debe estar entre 
--1 y 8 caracteres, sin embargo, se encontraron 9 caracteres 

--SOLUCION DADA:
--Error l�nea 102641 CAMPO 98. LICENCIA_TURISTICA_NACIONAL =  TTT-033  

--LINEA ERRADA LA CORRECTA ES: ****102630****

-- UPDATE jf77062.TB_DMAT04 SET LICENCIATURISTICANACIONAL = 'TTT-033'
-- WHERE NUMEROCREDITO ='8111990302'

--------------------------------------------------------------------------------------------------------------
--Como el valor del campo RENDIMIENTO POR COBRAR VENCIDOS es mayor que 0 por lo menos una de las 
--siguientes afirmaciones deber�a cumplirse: -  Como el valor del campo CODIGO CONTABLE es distinto de 
--1321810101 entonces deber�a cumplirse que el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR 
--sea menor que 0 
-- o -  Como el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR es menor o igual que 0 
--entonces deber�a cumplirse que el valor del campo CODIGO CONTABLE sea igual a 1321810101

--SOLUCION DADA:
--L�nea 87562  64. Provisi�n = -0.01

UPDATE jf77062.TB_DMAT04 SET PROVISIONRENDIMIENTOCOBRAR = '-0.01'
WHERE CONVERT(DECIMAL(18,2),RENDIMIENTOSCOBRARVENCIDOS) > 0 
	AND CODIGOCONTABLE <> '1321810101'  --CASO 1
	AND CONVERT(DECIMAL(18,2),PROVISIONRENDIMIENTOCOBRAR) >= 0 --CASO 1 PARA SABER VALORES ERRADOS

--------------------------------------------------------------------------------------------------------------
--Como el valor del campo NUMERO DE DESEMBOLSO es mayor que 0, y el valor del campo SALDO + el valor 
--del campo MONTO VENCIDO A 30 DIAS + el valor del campo MONTO VENCIDO A 60 DIAS + el valor del campo 
--MONTO VENCIDO A 90 DIAS + el valor del campo MONTO VENCIDO A 120 DIAS es menor que el valor del campo 
--MONTO ORIGINAL, y el valor del campo CODIGO CONTABLE empieza por algunos de los siguientes valores: 
--(131,132), y el valor del campo MODALIDAD HIPOTECARIO es distinto de 2, y el valor del campo TIPO DE 
--CREDITO es distinto de 6, y el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes 
--valores: (13109,13111,13112,13102,13302,13402), y el valor del campo ULTIMA FECHA DE CANCELACION CUOTA 
--CAPITAL es mayor o igual que el valor del campo FECHA DE LIQUIDACION entonces deber�a cumplirse que el 
--valor del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL sea menor o igual que la fecha final del 
--per�odo reportado 


--SOLUCION DADA:
--LINEAS  102604 ,  102613 ULTIMA FECHA DE CANCELACION CUOTA CAPITAL = 20120629 un dia menos al ultimo dia mes


UPDATE jf77062.TB_DMAT04 SET ULTIMAFECHACANCELACIONCUOTACAPITAL = (select pencha from #fechasup) ----FactualizarP la fecha segun el mes a setear
from jf77062.TB_DMAT04 dm
WHERE convert(decimal(18,2),NUMERODESEMBOLSO) > 0
	and (CONVERT(DECIMAL(15,2),DM.Saldo)
		+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO30DIAS)
		+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO60DIAS)
		+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO90DIAS)
		+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO120DIAS))< 
		CONVERT(DECIMAL(15,2),DM.MontoOriginal)			
	and (CODIGOCONTABLE like ('131%')
		or CODIGOCONTABLE like ('132%'))
	and MODALIDADHIPOTECA <> '2'
	and TIPOCREDITO <> '6'
	and (CODIGOCONTABLE not like ('13109%')
		or CODIGOCONTABLE like ('13111%')
		or CODIGOCONTABLE like ('13112%')
		or CODIGOCONTABLE like ('13102%')
		or CODIGOCONTABLE like ('13302%')
		or CODIGOCONTABLE like ('13402%'))
	and ULTIMAFECHACANCELACIONCUOTACAPITAL  >= FECHALIQUIDACION
and ULTIMAFECHACANCELACIONCUOTACAPITAL > (select ultfecha from #fechasup)  ----Factualizaru la fecha segun el mes a setear

--------------------------------------------------------------------------------------------------------------
--Como el valor del campo MODALIDAD HIPOTECARIO es igual a 2, y el valor del campo ULTIMA FECHA DE 
---CANCELACION CUOTA CAPITAL es mayor o igual que el valor del campo FECHA DE LIQUIDACION entonces 
--deber�a cumplirse que el valor del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL sea menor o igual 
--que la fecha final del per�odo reportado 

--SOLUCION DADA:
--102652, 102810, 102811   ULTIMA FECHA DE CANCELACION CUOTA CAPITAL = 20120629


UPDATE jf77062.TB_DMAT04 SET ULTIMAFECHACANCELACIONCUOTACAPITAL = (select pencha from #fechasup) ----FactualizarP la fecha segun el mes a setear
WHERE MODALIDADHIPOTECA = '2'
	AND ULTIMAFECHACANCELACIONCUOTACAPITAL >= FECHALIQUIDACION
AND ULTIMAFECHACANCELACIONCUOTACAPITAL > (select ultfecha from #fechasup) ----FactualizarU la fecha segun el mes a setear
--------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 953): Como el valor del campo TIPO DE CREDITO es igual a 6, y el valor del campo ESTADO DEL CREDITO 
--es distinto de 1 entonces deber�a cumplirse que el valor del campo TIPO DE BENEFICIARIO SECTOR TURISMO sea igual a 0 

-- select tipocredito,estadocredito,TipoBeneficiarioSectorTurismo,
-- * from jf77062.TB_DMAT04 where tipocredito = '6' and estadocredito <> '1' 
-- and TipoBeneficiarioSectorTurismo <> '0'

update jf77062.TB_DMAT04
set TipoBeneficiarioSectorTurismo = '1'
where tipocredito = '6' and estadocredito = '1' 
and TipoBeneficiarioSectorTurismo = '0'
--------------------------------------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es igual a 6, y el valor del campo ESTADO DEL CREDITO es igual a 1 
--entonces deber�a cumplirse que el valor del campo TIPO DE BENEFICIARIO SECTOR TURISMO sea distinto de 0 
-- select tipocredito,estadocredito,TipoBeneficiarioSectorTurismo,
-- * from jf77062.TB_DMAT04 where tipocredito = '6' and estadocredito = '1' 
-- and TipoBeneficiarioSectorTurismo = '0'

--------------------------------------------------------------------------------------------------------------

--Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (4,6), y 
--el valor del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que el valor del 
--campo NOMBRE PROYECTO sea distinto de VACIO

--SOLUCION DADA:
--L�nea 102613, 102661, 102837, 102773, 102806  Campo 102 nombre del proyecto  = 0


UPDATE jf77062.TB_DMAT04 SET  nombreproyectounidadproduccion= '0'
WHERE TIPOCREDITO IN ('4','6')
AND ESTADOCREDITO='1'
and nombreproyectounidadproduccion =''  --5 

----------------------------------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CLIENTE es igual a uno de los siguientes valores: (J,G), y el 
--valor del campo IDENTIFICACION DEL CLIENTE es un n�mero entonces deber�a cumplirse que el valor 
--del campo IDENTIFICACION DEL CLIENTE sea un rif v�lido 

--SOLUCION DADA:
--RIF  (Tomado de la transmisi�n de Diciembre)
--Linea 102806  Cr�dito 8120950301  CAMPO 19 y 23  =  301862244
--Lineas 102773 ,  102806 y 102837     CAMPO 19 y 23  =  070014733

-- UPDATE jf77062.TB_DMAT04 SET TIPOCLIENTE = 'V',
-- 				IDENTIFICACIONCLIENTE = '17962922',
-- 				TIPOCLIENTERIF = 'V',
-- 				IDENTIFICACIONTIPOCLIENTERIF = '179629220'
-- WHERE NUMEROCREDITO IN ('9014390001')

-- UPDATE jf77062.TB_DMAT04 SET TIPOCLIENTE = 'J',
-- 				IDENTIFICACIONCLIENTE = '301862244',
-- 				TIPOCLIENTERIF = 'J',
-- 				IDENTIFICACIONTIPOCLIENTERIF = '301862244'
-- WHERE NUMEROCREDITO IN ('8122920307')
----------------------------------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es diferente de los siguientes valores: (4,6) 
--entonces deber�a cumplirse que el valor del campo 
--DIRECCION PROYECTO UNIDAD PRUDUCCION sea igual a VACIO

--SOLUCION DADA:
--SI EL tipo de cr�dito <> 4 OR 6 ENTONCES  103 DIRECCION DE PROYECTO = 0

update jf77062.TB_DMAT04  
set 	DIRECCIONPROYECTOUNIDADPRODUCCION = ''
WHERE 	TIPOCREDITO  not IN ('4', '6') and  
	DIRECCIONPROYECTOUNIDADPRODUCCION <> ''

-------------------------------------------------------------------------------------------------------------

--Como el valor del campo ESTADO DEL CREDITO es igual a 1, y el valor del campo el valor del campo 
--PERIODICIDAD DE PAGO DEL CAPITAL est� contenido dentro de los valores de la funcion binaria 3071, y 
--el valor del campo ULTIMA FECHA DE CANCELACION CUOTA INTERES es mayor o igual que el valor del campo 
--FECHA DE LIQUIDACION entonces deber�a cumplirse que el valor del campo 
--ULTIMA FECHA DE CANCELACION CUOTA INTERES sea menor o igual que la fecha final del per�odo 
--reportado ��(el valor del campo TASA DE INTERES ACTUAL sea mayor que 0 , y el valor del campo 
--ULTIMA FECHA DE CANCELACION CUOTA INTERES sea menor o igual que la fecha final del per�odo reportado )

--SOLUCION DADA:
--ULTIMA FECHA DE CANCELACION CUOTA INTERES  = 20120629
----ver



UPDATE jf77062.TB_DMAT04 SET ULTIMAFECHACANCELACIONCUOTAINTERESES =(select pencha from #fechasup) --FactualizarP la fecha segun el mes a setear
where ESTADOCREDITO = '1'
AND ULTIMAFECHACANCELACIONCUOTAINTERESES >= FECHALIQUIDACION
AND ULTIMAFECHACANCELACIONCUOTAINTERESES > (select ultfecha from #fechasup) --FactualizarU la fecha segun el mes a setear

 
-------------------------------------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (6,4), y 
--el valor del campo ESTADO DEL CREDITO es igual a 1, y el valor del campo FECHA DE LIQUIDACION 
--es mayor o igual que 20100101 entonces deber�a cumplirse que el valor del campo 
--FECHA ULTIMA INSPECCION sea mayor o igual que el valor del campo FECHA DE LIQUIDACION

--SOLUCION DADA:
--L�neas 102613, 102661, 102773, 102837   109. Fecha d �ltima inspecci�n = Fecha de liquidaci�n 

UPDATE jf77062.TB_DMAT04 SET FECHAULTIMAINSPECCION = FECHALIQUIDACION
where TIPOCREDITO IN ('6','4')
AND ESTADOCREDITO = '1'
AND FECHALIQUIDACION >= '2010/01/01'
AND FECHAULTIMAINSPECCION < FECHALIQUIDACION
 
-------------------------------------------------------------------------------------------------------------
--Como el valor del campo SALDO + el valor del campo MONTO VENCIDO A 30 DIAS + el valor del campo 
--MONTO VENCIDO A 60 DIAS + el valor del campo MONTO VENCIDO A 90 DIAS + el valor del campo 
--MONTO VENCIDO A 120 DIAS es igual a el valor del campo MONTO ORIGINAL, y el valor del campo 
--CODIGO CONTABLE empieza por algunos de los siguientes valores: (131,132), y el valor del campo 
--MODALIDAD HIPOTECARIO es distinto de 2, y el valor del campo TIPO DE CREDITO es distinto de 6, y 
--el valor del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL es mayor o igual que 19000101 
--entonces deber�a cumplirse que el valor del campo CODIGO CONTABLE empezara por algunos de los 
--siguientes valores: (13106,13206,13102,13302,13402) 


--SOLUCION DADA:
--Corregir  46. Fecha de vencimiento ultima cuota de capital  =  19000101


-- SELECT ULTIMAFECHACANCELACIONCUOTACAPITAL --DISTINCT CODIGOCONTABLE--,  
-- 	FROM jf77062.TB_DMAT04 dm
-- WHERE (CONVERT(DECIMAL(15,2),DM.Saldo)
-- 		+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO30DIAS)
-- 		+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO60DIAS)
-- 		+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO90DIAS)
-- 		+ CONVERT(DECIMAL(15,2),DM.MONTOVENCIDO120DIAS))= 
-- 		CONVERT(DECIMAL(15,2),DM.MontoOriginal)			
-- 	and MODALIDADHIPOTECA <> '2'
-- 	and TIPOCREDITO <> '6'
-- 	and (CODIGOCONTABLE like ('13109%')
-- 		or CODIGOCONTABLE like ('13111%')
-- 		or CODIGOCONTABLE like ('13112%')
-- 		or CODIGOCONTABLE like ('13102%')
-- 		or CODIGOCONTABLE like ('13302%')
-- 		or CODIGOCONTABLE like ('13402%'))
-- 	and ULTIMAFECHACANCELACIONCUOTACAPITAL  <> '1900/01/01' --no ahi

--------------------------------------------------------------------------------------------------------
--Como el valor del campo CANTIDAD DE PRORROGA es igual a 0, y el valor del campo 
--FECHA DE VENCIMIENTO ACTUAL es distinto de 19000101, y el valor del campo CANTIDAD DE RENOVACIONES 
--es igual a 0 entonces deber�a cumplirse que el valor del campo FECHA DE VENCIMIENTO ACTUAL sea igual 
--a el valor del campo FECHA DE VENCIMIENTO ORIGINAL


--SOLUCION DADA:
--39 Fecha de Vencimiento Actual =  38 Fecha de Vencimiento Original
--Si el valor del campo [Cantidad de Pr�rroga] es igual que (�0�) o el valor del campo 
--[Cantidad de Renovaciones] es igual que (�0�), entonces el valor de este campo debe ser igual 
--que el valor del campo [Fecha de Vencimiento Original].

/*FALTA HACER*/

update jf77062.TB_DMAT04 
set FECHAVENCIMIENTOACTUAL = FECHAVENCIMIENTOORIGINAL
where CONVERT(DECIMAL,CANTIDADPRORROGA) = 0
	AND FECHAVENCIMIENTOACTUAL <> '1900/01/01'
	AND CONVERT(DECIMAL,CANTIDADRENOVACIONES) = 0
and FECHAVENCIMIENTOACTUAL <> FECHAVENCIMIENTOORIGINAL

--------------------------------------------------------------------------------------------------------
update jf77062.TB_DMAT04
set	montooriginal = SALDO,
	montoinicial = SALDO
where convert(decimal(18,2), Saldo) > convert(decimal(18,2),MontoOriginal)
and  convert(decimal(18,2), Saldo) > convert(decimal(18,2),MontoInicial)

--------------------------------------------------------------------------------------------------------------
--Como el valor del campo FECHA ULTIMA INSPECCION es distinto de 19000101 entonces deber�a cumplirse 
--que el valor del campo PORCENTAJE EJECUCION PROYECTO sea mayor que 0

--SOLUCION DADA:
--SETEAR 100 % A LOS CASOS

UPDATE jf77062.TB_DMAT04 SET PORCENTAJEEJECUCIONPROYECTO = '100.0000'
WHERE FECHAULTIMAINSPECCION <> '1900/01/01'
AND CONVERT(DECIMAL(18,2),PORCENTAJEEJECUCIONPROYECTO) <= 0
---------------------------------------------------------------------------

/* Error de Fondo (Error Nro. 7): Como el valor del campo FECHA ULTIMA INSPECCION 
es igual a 19000101 entonces deber�a cumplirse que el valor del campo 
PORCENTAJE EJECUCION PROYECTO sea igual a 0 */

UPDATE jf77062.TB_DMAT04 SET PORCENTAJEEJECUCIONPROYECTO = '0.00'
WHERE FECHAULTIMAINSPECCION = '1900/01/01'
AND CONVERT(DECIMAL(18,2),PORCENTAJEEJECUCIONPROYECTO) = 100.00

---------------------------------------------------------------------------
--Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (2,3) 
--entonces deber�a cumplirse que el valor del campo PLAZO DEL CREDITO sea igual a 0

UPDATE jf77062.TB_DMAT04
SET 	PLAZOCREDITO = '0'
WHERE 	ESTADOCREDITO IN  ('2','3')
	AND PLAZOCREDITO <> '0' 

/*Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (2,3) 
entonces deber�a cumplirse que el valor del campo PERIODICIDAD DE PAGO INTERES DEL CREDITO sea igual a 0 */
	
UPDATE jf77062.TB_DMAT04
SET 	PeriodicidadPagoInteresCredito = '0'
WHERE 	ESTADOCREDITO IN  ('2','3')
	AND PeriodicidadPagoInteresCredito <> '0' 
	
/*Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: 
(2,3) entonces deber�a cumplirse que el valor del campo NUMERO DE CUOTAS VENCIDAS sea igual a 0	*/
UPDATE jf77062.TB_DMAT04
SET 	NumeroCuotasVencidas = '0'
WHERE 	ESTADOCREDITO IN  ('2','3')
	AND NumeroCuotasVencidas <> '0' 
	
	
----------------------------------

--Como el valor del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que ��el valor del 
--campo CODIGO CONTABLE empezara por algunos de los siguientes valores: (132)�el valor del campo 
--CODIGO CONTABLE empezara por algunos de los siguientes valores: (134)�el valor del campo CODIGO CONTABLE 
--empezara por algunos de los siguientes valores: (131)

--***** NORMALMENTE SON CASOS PUNTUALES***********--


-------------------------------------------------------


--Como el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13111,13112,13311,13312,13411,13412,13102,13302,13402,819), y el valor del campo 
--FECHA DE VENCIMIENTO ULTIMA CUOTA INTERES es mayor o igual que el valor del campo 
--FECHA DE LIQUIDACION entonces deber�a cumplirse que el valor del campo 
--FECHA DE VENCIMIENTO ULTIMA CUOTA INTERES sea menor o igual que el valor del campo 
--FECHA DE VENCIMIENTO ACTUAL (el valor del campo TASA DE INTERES ACTUAL sea mayor que 0 , y 
--el valor del campo FECHA DE VENCIMIENTO ULTIMA CUOTA INTERES sea menor o igual que el valor del campo 
--FECHA DE VENCIMIENTO ACTUAL )�(el valor del campo FECHA DE VENCIMIENTO ULTIMA CUOTA INTERES 
--sea menor o igual que el valor del campo FECHA DE VENCIMIENTO ACTUAL , y el valor del campo 
--TASA DE INTERES COBRADA sea mayor que 0 ) 

UPDATE jf77062.TB_DMAT04 SET FECHAVENCIMIENTOULTIMACUOTAINTERES = FECHAVENCIMIENTOACTUAL
WHERE (CODIGOCONTABLE not like ('13311%')
		OR CODIGOCONTABLE not like ('13312%')
		or CODIGOCONTABLE not like ('13111%')
		or CODIGOCONTABLE not like ('13112%')
		or CODIGOCONTABLE not like ('13102%')
		or CODIGOCONTABLE not like ('13302%')
		or CODIGOCONTABLE not like ('13402%')
		or CODIGOCONTABLE not like ('13411%')
	or CODIGOCONTABLE not like ('13412%')
	or CODIGOCONTABLE not like ('819%'))
AND FECHAVENCIMIENTOULTIMACUOTAINTERES >= FECHALIQUIDACION
AND FECHAVENCIMIENTOULTIMACUOTAINTERES > FECHAVENCIMIENTOACTUAL

-------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------
-- El valor del campo NUMERO DE CUOTAS debe ser mayor que 0 

/*Verficar que este credito posea numero de cuotas mayor que cero, en caso de que no sea asi,
correr el query de update*/

--SOLUCION DADA:

-- update jf77062.TB_DMAT04 set numerocuotas = '36'
-- where numerocredito ='3000000166'
-------------------------------------------------------------------------------------------------------------

-- SELECT DM.ESTADOCREDITO, DM.TIPOSUBSECTOR , 
-- DM.SITUACIONCREDITO AS SITUACIONCREDITO,
-- DM.CODIGOCONTABLE AS NUEVO,
-- DM.NUMEROCREDITO, 
-- DM.RUBRO AS NUEVO_RUBRO, 
-- DM.CODIGOUSO AS NUEVO_CODIGOUSO,
-- TIPODC
-- FROM jf77062.TB_DMAT04 DM 
-- WHERE DM.ESTADOCREDITO = '1' 
-- AND DM.TIPOCREDITO = '4' 
-- AND DM.TIPOSUBSECTOR = '0'


-- SELECT DM.TIPOSUBSECTOR , 
-- DM.RUBRO AS NUEVO_RUBRO, 
-- DM.CODIGOUSO AS NUEVO_CODIGOUSO,
-- dm.NumeroRegistro_ConstanciaMPPAT,
-- dm.TipoRegistro_ConstanciaMPPAT,
-- dm.FechaVencimientoRegistro_ConstanciaMPPAT,
-- DM.NUMEROCREDITO
-- FROM jf77062.TB_DMAT04 DM 
-- WHERE DM.ESTADOCREDITO = '1' 
-- AND DM.TIPOCREDITO = '4' 
-- AND DM.TIPOSUBSECTOR = '0'
-- and dm.TipoRegistro_ConstanciaMPPAT <> ''

----------------------------------------------------------------------------------------------------------------

--Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (4,6), y el valor del 
--campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que el valor del campo NOMBRE PROYECTO 
--sea distinto de VACIO 

-- SELECT NombreProyectoUnidadProduccion
-- FROM jf77062.TB_DMAT04 DM 
-- WHERE DM.ESTADOCREDITO = '1' 
-- AND DM.TIPOCREDITO = '4' 
-- AND DM.TIPOSUBSECTOR = '0'and
--  dm.TipoRegistro_ConstanciaMPPAT <> '' --no ahi

 --Reportar

----------------------------------------------------------------------------------------------------------------

--Como el valor del campo CLASIFICACION DE RIESGO es distinto de A entonces deber�a cumplirse que el
--valor del campo PROVISION ESPECIFICA sea menor que 0 

-- UPDATE jf77062.TB_DMAT04 
-- --SET ProvisionEspecifica=(CONVERT(DECIMAL(18,2),ISNULL(PocentajeProvisionEspecifica,0))*CONVERT(DECIMAL(18,2),ISNULL(Saldo,0))/100)*-1
-- SET ProvisionEspecifica=(CONVERT(DECIMAL(18,2),ISNULL(PocentajeProvisionEspecifica,0))*CONVERT(DECIMAL(18,2),ISNULL(Saldo,0)))*-1
-- where  CONVERT(DECIMAL(18,2),ISNULL(provisionespecifica, 0)) >= 0 
-- and ClasificacionRiesgo not in ('A', '0')

--Cuando el saldo = 0 pero CLASIFICACION DE RIESGO es distinto de A

-- UPDATE jf77062.TB_DMAT04 
-- SET ProvisionEspecifica = '-0.01'
-- where  CONVERT(DECIMAL(18,2),ISNULL(provisionespecifica, 0)) >= 0 
-- 	and CONVERT(DECIMAL(18,2),ISNULL(saldo, 0)) = 0
-- 	and ClasificacionRiesgo not in ('A', '0')

-- --para atajat unos que no se ajustaron debidoa que el saldo no estaba en 0
-- --y dieron error en una pre validacion
-- UPDATE jf77062.TB_DMAT04 
-- SET  ProvisionEspecifica = '-0.01'
-- where  CONVERT(DECIMAL(18,2),ISNULL(provisionespecifica, 0)) >= 0 
-- 	--and CONVERT(DECIMAL(18,2),ISNULL(saldo, 0)) = 0
-- 	and ClasificacionRiesgo not in ('A', '0')	
	
----------------------------------------------------------------------------------------------------------------
--porsiaca
-- select situacioncredito, numerocredito 
-- from jf77062.TB_DMAT04
-- where codigocontable like('133%') and EstadoCredito ='1' and situacioncredito <> '3'--no ahi

----------------------------------------------------------------------------------------------------------------
/*aqui*/
--Error en el campo PROVISION_ESPECIFICA: El valor cero (0,0) no puede ser negativo 

UPDATE jf77062.TB_DMAT04 
SET ProvisionEspecifica =  '-0.01'
WHERE ProvisionEspecifica like '-0.00%'

----------------------------------------------------------------------------------------------------------------
-- Como el valor del campo RUBRO es distinto de 0 entonces deber�a cumplirse que el valor del campo 
--CANTIDAD DE UNIDADES sea distinto de 0 

-- SELECT rubro
-- FROM jf77062.TB_DMAT04 DM 
-- WHERE CONVERT(DECIMAL(18,2), DM.RUBRO) <> 0
-- AND CONVERT(DECIMAL(18,2),DM.CANTIDADUNIDADES) = 0


/*SOLUCION: COLOCAR LA DATA DE DICIEMBRE*/

----------------------------------------------------------------------------------------------------

--Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (4,6), y el valor 
--del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que el valor del campo NOMBRE 
--PROYECTO sea distinto de VACIO 

-- select 	numerocredito,
-- 	NombreProyectoUnidadProduccion,
-- 	tipocredito
-- from jf77062.TB_DMAT04
-- where 	NombreProyectoUnidadProduccion = '' and
-- 	tipocredito in ('4', '6') and
-- 	estadocredito = '1'

--SOLUCION PONER INF DE DIC

----------------------------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (4,6) 
--entonces deber�a cumplirse que el valor del campo DIRECCION PROYECTO UNIDAD PRUDUCCION sea 
--distinto de VACIO 
-- select 	numerocredito,
-- 	tipocredito,
-- 	DireccionProyectoUnidadProduccion
-- from jf77062.TB_DMAT04
-- where 	DireccionProyectoUnidadProduccion = '' and
-- 	tipocredito in ('4', '6')
	
UPDATE jf77062.TB_DMAT04 
SET DireccionProyectoUnidadProduccion = DM2.DireccionProyectoUnidadProduccion
FROM jf77062.TB_DMAT04 DM
INNER JOIN #TEMP_AT04_MesAnterior DM2 on DM2.NUMEROCREDITO = DM.NumeroCredito
WHERE  DM.DireccionProyectoUnidadProduccion = '' and
	DM.TipoCredito in ('4', '6')	
	

--SOLUCION PONER INF DE DIC
------------------------------------------
--Error en el campo CODIGO_DE_LINEA_DE_CREDITO: 
--El valor del campo debe estar entre 0 y 2

-- SELECT NumeroCredito,CodigoLineaCredito,NumeroCreditoPrimerDesembolso ,NumeroDesembolso ,EstadoCredito, TipoDC, * FROM JF77062.TB_DMAT04
-- WHERE CodigoLineaCredito = '-1'

---Solucion 
UPDATE jf77062.tb_dmat04 
SET CodigoLineaCredito = 1 
WHERE CodigoLineaCredito =-1

---------------------------------------------------------------------------------------------------------

--Como el valor del campo TIPO DE CREDITO es igual a 4, y el valor del campo ESTADO DEL CREDITO es igual a 
--1 entonces deber�a cumplirse que el valor del campo NUMERO REGISTRO MPPAT sea mayor que 0 

-- SELECT 	NUMEROCREDITO, 
-- 	tipocredito,  
-- 	estadocredito, 
-- 	situacioncredito,
-- 	NumeroRegistro_ConstanciaMPPAT
-- FROM jf77062.TB_DMAT04 DM 
-- WHERE 	tipocredito = '4' AND 
-- 	estadocredito = '1' AND
-- 	NumeroRegistro_ConstanciaMPPAT = ''
	

/* COLOCAR INFORMACION DE DICIEMBRE*/


---------------------------------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (4,6), y el 
--valor del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que el valor del campo 
--NOMBRE PROYECTO sea distinto de VACIO 


-- SELECT 	NombreProyectoUnidadProduccion -- SI EL ESTADO DEL CREDITO = 3 ENTONCES NombreProyectoUnidadProduccion = ''
-- FROM jf77062.TB_DMAT04 DM 
-- where dm.TIPOCREDITO in ('4','6')
-- and dm.ESTADOCREDITO = '1'
-- and dm.NombreProyectoUnidadProduccion = ''

/* COLOCAR INFORMACION DE DICIEMBRE*/

---------------------------------------------------------------------------------------------------------

--Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (6,4), y el 
--valor del campo ESTADO DEL CREDITO es igual a 1, y el valor del campo FECHA DE LIQUIDACION es 
--mayor o igual que 20100101 entonces deber�a cumplirse que el valor del campo FECHA ULTIMA INSPECCION 
--sea mayor o igual que el valor del campo FECHA DE LIQUIDACION 

-- select FECHALIQUIDACION, 
-- FECHAULTIMAINSPECCION   
-- from jf77062.TB_DMAT04
-- WHERE TIPOCREDITO IN ('4','6') AND
-- 	ESTADOCREDITO = '1' AND
-- 	FECHALIQUIDACION >= '2010/01/01' AND
-- 	FECHAULTIMAINSPECCION < FECHALIQUIDACION

--EN CASO DE APLICAR NOTIFICAR

----------------------------------------------------------------------------------------------
--Como el valor del campo SITUACION DEL CREDITO es igual a uno de los siguientes valores: 
--(3,4) entonces deber�a cumplirse que el valor del campo NUMERO DE CUOTAS VENCIDAS sea mayor 
--que 0 --colocar valor 1 por defecto al campo NUMERO DE CUOTAS VENCIDAS

-- select tipodc, estadocredito ,numerocuotasvencidas, SituacionCredito,MONTOVENCIDO60DIAS  --,  numerocuotasvencidas ,,
-- from jf77062.TB_DMAT04
-- where 	situacioncredito in ('3','4') and
-- 	numerocuotasvencidas <=0  --300 tipodc 2/5/16

UPDATE
  jf77062.TB_DMAT04
SET
  NumeroCuotasVencidas = C.NUM_CUOTAS_VENCIDAS
FROM
  jf77062.TB_DMAT04 DM
  INNER JOIN RPT_STG_Dirigidas_TURISMO C ON C.NUM_CREDITO = DM.NUMEROCREDITO
  AND DM.TIPODC = ('8')
UPDATE
  jf77062.TB_DMAT04
SET
  NumeroCuotasVencidas = F.NUM_CUOTAS_VENCIDAS
FROM
  jf77062.TB_DMAT04 DM
  INNER JOIN RPT_STG_Dirigidas_AGRICOLA_CORPORATE F ON F.NUM_CREDITO = DM.NUMEROCREDITO
  AND DM.TIPODC = ('11')
UPDATE
  jf77062.TB_DMAT04
SET
  NumeroCuotasVencidas = E.NUM_CUOTAS_VENCIDAS
FROM
  jf77062.TB_DMAT04 DM
  INNER JOIN RPT_STG_Dirigidas_MANUFACTURA E ON E.NUM_CREDITO = DM.NUMEROCREDITO
  AND DM.TIPODC = ('10')
UPDATE
  jf77062.TB_DMAT04
SET
  NumeroCuotasVencidas = B.NUM_CUOTAS_VENCIDAS
FROM
  jf77062.TB_DMAT04 DM
  INNER JOIN RPT_STG_Dirigidas_HIPOTECARIO_CORTO_PLAZO B ON B.NUM_CREDITO = DM.NUMEROCREDITO
  AND DM.TIPODC = ('7')
UPDATE
  jf77062.TB_DMAT04
SET
  NumeroCuotasVencidas = PC.MaxOfCantCuotasVencidas
FROM
  jf77062.TB_DMAT04 DM
  INNER JOIN TMP_PROVISONESCAPITAL PC ON PC.Account = DM.NUMEROCREDITO

UPDATE jf77062.TB_DMAT04 SET numerocuotasvencidas = DM2.numerocuotasvencidas
FROM jf77062.TB_DMAT04 DM
INNER JOIN #TEMP_AT04_MesAnterior DM2 on DM2.NUMEROCREDITO = DM.NumeroCredito
WHERE  	DM.situacioncredito in ('3','4') and
	DM.numerocuotasvencidas <=0


/*SOLO APLICAR CUANDO SE HAGAN CAMBIOS EN LA CONTABILIDAD SOBRE LOS BOCKETS VENCIDOS*/
UPDATE jf77062.TB_DMAT04 
SET NumeroCuotasVencidas = CASE
	WHEN SituacionCredito in ('1', '2', '3', '4') THEN
		CASE
			WHEN CONVERT(DECIMAL(18,2),MONTOVENCIDO180DIAS) <> CONVERT(DECIMAL(18,2),0) THEN 5
			WHEN CONVERT(DECIMAL(18,2),MONTOVENCIDO120DIAS) <> CONVERT(DECIMAL(18,2),0) THEN 4
			WHEN CONVERT(DECIMAL(18,2),MONTOVENCIDO90DIAS) <> CONVERT(DECIMAL(18,2),0) THEN 3
			WHEN CONVERT(DECIMAL(18,2),MONTOVENCIDO60DIAS) <> CONVERT(DECIMAL(18,2),0) THEN 2					
			WHEN CONVERT(DECIMAL(18,2),MONTOVENCIDO30DIAS) <> CONVERT(DECIMAL(18,2),0) THEN 1
		ELSE 0
		END
	WHEN EstadoCredito in ('2','3')  THEN 0
	ELSE 0
	END
FROM jf77062.TB_DMAT04 
where tipodc in ('5','2','6')

-- Y SI DESPUES DE HACER EL UPDATE ANTERIOR AUN QUEDAN CUOTAS VENCIDAS = 0, ESTAS SE DEBEN SETEAR
-- CON EL VALOR 1

UPDATE jf77062.TB_DMAT04
SET numerocuotasvencidas = '1'
WHERE situacioncredito in ('3','4') and
	numerocuotasvencidas <=0 --345

/****************************************************************************************/

--Como el valor del campo NATURALEZA DEL CLIENTE es igual a 2 entonces deber�a cumplirse que 
--el valor del campo TIPO DE CLIENTE sea igual a uno de los siguientes valores: (J,I,G,X)
-- select NATURALEZACLIENTE
-- from jf77062.TB_DMAT04
-- where 	TIPOCLIENTE in ('V', 'E', 'P') and
-- 	NATURALEZACLIENTE <> '1'--no ahi

--Como el valor del campo ESTADO DEL CREDITO es diferente de los siguientes valores: (1,3) 
--entonces deber�a cumplirse que el valor del campo SALDO sea igual a 0 

UPDATE jf77062.TB_DMAT04
SET  saldo = '0.00'
where 	estadocredito not in ('1','3') and 
	CONVERT(DECIMAL(18,2),saldo) > 0

--------------------------------------------------------------------------
--Como el valor del campo ESTADO DEL CREDITO es igual a 2, y el valor del 
--campo FECHA DE CANCELACION TOTAL es menor o igual que la fecha final del per�odo reportado 
--entonces deber�a cumplirse que el valor del campo FECHA DE CANCELACION TOTAL sea mayor que el valor 
--del campo FECHA DE LIQUIDACION 

--SOLUCION: COLOCARLE AL CAMPO fechacancelaciontotal = ULTIMO DIA DEL MES A REPORTAR

UPDATE jf77062.TB_DMAT04
SET fechacancelaciontotal = (select ultfecha from #fechasup)--FactualizarU
where 	estadocredito = '2' and 
	fechacancelaciontotal <= (select ultfecha from #fechasup) and --FactualizarU
	fechacancelaciontotal <= fechaliquidacion 


--Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (2,3) 
--entonces deber�a cumplirse que el valor del campo CLASIFICACION DE RIESGO sea igual a 0


UPDATE jf77062.TB_DMAT04
SET CLASIFICACIONRIESGO = '0'
where 	estadocredito IN ('2','3') and 
	CLASIFICACIONRIESGO <> '0' 

--Como el valor del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que 
--��el valor del campo CODIGO CONTABLE empezara por algunos de los siguientes valores: 
--(132)�el valor del campo CODIGO CONTABLE empezara por algunos de los siguientes valores: 
--(134)�el valor del campo CODIGO CONTABLE empezara por algunos de los siguientes valores: 
--(131)revisarabril2013

--SOLUCION: Revisar los registros de la 819.

-- select estadocredito, agri.estado_credito,NUMEROCREDITO
-- from jf77062.TB_DMAT04 dm
-- INNER join RPT_STG_Dirigidas_AGRICOLA_CONSUMER agri on convert(decimal,agri.num_credito) = dm.NUMEROCREDITO
-- where 	codigocontable like ('819%') and
-- 	estadocredito <> agri.estado_credito --0

UPDATE jf77062.TB_DMAT04
SET	estadocredito = estado_credito
from jf77062.TB_DMAT04 dm
INNER join RPT_STG_Dirigidas_AGRICOLA_CONSUMER agri on convert(decimal,agri.num_credito) = dm.NUMEROCREDITO
where 	codigocontable like ('819%') and
	estadocredito = '1'


-----------------------------------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (4,6), 
--y el valor del campo ESTADO DEL CREDITO es distinto de 1 entonces deber�a cumplirse que el 
--valor del campo NOMBRE PROYECTO sea igual a VACIO 

--COMO SON CASTIGO SE DEBE TRATAR COMO TAL, POR ENDE TIPO DE CREDITO DEBE DE SER = 0,
-- NombreProyectoUnidadProduccion = '' 
-- SI EL ESTADO DEL CREDITO = 3 ENTONCES NombreProyectoUnidadProduccion = ''

UPDATE jf77062.TB_DMAT04
SET 	NombreProyectoUnidadProduccion = '',
	TIPOCREDITO = '0'
where 	TIPOCREDITO in ('4','6')
	and ESTADOCREDITO <> '1'
	and NombreProyectoUnidadProduccion <> ''

--Como el valor del campo CODIGO DE LINEA DE CREDITO es distinto de 2, y el valor del campo 
--CODIGO CONTABLE no empieza por algunos de los siguientes valores: (13106101,13106201,13106102,
--13106202,13206101,13206201,13206102,13206202,13306101,13306201,13306102,13306202,13406101,
--13406201,13406102,13406202) entonces deber�a cumplirse que el valor del campo MONTO DE LA 
--LINEA DE CREDITO sea igual a 0

UPDATE jf77062.TB_DMAT04
SET MontoLineaCredito = '0.00'
where CodigoLineaCredito <> '2'  
       AND CODIGOCONTABLE NOT LIKE ('13106101%') 
       AND  CODIGOCONTABLE NOT LIKE ('13106201%') 
       AND  CODIGOCONTABLE NOT LIKE ('13106102%') 
       AND  CODIGOCONTABLE NOT LIKE ('13106202%') 
       AND  CODIGOCONTABLE NOT LIKE ('13206101%') 
       AND  CODIGOCONTABLE NOT LIKE ('13206201%') 
       AND  CODIGOCONTABLE NOT LIKE ('13206102%') 
       AND  CODIGOCONTABLE NOT LIKE ('13206202%') 
       AND  CODIGOCONTABLE NOT LIKE ('13306101%') 
       AND  CODIGOCONTABLE NOT LIKE ('13306201%') 
       AND  CODIGOCONTABLE NOT LIKE ('13306102%') 
       AND  CODIGOCONTABLE NOT LIKE ('13306202%') 
       and convert(decimal(18,2),MontoLineaCredito) <> 0

--------------------------------------------------------------------------------------------
--Como el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13102,13302,13402), y el valor del campo FECHA DE VENCIMIENTO ULTIMA CUOTA CAPITAL es menor 
--o igual que el valor del campo FECHA DE VENCIMIENTO ACTUAL entonces deber�a cumplirse que el 
--valor del campo FECHA DE VENCIMIENTO ULTIMA CUOTA CAPITAL sea mayor o igual que el valor del 
--campo FECHA DE LIQUIDACION 

--solucion: el campo FECHA DE VENCIMIENTO ULTIMA CUOTA CAPITAL = FECHA DE LIQUIDACION 


UPDATE 	jf77062.TB_DMAT04
SET 	FechaVencimientoUltimaCoutaCapital = FechaLiquidacion
where 	CODIGOCONTABLE NOT LIKE ('13102%') 
       	AND  CODIGOCONTABLE NOT LIKE ('13302%') 
       	AND  CODIGOCONTABLE NOT LIKE ('13402%') 
       	and FechaVencimientoUltimaCoutaCapital <= FechaVencimientoActual
	and FechaVencimientoUltimaCoutaCapital < FechaLiquidacion

--Como el valor del campo SALDO es igual a el valor del campo MONTO ORIGINAL, y el valor del campo 
--CODIGO CONTABLE empieza por algunos de los siguientes valores: (133,134), y el valor del campo 
--MODALIDAD HIPOTECARIO es distinto de 2, y el valor del campo TIPO DE CREDITO es distinto de 6, y 
--el valor del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL es mayor o igual que 19000101 
--entonces deber�a cumplirse que el valor del campo CODIGO CONTABLE empezara por algunos de los 
--siguientes valores: (13306,13406)

--SOLUCION: COLOCARLE AL CAMPO UltimaFechaCancelacionCuotaCapital = '1900/01/01'

UPDATE jf77062.TB_DMAT04
SET UltimaFechaCancelacionCuotaCapital = '1900/01/01'
where 	convert(decimal(18,2), saldo) = convert(decimal(18,2), MontoOriginal)
	and (CODIGOCONTABLE LIKE ('133%')
	or CODIGOCONTABLE LIKE ('134%'))
       	AND CODIGOCONTABLE not LIKE ('13306%') 
       	AND CODIGOCONTABLE not LIKE ('13406%') 
       	AND ModalidadHipoteca <> '2'
	AND TipoCredito <> '6'
	AND UltimaFechaCancelacionCuotaCapital > '1900/01/01'

----------------------RIF INVALIDO-----------------------------
--8122370307, 0301862244 (IdentificacionCliente),0030186224 (IdentificacionTipoClienteRIF)

-- UPDATE jf77062.TB_DMAT04
-- SET 	IdentificacionCliente = '301862244',
-- 	IdentificacionTipoClienteRIF = '301862244'
-- where numerocredito = '8122370307'

-- UPDATE jf77062.TB_DMAT04
-- SET 	IdentificacionCliente = '301862244',
-- 	IdentificacionTipoClienteRIF = '301862244'
-- where numerocredito = '8130510306'


-- UPDATE jf77062.TB_DMAT04
-- SET 	IdentificacionCliente = '307617470',
-- 	IdentificacionTipoClienteRIF = '307617470'
-- where numerocredito = '8130530315'

-------------------------------------------------------------
--Como el valor del campo NUMERO DE DESEMBOLSO es igual a 0, 
--y el valor del campo CODIGO CONTABLE empieza por algunos de los siguientes valores: 
--(131,132), y el valor del campo MODALIDAD HIPOTECARIO es distinto de 2, y el valor del 
--campo TIPO DE CREDITO es distinto de 6, y el valor del campo CODIGO CONTABLE no empieza 
--por algunos de los siguientes valores: (13109,13111,13112,13102,13302,13402) entonces deber�a 
--cumplirse que el valor del campo CODIGO DE LINEA DE CREDITO sea distinto de 2, y el valor del 
--campo SALDO + el valor del campo MONTO VENCIDO A 30 DIAS + el valor del campo MONTO VENCIDO A 
--60 DIAS + el valor del campo MONTO VENCIDO A 90 DIAS + el valor del campo MONTO VENCIDO A 120 
--DIAS sea menor que el ... ERROR GRANDE

--SOLUCION: COLOCAR AL CAMPO MontoOriginal  Y MontoInicial EL VALOR DE LA SUMA DEL SALDO MAS LOS BUCKET VENCIDOS
--************** CASOS ESPECIFICOS**********-------
/*select NUMEROCREDITO, 
	sum(	convert(decimal(15,2),saldo)+ 
		convert(decimal(15,2),MontoVencido30dias) +
		convert(decimal(15,2),MontoVencido60dias)+
		convert(decimal(15,2),MontoVencido90dias)+
		convert(decimal(15,2),MontoVencido120dias)), 
	MontoOriginal, MontoInicial
from jf77062.TB_DMAT04
where numerocredito = '8057294109'
group by NUMEROCREDITO, MontoOriginal, MontoInicial



UPDATE jf77062.TB_DMAT04
SET	MontoOriginal = convert(decimal(15,2),saldo)+ 
		convert(decimal(15,2),MontoVencido30dias) +
		convert(decimal(15,2),MontoVencido60dias)+
		convert(decimal(15,2),MontoVencido90dias)+
		convert(decimal(15,2),MontoVencido120dias),
	MontoInicial = convert(decimal(15,2),saldo)+ 
		convert(decimal(15,2),MontoVencido30dias) +
		convert(decimal(15,2),MontoVencido60dias)+
		convert(decimal(15,2),MontoVencido90dias)+
		convert(decimal(15,2),MontoVencido120dias)
where numerocredito = '8057294109'*/
------------------------------------------------------------------------
--Como el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13106101,13106201,13106102,13106202,13206101,13206201,13206102,13206202,13306101,13306201,
--13306102,13306202,13406101,13406201,13406102,13406202) entonces deber�a cumplirse que el valor 
--del campo MONTO INICIAL AT04 sea mayor que 0
--para atajar

-- select montoinicial,* from jf77062.TB_DMAT04 where codigocontable not in ('13106101','13106201','13106102',
-- '13106202','13206101','13206201','13206102','13206202','13306101','13306201','13306102',
-- '13306202','13406101','13406201','13406102','13406202') and 
-- convert(decimal(18,2),montoinicial) < 0

-- select *--NUMEROCREDITO, SALDO, MONTOINICIAL, MONTOORIGINAL
-- from jf77062.TB_DMAT04
-- WHERE numerocredito in ('4858010000214365','4858010000000145')


/* CASOS ESPECIFICOS, EN CASO DE PRESENTARSE ESTE ERROR LO QUE SE DEBE HACER ES COLOCAR
AL CAMPO MONTOINICIAL EL VALOR DEL CAMPO MONTOORIGINAL O VICEVERSA
  PERO EN CASO DE NO TENER NUMEROS DE CREDITOS ASOCIADOS AL CLIENTE, SE DEBE REPORTAR Y EN
LA MAYORIA DE LOS CASOS LOS MANDAN A ELIMINAR DEL REPORTE*/

--Como el valor del campo NUMERO DE DESEMBOLSO es mayor que 0, y el valor del campo SALDO + 
--el valor del campo MONTO VENCIDO A 30 DIAS + el valor del campo MONTO VENCIDO A 60 DIAS + 
--el valor del campo MONTO VENCIDO A 90 DIAS + el valor del campo MONTO VENCIDO A 120 DIAS es 
--menor que el valor del campo MONTO ORIGINAL, y el valor del campo CODIGO CONTABLE empieza por 
--algunos de los siguientes valores: (131,132), y el valor del campo MODALIDAD HIPOTECARIO es 
--distinto de 2, y el valor del campo TIPO DE CREDITO es distinto de 6, y el valor del campo 
--CODIGO CONTABLE no empieza por algunos de los siguientes valores: (13109,13111,13112,13102,
--13302,13402), y el valor del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL es menor o igual 
--que la fecha final del per�odo reportado entonces deber�a cumplirse que el valor del campo 
--ULTIMA FECHA DE CANCELACION CUOTA CAPITAL sea mayor o igual que el valor del campo 
--FECHA DE LIQUIDACION 

--SOLUCION: COLOCARLE AL CAMPO UltimaFechaCancelacionCuotaCapital = FECHA DE LIQUIDACION 
--HACER QUERY
-- select tipodc,ModalidadHipoteca,tipocredito,ultimafechacancelacioncuotacapital,fechaliquidacion,*
-- from jf77062.TB_DMAT04
-- where 
-- numerodesembolso > 0 and
-- (convert(decimal(18,2),replace(saldo,',','.'))+
-- convert(decimal(18,2),replace(MontoVencido30dias,',','.'))+
-- convert(decimal(18,2),replace(MontoVencido60dias,',','.'))+
-- convert(decimal(18,2),replace(MontoVencido90dias,',','.'))+
-- convert(decimal(18,2),replace(MontoVencido120dias,',','.')))< convert(decimal(18,2),replace(MontoOriginal,',','.')) 
-- and ModalidadHipoteca <> '2' 
-- and tipocredito <>'6'
-- and codigocontable not in ('13109','13111','13112','13102','13302','13402')
-- and (CODIGOCONTABLE LIKE ('%131%') or CODIGOCONTABLE LIKE ('%132%'))
-- and replace(ultimafechacancelacioncuotacapital,'/','')<= replace(fechaliquidacion,'/','')


update jf77062.TB_DMAT04 set UltimaFechaCancelacionCuotaCapital = fechaliquidacion
where 
numerodesembolso > 0 and
(convert(decimal(18,2),replace(saldo,',','.'))+
convert(decimal(18,2),replace(MontoVencido30dias,',','.'))+
convert(decimal(18,2),replace(MontoVencido60dias,',','.'))+
convert(decimal(18,2),replace(MontoVencido90dias,',','.'))+
convert(decimal(18,2),replace(MontoVencido120dias,',','.')))< convert(decimal(18,2),replace(MontoOriginal,',','.')) 
and ModalidadHipoteca <> '2' 
and tipocredito <>'6'
and codigocontable not in ('13109','13111','13112','13102','13302','13402')
and (CODIGOCONTABLE LIKE ('%131%') or CODIGOCONTABLE LIKE ('%132%'))
and replace(ultimafechacancelacioncuotacapital,'/','')< replace(fechaliquidacion,'/','')
--------------------------------------------------------------

--Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,3),
-- y el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13106101,13106201) entonces deber�a cumplirse que el valor del campo SALDO sea mayor que 0
--revisisaldo

-- select EstadoCredito,Codigocontable,Saldo,tipodc, * from jf77062.TB_DMAT04 
-- where EstadoCredito in ('1','3')  
-- AND (CODIGOCONTABLE not LIKE ('13106201%')AND CODIGOCONTABLE not LIKE ('13106101%'))  
-- AND convert(decimal(15,2),SALDO) <= 0

/*Solucion: se present� en la transmision del mes de data feb 2016 y por orden de Julycer (FINCON)
se eliminaron esos 12 reg. primero consultar (los registros eran de sobregiros) */


---se buscaron en el insumo de dirigidas (lo que pertenecian a esa cartera)y se le coloco saldo 0.01 que era el que tenioan alli

--select SALDO,ESTADO_CREDITO ,COD_CONTABLE,* from RPT_STG_Dirigidas_HIPOTECARIO_LARGO_PLAZO where num_credito IN ('6000000175',
--'6000000426',
--'6000000046')

--update jf77062.TB_DMAT04 
--set Saldo = '0.01'
-- where NumeroCredito IN ('6000000175',
--'6000000426',
--'6000000046')
--el del corporativo se busco en corporativo no dirigido y se coloco el saldo que tenia alli
--select  * from TB_CarteraNoDirigida where Referencia  = '8171170321'

--select * from TB_DCAT04_04 where REFERNO   = '8171170321'

--update jf77062.TB_DMAT04 
--set Saldo = '97600000.00'
-- where NumeroCredito IN ('8171170321')






/**********************************************************************************************************************************/
-- SELECT 	NUMEROCREDITO, SALDO, MONTOINICIAL, MONTOORIGINAL, 
-- 	CODIGOCONTABLE,TIPODC, IdentificacionCliente,estadocredito,
-- 	sum(	convert(decimal(15,2),saldo)+ 
-- 		convert(decimal(15,2),MontoVencido30dias) +
-- 		convert(decimal(15,2),MontoVencido60dias)+
-- 		convert(decimal(15,2),MontoVencido90dias)+
-- 		convert(decimal(15,2),MontoVencido120dias))
-- FROM jf77062.TB_DMAT04
-- WHERE 	EstadoCredito IN ('1','3')
-- 	AND CODIGOCONTABLE not LIKE ('13106101%')
-- 	AND CODIGOCONTABLE not LIKE ('13106201%')
-- 	AND convert(decimal(15,2),SALDO) <= 0
-- group by NUMEROCREDITO, SALDO, MONTOINICIAL, MONTOORIGINAL,estadocredito, CODIGOCONTABLE,TIPODC, IdentificacionCliente

--Solucion dada: a estos registros que dan error se les coloco valor 2 que era el que tenian en reporte sif
--update jf77062.TB_DMAT04 set estadocredito = '2' where numerocredito in


-- select estadocredito,* from tb_dcat04_01 where acct in ('8143360310',
-- '8143180301',
-- '8143280301')


------------------------------------------------------------
--Como el valor del campo CODIGO CONTABLE empieza por algunos de los siguientes valores: 
--(133), y el valor del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse 
--que el valor del campo SITUACION DEL CREDITO sea igual a 3

--SOLUCION: SE DEBE COLOCAR SituacionCredito = 3 Y NumeroCuotasVencidas = 1

UPDATE jf77062.TB_DMAT04
SET 	SituacionCredito = '3',
	NumeroCuotasVencidas = '1'
WHERE 	CODIGOCONTABLE LIKE ('133%') 
	AND EstadoCredito = '1'
	AND SituacionCredito <> '3'--34
-----------------------------------------------------------------------------
--SE DEBE PASAR EL VALOR DE LOS RENDIMIENTOS POR COBRAR VIGENTE A VENCIDOS SIEMPRE
--QUE LA CUENTA CONTABLE COMIENCE CON 133

--******SUSTITUIR EL VALOR DE LAS CUENTAS CONTABLES EN EL QUERY **************************
--Directo
---/**********************************************************************************************************************************************************************

UPDATE jf77062.TB_DMAT04
SET 	RendimientosCobrarVencidos = CONVERT(DECIMAL(18,2),RendimientosCobrar)+
				     CONVERT(DECIMAL(18,2),RendimientosCobrarVencidos),
	RendimientosCobrar = '0.00'
WHERE CODIGOCONTABLE IN(
SELECT codigocontable
FROM jf77062.TB_DMAT04
WHERE CODIGOCONTABLE LIKE ('133%')
GROUP BY codigocontable
HAVING SUM(CONVERT(DECIMAL(18,2),RendimientosCobrar))>0)


/*
SELECT codigocontable,SUM(CONVERT(DECIMAL(18,2),RendimientosCobrar)), SUM(CONVERT(DECIMAL(18,2),RendimientosCobrarVencidos))
FROM jf77062.TB_DMAT04
WHERE CODIGOCONTABLE like ('133%')
group by codigocontable

UPDATE jf77062.TB_DMAT04
SET 	RendimientosCobrarVencidos = CONVERT(DECIMAL(18,2),RendimientosCobrar)+
					CONVERT(DECIMAL(18,2),RendimientosCobrarVencidos),
	RendimientosCobrar = '0.00'
WHERE CODIGOCONTABLE = '1330610100' 
*/
------------------------------------------------------------------------------
--El campo 'NUMERO_EXPEDIENTE_CONFORMIDAD_TURISTICA' es obligatorio, por ende no 
--puede estar vac�o Error cr�tico, proceso de validaci�n abortado 

-- select numerocredito, NumeroExpedienteConformidadTuristica,tipodc
-- from jf77062.TB_DMAT04
-- where numerocredito = '8102430301'

-- select numerocredito, NumeroExpedienteConformidadTuristica,tipodc
-- from jf77062.TB_DMAT04
-- where NumeroExpedienteConformidadTuristica = '' OR 
-- 	NumeroExpedienteConformidadTuristica IS NULL


------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es diferente de los siguientes valores: (5,8) 
--entonces deber�a cumplirse que el valor del campo FECHA ESTADO FINANCIERO sea igual a 19000101 

UPDATE jf77062.TB_DMAT04
SET FechaEstadoFinanciero = '1900/01/01'
where  	TipoCredito not in ('5','8') and 
	FechaEstadoFinanciero <> '1900/01/01'


--Como el valor del campo TIPO DE CREDITO es distinto de 6 entonces deber�a 
--cumplirse que el valor del campo FECHA EMISION SOCIOTECNICA CONFORMIDAD TURISTICA 
--sea igual a 19000101 

UPDATE jf77062.TB_DMAT04
SET FechaEmisionFactibilidadSociotecnica_ConformidadTuristica = '1900/01/01'
where  	TipoCredito <> '6' and
	FechaEmisionFactibilidadSociotecnica_ConformidadTuristica <> '1900/01/01'


--Como el valor del campo TIPO DE CREDITO es distinto de 4 entonces deber�a cumplirse que el valor 
--del campo FECHA VENCIMIENTO DEL REGISTRO MPPAT sea igual a 19000101 

UPDATE jf77062.TB_DMAT04
SET FechaVencimientoRegistro_ConstanciaMPPAT = '1900/01/01'
WHERE 	TipoCredito <> '4' AND FechaVencimientoRegistro_ConstanciaMPPAT <> '1900/01/01'


--Como el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13110,13111,13112,13310,13410,13311,13411,13312,13412,13106101,13106201,13106102,13106202,
--13206101,13206201,13206102,13206202,13306101,13306201,13306102,13306202,13406101,13406201,
--13406102,13406202) entonces deber�a cumplirse que el valor del campo MONTO ORIGINAL 
--sea mayor que 0 
---solucion: solicitar el monto original al usuario el monto original. 
--Esto puede desencadenar en el issue de la linea 680 . --tambien se igualo el montoinicial = montooriginal
--Correr el query de esa linea (SELECT!!!). Si hay registros, correr el update 
--

--EN EL REPORTE DATA DE FEBRERRO SE PRESENTO ESTE TEMA ES POR UNA MAL APERTURA DE CUENTA 
--SE DEBE ELIMINAR EL CREDITO 1046748553
--delete jf77062.TB_DMAT04 where numerocredito = '1046748553'
--Colocarle 0.0100 a monto inicial y monto original
-- SELECT numerocredito,CODIGOCONTABLE,SALDO,ESTADOCREDITO,TIPODC,MONTOINICIAL,MontoOriginal , sum(	convert(decimal(15,2),saldo)+ 
-- 		convert(decimal(15,2),MontoVencido30dias) +
-- 		convert(decimal(15,2),MontoVencido30dias)+
-- 		convert(decimal(15,2),MontoVencido90dias)+
-- 		convert(decimal(15,2),MontoVencido120dias))
-- FROM jf77062.TB_DMAT04
-- WHERE 	CODIGOCONTABLE NOT LIKE ('13110%') AND 
-- 	CODIGOCONTABLE NOT LIKE ('13111%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13112%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13310%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13410%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13311%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13411%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13312%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13412%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13106101%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13106201%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13106102%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13106202%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13206101%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13206201%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13206102%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13206202%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13306101%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13306201%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13306102%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13306202%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13406101%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13406201%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13406102%') AND
-- 	CODIGOCONTABLE NOT LIKE ('13406202%') AND
-- 	CONVERT(DECIMAL(18,2), MontoOriginal) <= 0
-- group by numerocredito,MontoOriginal,CODIGOCONTABLE,SALDO,TIPODC, SALDO, MONTOINICIAL, MONTOORIGINAL,ESTADOCREDITO



--Como el valor del campo NATURALEZA DEL CLIENTE es igual a 1 entonces deber�a 
--cumplirse que el valor del campo TIPO DE CLIENTE sea igual a uno de los siguientes 
--valores:(V,E,P,R,X) 

UPDATE jf77062.TB_DMAT04
SET NaturalezaCliente = '2'
WHERE NaturalezaCliente = '1' AND TipoCliente NOT IN ('V','E','P','R','X')

----------------------------------------------------------
--8122920307 --RIF INVALIDO
--1044014978 --IDENTIFICACION CLIENTE INVALIDO

-- UPDATE jf77062.TB_DMAT04
-- SET 	TipoCliente = 'V',
-- 	TipoClienteRIF = 'V',
-- 	IdentificacionTipoClienteRIF = '113642579'
-- WHERE NumeroCredito = '1044014978'
-----------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es distinto de 4 entonces deber�a cumplirse 
--que el valor del campo NUMERO REGISTRO MPPAT sea igual a 0

UPDATE jf77062.TB_DMAT04
SET NumeroRegistro_ConstanciaMPPAT = '0'
WHERE TipoCredito <> '4' and EstadoCredito <> '1' and NumeroRegistro_ConstanciaMPPAT <> '0'

------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 18): Como el valor del campo TIPO DE CREDITO es igual a 4,
-- y el valor del campo ESTADO DEL CREDITO es distinto de 1 entonces deber�a cumplirse 
--que el valor del campo TIPO DE REGISTRO MPPAT sea igual a VACIO 

-- select numerocredito,TipoRegistro_ConstanciaMPPAT,estadocredito,tipodc
-- from jf77062.TB_DMAT04
-- where 	(TipoCredito = '4' and
-- 	estadocredito <> '1') and
-- 	TipoRegistro_ConstanciaMPPAT <> ''

UPDATE jf77062.TB_DMAT04
SET TipoRegistro_ConstanciaMPPAT = ''
where 	(TipoCredito = '4' and
	estadocredito <> '1') and
	TipoRegistro_ConstanciaMPPAT <> ''

-----------------------------------------------------------
--RIF INVALIDO

-- UPDATE jf77062.TB_DMAT04
-- SET 	TipoCliente = 'V',
-- 	TipoClienteRIF = 'V',
-- 	NaturalezaCliente = '1'
-- WHERE numerocredito = '9014390001' 

-- UPDATE jf77062.TB_DMAT04
-- SET 	IdentificacionTipoClienteRIF = '307617470',
-- 	IdentificacionCliente = '307617470'
-- WHERE numerocredito = '8123170312'


-- UPDATE jf77062.TB_DMAT04
-- SET 	IdentificacionTipoClienteRIF = '301862244',
-- 	IdentificacionCliente = '301862244'
-- WHERE numerocredito = '8123560315'


-----------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es distinto de 4 entonces deber�a 
--cumplirse que el valor del campo TIPO DE REGISTRO MPPAT sea igual a VACIO

-- select numerocredito,TipoRegistro_ConstanciaMPPAT,tipodc
-- from jf77062.TB_DMAT04
-- where 	TipoCredito <> '4' and
-- 	TipoRegistro_ConstanciaMPPAT <> ''


UPDATE jf77062.TB_DMAT04
SET	TipoRegistro_ConstanciaMPPAT = ''
WHERE tipodc = '16'

UPDATE jf77062.TB_DMAT04
SET	TipoRegistro_ConstanciaMPPAT = ''
WHERE TipoCredito <> '4' AND
	TipoRegistro_ConstanciaMPPAT <> ''

-----------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CLIENTE es igual a uno de los siguientes valores: 
--(E,P,I), y el c�digo de la Entidad que esta realizando la transferencia es igual 
--a uno de los siguientes valores: (02911,00418,00005,00816,01212,01112,13812,01714) 
--entonces deber�a cumplirse que el valor del campo PAIS NACIONALIDAD sea diferente a 
--los siguientes valores: (0,VE) 

-- select numerocredito,PaisNacionalidad,tipodc
-- from jf77062.TB_DMAT04
-- where 	TipoCliente in ('E','P','I') and 
-- 	PaisNacionalidad = 'VE'

UPDATE jf77062.TB_DMAT04
SET PaisNacionalidad = 'XX'
where 	TipoCliente in ('E','P','I') and 
	PaisNacionalidad = 'VE'

--Como el valor del campo TIPO DE CLIENTE es igual a uno de los siguientes valores:
--(V,J,G,C) entonces deber�a cumplirse que el valor del campo 
--PAIS NACIONALIDAD sea igual a VE 
-- select numerocredito,PaisNacionalidad,tipodc
-- from jf77062.TB_DMAT04
-- where 	TipoCliente in ('J','V','G','C') and 
-- 	PaisNacionalidad <> 'VE'
	
UPDATE jf77062.TB_DMAT04
SET PaisNacionalidad = 'VE'
where 	TipoCliente in ('J','V','G','C') and 
		PaisNacionalidad <> 'VE'		
	
	
	
	
-----------------------------------------------------------------------------------
--Como el valor del campo ESTADO DEL CREDITO es diferente de los siguientes valores: 
--(2,3) , y el valor del campo TASA DE INTERES ACTUAL es igual a 0, y el valor del campo
-- TASA DE INTERES COBRADA es igual a 0 entonces deber�a cumplirse que el valor del campo 
--PERIODICIDAD DE PAGO INTERES DEL CREDITO sea igual a 0 

-- select numerocredito,PeriodicidadPagoInteresCredito,EstadoCredito,tipodc
-- from jf77062.TB_DMAT04
-- where	EstadoCredito not in ('2','3') and
-- 	convert(decimal(18,2),TasasInteresActual) = 0 and
-- 	convert(decimal(18,2),TasasInteresCobrada) = 0 and
-- 	convert(decimal(18,2),PeriodicidadPagoInteresCredito) <> 0

UPDATE jf77062.TB_DMAT04
SET 	PeriodicidadPagoInteresCredito = '0'
where	EstadoCredito not in ('2','3') and
	convert(decimal(18,2),TasasInteresActual) = 0 and
	convert(decimal(18,2),TasasInteresCobrada) = 0 and
	convert(decimal(18,2),PeriodicidadPagoInteresCredito) <> 0

-----------------------------------------------------------------------------------
--Como el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes 
--valores: (13106101,13106201,13106102,13106202,13206101,13206201,13206102,13206202,
--13306101,13306201,13306102,13306202,13406101,13406201,13406102,13406202) entonces 
--deber�a cumplirse que el valor del campo COMISIONES COBRADAS sea mayor o igual que 0

-- select numerocredito,ComisionesCobradas,tipodc
-- from jf77062.TB_DMAT04
-- where 	CodigoContable not like ('13106101%') and 
-- 	CodigoContable not like ('13106201%') and
-- 	CodigoContable not like ('13106102%') and
-- 	CodigoContable not like ('13106202%') and
-- 	CodigoContable not like ('13206101%') and
-- 	CodigoContable not like ('13206201%') and
-- 	CodigoContable not like ('13206102%') and
-- 	CodigoContable not like ('13206202%') and
-- 	CodigoContable not like ('13306101%') and
-- 	CodigoContable not like ('13306201%') and
-- 	CodigoContable not like ('13306102%') and
-- 	CodigoContable not like ('13306202%') and
-- 	CodigoContable not like ('13406101%') and
-- 	CodigoContable not like ('13406201%') and
-- 	CodigoContable not like ('13406102%') and
-- 	CodigoContable not like ('13406202%') and
-- 	convert(decimal(18,2),ComisionesCobradas) < 0

-----------------------------------------------------------------------------------
-- Como el valor del campo MODALIDAD HIPOTECARIO es igual a 2, y el valor del campo 
--ULTIMA FECHA DE CANCELACION CUOTA CAPITAL es menor o igual que la fecha final del 
--per�odo reportado entonces deber�a cumplirse que el valor del campo ULTIMA FECHA DE 
--CANCELACION CUOTA CAPITAL sea mayor o igual que el valor del campo FECHA DE LIQUIDACION 

-- select numerocredito,UltimaFechaCancelacionCuotaCapital,tipodc
-- from jf77062.TB_DMAT04
-- where 	ModalidadHipoteca = '2' and
-- 	UltimaFechaCancelacionCuotaCapital <= (select ultfecha from #fechasup) and --factaulizaru Fecha final del per�odo reportado
-- 	UltimaFechaCancelacionCuotaCapital < FechaLiquidacion

UPDATE jf77062.TB_DMAT04
SET  UltimaFechaCancelacionCuotaCapital = FechaLiquidacion
WHERE  	ModalidadHipoteca = '2' and
	UltimaFechaCancelacionCuotaCapital <= (select ultfecha from #fechasup) and --factualizaru Fecha final del per�odo reportado
	UltimaFechaCancelacionCuotaCapital < FechaLiquidacion

-----------------------------------------------------------------------------------
--Como el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13111,13112,13311,13312,13411,13412,13102,13302,13402,819) por lo menos una de las siguientes 
--afirmaciones deber�a cumplirse: 
-- - Como el valor del campo FECHA DE VENCIMIENTO ULTIMA CUOTA INTERES es mayor o igual que el 
--valor del campo FECHA DE LIQUIDACION, y el valor del campo FECHA DE VENCIMIENTO ULTIMA CUOTA 
--INTERES es menor o igual que el valor del campo FECHA DE VENCIMIENTO ACTUAL entonces deber�a 
--cumplirse que el valor del campo TASA DE INTERES ACTUAL sea mayor que 0 �el valor del campo 
--TASA DE INTERES COBRADA sea mayor que 0 
-- - Como el valor del campo TASA DE INTERES ACTUAL es igual a 0, y el valor del campo 
--TASA DE INTERES COBRADA es igual a 0 entonces deber�a cumplirse que el valor del campo 
--FECHA DE VENCIMIENTO ULTIMA CUOTA INTERES sea igual a 19000101	

-- select numerocredito,tipodc,TasasInteresActual,FechaVencimientoUltimaCuotaInteres,*
-- from jf77062.TB_DMAT04
-- where 	CodigoContable not in ('13111%','13112%','13311%','13312%','13411%','13412%',
-- 	'13102%','13302%','13402%','819%') and
-- 	convert(decimal(18,2),TasasInteresActual) = 0 and
-- 	convert(decimal(18,2),TasasInteresCobrada) = 0 and
-- 	FechaVencimientoUltimaCuotaInteres <> '1900/01/01'

UPDATE jf77062.TB_DMAT04
SET FechaVencimientoUltimaCuotaInteres = '1900/01/01'
where 	CodigoContable not in ('13111%','13112%','13311%','13312%','13411%','13412%',
	'13102%','13302%','13402%','819%') and
	convert(decimal(18,2),TasasInteresActual) = 0 and
	convert(decimal(18,2),TasasInteresCobrada) = 0 and
	FechaVencimientoUltimaCuotaInteres <> '1900/01/01'

	--Error de Fondo (Error Nro. 2): Como el valor del campo ESTADO DEL CREDITO es igual a 1, 
	--y el valor del campo el valor del campo PERIODICIDAD DE PAGO DEL CAPITAL est� contenido 
	--dentro de los valores de la funcion binaria 3071, y el valor del campo 
	--ULTIMA FECHA DE CANCELACION CUOTA INTERES es menor o igual que la fecha final del per�odo 
	--reportado entonces deber�a cumplirse que el valor del campo ULTIMA FECHA DE CANCELACION 
	--CUOTA INTERES sea mayor o igual que el valor del campo FECHA DE LIQUIDACION ��
	--(el valor del campo TASA DE INTERES ACTUAL sea mayor que 0 , y el valor del campo 
	--ULTIMA FECHA DE CANCELACION CUOTA INTERES sea mayor o igual que el valor del campo 
	--FECHA DE LIQUIDACION ) 
	
-- select PeriodicidadPagoCapital,ULTIMAFECHACANCELACIONCUOTAINTERESES,FechaLiquidacion ,
-- TasasInteresActual,ESTADOCREDITO,* from jf77062.tb_dmat04 
-- where ESTADOCREDITO = '1'
-- 		and (ULTIMAFECHACANCELACIONCUOTAINTERESES<= '2017/09/29'--FactualizarP la fecha segun el mes a setear
-- 		and ULTIMAFECHACANCELACIONCUOTAINTERESES < FechaLiquidacion
-- 		and convert(decimal(18,2),TasasInteresActual) > '0' )

UPDATE jf77062.TB_DMAT04
SET UltimaFechaCancelacionCuotaIntereses = FechaLiquidacion
where ESTADOCREDITO = '1'
		and (ULTIMAFECHACANCELACIONCUOTAINTERESES<= (select ultfecha from #fechasup) --'2019/06/30'--Actualizar la fecha segun el mes a setear
		and ULTIMAFECHACANCELACIONCUOTAINTERESES < FechaLiquidacion
		and convert(decimal(18,2),TasasInteresActual) > '0' )

--El campo 'TIPO_DE_CLIENTE_NCP' es obligatorio, por ende no puede estar vac�o Error 
--cr�tico, proceso de validaci�n abortado 
--L�nea: 626


-- select *
-- from jf77062.TB_DMAT04
-- where TipoClienteRIF is null
-- select *
-- from jf77062.TB_DMAT04
-- where TipoClienteRIF = ''

-- select FechaVencimientoOriginal, FechaLiquidacion
-- from jf77062.TB_DMAT04
-- where  (CodigoContable not like ('13302%') or
-- 	CodigoContable not like ('13103%')) and
-- 	FechaVencimientoOriginal <> '1900/01/01' and	
-- 	FechaVencimientoOriginal <= FechaLiquidacion
UPDATE jf77062.TB_DMAT04
SET  FechaVencimientoOriginal = CONVERT(VARCHAR(10),DATEADD (mm, +12, FechaLiquidacion), 111),
	FechaVencimientoActual = CONVERT(VARCHAR(10),DATEADD (mm, +12, FechaLiquidacion), 111) 
from jf77062.TB_DMAT04
where  (CodigoContable not like ('13302%') or
	CodigoContable not like ('13103%')) and
	FechaVencimientoOriginal <> '1900/01/01' and	
	FechaVencimientoOriginal <= FechaLiquidacion

	
---- PARA VERIFICAR SI ESTA EL CLIENTE FANTASMA COSIO V,SERGIO JAVIER	JF77062
-- select * from jf77062.TB_DMAT04 where numerocredito = '4487428321542000' and IdentificacionCliente = '99260007406'

-- UPDATE 	jf77062.TB_DMAT04
-- SET  	IdentificacionCliente = '26007406',
-- 		IdentificacionTipoClienteRIF = '26007406'
-- where 	numerocredito = '4487428321542000' 
-- and 	IdentificacionCliente = '99260007406'

-- select * from jf77062.TB_DMAT04 where numerocredito = '4487428321542000' 

-- PARA VERIFICAR SI EXISTEN NOMBRES DE GRUPOS ECONOMIGOS FINANCIEROS VACIOS
--Y DEN ERROR EN LA PRE VALIDACION JF77062

-- SELECT NumeroCredito,TipoCliente,IdentificacionCliente,GrupoEconomicoFinanciero 
-- FROM jf77062.TB_DMAT04 
-- WHERE (GrupoEconomicoFinanciero = '2' AND NombreGrupoEconomicoFinanciero is null) or 
-- GrupoEconomicoFinanciero = '2' AND NombreGrupoEconomicoFinanciero =''

--PARA ATAJAR ESTE ERROR DE PRE VALIDACION, EN CASO DE PRESENTARSE INVESTIGAR EL TIPODC E NOTIFICAR AL DUE�O DE LA CARTERA LAS ACCIONES A SEGUIR
--Error de Fondo (Error Nro. 5): Como el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13106101,13106201,13106102,13106202,13206101,13206201,13206102,13206202,13306101,13306201,13306102,13306202,13406101,13406201,
--13406102,13406202,13109,13309,13409) entonces deber�a cumplirse que el valor del campo FECHA DE LIQUIDACION este entre el
 --valor del campo FECHA DE APROBACION y la fecha final del per�odo reportado JF77062	
 
--  SELECT * FROM jf77062.TB_DMAT04 WHERE CodigoContable NOT IN  ('131061010','13106201','13106102','13106202','13206101','13206201',
-- '13206102','13206202','13306101','13306201','13306102','13306202','13406101','13406201','13406102','13406202','13109',
-- '13309','13409') AND  FechaLiquidacion NOT BETWEEN  FechaAprobacion and '2016/01/31' --<--<-----COLOCAR LA FECHA CIERRE DEL MES A REPORTAR

---para saber si hay registros sin identificadores de clientes 
---de haberlos buscarlos en tipo de garantia por el nombre jf77062

-- select 	Nombre_RazonSocial,identificacioncliente,tipocliente, numerocredito, TIPODC 
-- from 	jf77062.TB_DMAT04 
-- where 	identificacioncliente = '' 


-- select 	Nombre_RazonSocial,identificacioncliente,tipocliente, numerocredito 
-- from 	jf77062.TB_DMAT04NOVIEMBRETRANSMITIDO 
-- WHERE 	NUMEROCREDITO IN ()

--jf77062.TB_DMAT04ENEROTRANSMITIDO
--jf77062.TB_DMAT04FEBREROTRANSMITIDO
--jf77062.TB_DMAT04DICIEMBRETRANSMITIDO
--jf77062.TB_DMAT04NOVIEMBRETRANSMITIDO

---para saber si hay registros sin tipocliente (letra) de clientes 
-- select 	Nombre_RazonSocial,identificacioncliente,tipocliente, numerocredito 
-- from 	jf77062.TB_DMAT04 
-- where 	tipocliente =''


-- COMERCIALIZADORA ARCADIA,C.A.
-- update jf77062.TB_DMAT04 set 
-- TipoCliente='J',
-- IdentificacionCliente='311428119',
-- TipoClienteRIF='J',
-- IdentificacionTipoClienteRIF='311428119'
-- where numerocredito in ('1211441022')

-- -- SAMSUNG ELC.LATIN.SUC.VZLA.SA
-- update jf77062.TB_DMAT04 set 
-- TipoCliente='J',
-- IdentificacionCliente='306370790',
-- TipoClienteRIF='J',
-- IdentificacionTipoClienteRIF='306370790'
-- where numerocredito in ('1209521028')

-- --GRUPO TRANSBEL, C.A.
-- update jf77062.TB_DMAT04 set 
-- TipoCliente='J',
-- IdentificacionCliente='303525750',
-- TipoClienteRIF='J',
-- IdentificacionTipoClienteRIF='303525750'
-- where numerocredito in ('1208931056')

-- ---grupos economicos (nombres) jf77062
-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='TECHINT GROUP'
-- where numerocredito in ('8152190314',
-- '8152400313',
-- '8152430312',
-- '8152310302')

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='REPSOL'
-- where numerocredito ='8151111314'


-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero =' HUAWEI INVEST'
-- where numerocredito ='8160190302'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='BAKER HUGHES '
-- where numerocredito ='8160050309'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='NABORS INDUSTRIES LTD '
-- where numerocredito ='8160130307'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='MASTERCARD INC'
-- where numerocredito ='8132840317'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='3M CO'
-- where numerocredito ='8141110303'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='3M CO'
-- where numerocredito ='8140930311'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='ROCKWELL AUTOMA '
-- where numerocredito ='8141200324'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='3M CO'
-- where numerocredito ='8140970303'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='INDUSTRIA LACTE'
-- where numerocredito in ('8162520308','8162700306','8162710301')

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='ALIMENTOS PROCESADOS Y COMERCIALIZADOS, C.A'
-- where numerocredito ='8162730323'

-- update jf77062.TB_DMAT04 set NombreGrupoEconomicoFinanciero ='INVERSORA ISLAM'
-- where numerocredito ='8163050307'

-- Este cliente en caso de aparecer debe ser eliminado, ya que es un cliente es de la cartera 
--de microcreditoque ya cancelo su prestamo pero en el departamento de BI se les ha olvidado 
--eliminar. Este cliente se elimino en los reportes de marzo y abril 2014

-- select * from jf77062.TB_DMAT04 where numerocredito = '4858010000477574'
--delete from jf77062.TB_DMAT04 where nnumerocredito = '4858010000477574'

--SE EVALUA: Como el valor del campo RENDIMIENTO POR COBRAR VENCIDOS es mayor que 0 por lo menos 
--una de las siguientes afirmaciones deber�a cumplirse: 
--Como el valor del campo CODIGO CONTABLE es distinto de 1321810101 entonces deber�a cumplirse que 
--el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR sea menor que 0 
--Como el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR es menor o igual que 0 entonces deber�a 
--cumplirse que el valor del campo CODIGO CONTABLE sea igual a 1321810101 JF77062

-- SELECT 	ProvisionRendimientoCobrar, RendimientosCobrarVencidos,PocentajeProvisionEspecifica , tipodc
-- FROM 	jf77062.TB_DMAT04 
-- WHERE 	CONVERT(DECIMAL(18,2), replace(RendimientosCobrarVencidos,',','.')) > 0 AND 
--       	CODIGOCONTABLE NOT LIKE ('1321810101%') AND 
-- 	CONVERT(DECIMAL(18,2), replace(ProvisionRendimientoCobrar,',','.')) > 0 OR
-- 	CONVERT(DECIMAL(18,2), replace(ProvisionRendimientoCobrar,',','.')) >= 0 AND 
-- 	CODIGOCONTABLE LIKE ('1321810101%')
	
--El campo 'CLASIFICACION_DE_RIESGO' es obligatorio, por ende no puede estar vac�o Error 
--cr�tico, proceso de validaci�n abortado 

-- SELECT clasificacionriesgo, numerocredito FROM jf77062.TB_DMAT04 WHERE clasificacionriesgo is null	

---este cliente da error debido al apostrofe del nombre Da'Silva

-- update jf77062.TB_DMAT04 set domiciliofiscal = 'MANUEL VASCONCELOS DA SILVA' where numerocredito = '1710022301'

-- update jf77062.TB_DMAT04 set DomicilioFiscal = 'L INCONTRO' where numerocredito = '5015064406'
-- --Agagas	
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000388270',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000388270'
-- where numerocredito='1043871027' 

-- --YORK INTERNA
-- update jf77062.TB_DMAT04 set identificacioncliente ='403050252',tipocliente ='J'
-- where numerocredito ='1220271011'
-- update jf77062.TB_DMAT04 set identificaciontipoclienterif ='403050252',tipoclienterif ='J'
-- where numerocredito ='1220271011'

-- --WEG INDUSTRI
-- update jf77062.TB_DMAT04 set identificacioncliente ='308232041',tipocliente ='J'
-- where numerocredito ='1219971017'
-- update jf77062.TB_DMAT04 set identificaciontipoclienterif ='308232041',tipoclienterif ='J'
-- where numerocredito ='1219971017'

-- --PLUMROSELATI
-- update jf77062.TB_DMAT04 set identificacioncliente ='000193614',tipocliente ='J'
-- where numerocredito ='1203201013'
-- update jf77062.TB_DMAT04 set identificaciontipoclienterif ='000193614',tipoclienterif ='J'
-- where numerocredito ='1203201013'

-- --C.A.DANAVEN
-- update jf77062.TB_DMAT04 set identificacioncliente ='075051734',tipocliente ='J'
-- where numerocredito ='575381232'
-- update jf77062.TB_DMAT04 set identificaciontipoclienterif ='075051734',tipoclienterif ='J'
-- where numerocredito ='575381232'

-- --GUYCARPENTE

-- update jf77062.TB_DMAT04 set identificacioncliente ='002622555',tipocliente ='J'
-- where numerocredito ='60391037'
-- update jf77062.TB_DMAT04 set identificaciontipoclienterif ='002622555',tipoclienterif ='J'
-- where numerocredito ='60391037'

-- --UNILEVER 
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='000564868',
-- tipoclienterif='J',
-- identificaciontipoclienterif='000564868'
-- where numerocredito='289581028' 

-- --MASTERCARD -
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='302608350',
-- tipoclienterif='J',
-- identificaciontipoclienterif='302608350'
-- where numerocredito='1215321014' 

-- --IND CORPANAL
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='300706206',
-- tipoclienterif='J',
-- identificaciontipoclienterif='300706206'
-- where numerocredito='1220231016' 

-- --SUNCHEMICAL VENEZUELA,C.A.     	
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='305354227',
-- tipoclienterif='J',
-- identificaciontipoclienterif='305354227'
-- where numerocredito='1163801028' 

-- --INV ALPINA FINAN PRIM C.A         	
-- update jf77062.TB_DMAT04 set 
-- tipocliente='J',
-- identificacioncliente='007700902',
-- tipoclienterif='J',
-- identificaciontipoclienterif='007700902'
-- where numerocredito='297621011' 

-- �	Cartera 16. Sobregiros: para el campo �Porcentaje de Especifica� 
--se debe colocar 100% y aplicar este valor al monto del sobregiro. 

update jf77062.TB_DMAT04 set ProvisionEspecifica = SALDO
		where tipodc = '16'
--******************************************************************************************************************************************************************
--******************************************************************************************************************************************************************
--******************************************************************************************************************************************************************
--******************************************************************************************************************************************************************
--******************************************************************************************************************************************************************
--******************************************************************************************************************************************************************
--******************************************************************************************************************************************************************
--******************************************************************************************************************************************************************
--Ajuste en los campos nuevos de noviembre 2014 ---jf77062 *********************************************************************************************************
--para atajar errores con los formatos de las fechas (campos nuevos)


-- select FechaCambioEstatusCredito,* from jf77062.TB_DMAT04 where len(FechaCambioEstatusCredito) <> 8  
-- OR FechaCambioEstatusCredito like '%/%'

UPDATE jf77062.TB_DMAT04 SET FechaCambioEstatusCredito ='19000101' WHERE FechaCambioEstatusCredito = ''
UPDATE jf77062.TB_DMAT04 SET FechaCambioEstatusCredito ='19000101' WHERE FechaCambioEstatusCredito = '0'
UPDATE jf77062.TB_DMAT04 SET FechaCambioEstatusCredito ='19000101' WHERE FechaCambioEstatusCredito is null
UPDATE jf77062.TB_DMAT04 SET FechaCambioEstatusCredito = REPLACE(FechaCambioEstatusCredito,'/','')

-- SELECT DISTINCT(FechaCambioEstatusCredito) FROM jf77062.TB_DMAT04

-- ------------------------------------
-- select FechaRegistroVencidaLitigiooCastigada,* from jf77062.TB_DMAT04 where len(FechaRegistroVencidaLitigiooCastigada) <> 8
-- OR FechaRegistroVencidaLitigiooCastigada like '%/%'

UPDATE jf77062.TB_DMAT04 SET FechaRegistroVencidaLitigiooCastigada ='19000101' WHERE FechaRegistroVencidaLitigiooCastigada = ''
UPDATE jf77062.TB_DMAT04 SET FechaRegistroVencidaLitigiooCastigada ='19000101' WHERE FechaRegistroVencidaLitigiooCastigada = '0'
UPDATE jf77062.TB_DMAT04 SET FechaRegistroVencidaLitigiooCastigada ='19000101' WHERE FechaRegistroVencidaLitigiooCastigada is null
UPDATE jf77062.TB_DMAT04 SET FechaRegistroVencidaLitigiooCastigada = REPLACE(FechaRegistroVencidaLitigiooCastigada,'/','')

-- SELECT DISTINCT(FechaRegistroVencidaLitigiooCastigada) FROM jf77062.TB_DMAT04
--------------------------------------
-- select FechaExigibilidadPagoUltimaCuotaPagada,* from jf77062.TB_DMAT04 where len(FechaExigibilidadPagoUltimaCuotaPagada) <> 8
-- OR FechaExigibilidadPagoUltimaCuotaPagada like '%/%'

UPDATE jf77062.TB_DMAT04 SET FechaExigibilidadPagoUltimaCuotaPagada ='19000101' WHERE FechaExigibilidadPagoUltimaCuotaPagada = ''
UPDATE jf77062.TB_DMAT04 SET FechaExigibilidadPagoUltimaCuotaPagada ='19000101' WHERE FechaExigibilidadPagoUltimaCuotaPagada = '0'
UPDATE jf77062.TB_DMAT04 SET FechaExigibilidadPagoUltimaCuotaPagada ='19000101' WHERE FechaExigibilidadPagoUltimaCuotaPagada is null
UPDATE jf77062.TB_DMAT04 SET FechaExigibilidadPagoUltimaCuotaPagada = REPLACE(FechaExigibilidadPagoUltimaCuotaPagada,'/','')

-- SELECT DISTINCT(FechaExigibilidadPagoUltimaCuotaPagada) FROM jf77062.TB_DMAT04
------------------------------------------

-- select FechaEmisionCertificacionBeneficiarioEspecial,* from jf77062.TB_DMAT04 where len(FechaEmisionCertificacionBeneficiarioEspecial) <> 8
-- OR FechaEmisionCertificacionBeneficiarioEspecial like '%/%'

UPDATE jf77062.TB_DMAT04 SET FechaEmisionCertificacionBeneficiarioEspecial ='19000101' WHERE FechaEmisionCertificacionBeneficiarioEspecial = ''
UPDATE jf77062.TB_DMAT04 SET FechaEmisionCertificacionBeneficiarioEspecial ='19000101' WHERE FechaEmisionCertificacionBeneficiarioEspecial = '0'
UPDATE jf77062.TB_DMAT04 SET FechaEmisionCertificacionBeneficiarioEspecial ='19000101' WHERE FechaEmisionCertificacionBeneficiarioEspecial is null
UPDATE jf77062.TB_DMAT04 SET FechaEmisionCertificacionBeneficiarioEspecial = REPLACE(FechaEmisionCertificacionBeneficiarioEspecial,'/','')

-- SELECT DISTINCT(FechaEmisionCertificacionBeneficiarioEspecial) FROM jf77062.TB_DMAT04
-----------------------------------------
-- select FechaFinPeriodoGraciaPagoInteres,* from jf77062.TB_DMAT04 where len(FechaFinPeriodoGraciaPagoInteres) <> 8
-- OR FechaFinPeriodoGraciaPagoInteres like '%/%'

UPDATE jf77062.TB_DMAT04 SET FechaFinPeriodoGraciaPagoInteres ='19000101' WHERE FechaFinPeriodoGraciaPagoInteres = ''
UPDATE jf77062.TB_DMAT04 SET FechaFinPeriodoGraciaPagoInteres ='19000101' WHERE FechaFinPeriodoGraciaPagoInteres = '0'
UPDATE jf77062.TB_DMAT04 SET FechaFinPeriodoGraciaPagoInteres ='19000101' WHERE FechaFinPeriodoGraciaPagoInteres is null
UPDATE jf77062.TB_DMAT04 SET FechaFinPeriodoGraciaPagoInteres = REPLACE(FechaFinPeriodoGraciaPagoInteres,'/','')

-- SELECT DISTINCT(FechaFinPeriodoGraciaPagoInteres) FROM jf77062.TB_DMAT04
----------------------------------------
-- select FechaCambioEstatusCapitalTransferido,* from jf77062.TB_DMAT04 where len(FechaCambioEstatusCapitalTransferido) <> 8
-- OR FechaCambioEstatusCapitalTransferido like '%/%'

UPDATE jf77062.TB_DMAT04 SET FechaCambioEstatusCapitalTransferido ='19000101' WHERE FechaCambioEstatusCapitalTransferido = ''
UPDATE jf77062.TB_DMAT04 SET FechaCambioEstatusCapitalTransferido ='19000101' WHERE FechaCambioEstatusCapitalTransferido = '0'
UPDATE jf77062.TB_DMAT04 SET FechaCambioEstatusCapitalTransferido ='19000101' WHERE FechaCambioEstatusCapitalTransferido is null
UPDATE jf77062.TB_DMAT04 SET FechaCambioEstatusCapitalTransferido = REPLACE(FechaCambioEstatusCapitalTransferido,'/','')

-- SELECT DISTINCT(FechaCambioEstatusCapitalTransferido) FROM jf77062.TB_DMAT04

------------------------------------------------------------------------------------------------------------------------------------------------
--Error Cr�tico (Error Nro. 6): El campo 'TIPO_DE_VIVIENDA' es obligatorio, por ende no puede estar vac�o 
--Error cr�tico, proceso de validaci�n abortado 
UPDATE jf77062.TB_DMAT04 
SET  TipoVivienda = ISNULL(B.[Tipo de Vivienda],ISNULL(C.Tipo_Vivienda,'0'))
FROM jf77062.TB_DMAT04 A
LEFT JOIN tbGavetas B on A.NUMEROCREDITO = B.[N�mero de Cr�dito]
LEFT JOIN tb_dcat04_01 C on A.NUMEROCREDITO = C.Acct
WHERE tipodc in ('1','2','3','4','5','6','9','12', '14','15','8', '11', '10', '7', '13', '16')

-- select tipovivienda,* from jf77062.TB_DMAT04 where tipovivienda = '' or tipovivienda is null
-- SELECT DISTINCT(tipovivienda) FROM jf77062.TB_DMAT04

------------------------------------------------------------------------------------------------------------------------------------------------
--Error: en el campo CAPITAL_TRANSFERIDO: El valor del campo no es un n�mero real v�lido. 
--El formato correcto es: [SIGNO_NEGATIVO_OPCIONAL(-)]<DIGITO(S)><SEPARADOR_DECIMAL(,)><DIGITO(S)> 
--Solucion:
UPDATE jf77062.TB_DMAT04 SET capitaltransferido = '0,00' WHERE capitaltransferido IS NULL or capitaltransferido = ''
UPDATE jf77062.TB_DMAT04 SET capitaltransferido = replace(convert(decimal(18,2),replace(capitaltransferido,',','.')),'.',',')
UPDATE jf77062.TB_DMAT04 SET capitaltransferido  = ltrim(rtrim(capitaltransferido))


-- SELECT DISTINCT(capitaltransferido) FROM jf77062.TB_DMAT04
--------------------------------
---para verificar 
--select RendimientosCobrarAfectosReporto from jf77062.TB_DMAT04enerotransmitido
--select distinct(RendimientosCobrarAfectosReporto) from jf77062.TB_DMAT04
update jf77062.TB_DMAT04 
set RendimientosCobrarReestructurados = replace(convert(decimal(18,2),replace(RendimientosCobrarReestructurados,',','.')),'.',',')
update jf77062.TB_DMAT04 
set RendimientosCobrarReestructurados = '0,00' from jf77062.TB_DMAT04 where RendimientosCobrarReestructurados is NULL 
or RendimientosCobrarReestructurados IS NULL or capitaltransferido = ''

-- SELECT DISTINCT(RendimientosCobrarReestructurados) FROM jf77062.TB_DMAT04
----------------------------------

update jf77062.TB_DMAT04 
set RendimientosCobrarAfectosReporto = replace(convert(decimal(18,2),replace(RendimientosCobrarAfectosReporto,',','.')),'.',',')

update jf77062.TB_DMAT04 
set RendimientosCobrarAfectosReporto = '0,00' from jf77062.TB_DMAT04
where RendimientosCobrarAfectosReporto is NULL 

-- select RendimientosCobrarAfectosReporto,* from jf77062.TB_DMAT04 

-- SELECT DISTINCT(RendimientosCobrarAfectosReporto) FROM jf77062.TB_DMAT04
------------------------------------

update jf77062.TB_DMAT04 
set RendimientosCobrarLitigio = replace(convert(decimal(18,2),replace(RendimientosCobrarLitigio,',','.')),'.',',')

update jf77062.TB_DMAT04 
set RendimientosCobrarLitigio = '0,00' from jf77062.TB_DMAT04
where RendimientosCobrarLitigio is NULL 

-- SELECT DISTINCT(RendimientosCobrarLitigio) FROM jf77062.TB_DMAT04

------------------------------------------------

update jf77062.TB_DMAT04 
set InteresEfectivamenteCobrado = replace(convert(decimal(18,2),replace(InteresEfectivamenteCobrado,',','.')),'.',',')
update jf77062.TB_DMAT04 
set InteresEfectivamenteCobrado = '0,00' from jf77062.TB_DMAT04
where InteresEfectivamenteCobrado is NULL 

update jf77062.TB_DMAT04 
set InteresEfectivamenteCobrado = '0,00' from jf77062.TB_DMAT04
where InteresEfectivamenteCobrado = ''

--SELECT InteresEfectivamenteCobrado,isnumeric(InteresEfectivamenteCobrado) FROM jf77062.TB_DMAT04 order by 2 

-- SELECT DISTINCT(InteresEfectivamenteCobrado) FROM jf77062.TB_DMAT04
----------------------------------------------

update jf77062.TB_DMAT04 
set MontoComisionFlat = replace(convert(decimal(18,2),replace(MontoComisionFlat,',','.')),'.',',')
update jf77062.TB_DMAT04 
set MontoComisionFlat = '0,00' from jf77062.TB_DMAT04
where MontoComisionFlat is NULL 
-- select MontoComisionFlat,* from jf77062.TB_DMAT04 

-- SELECT DISTINCT(MontoComisionFlat) FROM jf77062.TB_DMAT04

-----------------------------------------------
update jf77062.TB_DMAT04 
set PorcentajeComisionFlat = replace(convert(decimal(18,4),replace(PorcentajeComisionFlat,',','.')),'.',',')
update jf77062.TB_DMAT04 
set PorcentajeComisionFlat = '0,0000' from jf77062.TB_DMAT04
where PorcentajeComisionFlat is NULL 

-- select DISTINCT(PorcentajeComisionFlat) from jf77062.TB_DMAT04
-----------------------------------------------
update jf77062.TB_DMAT04 
set PeriocidadPagoEspecialCapital = '0' from jf77062.TB_DMAT04
where PeriocidadPagoEspecialCapital is NULL 

-- select distinct(PeriocidadPagoEspecialCapital) from jf77062.TB_DMAT04 
-----------------------------------

update jf77062.TB_DMAT04 
set MontoInteresCuentaOrden = replace(convert(decimal(18,2),replace(MontoInteresCuentaOrden,',','.')),'.',',')

update jf77062.TB_DMAT04 
set MontoInteresCuentaOrden = '0,00' from jf77062.TB_DMAT04
where MontoInteresCuentaOrden is NULL 

-- select distinct(MontoInteresCuentaOrden) from jf77062.TB_DMAT04 

---------------------------------------
---RECORDAR CON TODAS LAS FECHAS QUE NO SE MODIFICAN EN RPT

update jf77062.TB_DMAT04 
set FechaCambioEstatusCredito = replace(FechaCambioEstatusCredito,'/','')

-- select distinct(FechaCambioEstatusCredito) from jf77062.TB_DMAT04

--YA NO SE DEBE REALIZAR ESTA VALIDACION...AHORA LA FECHA DE EXIGIBILIDAD = FECHA LIQUIDACION
--para atajatr el error : Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes 
--valores: (2,3) entonces deber�a cumplirse que el valor del campo FECHA EXIGI PAGO ULTIMA CUOTA PAGADA sea igual a 19000101
--se hizo el ajuste segun correo Wed 2/25/2015 9:38 AM de Julycer 
--select estadocredito,FechaExigibilidadPagoUltimaCuotaPagada,tipodc, * from jf77062.TB_DMAT04 where estadocredito in ('2','3') 
--and FechaExigibilidadPagoUltimaCuotaPagada <> '19000101'

--Solucion 
--update jf77062.TB_DMAT04 set FechaExigibilidadPagoUltimaCuotaPagada = '19000101'
		--where  estadocredito in ('2','3') 
--and FechaExigibilidadPagoUltimaCuotaPagada <> '19000101'
/*
Error en el campo PROVISION_DEL_RENDIMIENTO_POR_COBRAR: El valor cero (0,0) no puede ser negativo 
*/





--------------------------------------------------------------------------------------------------------------------------------------
--(Error Nro. 500): Como el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR es igual a 0 
--entonces deber�a cumplirse que el valor del campo CUENTA CONTABLE PROVISION RENDIMIENTO sea igual a 0 (Segun manual)
--para atajar el error

-- select CuentaContableProvisionRendimiento,ProvisionRendimientoCobrar,* from jf77062.TB_DMAT04 
-- where Convert(decimal(18,2),replace(ProvisionRendimientoCobrar,',','.')) = 0
-- and (CuentaContableProvisionRendimiento IS NULL OR 
-- CuentaContableProvisionRendimiento <> 0 )

--solucion (Segun manual)
update jf77062.TB_DMAT04 set CuentaContableProvisionRendimiento = '0'
where Convert(decimal(18,2),replace(ProvisionRendimientoCobrar,',','.')) = 0
and (CuentaContableProvisionRendimiento IS NULL OR 
CuentaContableProvisionRendimiento <> 0 )

---------------------------------------------------------------------------------------------------------------------------------------
--(Error Nro. 575): Error en el campo INTERES_EFECTIVAMENTE_COBRADO: El valor del campo no es un n�mero real v�lido. 
--El formato correcto es: [SIGNO_NEGATIVO_OPCIONAL(-)]<DIGITO(S)><SEPARADOR_DECIMAL(,)><DIGITO(S)> 

update jf77062.TB_DMAT04 
set InteresEfectivamenteCobrado = replace(Convert(decimal(18,2),replace(InteresEfectivamenteCobrado,',','.')),'.',',')

update jf77062.TB_DMAT04 
set InteresEfectivamenteCobrado = '0,00'
where InteresEfectivamenteCobrado is NULL 

-- select distinct(InteresEfectivamenteCobrado) from jf77062.TB_DMAT04
-----------------------------------------------------------------------------------------------------------------------------------------
--ERROR Como el valor del campo PROVISION ESPECIFICA es distinto de 0 entonces deber�a cumplirse que el valor del 
--campo CUENTA CONTABLE PROVISION ESPECIFICA empezara por algunos de los siguientes valores: (139)
--para atajar el error
-- select CuentaContableProvisionEspecifica,codigocontable, * from jf77062.TB_DMAT04
-- where convert(decimal(18,2),ProvisionEspecifica) <> 0
-- and SUBSTRING(CuentaContableProvisionEspecifica,1,3)<> '139'

-----------------------------------------------------------------------------------------------------------------------------------------
 --Error  Como el valor del campo PROVISION ESPECIFICA es igual a 0 entonces deber�a cumplirse que el valor 
 --del campo CUENTA CONTABLE PROVISION ESPECIFICA sea igual a 0 
 --para atajar el error
-- select CuentaContableProvisionEspecifica,provisionespecifica, * from jf77062.TB_DMAT04
-- where CuentaContableProvisionEspecifica <> '0' 
-- and convert(decimal(18,2),provisionespecifica) = 0
--Solucion 
-- update jf77062.TB_DMAT04 set CuentaContableProvisionEspecifica = 0  
-- where CuentaContableProvisionEspecifica <> '0' 
-- and convert(decimal(18,2),provisionespecifica) = 0

-------------------------------------------------------------------------------------------------------------------------------------------
--ERROR; Como el valor del campo CLASIFICACION DE RIESGO es igual a A entonces deber�a cumplirse que el valor 
--del campo PROVISION ESPECIFICA sea menor o igual que 0 (Era la cartera de sobregiros que estaba mal la clasificacion del riesgo, 
--tenia A por defecto)
--solucion
update jf77062.TB_DMAT04 set clasificacionriesgo = 'E' where tipodc='16' 
-------------------------------------------------------------------------------------------------------------------------------------------
--error= Como el valor del campo CLASIFICACION DE RIESGO es distinto de A entonces deber�a cumplirse que el 
--valor del campo PROVISION ESPECIFICA sea menor que 0 
--para atajar el error

-- select tipodc,clasificacionriesgo,Provisionespecifica, * from jf77062.TB_DMAT04
-- where clasificacionriesgo <> 'A' 
-- and convert(decimal(18,2),provisionespecifica)> 0
--Si es la cartera de sobregiros 16
update jf77062.TB_DMAT04 set Provisionespecifica = saldo
		where tipodc = '16'
update jf77062.TB_DMAT04 set PocentajeProvisionEspecifica = 100.0000 
		where tipodc = '16'

update jf77062.TB_DMAT04 set Provisionespecifica = convert(varchar(10),convert(decimal(18,2),Provisionespecifica)* -1)
where tipodc= 16
--sino verificar el mapeo y los insumos.
-----------------------------------------------------------------------
--DE ACUERDO A LA RECONVERSION DEL 20-08-2018 SE PROCEDE A CREAR ESTE QUERY
UPDATE JF77062.TB_DMAT04
SET Moneda = 'VES'
WHERE Moneda = 'VEB'


UPDATE JF77062.TB_DMAT04
SET ProvisionEspecifica = ROUND (ProvisionEspecifica ,2)
--LA FUNCION ES ACTUALIZAR EL TIPO DE MONEDA DE VEB POR VES, DE ACUERDO AL MANUAL DE ESPECIFICACIONES TECNICAS //EY40972

--DE ACUERDO A INSTRUCCIONES DE BIR, SE REALIZAN ESTAS ACTUALIZACIONES EN LOS CAMPOS DE PROVISIONES

UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = C.PROVISION_ESPECIFICA,
	PocentajeProvisionEspecifica  = C.PORCENTAJE_PROVISION_ESPECIFICA,
	ProvisionRendimientoCobrar  = C.PROVISION_RENDIMIENTO_X_COBRAR,
	ClasificacionRiesgo= C.CLASE_RIESGO
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  RPT_STG_Dirigidas_TURISMO C ON C.NUM_CREDITO =  DM.NUMEROCREDITO 
	AND  DM.TIPODC = ('8')
	
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = G.PROVISION_ESPECIFICA,
	PocentajeProvisionEspecifica  = G.PORCENTAJE_PROVISION_ESPECIFICA,
	ProvisionRendimientoCobrar  = G.PROVISION_RENDIMIENTO_X_COBRAR,
	ClasificacionRiesgo= G.CLASE_RIESGO
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  RPT_STG_Dirigidas_AGRICOLA_CONSUMER G ON G.NUM_CREDITO =  DM.NUMEROCREDITO 
	AND  DM.TIPODC = ('12')
	
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = F.PROVISION_ESPECIFICA,
	PocentajeProvisionEspecifica  = F.PORCENTAJE_PROVISION_ESPECIFICA,
	ProvisionRendimientoCobrar  = F.PROVISION_RENDIMIENTO_X_COBRAR,
	ClasificacionRiesgo= F.CLASE_RIESGO
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  RPT_STG_Dirigidas_AGRICOLA_CORPORATE F ON F.NUM_CREDITO =  DM.NUMEROCREDITO 
	AND  DM.TIPODC = ('11')
	
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = E.PROVISION_ESPECIFICA,
	PocentajeProvisionEspecifica  = E.PORCENTAJE_PROVISION_ESPECIFICA,
	ProvisionRendimientoCobrar  = E.PROVISION_RENDIMIENTO_X_COBRAR,
	ClasificacionRiesgo= E.CLASE_RIESGO
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  RPT_STG_Dirigidas_MANUFACTURA E ON E.NUM_CREDITO =  DM.NUMEROCREDITO 
	AND  DM.TIPODC = ('10')
	
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = B.PROVISION_ESPECIFICA,
	PocentajeProvisionEspecifica  = B.PORCENTAJE_PROVISION_ESPECIFICA,
	ProvisionRendimientoCobrar  = B.PROVISION_RENDIMIENTO_X_COBRAR,
	ClasificacionRiesgo= B.CLASE_RIESGO
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  RPT_STG_Dirigidas_HIPOTECARIO_CORTO_PLAZO B ON B.NUM_CREDITO =  DM.NUMEROCREDITO 
	AND  DM.TIPODC = ('7')
	
	
		
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = A.PROVISION_ESPECIFICA,
	PocentajeProvisionEspecifica  = A.PORCENTAJE_PROVISION_ESPECIFICA,
	ProvisionRendimientoCobrar  = A.PROVISION_RENDIMIENTO_X_COBRAR,
	ClasificacionRiesgo= A.CLASE_RIESGO
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  RPT_STG_Dirigidas_HIPOTECARIO_LARGO_PLAZO A ON A.NUM_CREDITO =  DM.NUMEROCREDITO 
	AND  DM.TIPODC = ('6')
	
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = D.PROVISION_ESPECIFICA,
	PocentajeProvisionEspecifica  = D.PORCENTAJE_PROVISION_ESPECIFICA,
	ProvisionRendimientoCobrar  = D.PROVISION_RENDIMIENTO_X_COBRAR,
	ClasificacionRiesgo= D.CLASE_RIESGO
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  RPT_STG_Dirigidas_MICROFINANCIERO D ON D.NUM_CREDITO =  DM.NUMEROCREDITO 
	AND  DM.TIPODC = ('9')
	
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = SOBC.SaldoProvision ,
	PocentajeProvisionEspecifica  = SOBC.Provision ,
	ClasificacionRiesgo= SOBC.Riesgo
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  TMP_SobregirosConsumer SOBC ON SOBC.Acct  =  DM.NUMEROCREDITO 
	AND  DM.TIPODC = ('16')
	
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = DC01.SaldoProvision,
	PocentajeProvisionEspecifica  = DC01.Provision 
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  TB_DCAT04_01 DC01 ON DC01.Acct =  DM.NUMEROCREDITO
	AND  DM.TIPODC = ('1')
	
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionRendimientoCobrar  = TMPR.Saldo_Provision_REND,
	PocentajeProvisionEspecifica  = TMPR.ProvisionREND  
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  TMP_Rendimiento TMPR ON TMPR.Acct =  DM.NUMEROCREDITO
	AND  DM.TIPODC = ('1')
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = REM.Saldo_Provision_REND ,
	PocentajeProvisionEspecifica  = REM.ProvisionREND
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  TMP_Rendimiento REM ON REM.Acct =  DM.NUMEROCREDITO 
	AND  DM.TIPODC = ('5')
	
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = REM.Saldo_Provision_REND ,
	PocentajeProvisionEspecifica  = REM.ProvisionREND
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  TMP_Rendimiento REM ON REM.Acct =  DM.NUMEROCREDITO 
	
	

	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = REM.Saldo_Provision_REND ,
	PocentajeProvisionEspecifica  = REM.ProvisionREND
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  TMP_Rendimiento REM ON REM.Acct =  DM.NUMEROCREDITO 
	AND  DM.TIPODC = ('5')
--ESTAS PROVISIONES SE TOMAN DIRECTAMENTE DE LOS INSUMOS DE LAS CARTERAS DE DIRIGIDAS, SOBREGIROS CONSUMER, SIF Y BALBYACCOUNT TRANSFORMADA.
---------------------------------------------------------------------------------------------------------------------------------------------
--Para atajar este error
--ERROR: Como el valor del campo SITUACION DEL CREDITO es igual a uno de los siguientes valores: 
--(3,4), y el valor del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que el valor del 
--campo FECHA DE REGISTRO EN VENCIDA LITIGIO O CASTIGADA este entre el valor del campo FECHA DE LIQUIDACION 
--y la fecha final del per�odo reportado
--Solucion: se debe buscar de que cartera son y verificar que la infromacion no este en el insumo y
--de no estarlo se le debe pedir al due�o . esta vez se le pidio a Luis mendoza de BI 
--y las otra a Eliana Fernandez para que se las solicitara al usuario correspondiente
-- select FechaRegistroVencidaLitigiooCastigada,*from jf77062.TB_DMAT04 where SituacionCredito in ('3','4') and
-- EstadoCredito = '1' and 
-- ((convert(varchar(10),FechaRegistroVencidaLitigiooCastigada) not between convert(varchar(10),REPLACE(FECHaLIQUIDACION,'/','')) and '20160430') --Aqu� se coloca la fecha del mes a reportar
-- or  convert(varchar(10),FechaRegistroVencidaLitigiooCastigada)= '19000101')

/*JG: La fecha de registro en vencida no puede ser la misma fecha de liquidaci�n del cr�dito, en el campo 
�FechaRegistroVencidaLitigiooCastigada� debe reportarse la fecha en que el cr�dito cambia de vigente a vencido.
 Cuando se presente este error durante las prevalidaciones debemos revisar la fecha de liquidaci�n y de registro 
 en vencida que se est� reportando y validar si es correcta. .*/


-------------------------------------------------------------------------------------------------------------------------------------------------
--ACTUALIZACION DE LA MODALIDAD HIPOTECARIA SEGUN MANUAL
--NOVIEMBRE 2014 (CAMPOS NUEVOS)
--ERROR: El valor "1" no se encuentra entre los valores de referencia de la lista de valores 'MODALIDAD_HIPOTECARIA' 
--Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo

UPDATE jf77062.TB_DMAT04 
SET ModalidadHipoteca = '5'
WHERE  ModalidadHipoteca = '1' AND TIPODC = '6'

UPDATE jf77062.TB_DMAT04 
SET ModalidadHipoteca = '6'
WHERE  ModalidadHipoteca = '2'AND TIPODC = '6'

UPDATE jf77062.TB_DMAT04 
SET ModalidadHipoteca = '4'
WHERE  ModalidadHipoteca = '9'AND TIPODC = '6'
------------------------------------------------------------------------------------------------------------------------------------------------------
--para atajar el error: Como el valor del campo RENDIMIENTO POR COBRAR VENCIDOS es igual a 0 entonces deber�a cumplirse que 
--el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR sea menor o igual que 0 
---no debe dar resultado, en caso de dar verificar el insumo

-- select RendimientosCobrarVencidos,ProvisionRendimientoCobrar,* from jf77062.TB_DMAT04 where 
-- convert(numeric,replace(RendimientosCobrarVencidos,',','.')) = 0 and 
-- convert(numeric,replace(ProvisionRendimientoCobrar,',','.')) > 0 order by numerocredito

---Error:Como el valor del campo SITUACION DEL CREDITO es igual a uno de los siguientes valores: (3,4), 
--y el valor del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que el valor del campo 
--FECHA DE REGISTRO EN VENCIDA LITIGIO O CASTIGADA este entre el valor del campo FECHA DE LIQUIDACION y la fecha final del per�odo reportado
--Solucion: este error se debe a error en la data de TDC. Se debe solicitar al equipo de BI que indique los clientes a eliminar y dejar el
--saldo original del cliente  a los que se les va a actualizar la informacion
--y el valor del campo monto vencido a 30 o 60 dias que reporten a la cuenta 1310610100 se le debe sumar al monto vencido a 30 o 60 dias del credito a actualizar
--ejemplo: 

--update jf77062.TB_DMAT04 set saldo (cliente nuevo) = '',
--montovencido30dias = '' (monto cliente nuevo + monto cliente a eliminar)
--where numerocredito = '' 

--NO CORRER A MENOS QUE SEA NECESARIO
update jf77062.TB_DMAT04 set saldo = '',
		montovencido30dias = ''
		where numerocredito = ''

-- SELECT * FROM jf77062.TB_DMAT04

---Error de Fondo (Error Nro. 8): Como el valor del campo CODIGO CONTABLE empieza por algunos de los siguientes valores: 
--(13106101,13106201), y el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,3) entonces 
--deber�a cumplirse que el valor del campo SALDO sea mayor o igual que 0 
--SE CONSULTO CON LUIS MENDOZA (BI) E INDICO QUE LOS REGISTROS DEBEN ELIMINARSE Y AJUSTARSE A OTROS CLIENTES
--PARA ATAJAR EL ERROR (SI ESTE SELECT DA REGISTROS, VERIFICAR EL SALDO EN REPORTE SIF Y SI AUN ALLI ESTAN 
--NEGTIVOS SE DEBE APLICAR LA SOLUCION ANTES INDICADA)

-- select numerocredito,saldo,codigocontable,estadocredito,situacioncredito,* from jf77062.TB_DMAT04 
-- where	(codigocontable like ('%13106101%')and
-- 	codigocontable like ('%13106101%') and
-- 	estadocredito in ('1','3'))and 
-- 	convert(decimal(18,2),saldo) < 0 order by numerocredito
	
--se recomienda hacer antes un select de los registros que se van a eliminar y guardarlos
-- select * FROM jf77062.TB_DMAT04 where numerocredito = ''
-- --- Y se deben eliminar (estos clientes los debe indicar BI)
-- delete jf77062.TB_DMAT04 where numerocredito = ''


 
--//////////// 
 
 
 --atajar error Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (3,2)
 --entonces deber�a cumplirse que el valor del campo SITUACION DEL CREDITO sea igual a 0 

-- select estadocredito,situacioncredito,* from jf77062.TB_DMAT04 where estadocredito in ('2','3') and situacioncredito <>0
--investigar los estados del credito

---atajar:  Como el valor del campo ESTADO DEL CREDITO es distinto de 2 entonces deber�a cumplirse que el valor 
--del campo FECHA DE CANCELACION TOTAL sea igual a 19000101 
-- select tipodc,estadocredito,fechacancelaciontotal,* from jf77062.TB_DMAT04 where estadocredito <> 2 
-- and fechacancelaciontotal <> '1900/01/01'

update jf77062.TB_DMAT04 set fechacancelaciontotal = '1900/01/01'  where estadocredito <> 2 
and fechacancelaciontotal <> '1900/01/01'

--Como el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13106101,13106201,13106102,13106202,13206101,13206201,13206102,13206202,13306101,13306201,
--13306102,13306202,13406101,13406201,13406102,13406202) entonces deber�a cumplirse que el valor 
--del campo MONTO INICIAL AT04 sea mayor que 0 

-- select tipodc,codigocontable,montoinicial,* from jf77062.TB_DMAT04 where (codigocontable not like ('%13106101%')
-- and codigocontable not like ('%13106201%')
-- and codigocontable not like ('%13106102%')
-- and codigocontable not like ('%13206101%')
-- and codigocontable not like ('%13206201%')
-- and codigocontable not like ('%13206102%')
-- and codigocontable not like ('%13206202%')
-- and codigocontable not like ('%13306101%')
-- and codigocontable not like ('%13306201%')
-- and codigocontable not like ('%13306102%')
-- and codigocontable not like ('%13306202%')
-- and codigocontable not like ('%13406101%')
-- and codigocontable not like ('%13406201%')
-- and codigocontable not like ('%13406102%')
-- and codigocontable not like ('%13406202%'))
-- and convert(decimal,replace(montoinicial,',','.')) < 0


--Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (2,3)
--entonces deber�a cumplirse que el valor del campo PLAZO DEL CREDITO sea igual a 0 (debe dar 0 registros sino verificar.)
-- select estadocredito,plazocredito,* from jf77062.TB_DMAT04 where plazocredito = '0' and estadocredito not in ('2','3')

--Como el valor del campo ESTADO DEL CREDITO es diferente de los siguientes valores: (2,3) ,
-- y el c�digo de la Entidad que esta realizando la transferencia es diferente de los siguientes valores: (00418,00005)
-- entonces deber�a cumplirse que el valor del campo PLAZO DEL CREDITO sea distinto de 0 
--en caso de dar verificar el insumof
-- select tipodc,codigocontable,estadocredito,situacioncredito,numerocredito,plazocredito,* 
-- from jf77062.TB_DMAT04 where estadocredito not in ('2','3') and plazocredito = '0'


--Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,3),
-- y el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: 
--(13106101,13106201) entonces deber�a cumplirse que el valor del campo SALDO sea mayor que 0 
-- select saldo,codigocontable,estadocredito,* from jf77062.TB_DMAT04 where codigocontable not like ('%13106101%')
-- and codigocontable not like ('%13106201%') and estadocredito in ('1','3')and convert(decimal,replace(saldo,',','.')) < 0

--Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (2,3) entonces deber�a 
--cumplirse que el valor del campo PERIODICIDAD DE PAGO DEL CAPITAL sea igual a 0  No deberia haber
--verificar os estados de credito en el insumo
--en caso de una reclasificacion comparar con reg similares
-- select estadocredito,* from jf77062.TB_DMAT04 where estadocredito in ('2','3')and 
-- PeriodicidadPagoCapital <> 0

/*
update jf77062.TB_DMAT04 set PeriodicidadPagoCapital = 0
where estadocredito in ('2','3')and 
PeriodicidadPagoCapital <> 0*/

--Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (2,3) 
--entonces deber�a cumplirse que el valor del campo PROVISION ESPECIFICA sea igual a 0 
-- select numerocredito,tipodc,estadocredito,provisionespecifica from jf77062.TB_DMAT04 where estadocredito in ('2','3') and
-- convert(numeric,provisionespecifica) < 0

-- update jf77062.TB_DMAT04 set provisionespecifica = 0  where estadocredito in ('2','3') and
-- convert(decimal(18,2),replace(provisionespecifica,',','.')) < 0

-- SELECT provisionespecifica, * FROM jf77062.TB_DMAT04 WHERE provisionespecifica = '-3e+006'

--Como el valor del campo CODIGO CONTABLE empieza por algunos de los siguientes valores: (132), 
--y el valor del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que el valor 
--del campo SITUACION DEL CREDITO sea igual a 2 
-- select tipodc,codigocontable,estadocredito,situacioncredito,numerocredito  from jf77062.TB_DMAT04 
-- where (estadocredito = 1 and codigocontable like ('%132%')) and situacioncredito <> 2

--update jf77062.TB_DMAT04 set situacioncredito = '2' where numerocredito in 


--Como el valor del campo CODIGO CONTABLE empieza por algunos 
--de los siguientes valores: (131), y el valor del campo ESTADO DEL CREDITO 
--es igual a 1 entonces deber�a cumplirse que el valor del campo SITUACION DEL CREDITO sea igual a 1 

-- select tipodc,codigocontable,estadocredito,situacioncredito,* from jf77062.TB_DMAT04 
-- where (codigocontable like '%131%' and estadocredito = 1) and situacioncredito <> 1

--Como el valor del campo PROVISION ESPECIFICA es distinto de 0 entonces deber�a cumplirse que
-- el valor del campo CUENTA CONTABLE PROVISION ESPECIFICA empezara por algunos de los siguientes valores: (139)

-- select TIPODC,numerocredito,CodigoContable,CUENTACONTABLEPROVISIONESPECIFICA,estadocredito,provisionespecifica 
-- from jf77062.TB_DMAT04
-- where
-- convert(DECIMAL(18,2),provisionespecifica) <> 0 AND 
-- CUENTACONTABLEPROVISIONESPECIFICA  = 0 AND 
-- estadocredito NOT in ('2','3') 

--Como el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR es distinto de 0 entonces deber�a cumplirse 
--que el valor del campo CUENTA CONTABLE PROVISION RENDIMIENTO empezara por algunos de los siguientes valores: (149) 

-- SELECT PROVISIONRENDIMIENTOCOBRAR,CUENTACONTABLEPROVISIONRENDIMIENTO,* FROM jf77062.TB_DMAT04
-- WHERE  CONVERT(DECIMAL(18,2),REPLACE(PROVISIONRENDIMIENTOCOBRAR,',','.')) <>0 AND 
-- CUENTACONTABLEPROVISIONRENDIMIENTO = 0
	
update jf77062.TB_DMAT04 set CuentaContableProvisionRendimiento = '1490310000'
where CONVERT(DECIMAL(18,2),REPLACE(PROVISIONRENDIMIENTOCOBRAR,',','.')) <>0 AND 
CUENTACONTABLEPROVISIONRENDIMIENTO = 0

-- Como el valor del campo TIPO DE CREDITO es distinto de 5 entonces deber�a cumplirse que el 
--valor del campo MODALIDAD DEL MICROCREDITO sea igual a 0 

-- SELECT TIPOCREDITO,
-- ModalidadMicrocredito,TIPODC,* FROM jf77062.TB_DMAT04 WHERE TIPOCREDITO <> 5 AND ModalidadMicrocredito <> 0 

--Como el valor del campo ESTADO DEL CREDITO es diferente de los siguientes valores: (2,3) , 
--y el valor del campo FECHA EXIGI PAGO ULTIMA CUOTA PAGADA es menor o igual que el valor del 
--campo FECHA DE VENCIMIENTO ACTUAL entonces deber�a cumplirse que el valor del campo
--FECHA EXIGI PAGO ULTIMA CUOTA PAGADA sea mayor o igual que el valor del campo FECHA DE LIQUIDACION 
--para atajarlo

--NO APLICA POR AHORA 
/*SELECT TIPODC,ESTADOCREDITO,FechaExigibilidadPagoUltimaCuotaPagada,FechaVencimientoActual,
FECHALIQUIDACION,NumeroCuotasVencidas,* FROM jf77062.TB_DMAT04
WHERE 
ESTADOCREDITO NOT IN ('2','3') AND 
FechaExigibilidadPagoUltimaCuotaPagada <= FechaVencimientoActual AND
FechaExigibilidadPagoUltimaCuotaPagada <= REPLACE(FECHALIQUIDACION, '/','')*/

--verificar si estos creditos aparecen es porque fueron migrados 
--por alguna razon no aparecen en el migrated
-- se deben buscar en el reporte sif con el numero que esta al lado 
--son de la cartera 6. 
--esto se hablo con BI Luis Mendoza

-- select Fecha_Exigibilidad_pago_ult_cuota,* from tb_dcat04_01 where acct in
-- ('6000000259', --6900000259
-- '6000000371', --6900000371
-- '6000000256', --6910000256
-- '6000000103', --6900000103
-- '6000000473') --6900000473
---------------------------------------------------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es igual a 3, y el valor del campo 
--ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que el valor del campo TIPO DE VIVIENDA sea distinto de 0 
-- select estadocredito,tipocredito,tipovivienda,tipodc,*  from jf77062.TB_DMAT04 where tipocredito = 3 and
-- estadocredito = 1 and tipovivienda = 0

update jf77062.TB_DMAT04 set tipovivienda = tipo_vivienda
from jf77062.TB_DMAT04 DM
inner join TMP_Migrados M on M.oldacct = DM.numerocredito
inner join tb_dcat04_01 LDWH on LDWH.acct  = M.newacct 
Where tipodc in ('6')

update jf77062.TB_DMAT04 
set TipoVivienda = '1'
 where tipocredito = 3 and
estadocredito = 1 and tipovivienda = 0

--PARA LOS CASOS DE REMODELACION QUE SON LOS NUMEROS DE CREDITO QUE COMIENZAN EN 67
--SE DEBE COLOCAR TIPO VIVIENDA 2
update jf77062.TB_DMAT04 set tipovivienda = '2'
from jf77062.TB_DMAT04 
Where tipocredito = 3 AND
estadocredito = 1 AND 
tipovivienda = 0 AND
tipodc in ('6') and SUBSTRING(numerocredito,1,2)='67'

---------------------------------------------------------------------------------------------------------------------------------
-- se deben buscar en el reporte sif con el numero que esta al lado 
--son de la cartera 6. 
--esto se hablo con BI Luis Mendoza
-- select tipo_vivienda,* from tb_dcat04_01 where acct in
-- ('6000000259', --6900000259
-- '6000000371', --6900000371
-- '6000000256', --6910000256
-- '6000000103', --6900000103
-- '6000000473') --6900000473
---------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 20): Como el valor del campo ESTADO DEL CREDITO es diferente de los siguientes valores: (2,3)
--entonces deber�a cumplirse que el valor del campo el valor del campo PERIODICIDAD DE PAGO DEL CAPITAL deber�a estar
-- contenido dentro de los valores de la funcion binaria 4095 
--para atajat

-- select estadocredito,periodicidadpagocapital,tipodc, * from jf77062.TB_DMAT04 where periodicidadpagocapital = 0  and 
-- estadocredito not in ('2','3')
--solucion: se verificaron los insumos (turismo se arreglo) y se le solicito la informacion al due�o de la cartera en este caso Julycer (para PIL RRHH)
--se le coloco 8 que significa mensual
-- update jf77062.TB_DMAT04 set periodicidadpagocapital = '8' where numerocredito in ('1010042156','943148')and tipodc = '3'
-------------------------------------------------------------------------------------------------------------------
--Como el valor del campo SITUACION DEL CREDITO es igual a 0, y el valor del campo ESTADO DEL CREDITO es igual a 3 
--entonces deber�a cumplirse que el valor del campo FECHA DE REGISTRO EN VENCIDA LITIGIO O CASTIGADA este entre el 
--valor del campo FECHA DE LIQUIDACION y la fecha final del per�odo reportado 
--fueron los dos clientes que siempre se incluyen en el reporte para cuadrar el summary de saldos
--se le consulto a BI
--indicaron que los registros estaban en el insumo de reporte sif ...hay que buscarlo ya que no cruza porque no tienen 
--tipodc, el cual es 7
-- select tipodc,estadocredito,situacioncredito,FechaRegistroVencidaLitigiooCastigada,tipodc, * from jf77062.TB_DMAT04 
-- 	where (estadocredito = 3
-- 	and situacioncredito = 0)
-- 	and (FechaRegistroVencidaLitigiooCastigada = '19000101')
	
UPDATE  JF77062.TB_DMAT04 SET FechaRegistroVencidaLitigiooCastigada = (select ultfecha from #fechasup)--'20190531' ----CAMBIAR FECHA DE CIERRE
 WHERE (estadocredito = 3
	and situacioncredito = 0)
	and (FechaRegistroVencidaLitigiooCastigada = '19000101')
	
/*JG: En estos casos se debe reportar la fecha en que el cr�dito fue registrado como castigado. */


/*Como el valor del campo SITUACION DEL CREDITO es igual a 0, y el valor del campo ESTADO DEL CREDITO es igual a 3 
por lo menos una de las siguientes afirmaciones debería cumplirse: 
Si el valor del campo FECHA DE REGISTRO EN VENCIDA LITIGIO O CASTIGADA es igual a el valor del campo 
FECHA DE LIQUIDACION entonces el código de la Entidad que esta realizando la transferencia 
debe ser uno de los siguientes valores:
(01212,13812,04217) 
El valor del campo FECHA DE REGISTRO EN VENCIDA LITIGIO O CASTIGADA debe estar entre el valor del campo FECHA DE LIQUIDACION y la fecha final del período reportado*/

-- select tipodc,situacioncredito,estadocredito,FechaRegistroVencidaLitigiooCastigada,CodigoContable, * from jf77062.TB_DMAT04 
-- 	where (estadocredito = 3
-- 	and situacioncredito = 0)
-- 	and (FechaRegistroVencidaLitigiooCastigada =  FechaLiquidacion)

----------------------------------------------------------------------------------------------------------------------	
--Como el valor del campo SITUACION DEL CREDITO es igual a 0, y el valor del campo ESTADO DEL CREDITO es igual a 2
--entonces deber�a cumplirse que el valor del campo FECHA DE REGISTRO EN VENCIDA LITIGIO O CASTIGADA sea igual a 19000101 

-- select situacioncredito,estadocredito,FechaRegistroVencidaLitigiooCastigada,* from jf77062.TB_DMAT04 where 
-- situacioncredito in ('0') and estadocredito = '2' and 
-- FechaRegistroVencidaLitigiooCastigada <> '19000101'

--solucion: verificar la situcion del credito en el insumo, suele cambiarse

----------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 381): Como el valor del campo TIPO DE CREDITO es igual a 4, y el valor del campo 
--ESTADO DEL CREDITO es igual a 1, y el valor del campo SECTOR DE PRODUCCION es igual a 4 por lo menos una de 
--las siguientes afirmaciones deber�a cumplirse: 
--  El valor del campo RUBRO debe ser uno de los siguientes valores:
--(2050200,2050201,2050202,2050203,2050204,2050205,2050206,2050207,2050208,2050209,2060100,2060101,2060102,2060103,2060104,2060105,2060106,2060107,2060108,2060200,2060201,2060202,2060203) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(2080104,2080105,2080106,2080200,2080201,2080202,2080203,2080204,2080205,2080206,2120100,3010100,3010101,3010200,3010201,3010300,3010301,3010400,3010401,3010500,3010501,3010600,3010601) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(2060204,2060205,2060206,2060207,2060208,2070100,2070101,2070102,2070103,2070104,2070105,2070106,2070200,2070201,2070202,2070203,2070204,2070205,2070206,2080100,2080101,2080102,2080103) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(3010700,3010701,3010800,3010801,3010900,3010901,3011000,3011001,3011100,3011101,4010300,4010400,4010500,4010700,4010800,4011000,4020100,4030300,4030500,4030800,4031000,4031400,4031500) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(4032300,4032800,4033500,4040500,4040600,4041100,4041600,4041800,4042200,4042900,4043300,4043400,4043500,4044300,4044800,4045700,4045900,4046200,4046400,4047800,4050700,4050800,4051200) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(1090501,1090502,1090503,1090600,1090601,1090602,1090701,1090702,1090703,1110101,1110102,1110200,1110201,1110300,1110301,1110400,1110401,1110500,1110501,1110600,1110601,1110700,1110701) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(2010101,2010200,2010201,2010401,2010500,2010501,2020100,2020101,2020102,2020103,2030101,2040100,2040101,2050100,2050101,2050102,2050103,2050104,2050105,2050106,2050107,2050108,2050109) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(4051400,4051500,4054800,4056500,4061700,4066200) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(1041700,1041701,1042500,1042501,1050100,1050101,1050700,1050701,1050800,1050801,1051000,1051001,1051100,1051101,1051400,1051401,1051402,1051500,1051501,1051502,1051700,1051701,1051702) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(1030100,1030101,1030200,1030201,1030202,1030300,1030301,1030400,1030401,1040100,1040101,1040200,1040201,1040300,1040301,1040500,1040501,1040700,1040701,1040800,1040801,1040900,1040901) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(1010101,1010102,1010500,1010501,1010502,1010600,1010601,1010602,1010700,1010701,1020100,1020101,1020300,1020301,1020900,1020901,1020902,1021000,1021001,1021100,1021101,1021200,1021201) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(1073902,1073903,1073904,1074100,1074101,1074102,1074200,1074300,1074301,1080200,1080201,1080202,1080400,1080401,1080800,1080801,1090100,1090101,1090200,1090201,1090400,1090401,1090500) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(1071601,1071800,1071801,1072100,1072101,1072500,1072501,1072600,1072601,1073000,1073001,1073200,1073201,1073300,1073301,1073302,1073400,1073401,1073600,1073601,1073700,1073701,1073901) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(1070101,1070300,1070301,1070302,1070500,1070501,1070502,1070600,1070601,1070700,1070701,1070900,1070901,1071100,1071101,1071200,1071201,1071300,1071301,1071302,1071400,1071401,1071600) 
--El valor del campo RUBRO debe ser uno de los siguientes valores:
--(1051800,1051801,1052200,1052201,1052300,1052301,1052700,1052701,1052800,1052801,1053100,1053101,1053300,1053301,1053500,1053501,1053800,1053801,1054200,1054201,1054300,1054301,1070100) 
--para atajar el error
-- select rubro,sectorproduccion,* from jf77062.TB_DMAT04 where sectorproduccion <> '2' and rubro = '1150200'
--se cambio para el numero de credito 8141980305 el sector produccion = 2 que estaba en 1 (Tarcisio Hernandez)
--sOLUCION: SE LE SOLICITO AL DUE�O DE LA INFORMACION el cual indico que lo que estaba erroneo era el SectorProduccion
--para este credito 8141980305 se cambio a sector produccion 2 (tenia sector 4)
--update jf77062.TB_DMAT04 set SectorProduccion = '2' where numerocredito = '8141980305'
--otros ajustes
-- update jf77062.TB_DMAT04
-- set 	
-- TipoSubsector = '2',
-- rubro = '2050200',
-- CodIGOUso = '2',
-- CodIGOUnidadMedida = '3',
-- sectorproduccion = '4'
-- where numerocredito = '9018544101'


-- update jf77062.TB_DMAT04
-- set 	
-- TipoSubsector = '1',
-- rubro = '1010102',
-- CodIGOUso = '8',
-- CodIGOUnidadMedida = '3',
-- sectorproduccion = '4'
-- where numerocredito = '9018580701'


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Valor de Referencia no Encontrado (Error Nro. 648): El valor "60901" no se encuentra entre los valores de referencia de la lista de valores 
--'PARROQUIA' Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo 
--para atajar este error
-- select codigocontable,numerocredito,codigoparroquia,tipodc,* from jf77062.TB_DMAT04 where codigoparroquia like ('60901%') or 
-- 				codigoparroquia like ('32001%')or 
-- 				codigoparroquia like ('90601%')or 
-- 				codigoparroquia like ('40601%')or 
-- 				codigoparroquia like ('90201%')or 
-- 			codigoparroquia like ('40401%')
				
--solucion; se le solicito la informacion al due�o de la cartera (en este caso cartera 12)
--para el mes de dic lo cruce con el mes de noviembre
-- UPDATE jf77062.TB_DMAT04 
-- SET codigoparroquia = B.codigoparroquia
-- FROM jf77062.TB_DMAT04 A
-- LEFT JOIN jf77062.TB_DMAT04TransmitidoAbril2016 B on A.NUMEROCREDITO = B.numerocredito
-- WHERE  A.numerocredito in ('9016183901',
-- '9018561401',
-- '9017067801',
-- '9018590201',
-- '9014553301',
-- '9014553401',
-- '9014371001',
-- '9014419201',
-- '9018590301',
-- '9018614901',
-- '9019124901',
-- '9018544201')
-----------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 1): Como el valor del campo ESTADO DEL CREDITO es diferente de los siguientes valores: (2,3) por lo menos una de las siguientes afirmaciones deber�a cumplirse: 
--Como el valor del campo TASA DE INTERES ACTUAL es mayor que 0 entonces deber�a cumplirse que 
--el valor del campo el valor del campo PERIODICIDAD DE PAGO INTERES DEL CREDITO deber�a estar contenido dentro de los valores de la funcion binaria 4095
--Como el valor del campo TASA DE INTERES COBRADA es mayor que 0 entonces deber�a cumplirse que 
--el valor del campo el valor del campo PERIODICIDAD DE PAGO INTERES DEL CREDITO deber�a estar contenido dentro de los valores de la funcion binaria 4095
--Como el valor del campo PERIODICIDAD DE PAGO INTERES DEL CREDITO es igual a 0 entonces deber�a cumplirse que 
--el valor del campo TASA DE INTERES ACTUAL sea igual a 0 , y el valor del campo TASA DE INTERES COBRADA sea igual a 0
--no debe de venir ninguno, en caso de haber verificar los insumos y en caso de estar mal en los insumos consultar con el usuario correspondiente
-- select tipodc,estadocredito,PeriodicidadPagoInteresCredito,PeriodicidadPagocapital,
-- TasasInteresCobrada,TasasInteresActual,* from jf77062.TB_DMAT04 
-- where 
-- estadocredito not in ('2','3') and
-- (convert(decimal(18,2),Replace(TasasInteresActual,',','.'))> 0 and
-- convert(decimal(18,2),Replace(PeriodicidadPagoInteresCredito,',','.')) = 0)

-- select tipodc,estadocredito,PeriodicidadPagoInteresCredito,PeriodicidadPagocapital,
-- TasasInteresCobrada,TasasInteresActual,* from jf77062.TB_DMAT04 
-- where 
-- estadocredito not in ('2','3') and
-- (convert(decimal(18,2),Replace(TasasInteresCobrada,',','.'))> 0 and
-- convert(decimal(18,2),Replace(PeriodicidadPagoInteresCredito,',','.')) = 0)


-- select tipodc,estadocredito,PeriodicidadPagoInteresCredito,PeriodicidadPagocapital,
-- TasasInteresCobrada,TasasInteresActual,* from jf77062.TB_DMAT04 
-- where 
-- estadocredito not in ('2','3') and
-- convert(numeric,PeriodicidadPagoInteresCredito)= 0 and
-- (convert(decimal(18,2),Replace(TasasInteresActual,',','.'))<> 0 and 
-- convert(decimal(18,2),Replace(TasasInteresCobrada,',','.'))<> 0 )
----------------------------------------------------------------------------------------------------------------------------------------------------------
--omo el valor del campo BENEFICIARIO ESPECIAL es distinto de 0 entonces deber�a cumplirse que el valor del 
--campo FECHA EMISION CERTIFICACION BENEFICIARIO ESPECIAL este entre 20140101 y la fecha final del per�odo reportado
-- --verificar en los insumos
-- select 	BeneficiarioEspecial,* 
-- from 	jf77062.TB_DMAT04
-- where 	BeneficiarioEspecial like '%n/a%' or 
-- 	BeneficiarioEspecial  is null

update jf77062.TB_DMAT04 
set 	BeneficiarioEspecial = '0'
where 	BeneficiarioEspecial like '%n/a%' or 
	BeneficiarioEspecial  is null
----------------------------------------------------------------------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es diferente de los siguientes valores: (5,8) entonces deber�a cumplirse que el valor del campo 
--USO FINANCIERO sea igual a 0 
--verificar los insumos el tipo credito  y uso financiero
-- select tipodc,tipocredito,UsoFinanciero,* from jf77062.TB_DMAT04 where tipocredito not in ('5','8') and UsoFinanciero <> 0
-------------------------------------------------------------------------------------------------------------------------------------------
---Valor de Referencia no Encontrado (Error Nro. 127): El valor "8" ni "10" no se encuentra entre los valores de referencia 
--de la lista de valores 'USO_FINANCIERO' Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo 

-- select tipodc,tipocredito,UsoFinanciero,* from jf77062.TB_DMAT04 where  UsoFinanciero in ('8','10')



--Como el valor del campo CLASIFICACION DE RIESGO es distinto de A entonces deber�a cumplirse que el valor del campo PROVISION ESPECIFICA sea menor que 0 
--verificar el  % de provi especificas del insumo de cartera corporativa no dirigida
--VERIFICAR LA CLAS RIESGO
-- select ClasificacionRiesgo,ProvisionEspecifica,saldo,PocentajeProvisionEspecifica,* from jf77062.TB_DMAT04
-- where ClasificacionRiesgo <> 'A' and
-- convert(decimal(18,2),ProvisionEspecifica)> 0	
--se a
-- UPDATE jf77062.TB_DMAT04 
-- SET ProvisionEspecifica=(CONVERT(DECIMAL(18,2),ISNULL(PocentajeProvisionEspecifica,0))*CONVERT(DECIMAL(18,2),ISNULL(Saldo,0))/100)*-1
-- where  CONVERT(DECIMAL(18,2),ISNULL(provisionespecifica, 0)) >= 0 
-- and ClasificacionRiesgo not in ('A', '0')
-------------------------------------------------------------------------------------------------------------------------------------------------------------
--Valor de Referencia no Encontrado (Error Nro. 323): El valor "60701" no se encuentra entre los valores de referencia de la lista de valores 
--'PARROQUIA' Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo 
--SOLUCION: SE LE AGREGO UN 0 AL COD PARROQUIA YA QUE DEBE TENER LOGITUD DE 6 DIGITOS
-- select codigocontable,numerocredito,codigoparroquia,tipodc,* from jf77062.TB_DMAT04 where LEN(codigoparroquia) = 5	
update jf77062.TB_DMAT04 set codigoparroquia = '0'+ codigoparroquia where LEN(codigoparroquia) = 5
-------------------------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 2): Como el valor del campo SITUACION DEL CREDITO es igual a uno de los siguientes valores: (3,4) 
--entonces deber�a cumplirse que el valor del campo NUMERO DE CUOTAS VENCIDAS sea mayor que 0 
--NO SEBE DAR, EN CASO DE APLICAR VERIFICAR EL INSUMO Y EL QUERY
-- select SITUACIONCREDITO,NUMEROCUOTASVENCIDAS,TIPODC,* from jf77062.TB_DMAT04
-- where SITUACIONCREDITO IN ('4','3') and
-- convert(NUMERIC,NUMEROCUOTASVENCIDAS)<= 0
-- AND CODIGOCONTABLE LIKE ('133%') 
---------------------------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 23): Como el valor del campo TIPO DE CREDITO es igual a 4, y el valor del campo ESTADO DEL CREDITO es igual a 1 
--entonces deber�a cumplirse que el valor del campo FECHA VENCIMIENTO DEL REGISTRO MPPAT sea mayor que 19691231
---hacer query para verificar este error
--UPDATE jf77062.TB_DMAT04 
--SET   UsoFinanciero = B.UsoFinanciero
--FROM jf77062.TB_DMAT04 A
--INNER JOIN jf77062.TB_DMAT04MARZOTRANSMITIDO B on A.NUMEROCREDITO = B.numerocredito
--where 	A.NUMEROCREDITO IN


---------------------------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 211): Como el valor del campo ESTADO DEL CREDITO es diferente de los siguientes valores: (2,3) , 
--y el valor del campo FECHA EXIGI PAGO ULTIMA CUOTA PAGADA es mayor o igual que el valor del campo FECHA DE LIQUIDACION entonces 
--deber�a cumplirse que el valor del campo FECHA EXIGI PAGO ULTIMA CUOTA PAGADA sea menor o igual que el valor del campo FECHA DE VENCIMIENTO ACTUAL 
--se verificaron los insumos y se le solicito la informacion al usuario (en este caso FINCON)
--NO APLICA POR AHORA 
/*select TIPODC,FechaExigibilidadPagoUltimaCuotaPagada,ESTADOCREDITO,fechaliquidacion,FechaVencimientoActual,* from jf77062.TB_DMAT04  
where ESTADOCREDITO not in ('2','3') and 
(FechaExigibilidadPagoUltimaCuotaPagada >= replace(fechaliquidacion,'/','')) and 
(FechaExigibilidadPagoUltimaCuotaPagada > replace(FechaVencimientoActual,'/',''))*/
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 2): Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (4,6) 
--entonces deber�a cumplirse que el valor del campo DIRECCION PROYECTO UNIDAD PRUDUCCION sea distinto de VACIO 
--para atjar este error

-- select DireccionProyectoUnidadProduccion,DomicilioFiscal, tipodc,tipocredito,* 
-- from jf77062.TB_DMAT04 
-- where 	tipocredito in ('4', '6') and 
-- 	DireccionProyectoUnidadProduccion = '' 
	
UPDATE jf77062.TB_DMAT04 
SET   DireccionProyectoUnidadProduccion = B.DireccionProyectoUnidadProduccion
FROM jf77062.TB_DMAT04 A
INNER JOIN #TEMP_AT04_MesAnterior B on A.NUMEROCREDITO = B.numerocredito
where 	A.tipocredito in ('4', '6') and 
	A.tipodc in ('8', '11','12') and 
	A.DireccionProyectoUnidadProduccion = '' 		
	
----------------------------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 17): Como el valor del campo TIPO DE CREDITO es igual a 3, y el valor del campo ESTADO DEL CREDITO 
--es igual a uno de los siguientes valores: (1,2) entonces deber�a cumplirse que el valor del campo TIPO DE BENEFICIARIO sea distinto de 0 
--para atajarlo
--solucion: verificar insumo

-- select tipocredito,estadocredito,tipobeneficiario,tipodc,* from jf77062.TB_DMAT04 
-- where tipocredito = 3 and
-- estadocredito in ('1','2') and 
-- tipobeneficiario = 0
-----------------------------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 997): Por lo menos una de las siguientes afirmaciones deber�a cumplirse:
--Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (2,3) entonces deber�a cumplirse que el c�digo de la Entidad 
--que esta realizando la transferencia sea diferente a los siguientes valores: (01212,00816) 
--Como el c�digo de la Entidad que esta realizando la transferencia es igual a uno de los siguientes valores: (01212,00816) entonces deber�a cumplirse 
--que el valor del campo FECHA EXIGI PAGO ULTIMA CUOTA PAGADA sea igual a el valor del campo FECHA DE LIQUIDACION 
--para atajar el error
-- select estadocredito,fechaliquidacion,fechaexigibilidadpagoultimacuotapagada, * from jf77062.TB_DMAT04
-- where estadocredito  in ('2','3') and fechaexigibilidadpagoultimacuotapagada <> replace(fechaliquidacion,'/','')
--segun correo Mon 4/6/2015 12:23 PM Reporte AT04 data noviembre 2014 Ver33 Julycer Gonzalez
UPDATE jf77062.TB_DMAT04 SET fechaexigibilidadpagoultimacuotapagada = replace(fechaliquidacion,'/','')
WHERE  estadocredito  in ('2','3') and fechaexigibilidadpagoultimacuotapagada <> replace(fechaliquidacion,'/','')
----------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 500): Como el valor del campo MONTO DE INTERES EN CUENTA DE ORDEN es igual a 0 entonces 
--deber�a cumplirse que el valor del campo CUENTA CONTABLE DE INTERES EN CUENTA DE ORDEN sea igual a 0 
-- select MontoInteresCuentaOrden,CuentaContableInteresCuentaOrden, * from jf77062.TB_DMAT04 where 
-- convert(DECIMAL(18,2),Replace(MontoInteresCuentaOrden,',','.')) = 0 AND  
-- CuentaContableInteresCuentaOrden <> '0' OR 
-- CuentaContableInteresCuentaOrden IS NULL

--solucion 
update jf77062.TB_DMAT04 set CuentaContableInteresCuentaOrden = '0' where 
convert(DECIMAL(18,2),Replace(MontoInteresCuentaOrden,',','.')) = 0 AND  
CuentaContableInteresCuentaOrden <> '0' OR 
CuentaContableInteresCuentaOrden IS NULL
----------------------------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 6): Como el valor del campo ESTADO DEL CREDITO es diferente de los siguientes valores: (2,3) por lo menos una de las siguientes afirmaciones deber�a cumplirse: 
--  Como el c�digo de la Entidad que esta realizando la transferencia es igual a uno de los siguientes valores: (01212,00816) entonces deber�a cumplirse que 
--el valor del campo FECHA EXIGI PAGO ULTIMA CUOTA PAGADA sea igual a el valor del campo FECHA DE LIQUIDACION 
-- Como el valor del campo FECHA EXIGI PAGO ULTIMA CUOTA PAGADA es menor o igual que el valor del campo FECHA DE VENCIMIENTO ACTUAL entonces deber�a cumplirse que 
--el valor del campo FECHA EXIGI PAGO ULTIMA CUOTA PAGADA sea mayor o igual que el valor del campo FECHA DE LIQUIDACION 
-- select fechaexigibilidadpagoultimacuotapagada,fechaliquidacion,
-- estadocredito,fechavencimientoactual,* 
-- from jf77062.TB_DMAT04 
-- where
-- estadocredito not in ('2','3') and
-- (replace(fechaexigibilidadpagoultimacuotapagada,'/','') <> replace(fechaliquidacion,'/','')) 

-- select fechaexigibilidadpagoultimacuotapagada,fechaliquidacion,
-- estadocredito,fechavencimientoactual,* 
-- from jf77062.TB_DMAT04 
-- where
-- estadocredito not in ('2','3') and
-- (replace(fechaexigibilidadpagoultimacuotapagada,'/','') <=  replace(fechavencimientoactual,'/','') and 
--  replace(fechaexigibilidadpagoultimacuotapagada,'/','') < replace(fechaliquidacion,'/','')) 


----segun correo Mon 4/6/2015 12:23 PM Reporte AT04 data noviembre 2014 Ver33 Julycer Gonzalez (aplica para todos los estados de credito)
UPDATE jf77062.TB_DMAT04 SET fechaexigibilidadpagoultimacuotapagada = replace(fechaliquidacion,'/','')
WHERE  estadocredito  not in ('2','3') 
and fechaexigibilidadpagoultimacuotapagada <> replace(fechaliquidacion,'/','')
----------------------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 996): Como el valor del campo TIPO DE CREDITO es distinto de 3 entonces deber�a cumplirse que el valor del campo TIPO DE VIVIENDA sea igual a 0 
--no debe aplicar, en caso de dar verificar los tipo de vivienda
-- select tipocredito,tipovivienda,* from jf77062.TB_DMAT04 where tipocredito <> 3  and tipovivienda <> 0
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 3): Como el valor del campo PROVISION ESPECIFICA es distinto de 0, y el c�digo de la Entidad que esta realizando la transferencia es d
--iferente de los siguientes valores: (01212) entonces deber�a cumplirse que el valor del campo CUENTA CONTABLE PROVISION ESPECIFICA empezara por algunos de los 
--siguientes valores: (139) 
--para atajar
-- select ProvisionEspecifica,CuentaContableProvisionEspecifica,* from jf77062.TB_DMAT04  
-- WHERE convert(DECIMAL(18,4),ProvisionEspecifica)<> 0 and 
-- CuentaContableProvisionEspecifica = 0

-- UPDATE jf77062.TB_DMAT04 
-- SET  CuentaContableProvisionEspecifica = '0'
-- where 
-- convert(decimal(18,4),ProvisionEspecifica) = 0 and 
-- CuentaContableProvisionEspecifica <> 0 or 
-- CuentaContableProvisionEspecifica is null

--solucion... se verifico por codigo contable y se ajusto
-- update jf77062.TB_DMAT04 set CuentaContableProvisionEspecifica = '1390310000'
-- where 
-- convert(numeric,ProvisionEspecifica) <> 0 and 
-- CuentaContableProvisionEspecifica = 0

-- Error de Fondo (Error Nro. 74): Por lo menos una de las siguientes afirmaciones deber�a cumplirse:
--- El valor del campo FECHA DE CAMBIO DE ESTATUS DE CREDITO debe estar entre la fecha inicial del per�odo reportado y la fecha final del per�odo reportado
---  El valor del campo FECHA DE CAMBIO DE ESTATUS DE CREDITO debe ser igual a 19000101 
--para atajar el error
-- select FechaCambioEstatusCredito,* from jf77062.TB_DMAT04 where  (FechaCambioEstatusCredito > '20160430') or ----------------->> Ajustar las fcehad correspondinte al mes
--  (FechaCambioEstatusCredito < '20160401' and  FechaCambioEstatusCredito <> '19000101') 
--solucion dada
--se le debe colocar el ultimo dia del mes a transmitir (igual consultar con BI)
-- update jf77062.TB_DMAT04 
-- set  FechaCambioEstatusCredito = A.FechaCambioEstatusCredito
-- from jf77062.TB_DMAT04 B
-- inner join jf77062.TB_DMAT04_TransmitidoJulio2019 A on A.Numerocredito = B.Numerocredito 
-- where  b.numerocredito in ()

 --Solucion: se verificaron las fechas en los insumos y se solicito la informacion a cada usuario
 
 ---Error de Fondo (Error Nro. 75): Como el valor del campo TIPO DE CREDITO es igual a 8, y el valor del campo ESTADO DEL CREDITO es igual a 1 
 --entonces deber�a cumplirse que el valor del campo TIPO DE INDUSTRIA sea distinto de 0 
 --para atajar
--  select tipocredito,tipoindustria,* from jf77062.TB_DMAT04 where  (tipocredito =8 and estadocredito = 1) and tipoindustria =  0
 ---------------------------------------------------------------------------------------------
 --Error de Fondo (Error Nro. 2): Como el valor del campo TIPO DE CREDITO es igual a 8, 
 --y el valor del campo ESTADO DEL CREDITO es distinto de 1 entonces deber�a cumplirse 
 --que el valor del campo TIPO DE INDUSTRIA sea igual a 0 
--   select tipoindustria,tipoindustria,estadocredito,tipocredito,* from jf77062.TB_DMAT04
--   where  (tipocredito = '8' and estadocredito <> '1') and tipoindustria <>  0 

-- UPDATE jf77062.TB_DMAT04
-- SET tipoindustria = '0'
-- where numerocredito in ('8150290319')
 
 ---------------------------------------------------------------------------------------
 --Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (1,2,3,4,5,6,8), 
 --y el valor del campo CODIGO CONTABLE no empieza por algunos de los siguientes valores: (13106,13206,13306,13406)
 -- y el valor del campo FECHA DE APROBACION es menor o igual que el valor del campo FECHA DE LIQUIDACION entonces
-- deber�a cumplirse que el valor del campo FECHA DE APROBACION sea mayor o igual que el valor del campo FECHA DE SOLICITUD 
---para atajar el error
-- select tipocredito,codigocontable,fechaaprobacion,
-- fechaliquidacion,fechasolicitud,* from jf77062.TB_DMAT04  where (tipocredito in ('1','2','3','4','5','6','8') and 
-- codigocontable not in ('13106','13206','13306','13406')
-- and replace(fechaaprobacion,'/','') <= replace(fechaliquidacion,'/',''))
-- and (replace(fechaaprobacion,'/','') < replace(fechasolicitud,'/',''))
--solucion 
--se verificaron las fechas de aprobacion...estaban mal mapeadas
---------------------------------------------------------------------------------------------------------
--Como el valor del campo CODIGO CONTABLE empieza por algunos de los siguientes valores: 
--(13106101,13106201,13106102,13106202,13206101,13206201,13206102,13206202,13306101,13306201,
--13306102,13306202,13406101,13406201,13406102,13406202), 
--y el valor del campo COMISIONES COBRADAS es mayor que 0 entonces deber�a cumplirse que
-- el valor del campo TASA DE LA COMISION sea mayor que 0 
-- select TasaComision, * from jf77062.TB_DMAT04 where codigocontable not in ('13106101','13106201','13106102',
-- '13106202','13206101','13206201','13206102','13206202','13306101','13306201','13306102',
-- '13306202','13406101','13406201','13406102','13406202') and 
-- convert(decimal(18,2),ComisionesCobradas) > 0 and 
-- convert(decimal(18,4),TasaComision) < 0

--Como el valor del campo SITUACION DEL CREDITO es igual a uno de los siguientes valores: (1,2),
--y el valor del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que el valor 
--del campo FECHA DE REGISTRO EN VENCIDA LITIGIO O CASTIGADA sea igual a 19000101 
-- select situacioncredito,estadocredito,FechaRegistroVencidaLitigiooCastigada,* from jf77062.TB_DMAT04 where 
-- situacioncredito in ('1','2') and estadocredito = '1' and 
-- FechaRegistroVencidaLitigiooCastigada <> '19000101'


update jf77062.TB_DMAT04 set FechaRegistroVencidaLitigiooCastigada = '19000101'
where numerocredito =''

---Como el valor del campo RUBRO es igual a uno de los siguientes valores:
-- (5010100,5010200,5010300,5010500,5010600,5010700,5010800,5010900,5011000,5011100,5011200) 
--entonces deber�a cumplirse que el valor del campo el valor del campo CODIGO DE USO deber�a
-- estar contenido dentro de los valores de la funcion binaria 402815970 
-- update jf77062.TB_DMAT04 
-- set codigouso = '268435456' where  numerocredito in ('8121520303')

-- update jf77062.TB_DMAT04 
-- set codigouso = '2' where  numerocredito in ('8121520302')

-- --Como el valor del campo RUBRO es distinto de 0 por lo menos una de las siguientes afirmaciones deber�a cumplirse: 
-- --el valor del campo SECTOR DE PRODUCCION debe ser un sector v�lido para la combinacion de el valor del campo CODIGO DE USO
-- update jf77062.TB_DMAT04 set codigouso = '16384' where numerocredito in ('8112800309',
-- '8112800340',
-- '8112800341',
-- '8112800339',
-- '8112800342',
-- '8112800343',
-- '8120900305')

-- update jf77062.TB_DMAT04 set codigouso = '137438953472' where numerocredito in  ('8131360301',
-- '8133160312',
-- '8133170302',
-- '8133320321',
-- '8140570311',
-- '8133430308',
-- '8142410305',
-- '8142600304',
-- '8142600314',
-- '8142830301',
-- '8143090304',
-- '8143220301',
-- '8143320306',
-- '8143390317',
-- '8143450308',
-- '8143430302',
-- '8143520310',
-- '8143570306',
-- '8143570304',
-- '8143570305',
-- '8150300321')
--------------------------------------------------

---no debe dar y en caso de dar verificar las provisiones
-- select clasificacionriesgo,provisionespecifica,* 
-- from jf77062.TB_DMAT04
-- where clasificacionriesgo = ('A') and 
-- convert(decimal(18,2),provisionespecifica) <> 0

---primero hice  select comparando con el mes anterior
--y luego le coloque el mismo valor ya que tenia 0 y lo demas estaba igual
update jf77062.TB_DMAT04 set ProvisionEspecifica ='0.0000'
where numerocredito in ('')

-------------------------------------
-- select ProvisionEspecifica,* 
-- from jf77062.TB_DMAT04
-- where  ProvisionEspecifica ='0.00'


UPDATE jf77062.TB_DMAT04 
SET ProvisionEspecifica = '0'
where ProvisionEspecifica ='0.00'
---recordar verificar las cuentas ocntables de provision especificas
--si hay algun reg afectado osea que cambien a 0

----------------------
---Cada vez que ocurra un deajuste contable, verificar:
--1.- Restar los montos que estan aparecen en el error (AT31 -AT04)
--2.- Verificar sobre cual campo esta ocurriendo el desjauste (rendimientos por cobrar, rendimientos por cobrar vencidos, etc)
--3.- Verificar la cuenta contable
--4.- Sacamos el Detalle
--5.- Solicitamos a Julycer informaci�n sobre qu� hacer con el monto que se esta descuadrando
----5.1.- Usualmente implica cambiar los montos de una columna a otra. (Teniendo prevision de dejar la columna a la que se le quit� el monto en 0.00)
--6.- Correr el query 650 de calidad de data 1. SIEMPRE
--7.- Correr el query de calidad de data asociado a las CuentaContableProvisionRendimiento que deben ser iguales al valor 1490310000
-- select * from jf77062.TB_DMAT04 
-- where RendimientosCobrar <> '0.00' and codigocontable ='1330610100'
---Para atajar el error:
--Error de Fondo (Error Nro. 32): Como el c�digo de la Entidad que esta realizando la transferencia es 
--diferente de los siguientes valores: (01212) , y el valor del componente sumatorio AT04_REND_REESTRUCTURADOS(1,09)
-- - el valor del componente sumatorio AT31P_REND_REESTRUCTURADO(17317,48) es menor o igual que 50 entonces deber�a 
--cumplirse que el valor del componente sumatorio AT04_REND_REESTRUCTURADOS(1,09) - el valor del componente sumatorio 
--AT31P_REND_REESTRUCTURADO(17317,48) sea mayor o igual que -50 

-- select RendimientosCobrarReestructurados,rendimientoscobrar,* from jf77062.TB_DMAT04 where 
-- convert(decimal(18,2),replace(RendimientosCobrarReestructurados,',','.')) <> 0
--solucion
update jf77062.TB_DMAT04 set RendimientosCobrarReestructurados = Replace(rendimientoscobrar,'.',',')
where 
convert(decimal(18,2),replace(RendimientosCobrarReestructurados,',','.')) <> 0

/*
---Para resolver otros errores de uso, medida, TipoSubsector,rubro y sectorproduccion
UPDATE jf77062.TB_DMAT04 
SET  TipoSubsector = B.TipoSubsector,
	rubro = B.rubro,
	CodIGOUso = B.CodIGOUso,
	CodIGOUnidadMedida = B.CodIGOUnidadMedida,
	sectorproduccion = B.sectorproduccion
FROM jf77062.TB_DMAT04 A
INNER JOIN jf77062.TB_DMAT04TransmitidoAbril2016 B on A.NUMEROCREDITO = B.numerocredito
where 	A.tipodc in ('11','12') 	
and A.estadocredito = '1'
*/
---------------------------------------------------------------------
-- no debe dar

-- select rubro,CodIGOUso,CodIGOUnidadMedida,sectorproduccion,* from jf77062.TB_DMAT04 where rubro = '0' and CodIGOUso <> '0'

update jf77062.TB_DMAT04 set CodIGOUso = '0' where rubro = '0' and CodIGOUso <> '0'

----------------------------------------------------------------------
---(Error Nro. 34): Como el valor del campo TIPO DE CREDITO es igual a 8, y el valor del campo ESTADO DEL CREDITO 
--es igual a 1 entonces deber�a cumplirse que el valor del campo TIPO DE BENEFICIARIO SECTOR MANUFACTURERO sea 
--distinto de 0
-- select TipoBeneficiarioSectorManufacturero,tipocredito,estadocredito,* from jf77062.TB_DMAT04
-- where 	tipocredito = '8' 
-- and 	estadocredito = '1'
-- and 	TipoBeneficiarioSectorManufacturero = '0'

------------------------------------------------------------------
--Error de Fondo (Error Nro. 17): Por lo menos una de las siguientes afirmaciones deber�a cumplirse:
--Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,2) entonces 
--deber�a cumplirse que el valor del campo TIPO DE CREDITO sea igual a 2 � 
--el valor del campo TIPO DE CREDITO sea igual a 6 �
--el valor del campo TIPO DE CREDITO sea igual a 8 �
--el valor del campo TIPO DE CREDITO sea igual a 4 �
--el valor del campo TIPO DE CREDITO sea igual a 5 �
--el valor del campo TIPO DE CREDITO sea igual a uno de los siguientes valores:(1,2) �
--el valor del campo TIPO DE CREDITO sea igual a 1 �
--el valor del campo TIPO DE CREDITO sea igual a 3 
--Como el valor del campo TIPO DE CREDITO es igual a 0 entonces 
--deber�a cumplirse que el valor del campo ESTADO DEL CREDITO sea igual a 3 

-- SELECT	TIPOCREDITO,ESTADOCREDITO,* FROM jf77062.TB_DMAT04 
-- WHERE	ESTADOCREDITO IN ('1','2') AND
-- 	TIPOCREDITO NOT IN ('2','6','8','4','5','1','3')


-- SELECT	* FROM jf77062.TB_DMAT04 
-- WHERE	TIPOCREDITO = '0' AND
-- 	ESTADOCREDITO <> '3'


/*update 	jf77062.TB_DMAT04
SET 	TIPOCREDITO = '4'
WHERE	ESTADOCREDITO IN ('1','2') AND
	TIPOCREDITO NOT IN ('2','6','8','4','5','1','3')*/

----------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 8): Como el valor del campo TIPO DE CREDITO es diferente de los 
--siguientes valores: (5,8) entonces deber�a cumplirse que el valor del campo USO FINANCIERO sea igual a 0 

-- select 	* 
-- from 	jf77062.TB_DMAT04 
-- where 	TIPOCREDITO  NOT IN ('5','8') AND
-- 	USOFINANCIERO <> 0

---------------------------------------------------------------------------------------------------------------
--Error de Fondo (Error Nro. 2): Como el valor del campo TIPO DE CREDITO es igual a 8, y el valor del campo ESTADO DEL CREDITO
-- es igual a 1 entonces deber�a cumplirse que el valor del campo TIPO DE BENEFICIARIO SECTOR MANUFACTURERO sea distinto de 0

-- select 	* 
-- from 	jf77062.TB_DMAT04 
-- where 	(TIPOCREDITO = '8' AND
-- 	ESTADOCREDITO = '1') AND 
-- 	TipoBeneficiarioSectorManufacturero = 0
	

-- update jf77062.TB_DMAT04 set TipoBeneficiarioSectorManufacturero = '1'
-- where   numerocredito in ()
-----------------------------------------------------------------------------------------------------------------------
--- Ajuste Julycer Gonzalez segun correo Thu 8/13/2015 6:06 PM
UPDATE	jf77062.TB_DMAT04
SET 	TipoBeneficiario = A.TipoBeneficiario
FROM 	jf77062.TB_DMAT04 DM
INNER 	JOIN tb_AT04_TipoBeneficiario A 
	ON A.CtaContable = DM.CodigoContable
WHERE 	DM.Tipodc in ('6','7')

--ajustados 1437

--- ajuste Rafael Rodriguez / Luis Mendoza BI  segun correo Fri 8/21/2015 10:26 AM
UPDATE	jf77062.TB_DMAT04
SET 	IngresoFamiliar = M.IngresoFamiliar ,
	ModalidadHipoteca = M.ModalidadHipotecaria 
FROM 	jf77062.TB_DMAT04 DM
INNER 	JOIN tb_AT04IngresoFamModalidadHipo M 
	ON M.Numerocredito = DM.NumeroCredito
WHERE 	DM.Tipodc in ('6','7') 
--se actualizaron 1422


--Ajuste segun correo Eliana Fernandez FINCON Fri 8/21/2015 11:26 AM
--para el Corporate en los campos de Ingreso Familiar se debe colocar Saldo 0, 
--y en la Modalidad Hipotecaria se debe colocar  2 que es �Construcci�n�.

UPDATE	jf77062.TB_DMAT04
SET 	IngresoFamiliar = '0.00' ,
		ModalidadHipoteca = '2' 
WHERE 	Tipodc in ('7')
--se actualizaron 24

---Para atajar error
----ERRORES
 
/*---(Error Nro. 211): Como el valor del campo TIPO DE CREDITO es igual a 3, 
y el valor del campo ESTADO DEL CREDITO es igual a 1, y el valor del campo 
TIPO DE BENEFICIARIO es igual a 2, y el valor del campo FECHA DE LIQUIDACION 
es menor o igual que 20100430 entonces deber�a cumplirse que el valor del 
campo MODALIDAD HIPOTECARIO sea igual a uno de los siguientes valores:
(2,5,6) */

-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,FECHALIQUIDACION,MODALIDADHIPOTECA,TIPODC
-- FROM 	jf77062.TB_DMAT04
-- WHERE	TIPOCREDITO = '3'	
-- 	AND ESTADOCREDITO = '1' 
-- 	AND TIPOBENEFICIARIO = '2'
-- 	AND REPLACE(FECHALIQUIDACION,'/','') <= '20100430' 	
-- 	AND MODALIDADHIPOTECA NOT IN ('2','5','6')

/*Como el valor del campo TIPO DE CREDITO es igual a 3, y el valor del 
campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: 
(1,2), y el valor del campo TIPO DE BENEFICIARIO es igual a 2, y 
el a?o de la fecha final del per�odo reportado es mayor que el a?o 
de el valor del campo FECHA DE LIQUIDACION entonces deber�a cumplirse
que el valor del campo SALDO DEL CREDITO AL 31 12 sea mayor que 0 */

---Solucion: verificar los campos en el insumo de hipotecario largo plazo

-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,FECHALIQUIDACION,MODALIDADHIPOTECA,SALDOCREDITO31_12,TIPODC
-- FROM 	jf77062.TB_DMAT04
-- WHERE	TIPOCREDITO = '3'	
-- 	AND ESTADOCREDITO IN ('1','2') 
-- 	AND TIPOBENEFICIARIO = '2'
-- 	AND SUBSTRING(FECHALIQUIDACION,1,4) < '2017' ----ajustar el a�o cuando corresponda
-- 	AND CONVERT(DECIMAL(18,2),REPLACE(SALDOCREDITO31_12,',','.')) <= 0	

--solucion
-- UPDATE	jf77062.TB_DMAT04
-- SET 	SALDOCREDITO31_12 = M.SALDOCREDITO31_12
-- FROM 	jf77062.TB_DMAT04 DM
-- INNER 	JOIN TB_TEMP_AT04_SALDOCREDITO31_12 M 
-- 	ON M.Numerocredito = DM.NumeroCredito
-- WHERE 	DM.Tipodc in ('6','7')
-- 	AND DM.TIPOCREDITO = '3'	
-- 	AND DM.ESTADOCREDITO IN ('1','2') 
-- 	AND DM.TIPOBENEFICIARIO = '2'
-- 	AND SUBSTRING(DM.FECHALIQUIDACION,1,4) < '2019'----ajustar el a�o cuando corresponda
-- 	AND CONVERT(DECIMAL(18,2),REPLACE(DM.SALDOCREDITO31_12,',','.')) <= 0
--226	
--para buscar
	-- select TIPO_BENEFICIARIO ,TIPO_CREDITO , ESTADO_CREDITO,SALDO_CREDITO_31_12,* from RPT_STG_Dirigidas_HIPOTECARIO_LARGO_PLAZO
	-- where NUM_CREDITO in ()


---si quedan, verificar el tipo beneficiario en 
-- select TIPO_CREDITO,ESTADO_CREDITO,TIPO_BENEFICIARIO,* from RPT_STG_Dirigidas_HIPOTECARIO_LARGO_PLAZO where convert(numeric,num_credito)IN
/*Error de Fondo (Error Nro. 247): Como el valor del campo TIPO DE CREDITO 
es igual a 3, y el valor del campo ESTADO DEL CREDITO es igual a uno de los 
siguientes valores: (1,2), y el valor del campo TIPO DE BENEFICIARIO es 
distinto de 2 entonces deber�a cumplirse que el valor del campo SALDO 
DEL CREDITO AL 31 12 sea igual a 0 */

-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,FECHALIQUIDACION,MODALIDADHIPOTECA,SALDOCREDITO31_12,TIPODC
-- FROM 	jf77062.TB_DMAT04
-- WHERE	TIPOCREDITO = '3'	
-- 	AND ESTADOCREDITO IN ('1','2') 
-- 	AND TIPOBENEFICIARIO <> '2'
-- 	--AND REPLACE(FECHALIQUIDACION,'/','') < '20141231' 	
-- 	AND CONVERT(DECIMAL(18,2),REPLACE(SALDOCREDITO31_12,',','.')) <> 0


UPDATE 	jf77062.TB_DMAT04
SET 	SALDOCREDITO31_12 = '0.00'
WHERE	TIPOCREDITO = '3'	
	AND ESTADOCREDITO IN ('1','2') 
	AND TIPOBENEFICIARIO <> '2'
	AND CONVERT(DECIMAL(18,2),REPLACE(SALDOCREDITO31_12,',','.')) <> 0
	--actualizado 196 reg

/* Como el valor del campo TIPO DE CREDITO es igual a 3, y el valor del campo
 ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,2), y el 
valor del campo TIPO DE BENEFICIARIO es distinto de 2 entonces deber�a 
cumplirse que el valor del campo MONTO LIQUIDADO ANO EN CURSO sea igual a 0 */



-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,MontoLiquidadoDuranteAnoCurso,TIPODC
-- FROM 	jf77062.TB_DMAT04
-- WHERE	TIPOCREDITO = '3'	
-- 	AND ESTADOCREDITO IN ('1','2') 
-- 	AND TIPOBENEFICIARIO <> '2'
-- 	AND CONVERT(DECIMAL(18,2),REPLACE(MontoLiquidadoDuranteAnoCurso,',','.')) <> 0
/*
Error de Fondo (Error Nro. 930): Como el valor del campo TIPO DE CREDITO es igual a 3, y el 
valor del campo ESTADO DEL CREDITO es igual a 1, y el valor del campo TIPO DE BENEFICIARIO
 es igual a 2, y el valor del campo MODALIDAD HIPOTECARIO es distinto de 2 entonces deber�a 
 cumplirse que el valor del campo INGRESO FAMILIAR sea mayor que 0 .
*/
	
	
-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,MontoLiquidadoDuranteAnoCurso,TIPODC
-- FROM 	jf77062.TB_DMAT04
-- WHERE	TIPOCREDITO = '3'	
-- 	AND ESTADOCREDITO IN ('1') 
-- 	AND TIPOBENEFICIARIO = '2'
-- 	and ModalidadHipoteca <>'2'
-- 	AND CONVERT(DECIMAL(18,2),REPLACE(IngresoFamiliar,',','.')) <= 0.00	
	
	
--SOLUCION:SE APLICO ESTE UPDATE SEGUN ESPECIFICACIONES DEL EQUIPO DE FINCON CORREO 
--Mon 9/21/2015 11:41 AM DE Gonzalez, Julycer Carolina [FIN] <jg75090@imcla.lac.nsroot.net>

UPDATE 	jf77062.TB_DMAT04
SET 	MontoLiquidadoDuranteAnoCurso  ='0.00'
WHERE	TIPOCREDITO = '3'	
	AND ESTADOCREDITO IN ('1','2') 
	AND TIPOBENEFICIARIO <> '2'
	AND CONVERT(DECIMAL(18,2),REPLACE(MontoLiquidadoDuranteAnoCurso,',','.')) <> 0
--actualizado 17 reg

/* Como el valor del campo TIPO DE CREDITO es igual a 3, y el valor del campo
 ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,2), y el 
valor del campo TIPO DE BENEFICIARIO es distinto de 2 entonces deber�a 
cumplirse que el valor del campo MONTO LIQUIDADO ANO EN CURSO sea igual a 0 */


-- SELECT 	NUMEROCREDITO, TIPOCREDITO,MODALIDADHIPOTECA--,TIPODC
-- FROM 	jf77062.TB_DMAT04 --jf77062.TB_DMAT04 
-- WHERE	TIPOCREDITO <> '3'	
-- 	AND MODALIDADHIPOTECA NOT IN ('0') 

--SOLUCION: SEGUN CORREO Mon 9/21/2015 5:39 PM Gonzalez, Julycer Carolina [FIN] <jg75090@imcla.lac.nsroot.net>

UPDATE 	jf77062.TB_DMAT04
SET 	MODALIDADHIPOTECA = '0'
WHERE	TIPOCREDITO <> '3'	
	AND MODALIDADHIPOTECA NOT IN ('0') 
--7 reg act

--Como el valor del campo TIPO DE CREDITO es igual a 3, 
--y el valor del campo ESTADO DEL CREDITO es igual a 1, 
--y el valor del campo TIPO DE BENEFICIARIO es distinto de 2 
--entonces deber�a cumplirse que el valor del campo 
--CANTIDAD DE VIVIENDAS A CONSTRUIR sea igual a 0 


-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,CANTIDADVIVIENDASCONSTRUIR,TIPODC
-- FROM 	jf77062.TB_DMAT04 --jf77062.TB_DMAT04 
-- WHERE	TIPOCREDITO = '3'	
-- 	AND ESTADOCREDITO = '1'
-- 	AND TIPOBENEFICIARIO <> '2'
-- 	AND CANTIDADVIVIENDASCONSTRUIR <> '0'

--SOLUCION: SEGUN CORREO SEGUN CORREO Mon 9/21/2015 5:39 PM Gonzalez, Julycer Carolina [FIN] <jg75090@imcla.lac.nsroot.net>

UPDATE 	jf77062.TB_DMAT04
SET	CANTIDADVIVIENDASCONSTRUIR = '0'
WHERE	TIPOCREDITO = '3'	
	AND ESTADOCREDITO = '1'
	AND TIPOBENEFICIARIO <> '2'
	AND CANTIDADVIVIENDASCONSTRUIR <> '0'

---------------
---Como el valor del campo TIPO DE CREDITO es igual a 3, 
--y el valor del campo ESTADO DEL CREDITO es distinto de 1 
--entonces deber�a cumplirse que el valor del campo CANTIDAD DE VIVIENDAS A CONSTRUIR sea igual a 0 
-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,CANTIDADVIVIENDASCONSTRUIR,TIPODC
-- FROM 	jf77062.TB_DMAT04 
-- WHERE	TIPOCREDITO = '3'	
-- 	AND ESTADOCREDITO <> '1'
-- 	AND CANTIDADVIVIENDASCONSTRUIR <> '0'
--solucion
--si es de la cartera de hipotecario corto plazo se debe colocar cantviviendas = 0
--ya que son creditos castigados. Segun LuisM BI
UPDATE 	jf77062.TB_DMAT04 
SET  	CANTIDADVIVIENDASCONSTRUIR = '0'
WHERE	TIPOCREDITO = '3'	
	AND ESTADOCREDITO <> '1'
	AND CANTIDADVIVIENDASCONSTRUIR <> '0'
	AND TIPODC = '7' 

--Como el valor del campo TIPO DE CREDITO es igual a 3,
-- y el valor del campo ESTADO DEL CREDITO es distinto de 1
--entonces deber�a cumplirse que el valor del campo TIPO DE VIVIENDA sea igual a 0 
-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,CANTIDADVIVIENDASCONSTRUIR,TIPODC
-- FROM 	jf77062.TB_DMAT04 
-- WHERE	TIPOCREDITO = '3'	
-- 	AND ESTADOCREDITO <> '1'
-- 	AND TIPOVIVIENDA <> '0'
--SON LOS MISMOS REGISTROS DE ARRIBA
UPDATE 	jf77062.TB_DMAT04 
SET  	TIPOVIVIENDA = '0'
WHERE	TIPOCREDITO = '3'	
	AND ESTADOCREDITO <> '1'
	AND TIPOVIVIENDA <> '0'
	AND TIPODC = '7' 
	
-------------------------------------------------------------------------------------------------------------

--Valor de Referencia no Encontrado (Error Nro. 496): El valor "0007" no se encuentra entre los valores de 
--referencia de la lista de valores 'OFICINA' Consulte el manual respectivo para ver la lista de todos los 
--valores admitidos por este campo 

-- select * from jf77062.TB_DMAT04 where oficina = '7'

UPDATE jf77062.TB_DMAT04
SET oficina = '8'
WHERE oficina = '7'

-------------------------------------------------------------------------------------------------------------
/*Como el valor del campo TIPO DE CREDITO es igual a 3, y el valor del campo ESTADO DEL CREDITO es
igual a uno de los siguientes valores: (1,2), y el valor del campo TIPO DE BENEFICIARIO es distinto 
de 2 entonces deber�a cumplirse que el valor del campo SALDO DEL CREDITO AL 31 12 sea igual a 0 
*/
-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,FECHALIQUIDACION,MODALIDADHIPOTECA,SALDOCREDITO31_12,TIPODC
-- FROM 	jf77062.TB_DMAT04
-- WHERE	TIPOCREDITO = '3'	
-- 	AND ESTADOCREDITO IN ('1','2') 
-- 	AND TIPOBENEFICIARIO <> '2'
-- 	AND CONVERT(DECIMAL(18,2),REPLACE(SALDOCREDITO31_12,',','.')) <> 0

------------------------------------------------------------------------------------------------------------	
--en la cuenta 1310410000 no debe haber saldo vencido, en caso de haber se debe verificar los registros y consultar a julycer o
--cambiarse a saldo capital y dejar en saldo vencido a 0
	--JG: Por favor hacer este saldo cero, las cuentas vigentes no deben tener saldos vencidos.
-- SELECT	Numerocredito,
-- 	TipoDC,
-- 	MontoVencido30dias,
-- 	MontoVencido60dias,
-- 	MontoVencido90dias,
-- 	MontoVencido120dias,
-- 	MontoVencido180dias,
-- 	MontoVencidoUnAno,
-- 	MontoVencidoMasUnAno
-- FROM 	jf77062.TB_DMAT04 
-- WHERE	(CONVERT(DECIMAL(18,2),REPLACE(MontoVencido30dias,',','.'))> 0
-- 	OR CONVERT(DECIMAL(18,2),REPLACE(MontoVencido60dias,',','.')) > 0
-- 	OR CONVERT(DECIMAL(18,2),REPLACE(MontoVencido90dias,',','.')) > 0
-- 	OR CONVERT(DECIMAL(18,2),REPLACE(MontoVencido120dias,',','.'))> 0
-- 	OR CONVERT(DECIMAL(18,2),REPLACE(MontoVencido180dias,',','.'))> 0
-- 	OR CONVERT(DECIMAL(18,2),REPLACE(MontoVencidoUnAno,',','.')) > 0
-- 	OR CONVERT(DECIMAL(18,2),REPLACE(MontoVencidoMasUnAno,',','.')) > 0)
-- 	AND CodigoContable LIKE '%1310410000%'
	
	--JG: Por favor hacer este saldo cero, las cuentas vigentes no deben tener saldos vencidos.
	
------------------------------------------------------------------------------------------------------------------
--Valor de Referencia no Encontrado (Error Nro. 31): El valor "0007" no se 
--encuentra entre los valores de referencia de la lista de valores 'OFICINA' 
--Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo
--se pidio a Luis mendoza y el dijo de donde era el credito yse busco en la tabla TB_CFGSB46


-- update jf77062.TB_DMAT04 set oficina = '0007', CodigoParroquia = '30801' where numerocredito = '7090102405'

------------------------------------------------------------------------------------------------------------------

/*El valor "No aplica" no se encuentra entre los valores de referencia de la lista de valores 'CONFORMACION_TURISTICA' 
Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo */
-- select LicenciaTuristicaNacional,NumeroExpedienteConformidadTuristica, * from jf77062.TB_DMAT04 
-- where LicenciaTuristicaNacional = 'No aplica' or NumeroExpedienteConformidadTuristica = 'No aplica'
------------------------------------------------------------------------------------------------------------------
/*Detectar si hay registros repetidos en el reporte*/
-- select Numerocredito, count(Numerocredito)
-- from jf77062.TB_DMAT04
-- group by Numerocredito
-- having count(Numerocredito) > 1
------------------------------------------------------------------------------------------------------------------
/*Por lo menos una de las siguientes afirmaciones deber�a cumplirse:
-  Como el valor del campo ESTADO DEL CREDITO es igual a 3 entonces deber�a cumplirse que el valor del campo TIPO DE CREDITO sea igual a 0 
-  Como el valor del campo TIPO DE CREDITO es igual a 3 entonces deber�a cumplirse que el valor del campo ESTADO DEL CREDITO sea igual a 
uno de los siguientes valores:(1,2)*/
--SOLUCION: VERIFICAR INSUMOS Y CALIDAD DE DATA Y SI ES RECLASIFICACION A CASTIGADOS O ESTADO CREDIT 3 REALIZAR EL UPDATE 
-- select estadocredito,TIPOCREDITO,tipodc, * from jf77062.TB_DMAT04 where (estadocredito = 3  and 
-- TIPOCREDITO <> 0) AND SUBSTRING(CODIGOCONTABLE,1,3) = '819'

--UPDATE jf77062.TB_DMAT04 SET  TIPOCREDITO = 0 WHERE (estadocredito = 3  and 
--TIPOCREDITO <> 0)AND SUBSTRING(CODIGOCONTABLE,1,3) = '819'
------------------------------------------------------------------------------------------------------------------
/*Error de Fondo (Error Nro. 16): Como el valor del campo TIPO DE CREDITO es igual a 8, y el valor del campo 
ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,2) entonces deber�a cumplirse que el valor 
del campo CODIGO CONTABLE empezara por algunos de los siguientes valores: (13133,13233,13333,13433)
Solucion: se debia a la reclasificacion de las cuentas contables que orden� sudeban, sin embargo se tuvo que 
llevar los creditos de nuevo a su anterior cuenta ya que en el pre vlidador daban error.
Orden segun correo : 
*/

-- SELECT 	TipoCredito,
-- 	ESTADOCREDITO,
-- 	CODIGOCONTABLE 
-- FROM 	jf77062.TB_DMAT04
-- WHERE	TipoCredito = 8
-- 	AND ESTADOCREDITO IN ('1','2')
-- 	AND SUBSTRING(CODIGOCONTABLE,1,5) NOT IN ('13133','13233','13333','13433')

--SI DA ESTE SELECT SE DEBE VALIDAR CON JULYCER SI YA LA SUDEBAN ACTUALIZO SU VALIDADOR

------------------------------------------------------------------------------------------------------------------
--esta calidad de data se realiza por "alerta levantada por la SUDEBAN" sobre el valor del campo IngresoFamiliar
--que debe ser un monto valido. en caso de haber un ingreso menor a 700 consultar con usuario de carteras regualtorias
--esto no debe dar ya que el insumo de Robinson Sandoval debe suministrar esta informacion.
-- SELECT	INGRESOFAMILIAR,*
-- FROM 	jf77062.TB_DMAT04
-- WHERE 	TIPODC = 6 
-- 	AND CONVERT(DECIMAL(18,2),INGRESOFAMILIAR) < 700.00

-- update jf77062.TB_DMAT04 
-- set INGRESOFAMILIAR ='47264.63'
-- where numerocredito = '6000003637'
------------------------------------------------------------------------------------------------------------------
/*El valor "1312810000" no se encuentra entre los valores de referencia de la lista de valores 'CUENTA_CONTABLE' 
Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo 

El valor "1332810000" no se encuentra entre los valores de referencia de la lista de valores 'CUENTA_CONTABLE' 
Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo 

 */

/*Como el valor del campo CODIGO CONTABLE empieza por algunos de los siguientes valores: (131), y el valor del campo
 ESTADO DEL CREDITO es igual a 1 entonces deber�a cumplirse que el valor del campo SITUACION DEL CREDITO sea igual a 1 
 solucion: verificar los insumos y consultar al usuario
*/
-- SELECT * FROM jf77062.TB_DMAT04 
-- WHERE SUBSTRING(CODIGOCONTABLE,1,3) = '131'
-- AND ESTADOCREDITO = 1
-- AND SITUACIONCREDITO <>1 
------------------------------------------------------------------------------------------------------------------

/***RECORDAR QUE CADA VEZ QUE SE RECLASIFICAN REGISTROS EN CODIGOCONTABLE O ESTADOCREDITO SE DEBE VERIFICAR BIEN TODA LA CALIDAD DE DATA QUE ESO CONLLEVA***
***RECORDAR QUE LOS REGISTROS EN LAS CUENTAS DE CASTIGADOS LLEVAN VALORES SETEADOS POR DEFECTO, VERIFICAR EN LOS QUERYS-***/

------------------------------------------------------------------------------------------------------------------
/*Valor de Referencia no Encontrado (Error Nro. 1000): El valor "1312810000" no se encuentra entre los valores de referencia 
de la lista de valores 'CUENTA_CONTABLE' Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo */
-- SELECT * FROM jf77062.TB_DMAT04 WHERE codigocontable in ('1312810000','1322810000','1332810000')

--SOLUCION: PEDIR RECLASIFICACION DE CUENTAS A BIR

--Como el valor del campo TIPO DE CREDITO es igual a 1, y el valor del campo ESTADO DEL 
--CREDITO es igual a uno de los siguientes valores: (1,2) por lo menos una de las siguientes afirmaciones deber�a cumplirse: 
--El valor del campo CODIGO CONTABLE debe empezar por algunos de los siguientes valores: (1320510130,1320520130,1330510130,1330520130,1340510199,1340520199,13115,13215,13315,13415,1310510199,1310520199,1320510199,1320520199,1330510199,1330520199)
--El valor del campo CODIGO CONTABLE debe empezar por algunos de los siguientes valores: (1310510102,1310520102,1320510102,1320520102,1330510102,1330520102,1340510102,1340520102,13106,13206,13306,13406,13108,13208,13308,13408,13130102,13130202,13230102,13230202,13330102,13330202,13430102,13430202,13102,13302,13402,1310510199,1310520199)
-- select tipoCredito,estadocredito,* from jf77062.TB_DMAT04 where
-- tipoCredito = '1' and
-- estadocredito in ('1','2')
-- and (codigocontable not in ('1320510130','1320520130','1330510130','1330520130','1340510199',
-- '1340520199','1310510199','1310520199','1320510199','1320520199','1330510199','1330520199',
-- '1310510102','1310520102','1320510102','1320520102','1330510102',
-- '1330520102','1340510102','1340520102'))
-- and
-- (substring(codigocontable,1,5)not in ('13115','13215','13315','13415','13106','13206','13306','13406','13108','13208','13308','13408',
-- '13102','13302','13402'))and 
-- (substring(codigocontable,1,8)not in
-- ('13130102','13130202','13230102','13230202','13330102','13330202','13430102','13430202','1310510199','1310520199'))
/*Solucion: para el mes de sep 2016 se presento esete error y se consulto con BIR y Fincon e inicaron que el tipo de credito era lo que estaba mal, 
se paso de 1 a 5.*/

/*
El valor "1" no se encuentra entre los valores de referencia de la lista de valores 'SECTOR_PRODUCCION'
 Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo
*/

-- select distinct(SectorProduccion )from jf77062.TB_DMAT04 
/* 
Valor de Referencia no Encontrado (Error Nro. 648): El valor "60901,40601,90201,32001" no se encuentra 
entre los valores de referencia de la lista de valores PARROQUIA Consulte el manual respectivo para ver 
la lista de todos los valores admitidos por este campo 
*/

-- select distinct(CodigoParroquia )from jf77062.TB_DMAT04 where len(CodigoContable )<6

 --Error  Como el valor del campo PROVISION ESPECIFICA es igual a 0 entonces deber�a cumplirse que el valor 
 --del campo CUENTA CONTABLE PROVISION ESPECIFICA sea igual a 0 
 --para atajar el error
-- select CuentaContableProvisionEspecifica,provisionespecifica, * from jf77062.TB_DMAT04
-- where CuentaContableProvisionEspecifica <> '0' 
-- and convert(decimal(18,2),provisionespecifica) = 0
--Solucion 
-- update jf77062.TB_DMAT04 set CuentaContableProvisionEspecifica = 0  
-- where CuentaContableProvisionEspecifica <> '0' 
-- and convert(decimal(18,2),provisionespecifica) = 0

---------------------------------
/*(Error Nro. 248): Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (5,8), 
y el valor del campo ESTADO DEL CREDITO es igual a 1, y el c�digo de la Entidad que esta realizando la 
transferencia es distinto de 01920 entonces deber�a cumplirse que el valor del campo USO FINANCIERO sea 
diferente a los siguientes valores: (0,99) */

-- select UsoFinanciero ,* from jf77062.tb_dmat04
-- where UsoFinanciero in ('0','99')
-- and TipoCredito in ('5','8') and
-- EstadoCredito = '1'
--tenian 0 en el insumo de micro, se le pregunto a BI
--------------------------------------------------
--Error de Fondo (Error Nro. 4): El valor del campo RELACION CREDITICIA debe ser distinto de 0 
-- select RelacionCrediticia ,* from jf77062.TB_DMAT04 where RelacionCrediticia ='0'
---------------------------------------------------
 --Error  Como el valor del campo PROVISION ESPECIFICA es igual a 0 entonces deber�a cumplirse que el valor 
 --del campo CUENTA CONTABLE PROVISION ESPECIFICA sea igual a 0 
 --para atajar el error
--Solucion 
-- update jf77062.TB_DMAT04 set CuentaContableProvisionEspecifica = 0  
-- where CuentaContableProvisionEspecifica <> '0' 
-- and convert(decimal(18,2),provisionespecifica) = 0

--------------------------------------------------
--para evitar errores de forma
-- select InteresEfectivamenteCobrado,* from jf77062.TB_DMAT04 where InteresEfectivamenteCobrado not like '%,%'
-- select PorcentajeComisionFlat,* from jf77062.TB_DMAT04 where PorcentajeComisionFlat not like '%,%'
-- select MontoComisionFlat,* from jf77062.TB_DMAT04 where MontoComisionFlat not like '%,%'
-- select PeriocidadPagoEspecialCapital,* from jf77062.TB_DMAT04 where PeriocidadPagoEspecialCapital  like '%,%' or 
-- PeriocidadPagoEspecialCapital  like '%.%'
-- select MontoInteresCuentaOrden,* from jf77062.TB_DMAT04 where MontoInteresCuentaOrden  not like '%,%' 


--------------------------------------------------------------------------------------------------------------------------------------
--(Error Nro. 500): Como el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR es igual a 0 
--entonces deber�a cumplirse que el valor del campo CUENTA CONTABLE PROVISION RENDIMIENTO sea igual a 0 (Segun manual)
--para atajar el error
--solucion (Segun manual)
-- update jf77062.TB_DMAT04 set CuentaContableProvisionRendimiento = '0'
-- where Convert(decimal(18,2),replace(ProvisionRendimientoCobrar,',','.')) = 0
-- and (CuentaContableProvisionRendimiento IS NULL OR 
-- CuentaContableProvisionRendimiento <> 0 )
--------------------------------------------------------------------------------------------------------
/*Error de Fondo (Error Nro. 3): Como el valor del campo TIPO DE CREDITO es igual a 2, y el valor del campo 
ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,2), y el valor del campo CODIGO CONTABLE 
empieza por algunos de los siguientes valores: (13), y el valor del campo CODIGO CONTABLE no empieza por 
algunos de los siguientes valores: (13106,13206,13306,13406,13108,13208,13308,13408,13130102,13130202,
13230102,13230202,13330102,13330202,13430102,13430202,13118,13218,13318,13418,13130103,13130203,13230103,
13230203,13330103,13330203,13430103,13430203,13128,13228,13328,13428), y el valor del campo CODIGO CONTABLE
 no empieza por algunos de los siguientes valores: (13122,13222,13322,13422,13232,1310510102,1310520102,
 1320510102,1320520102,1330510102,1330520102,1340510102,1340520102) entonces deber�a cumplirse que el valor 
 del campo CODIGO CONTABLE no empezara por algunos de los siguientes valores: (13130104,13130204,13230104,
 13230204,13330104,13330204,13430104,13430204,13131,13231,13331,13431,13133,13233,13333,13433)*/

---/*Error en el campo PROVISION_DEL_RENDIMIENTO_POR_COBRAR: El valor cero (0,0) no puede ser negativo */
-- SELECT *
--  FROM jf77062.TB_DMAT04
-- WHERE  PROVISIONRENDIMIENTOCOBRAR like '-0.00%'

/*Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (2,3) entonces deber�a 
cumplirse que el valor del campo MONTO VENCIDO A 120 DIAS sea igual a 0*/
-- select * from jf77062.TB_DMAT04 where TipoCliente in ('J') and genero <> 0


update jf77062.TB_DMAT04
set Genero = '0'
 where TipoCliente in ('J') and genero <> 0
 
 
 /*Como el valor del campo TIPO DE CREDITO es igual a 3, y el valor del campo ESTADO DEL CREDITO es 
 igual a 1, y el valor del campo TIPO DE BENEFICIARIO es igual a 2, y el valor del campo MODALIDAD 
 HIPOTECARIO es igual a 2 entonces deber�a cumplirse que el valor del campo CANTIDAD DE VIVIENDAS A CONSTRUIR sea mayor que 0 */
 
 
 
--  SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,CANTIDADVIVIENDASCONSTRUIR,TIPODC
-- FROM 	jf77062.TB_DMAT04 --jf77062.TB_DMAT04 
-- WHERE	TIPOCREDITO = '3'	
-- 	AND ESTADOCREDITO = '1'
-- 	AND TIPOBENEFICIARIO = '2'
-- 	and ModalidadHipoteca = '2'
-- 	and CANTIDADVIVIENDASCONSTRUIR = 0

------------------------------------------------------------------------------------------------------------------
-- select count (*) from TB_rptAT04 with(NOLOCK)
/*
(Error Nro. 1): El valor "1" no se encuentra entre los valores de referencia de la lista de valores 'MODALIDAD_HIPOTECARIA'
 Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo 
*/
-- select TipoCredito,EstadoCredito,TipoBeneficiario,	
-- ModalidadHipoteca,IngresoFamiliar,* from jf77062.TB_DMAT04 where modalidadhipoteca = '1'

/*
Error en el campo CAPITAL_TRANSFERIDO: El valor del campo no es un n�mero real v�lido. 
El formato correcto es: [SIGNO_NEGATIVO_OPCIONAL(-)]<DIGITO(S)><SEPARADOR_DECIMAL(,)><DIGITO(S)>
*/
-- select CapitalTransferido,* from jf77062.TB_DMAT04 where CapitalTransferido  not like '%,%'

/*
Error en el campo RENDIMIENTOS_POR_COBRAR_REESTRUCTURADOS: El valor del campo no es un n�mero real v�lido.
El formato correcto es: [SIGNO_NEGATIVO_OPCIONAL(-)]<DIGITO(S)><SEPARADOR_DECIMAL(,)><DIGITO(S)> 
*/
-- select CapitalTransferido,* from jf77062.TB_DMAT04 where CapitalTransferido  not like '%,%'

/*
Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (2,3) 
entonces deber�a cumplirse que el valor del campo MONTO VENCIDO A 120 DIAS sea igual a 0 
*/

-- select CapitalTransferido,* from jf77062.TB_DMAT04 where EstadoCredito in ('2','3')
-- and (CONVERT(decimal(18,2),MontoVencido120dias) <> 0 or 
-- 		CONVERT(decimal(18,2),MontoVencido180dias) <> 0 or
-- 		CONVERT(decimal(18,2),MontoVencido30dias) <> 0 or
-- 		CONVERT(decimal(18,2),MontoVencido60dias) <> 0 or
-- 		CONVERT(decimal(18,2),MontoVencido90dias) <> 0 or
-- 		CONVERT(decimal(18,2),MontoVencidoMasUnAno) <> 0 or
-- 		CONVERT(decimal(18,2),MontoVencidoUnAno) <> 0)

update 	jf77062.TB_DMAT04 
set MontoVencido120dias= '0.00',
		MontoVencido180dias = '0.00',
		MontoVencido30dias = '0.00',
		MontoVencido60dias = '0.00',
		MontoVencido90dias = '0.00',
		MontoVencidoMasUnAno = '0.00' ,
		MontoVencidoUnAno = '0.00'
where EstadoCredito in ('2','3')
and (CONVERT(decimal(18,2),MontoVencido120dias) <> 0 or 
		CONVERT(decimal(18,2),MontoVencido180dias) <> 0 or
		CONVERT(decimal(18,2),MontoVencido30dias) <> 0 or
		CONVERT(decimal(18,2),MontoVencido60dias) <> 0 or
		CONVERT(decimal(18,2),MontoVencido90dias) <> 0 or
		CONVERT(decimal(18,2),MontoVencidoMasUnAno) <> 0 or
		CONVERT(decimal(18,2),MontoVencidoUnAno) <> 0)		
	
/*
Error en el campo RENDIMIENTOS_POR_COBRAR_REESTRUCTURADOS: El valor del campo no es un n�mero real v�lido.
El formato correcto es: [SIGNO_NEGATIVO_OPCIONAL(-)]<DIGITO(S)><SEPARADOR_DECIMAL(,)><DIGITO(S)> 
*/
-- select CapitalTransferido,* from jf77062.TB_DMAT04 where 
-- 														RendimientosCobrarReestructurados  not like '%,%' or
-- 														RendimientosCobrarAfectosReporto not like '%,%' or
-- 														RendimientosCobrarLitigio not like '%,%'	
/*
hacer el query para lo de las fechas ultimafechapagadacapital qye estaban casi tidas como 1900/01/01
*/


/*Como el valor del campo SALDO es menor que el valor del campo MONTO ORIGINAL,
 y el valor del campo CODIGO DE LINEA DE CREDITO es igual a 2, y el valor del 
 campo CODIGO CONTABLE empieza por algunos de los siguientes valores: (133,134),
  y el valor del campo MODALIDAD HIPOTECARIO es distinto de 2, y el valor del
   campo TIPO DE CREDITO es distinto de 6, y el valor del campo CODIGO CONTABLE 
   no empieza por algunos de los siguientes valores: (13309,13311,13312,13409,
   13411,13412,13102,13302,13402), y el valor del campo ULTIMA FECHA DE CANCELACION 
   CUOTA CAPITAL es mayor o igual que el valor del campo FECHA DE LIQUIDACION 
   entonces deber�a cumplirse que el valor del campo ULTIMA FECHA DE CANCELACION 
   CUOTA CAPITAL sea menor o igual que la fecha final del per�odo reportado */
   
--  select Saldo,MontoOriginal, CodigoLineaCredito ,
-- ModalidadHipoteca ,TipoCredito,UltimaFechaCancelacionCuotaCapital,
-- FechaLiquidacion ,* from  jf77062.TB_DMAT04
-- where CONVERT(decimal(18,2),Saldo) < CONVERT(decimal(18,2),MontoOriginal)and
-- 		CodigoLineaCredito ='2' and 
-- 		SUBSTRING(CodigoContable,1,3) in ('133','134') and
-- 		ModalidadHipoteca not in ('2') and
-- 		TipoCredito not in ('6') and 
-- 		SUBSTRING(CodigoContable,1,5) not in ('13309','13311','13312','13409',
--    '13411','13412','13102','13302','13402') and 
--    replace(UltimaFechaCancelacionCuotaCapital,'/','') > '20170630' -----------------------------AJUSTAR A LA FECHA DEL MES A REPORTAR.														
														
														
/*Como el valor del campo TIPO DE CREDITO es igual a 4, 
y el valor del campo ESTADO DEL CREDITO es distinto de 1
 entonces deber�a cumplirse que el valor del campo TIPO
  DEL SUBSECTOR sea igual a 0 */

   
-- select numerocredito,TipoSubsector,estadocredito,tipocredito, tipodc
-- from jf77062.TB_DMAT04
-- where 	(TipoCredito = '4' and
-- 	estadocredito <> '1') and
-- 	TipoSubsector <> '0'
	
--UPDATE jf77062.TB_DMAT04
--SET TipoSubsector = '0'
--where 	(TipoCredito = '4' and
--	estadocredito <> '1') and
--	TipoSubsector <> '0'
	
--para verificar
--select TIPO_SUBSECTOR, TIPO_CREDITO,ESTADO_CREDITO , * from RPT_STG_Dirigidas_AGRICOLA_CONSUMER
--where NUM_CREDITO = '9018544101'	


/*Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores:
 (4,6), y el valor del campo ESTADO DEL CREDITO es igual a 1 entonces deber�a 
 cumplirse que el valor del campo NOMBRE PROYECTO sea distinto de VACIO 

UPDATE jf77062.TB_DMAT04
SET	NombreProyectoUnidadProduccion = agri.NOMBRE_PROYECTO
from jf77062.TB_DMAT04 dm
INNER join RPT_STG_Dirigidas_AGRICOLA_CORPORATE agri on convert(decimal,agri.num_credito) = dm.NUMEROCREDITO
where 	NombreProyectoUnidadProduccion = '' and
	tipocredito in ('4', '6') and
	estadocredito = '1'
*/

 
--  select 	numerocredito,
-- 	NombreProyectoUnidadProduccion,
-- 	tipocredito,TipoDC
-- from jf77062.TB_DMAT04
-- where 	NombreProyectoUnidadProduccion = '' and
-- 	tipocredito in ('4', '6') and
-- 	estadocredito = '1'

--Error de Fondo (Error Nro. 9): Como el valor del campo TIPO DE CREDITO es igual a 3, 
--y el valor del campo ESTADO DEL CREDITO es igual a 1, y el valor del campo TIPO DE BENEFICIARIO 
--es igual a 2, y el valor del campo MODALIDAD HIPOTECARIO es distinto de 2 
--entonces deber�a cumplirse que el valor del campo INGRESO FAMILIAR sea mayor que 0 

-- select NumeroDesembolso , CodigoLineaCredito,
-- CodigoContable,ModalidadHipoteca,TipoCredito,Saldo, MontoOriginal,* from jf77062.TB_DMAT04 
-- where (TipoCredito = 3
-- 		and EstadoCredito = 1
-- 			and TipoBeneficiario = 2
-- 			and ModalidadHipoteca <> 2)
-- 			and convert(Decimal(18,2),IngresoFamiliar) <= 0													
------------------------------------------------------------------------------------------------------------------

update jf77062.tb_dmat04 set UltimaFechaCancelacionCuotaCapital = '1900/01/01'
where tipodc in ('1', '2','3','4','5','6','9','12','14','15') 
	and UltimaFechaCancelacionCuotaCapital = '' 
	or  UltimaFechaCancelacionCuotaCapital is null 
	
update jf77062.tb_dmat04 set UltimaFechaCancelacionCuotaIntereses = '1900/01/01'
where tipodc in ('1', '2','3','4','5','6','9','12','14','15') 
	and UltimaFechaCancelacionCuotaIntereses = '' 
	or  UltimaFechaCancelacionCuotaIntereses is null 	

------------------------------------------------------------------------------------------------------------------
--Como el valor del campo TIPO DE CREDITO es igual a 3, 
--y el valor del campo MODALIDAD HIPOTECARIO es igual a 
--uno de los siguientes valores: (3,5,6,7), y el valor del campo 
--FECHA DE LIQUIDACION es menor que la fecha inicial del per�odo 
--reportado entonces deber�a cumplirse que el valor del campo 
--MONTO LIQUIDADO EN EL MES sea igual a 0 
/*Solucion como cliente nuevo tenia que tener un valor en el campo Monto Liquidado en el mes 
en este mes no debe presentar monto alli ya que no es un cliente nuevo 
el monto debe ser 0 */

	
-- select TipoCredito ,ModalidadHipoteca ,TipoDC,*from jf77062.TB_DMAT04 
-- where (TipoCredito in ('3') and
-- 		ModalidadHipoteca  in('3','5','6','7') and 
-- 		convert(varchar(10),FECHaLIQUIDACION) < '20170701') --Aqu� se coloca la fecha del mes a reportar
-- 		and convert(decimal(18,2),MontoLiquidadoMes)<> 0
		
--solucion: se busco en el insumo y estaba mal la modalidad
--select TIPO_CREDITO,MODALIDAD_HIPOTECARIA,* from RPT_STG_Dirigidas_HIPOTECARIO_LARGO_PLAZO
--where NUM_CREDITO in ('6000003717')		

--update jf77062.TB_DMAT04 
--set ModalidadHipoteca = '1'
--where NumeroCredito in ('6000003717')		

/*Como el valor del campo TIPO DE CREDITO es igual a 4, y 
el valor del campo ESTADO DEL CREDITO es igual a uno de 
los siguientes valores: (1,2) entonces deber�a cumplirse 
que el valor del campo CODIGO CONTABLE empezara por algunos
 de los siguientes valores: (13122,13222,13322,13422,13232) */
 
-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPODC
-- FROM 	jf77062.TB_DMAT04
-- WHERE	(TIPOCREDITO = '4'	
-- 	AND ESTADOCREDITO IN ('1','2') )
-- 	AND SUBSTRING(CodigoContable,1,5) not in ('13122','13222','13322','13422','13232') ----ajustar el a�o cuando corresponda

	

----------------------------------------------------------------------------------------------------------------	
/*El valor "1" no se encuentra entre los valores de referencia de la lista 
de valores 'MODALIDAD_HIPOTECARIA' Consulte el manual respectivo para ver 
la lista de todos los valores admitidos por este campo 	*/


-- SELECT 	Rubro,CodigoUso,*
-- from jf77062.TB_DMAT04 where Rubro = '0' and CodigoUso <> '0'

update jf77062.TB_DMAT04 set CodIGOUso = '0' where rubro = '0' and CodIGOUso <> '0'

----------------------------------------------------------------------------------------------------------------
/*Como el valor del campo TIPO DE CREDITO es igual a 6, y el valor del campo ESTADO DEL CREDITO es distinto 
de 1 entonces deber�a cumplirse que el valor del campo LICENCIA TURISTICA NACIONAL sea igual a VACIO */

-- SELECT 	TipoCredito,EstadoCredito,LicenciaTuristicaNacional,*
-- FROM 	jf77062.TB_DMAT04
-- where (TipoCredito = '6'
-- 		and EstadoCredito <>'1') 
-- 		and LicenciaTuristicaNacional <> '' or LicenciaTuristicaNacional <> NULL


update jf77062.TB_DMAT04 set LicenciaTuristicaNacional = '' 
where (TipoCredito = '6'
		and EstadoCredito <>'1') 
		and LicenciaTuristicaNacional <> '' or LicenciaTuristicaNacional <> NULL


----------------------------------------------------------------------------------------------------------------	
	
/*Si el valor del campo "Fecha_de_Liquidaci�n"
es menor que 20170101, entonces el valor de
este campo debe ser mayor o igual que
"19000101" y menor o igual que la fecha de
cierre del mes reoortado.*/	
-- select FechaLiquidacion,FechaNacimiento, * from 	 jf77062.TB_DMAT04 
-- where convert(numeric,replace(FechaLiquidacion,'/','')) < '20170101'
--  and (convert(numeric,replace(FechaNacimiento,'/','')) < '19000101' and
-- 	convert(numeric,replace(FechaNacimiento,'/','')) < '20170930')
/*
2. Si el valor del campo "Fecha_de_Liquidaci�n"
es mayor que 20170101, entonces el valor de
este campo debe ser distinto de 19000101 y
menor o igual que la fecha de cierre del mes
reportado.*/
-- select * from 	 jf77062.TB_DMAT04 
-- where convert(numeric,replace(FechaLiquidacion,'/','')) > '20170101'
--  and (convert(numeric,replace(FechaNacimiento,'/','')) = '19000101'	and
-- 	convert(numeric,replace(FechaNacimiento,'/','')) < '20170930')	-----ajustar mes
	
	
/*1.	Si el valor del campo �Estado_del_Cr�dito� es igual que 3, 
entonces el valor de este campo debe ser mayor o igual que �19000101� 
y menor o igual que la fecha fin del mes reportado.
*/

-- select FechaLiquidacion,FechaNacimiento,IdentificacionCliente ,* from 	 jf77062.TB_DMAT04 
-- where EstadoCredito = '3' and 
-- 		(convert(numeric,replace(FechaNacimiento,'/','')) < '19000101' or 
-- 		convert(numeric,replace(FechaNacimiento,'/','')) > '20170930')	

/*2.	Si el valor del campo �Estado_del_Cr�dito� es distinto que �3�,
 entonces el valor de este campo debe ser distinto de 19000101
  y menor o igual que la fecha  fin del mes reportado.
*/

-- select FechaLiquidacion,FechaNacimiento,IdentificacionCliente ,* from 	 jf77062.TB_DMAT04 
-- where EstadoCredito not in ('3') and 
-- 		(convert(numeric,replace(FechaNacimiento,'/','')) = '19000101' or 
-- 		convert(numeric,replace(FechaNacimiento,'/','')) > '20170930')

-- update jf77062.TB_DMAT04 
-- set FechaNacimiento = '20190830' ----ajustar fecha segun mes a reportar
-- where EstadoCredito not in ('3') and 
-- 		(convert(numeric,replace(FechaNacimiento,'/','')) = '19000101' or 
-- 		convert(numeric,replace(FechaNacimiento,'/','')) > '20190731')
	
/* Como el valor del campo ESTADO DEL CREDITO es 
distinto de 3, y el valor del campo FECHA DE NACIMIENTO 
es igual a 19000101, y el valor del campo FECHA DE NACIMIENTO
 es menor o igual que la fecha final del per�odo reportado 
 entonces deber�a cumplirse que el c�digo de la Entidad 
 que esta realizando la transferencia sea igual a uno de los siguientes */
 
--  select * from jf77062.TB_DMAT04
--  where EstadoCredito not in ('3') and 
-- 		convert(numeric,replace(FechaNacimiento,'/','')) = '19000101' 
	
	
	
	

----------------------------------------------------------------------------------------------------------------$$$
-- select count (*) from TB_rptAT04 with(NOLOCK)

--PARA GARANTIZAR QUE EL REPORTE NO CONTENGA CAMPOS NO PERMITIDOS POR EL VALIDADOR EN BLANCO O NULL

-- SELECT NumeroCredito ,* FROM jf77062.TB_DMAT04 WHERE NumeroCredito = '' 
-- SELECT FechaLiquidacion ,* FROM jf77062.TB_DMAT04 WHERE FechaLiquidacion = '' 
-- SELECT FechaSolicitud ,* FROM jf77062.TB_DMAT04 WHERE FechaSolicitud = '' 
-- SELECT FechaAprobacion ,* FROM jf77062.TB_DMAT04 WHERE FechaAprobacion = '' 
-- SELECT Oficina ,* FROM jf77062.TB_DMAT04 WHERE Oficina = '' 
-- SELECT CodigoContable ,* FROM jf77062.TB_DMAT04 WHERE CodigoContable = '' 
-- SELECT NumeroCreditoPrimerDesembolso ,* FROM jf77062.TB_DMAT04 WHERE NumeroCreditoPrimerDesembolso = '' 
-- SELECT NumeroDesembolso ,* FROM jf77062.TB_DMAT04 WHERE NumeroDesembolso = '' 
-- SELECT CodigoLineaCredito ,* FROM jf77062.TB_DMAT04 WHERE CodigoLineaCredito = '' 
-- SELECT MontoLineaCredito ,* FROM jf77062.TB_DMAT04 WHERE MontoLineaCredito = '' 
-- SELECT EstadoCredito ,* FROM jf77062.TB_DMAT04 WHERE EstadoCredito = '' 
-- SELECT TipoCredito ,* FROM jf77062.TB_DMAT04 WHERE TipoCredito = '' 
-- SELECT SituacionCredito ,* FROM jf77062.TB_DMAT04 WHERE SituacionCredito = '' 
-- SELECT PlazoCredito ,* FROM jf77062.TB_DMAT04 WHERE PlazoCredito = '' 
-- SELECT ClasificacionRiesgo ,* FROM jf77062.TB_DMAT04 WHERE ClasificacionRiesgo = '' 
-- SELECT DestinoCredito ,* FROM jf77062.TB_DMAT04 WHERE DestinoCredito = '' 
-- SELECT NaturalezaCliente ,* FROM jf77062.TB_DMAT04 WHERE NaturalezaCliente = '' 
-- SELECT TipoCliente ,* FROM jf77062.TB_DMAT04 WHERE TipoCliente = '' 
-- SELECT IdentificacionCliente ,* FROM jf77062.TB_DMAT04 WHERE IdentificacionCliente = '' 
-- SELECT Nombre_RazonSocial ,* FROM jf77062.TB_DMAT04 WHERE Nombre_RazonSocial = '' 
-- SELECT Genero ,* FROM jf77062.TB_DMAT04 WHERE Genero = '' 
-- SELECT TipoClienteRIF ,* FROM jf77062.TB_DMAT04 WHERE TipoClienteRIF = '' 
-- SELECT IdentificacionTipoClienteRIF ,* FROM jf77062.TB_DMAT04 WHERE IdentificacionTipoClienteRIF = '' 
-- SELECT ActividadCliente ,* FROM jf77062.TB_DMAT04 WHERE ActividadCliente = '' 
-- SELECT PaisNacionalidad ,* FROM jf77062.TB_DMAT04 WHERE PaisNacionalidad = '' 
-- SELECT DomicilioFiscal ,* FROM jf77062.TB_DMAT04 WHERE DomicilioFiscal = '' 
-- SELECT ClienteNuevo ,* FROM jf77062.TB_DMAT04 WHERE ClienteNuevo = '' 
-- SELECT Cooperativa ,* FROM jf77062.TB_DMAT04 WHERE Cooperativa = '' 
-- SELECT Sindicado ,* FROM jf77062.TB_DMAT04 WHERE Sindicado = '' 
-- SELECT BancoLiderSindicato ,* FROM jf77062.TB_DMAT04 WHERE BancoLiderSindicato = '' 
-- SELECT RelacionCrediticia ,* FROM jf77062.TB_DMAT04 WHERE RelacionCrediticia = '' 
-- SELECT GrupoEconomicoFinanciero ,* FROM jf77062.TB_DMAT04 WHERE GrupoEconomicoFinanciero = '' 
-- SELECT NombreGrupoEconomicoFinanciero ,* FROM jf77062.TB_DMAT04 WHERE NombreGrupoEconomicoFinanciero = '' and GrupoEconomicoFinanciero = '2'
-- --si no es GrupoEconomicoFinanciero = '2' puede estar en blanco
-- SELECT CodigoParroquia ,* FROM jf77062.TB_DMAT04 WHERE CodigoParroquia = '' 
-- SELECT PeriodoGraciaCapital ,* FROM jf77062.TB_DMAT04 WHERE PeriodoGraciaCapital = '' 
-- SELECT PeriodicidadPagoCapital ,* FROM jf77062.TB_DMAT04 WHERE PeriodicidadPagoCapital = '' 
-- SELECT PeriodicidadPagoInteresCredito ,* FROM jf77062.TB_DMAT04 WHERE PeriodicidadPagoInteresCredito = '' 
-- SELECT FechaVencimientoOriginal ,* FROM jf77062.TB_DMAT04 WHERE FechaVencimientoOriginal = '' 
-- SELECT FechaVencimientoActual ,* FROM jf77062.TB_DMAT04 WHERE FechaVencimientoActual = '' 
-- SELECT FechaReestructuracion ,* FROM jf77062.TB_DMAT04 WHERE FechaReestructuracion = '' 
-- SELECT CantidadProrroga ,* FROM jf77062.TB_DMAT04 WHERE CantidadProrroga = '' 
-- SELECT FechaProrroga ,* FROM jf77062.TB_DMAT04 WHERE FechaProrroga = '' 
-- SELECT CantidadRenovaciones ,* FROM jf77062.TB_DMAT04 WHERE CantidadRenovaciones = '' 
-- SELECT FechaUltimaRenovacion ,* FROM jf77062.TB_DMAT04 WHERE FechaUltimaRenovacion = '' 
-- SELECT FechaCancelacionTotal ,* FROM jf77062.TB_DMAT04 WHERE FechaCancelacionTotal = '' 
-- SELECT FechaVencimientoUltimaCoutaCapital ,* FROM jf77062.TB_DMAT04 WHERE FechaVencimientoUltimaCoutaCapital = '' 
-- SELECT UltimaFechaCancelacionCuotaCapital ,* FROM jf77062.TB_DMAT04 WHERE UltimaFechaCancelacionCuotaCapital = '' 
-- SELECT FechaVencimientoUltimaCuotaInteres ,* FROM jf77062.TB_DMAT04 WHERE FechaVencimientoUltimaCuotaInteres = '' 
-- SELECT UltimaFechaCancelacionCuotaIntereses ,* FROM jf77062.TB_DMAT04 WHERE UltimaFechaCancelacionCuotaIntereses = '' 
-- SELECT Moneda ,* FROM jf77062.TB_DMAT04 WHERE Moneda = '' 
-- SELECT TipoCambioOriginal ,* FROM jf77062.TB_DMAT04 WHERE TipoCambioOriginal = '' 
-- SELECT TipoCambioCierreMes ,* FROM jf77062.TB_DMAT04 WHERE TipoCambioCierreMes = '' 
-- SELECT MontoOriginal ,* FROM jf77062.TB_DMAT04 WHERE MontoOriginal = '' 
-- SELECT MontoInicial ,* FROM jf77062.TB_DMAT04 WHERE MontoInicial = '' 
-- SELECT MontoLiquidadoMes ,* FROM jf77062.TB_DMAT04 WHERE MontoLiquidadoMes = '' 
-- SELECT EntePublico ,* FROM jf77062.TB_DMAT04 WHERE EntePublico = '' 
-- SELECT MontoInicialTerceros ,* FROM jf77062.TB_DMAT04 WHERE MontoInicialTerceros = '' 
-- SELECT Saldo ,* FROM jf77062.TB_DMAT04 WHERE Saldo = '' 
-- SELECT RendimientosCobrar ,* FROM jf77062.TB_DMAT04 WHERE RendimientosCobrar = '' 
-- SELECT RendimientosCobrarVencidos ,* FROM jf77062.TB_DMAT04 WHERE RendimientosCobrarVencidos = '' 
-- SELECT RendimientosCobrarMora ,* FROM jf77062.TB_DMAT04 WHERE RendimientosCobrarMora = '' 
-- SELECT ProvisionEspecifica ,* FROM jf77062.TB_DMAT04 WHERE ProvisionEspecifica = '' 
-- SELECT PocentajeProvisionEspecifica ,* FROM jf77062.TB_DMAT04 WHERE PocentajeProvisionEspecifica = '' 
-- SELECT ProvisionRendimientoCobrar ,* FROM jf77062.TB_DMAT04 WHERE ProvisionRendimientoCobrar = '' 
-- SELECT TasasInteresCobrada ,* FROM jf77062.TB_DMAT04 WHERE TasasInteresCobrada = '' 
-- SELECT TasasInteresActual ,* FROM jf77062.TB_DMAT04 WHERE TasasInteresActual = '' 
-- SELECT IndicadorTasaPreferencial ,* FROM jf77062.TB_DMAT04 WHERE IndicadorTasaPreferencial = '' 
-- SELECT TasaComision ,* FROM jf77062.TB_DMAT04 WHERE TasaComision = '' 
-- SELECT ComisionesCobrar ,* FROM jf77062.TB_DMAT04 WHERE ComisionesCobrar = '' 
-- SELECT ComisionesCobradas ,* FROM jf77062.TB_DMAT04 WHERE ComisionesCobradas = '' 
-- SELECT ErogacionesRecuperables ,* FROM jf77062.TB_DMAT04 WHERE ErogacionesRecuperables = '' 
-- SELECT TipoGarantiaPrincipal ,* FROM jf77062.TB_DMAT04 WHERE TipoGarantiaPrincipal = '' 
-- SELECT NumeroCuotas ,* FROM jf77062.TB_DMAT04 WHERE NumeroCuotas = '' 
-- SELECT NumeroCuotasVencidas ,* FROM jf77062.TB_DMAT04 WHERE NumeroCuotasVencidas = '' 
-- SELECT MontoVencido30dias ,* FROM jf77062.TB_DMAT04 WHERE MontoVencido30dias = '' 
-- SELECT MontoVencido60dias ,* FROM jf77062.TB_DMAT04 WHERE MontoVencido60dias = '' 
-- SELECT MontoVencido90dias ,* FROM jf77062.TB_DMAT04 WHERE MontoVencido90dias = '' 
-- SELECT MontoVencido120dias ,* FROM jf77062.TB_DMAT04 WHERE MontoVencido120dias = '' 
-- SELECT MontoVencido180dias ,* FROM jf77062.TB_DMAT04 WHERE MontoVencido180dias = '' 
-- SELECT MontoVencidoUnAno ,* FROM jf77062.TB_DMAT04 WHERE MontoVencidoUnAno = '' 
-- SELECT MontoVencidoMasUnAno ,* FROM jf77062.TB_DMAT04 WHERE MontoVencidoMasUnAno = '' 
-- SELECT MontoVencer30dias ,* FROM jf77062.TB_DMAT04 WHERE MontoVencer30dias = '' 
-- SELECT MontoVencer60dias ,* FROM jf77062.TB_DMAT04 WHERE MontoVencer60dias = '' 
-- SELECT MontoVencer90dias ,* FROM jf77062.TB_DMAT04 WHERE MontoVencer90dias = '' 
-- SELECT MontoVencer120dias ,* FROM jf77062.TB_DMAT04 WHERE MontoVencer120dias = '' 
-- SELECT MontoVencer180dias ,* FROM jf77062.TB_DMAT04 WHERE MontoVencer180dias = '' 
-- SELECT MontoVencerUnAno ,* FROM jf77062.TB_DMAT04 WHERE MontoVencerUnAno = '' 
-- SELECT MontoVencerMasUnAno ,* FROM jf77062.TB_DMAT04 WHERE MontoVencerMasUnAno = '' 
-- SELECT BancaSocial ,* FROM jf77062.TB_DMAT04 WHERE BancaSocial = '' 
-- SELECT UnidadProduccionSocial ,* FROM jf77062.TB_DMAT04 WHERE UnidadProduccionSocial = '' 
-- SELECT ModalidadMicrocredito ,* FROM jf77062.TB_DMAT04 WHERE ModalidadMicrocredito = '' 
-- SELECT UsoFinanciero ,* FROM jf77062.TB_DMAT04 WHERE UsoFinanciero = '' 
-- SELECT DestinoRecursosMicrofinancieros ,* FROM jf77062.TB_DMAT04 WHERE DestinoRecursosMicrofinancieros = '' 
-- SELECT CantidadTrabajadores ,* FROM jf77062.TB_DMAT04 WHERE CantidadTrabajadores = '' 
-- SELECT VentaAnuales ,* FROM jf77062.TB_DMAT04 WHERE VentaAnuales = '' 
-- SELECT FechaEstadoFinanciero ,* FROM jf77062.TB_DMAT04 WHERE FechaEstadoFinanciero = '' 
-- SELECT NumeroRTN ,* FROM jf77062.TB_DMAT04 WHERE NumeroRTN = '' ---COLOCAR EN NULL
-- --UPDATE jf77062.TB_DMAT04 SET NUMERORTN = NULL WHERE NUMERORTN = '' 
-- SELECT LicenciaTuristicaNacional ,* FROM jf77062.TB_DMAT04 WHERE LicenciaTuristicaNacional = '' ---COLOCAR EN NULL
-- --UPDATE jf77062.TB_DMAT04 SET LicenciaTuristicaNacional = NULL WHERE LicenciaTuristicaNacional = '' 
-- SELECT FechaEmisionFactibilidadSociotecnica_ConformidadTuristica ,* FROM jf77062.TB_DMAT04 WHERE FechaEmisionFactibilidadSociotecnica_ConformidadTuristica = '' 
-- SELECT NumeroExpedienteFactibilidadSociotecnica ,* FROM jf77062.TB_DMAT04 WHERE NumeroExpedienteFactibilidadSociotecnica = '' 
-- SELECT NumeroExpedienteConformidadTuristica ,* FROM jf77062.TB_DMAT04 WHERE NumeroExpedienteConformidadTuristica = '' 
-- SELECT NombreProyectoUnidadProduccion ,* FROM jf77062.TB_DMAT04 WHERE NombreProyectoUnidadProduccion = '' ---COLOCAR EN NULL
-- --UPDATE jf77062.TB_DMAT04 SET NombreProyectoUnidadProduccion = NULL WHERE NombreProyectoUnidadProduccion = '' 
-- SELECT DireccionProyectoUnidadProduccion ,* FROM jf77062.TB_DMAT04 WHERE DireccionProyectoUnidadProduccion = ''  ---COLOCAR EN NULL
-- --UPDATE jf77062.TB_DMAT04 SET DireccionProyectoUnidadProduccion = NULL WHERE DireccionProyectoUnidadProduccion = '' 
-- SELECT CodigoTipoProyecto ,* FROM jf77062.TB_DMAT04 WHERE CodigoTipoProyecto = '' 
-- SELECT CodigoTipoOperacionesFinanciamiento ,* FROM jf77062.TB_DMAT04 WHERE CodigoTipoOperacionesFinanciamiento = '' 
-- SELECT CodigoSegmento ,* FROM jf77062.TB_DMAT04 WHERE CodigoSegmento = '' 
-- SELECT TipoZona ,* FROM jf77062.TB_DMAT04 WHERE TipoZona = '' 
-- SELECT FechaAutenticacionProtocolizacion ,* FROM jf77062.TB_DMAT04 WHERE FechaAutenticacionProtocolizacion = '' 
-- SELECT FechaUltimaInspeccion ,* FROM jf77062.TB_DMAT04 WHERE FechaUltimaInspeccion = '' 
-- SELECT PorcentajeEjecucionProyecto ,* FROM jf77062.TB_DMAT04 WHERE PorcentajeEjecucionProyecto = '' 
-- SELECT PagosEfectuadosDuranteMes ,* FROM jf77062.TB_DMAT04 WHERE PagosEfectuadosDuranteMes = '' 
-- SELECT MontosLiquidadosFechaCierre ,* FROM jf77062.TB_DMAT04 WHERE MontosLiquidadosFechaCierre = '' 
-- SELECT AmortizacionesCapitalAcumuladasFecha ,* FROM jf77062.TB_DMAT04 WHERE AmortizacionesCapitalAcumuladasFecha = '' 
-- SELECT TasaIncentivo ,* FROM jf77062.TB_DMAT04 WHERE TasaIncentivo = '' 
-- SELECT NumeroOficioIncentivo ,* FROM jf77062.TB_DMAT04 WHERE NumeroOficioIncentivo = '' -----COLOCAR EN NULL
-- --UPDATE jf77062.TB_DMAT04 SET NumeroOficioIncentivo = NULL WHERE NumeroOficioIncentivo = '' 
-- SELECT NumeroRegistro_ConstanciaMPPAT ,* FROM jf77062.TB_DMAT04 WHERE NumeroRegistro_ConstanciaMPPAT = '' 
-- SELECT TipoRegistro_ConstanciaMPPAT ,* FROM jf77062.TB_DMAT04 WHERE TipoRegistro_ConstanciaMPPAT = '' --PUEDE ESTAR EN BLANCO
-- SELECT FechaVencimientoRegistro_ConstanciaMPPAT ,* FROM jf77062.TB_DMAT04 WHERE FechaVencimientoRegistro_ConstanciaMPPAT = '' 
-- SELECT TipoSubsector ,* FROM jf77062.TB_DMAT04 WHERE TipoSubsector = '' 
-- SELECT Rubro ,* FROM jf77062.TB_DMAT04 WHERE Rubro = '' 
-- SELECT CodigoUso ,* FROM jf77062.TB_DMAT04 WHERE CodigoUso = '' 
-- SELECT CantidadUnidades ,* FROM jf77062.TB_DMAT04 WHERE CantidadUnidades = '' 
-- SELECT CodigoUnidadMedida ,* FROM jf77062.TB_DMAT04 WHERE CodigoUnidadMedida = '' 
-- SELECT SectorProduccion ,* FROM jf77062.TB_DMAT04 WHERE SectorProduccion = '' 
-- SELECT CantidadHectareas ,* FROM jf77062.TB_DMAT04 WHERE CantidadHectareas = '' 
-- SELECT SuperficieTotalPropiedad ,* FROM jf77062.TB_DMAT04 WHERE SuperficieTotalPropiedad = '' 
-- SELECT NumeroProductoresBeneficiarios ,* FROM jf77062.TB_DMAT04 WHERE NumeroProductoresBeneficiarios = '' 
-- SELECT Prioritario ,* FROM jf77062.TB_DMAT04 WHERE Prioritario = '' 
-- SELECT DestinoManufacturero ,* FROM jf77062.TB_DMAT04 WHERE DestinoManufacturero = '' 
-- SELECT DestinoEconomico ,* FROM jf77062.TB_DMAT04 WHERE DestinoEconomico = '' 
-- SELECT TipoBeneficiario ,* FROM jf77062.TB_DMAT04 WHERE TipoBeneficiario = '' 
-- SELECT ModalidadHipoteca ,* FROM jf77062.TB_DMAT04 WHERE ModalidadHipoteca = '' 
-- SELECT IngresoFamiliar ,* FROM jf77062.TB_DMAT04 WHERE IngresoFamiliar = '' 
-- SELECT MontoLiquidadoDuranteAnoCurso ,* FROM jf77062.TB_DMAT04 WHERE MontoLiquidadoDuranteAnoCurso = '' 
-- SELECT SaldoCredito31_12 ,* FROM jf77062.TB_DMAT04 WHERE SaldoCredito31_12 = '' 
-- SELECT CantidadViviendasConstruir ,* FROM jf77062.TB_DMAT04 WHERE CantidadViviendasConstruir = '' 
-- SELECT RendimientosCobrarReestructurados ,* FROM jf77062.TB_DMAT04 WHERE RendimientosCobrarReestructurados = '' 
-- SELECT RendimientosCobrarAfectosReporto ,* FROM jf77062.TB_DMAT04 WHERE RendimientosCobrarAfectosReporto = '' 
-- SELECT RendimientosCobrarLitigio ,* FROM jf77062.TB_DMAT04 WHERE RendimientosCobrarLitigio = '' 
-- SELECT InteresEfectivamenteCobrado ,* FROM jf77062.TB_DMAT04 WHERE InteresEfectivamenteCobrado = '' 
-- SELECT PorcentajeComisionFlat ,* FROM jf77062.TB_DMAT04 WHERE PorcentajeComisionFlat = '' 
-- SELECT MontoComisionFlat ,* FROM jf77062.TB_DMAT04 WHERE MontoComisionFlat = '' 
-- SELECT PeriocidadPagoEspecialCapital ,* FROM jf77062.TB_DMAT04 WHERE PeriocidadPagoEspecialCapital = '' 
-- SELECT FechaCambioEstatusCredito ,* FROM jf77062.TB_DMAT04 WHERE FechaCambioEstatusCredito = '' 
-- SELECT FechaRegistroVencidaLitigiooCastigada ,* FROM jf77062.TB_DMAT04 WHERE FechaRegistroVencidaLitigiooCastigada = '' 
-- SELECT FechaExigibilidadPagoUltimaCuotaPagada ,* FROM jf77062.TB_DMAT04 WHERE FechaExigibilidadPagoUltimaCuotaPagada = '' 
-- SELECT CuentaContableProvisionEspecifica ,* FROM jf77062.TB_DMAT04 WHERE CuentaContableProvisionEspecifica = '' 
-- SELECT CuentaContableProvisionRendimiento ,* FROM jf77062.TB_DMAT04 WHERE CuentaContableProvisionRendimiento = '' 
-- SELECT CuentaContableInteresCuentaOrden ,* FROM jf77062.TB_DMAT04 WHERE CuentaContableInteresCuentaOrden = '' 
-- SELECT MontoInteresCuentaOrden ,* FROM jf77062.TB_DMAT04 WHERE MontoInteresCuentaOrden = '' 
-- SELECT TipoIndustria ,* FROM jf77062.TB_DMAT04 WHERE TipoIndustria = '' 
-- SELECT TipoBeneficiarioSectorManufacturero ,* FROM jf77062.TB_DMAT04 WHERE TipoBeneficiarioSectorManufacturero = '' 
-- SELECT TipoBeneficiarioSectorTurismo ,* FROM jf77062.TB_DMAT04 WHERE TipoBeneficiarioSectorTurismo = '' 
-- SELECT BeneficiarioEspecial ,* FROM jf77062.TB_DMAT04 WHERE BeneficiarioEspecial = '' 
-- SELECT FechaEmisionCertificacionBeneficiarioEspecial ,* FROM jf77062.TB_DMAT04 WHERE FechaEmisionCertificacionBeneficiarioEspecial = '' 
-- SELECT TipoVivienda ,* FROM jf77062.TB_DMAT04 WHERE TipoVivienda = '' 
-- SELECT FechaFinPeriodoGraciaPagoInteres ,* FROM jf77062.TB_DMAT04 WHERE FechaFinPeriodoGraciaPagoInteres = '' 
-- SELECT CapitalTransferido ,* FROM jf77062.TB_DMAT04 WHERE CapitalTransferido = '' 
-- SELECT FechaCambioEstatusCapitalTransferido ,* FROM jf77062.TB_DMAT04 WHERE FechaCambioEstatusCapitalTransferido = '' 
-- SELECT Fechanacimiento, * FROM jf77062.TB_DMAT04 WHERE Fechanacimiento  = '' 
-- --**********************************---------*********************************------------**************************


-- SELECT NumeroCredito, * FROM jf77062.TB_DMAT04 WHERE NumeroCredito IS NULL
-- SELECT FechaLiquidacion, * FROM jf77062.TB_DMAT04 WHERE FechaLiquidacion IS NULL
-- SELECT FechaSolicitud, * FROM jf77062.TB_DMAT04 WHERE FechaSolicitud IS NULL
-- SELECT FechaAprobacion, * FROM jf77062.TB_DMAT04 WHERE FechaAprobacion IS NULL
-- SELECT Oficina, * FROM jf77062.TB_DMAT04 WHERE Oficina IS NULL
-- SELECT CodigoContable, * FROM jf77062.TB_DMAT04 WHERE CodigoContable IS NULL
-- SELECT NumeroCreditoPrimerDesembolso, * FROM jf77062.TB_DMAT04 WHERE NumeroCreditoPrimerDesembolso IS NULL
-- SELECT NumeroDesembolso, * FROM jf77062.TB_DMAT04 WHERE NumeroDesembolso IS NULL
-- SELECT CodigoLineaCredito, * FROM jf77062.TB_DMAT04 WHERE CodigoLineaCredito IS NULL
-- SELECT MontoLineaCredito, * FROM jf77062.TB_DMAT04 WHERE MontoLineaCredito IS NULL
-- SELECT EstadoCredito, * FROM jf77062.TB_DMAT04 WHERE EstadoCredito IS NULL
-- SELECT TipoCredito, * FROM jf77062.TB_DMAT04 WHERE TipoCredito IS NULL
-- SELECT SituacionCredito, * FROM jf77062.TB_DMAT04 WHERE SituacionCredito IS NULL
-- SELECT PlazoCredito, * FROM jf77062.TB_DMAT04 WHERE PlazoCredito IS NULL
-- SELECT ClasificacionRiesgo, * FROM jf77062.TB_DMAT04 WHERE ClasificacionRiesgo IS NULL
-- SELECT DestinoCredito, * FROM jf77062.TB_DMAT04 WHERE DestinoCredito IS NULL
-- SELECT NaturalezaCliente, * FROM jf77062.TB_DMAT04 WHERE NaturalezaCliente IS NULL
-- SELECT TipoCliente, * FROM jf77062.TB_DMAT04 WHERE TipoCliente IS NULL
-- SELECT IdentificacionCliente, * FROM jf77062.TB_DMAT04 WHERE IdentificacionCliente IS NULL
-- SELECT Nombre_RazonSocial, * FROM jf77062.TB_DMAT04 WHERE Nombre_RazonSocial IS NULL
-- SELECT Genero, * FROM jf77062.TB_DMAT04 WHERE Genero IS NULL
-- SELECT TipoClienteRIF, * FROM jf77062.TB_DMAT04 WHERE TipoClienteRIF IS NULL
-- SELECT IdentificacionTipoClienteRIF, * FROM jf77062.TB_DMAT04 WHERE IdentificacionTipoClienteRIF IS NULL
-- SELECT ActividadCliente, * FROM jf77062.TB_DMAT04 WHERE ActividadCliente IS NULL
-- SELECT PaisNacionalidad, * FROM jf77062.TB_DMAT04 WHERE PaisNacionalidad IS NULL
-- SELECT DomicilioFiscal, * FROM jf77062.TB_DMAT04 WHERE DomicilioFiscal IS NULL
-- SELECT ClienteNuevo, * FROM jf77062.TB_DMAT04 WHERE ClienteNuevo IS NULL
-- SELECT Cooperativa, * FROM jf77062.TB_DMAT04 WHERE Cooperativa IS NULL
-- SELECT Sindicado, * FROM jf77062.TB_DMAT04 WHERE Sindicado IS NULL
-- SELECT BancoLiderSindicato, * FROM jf77062.TB_DMAT04 WHERE BancoLiderSindicato IS NULL
-- SELECT RelacionCrediticia, * FROM jf77062.TB_DMAT04 WHERE RelacionCrediticia IS NULL
-- SELECT GrupoEconomicoFinanciero, * FROM jf77062.TB_DMAT04 WHERE GrupoEconomicoFinanciero IS NULL
-- SELECT NombreGrupoEconomicoFinanciero, * FROM jf77062.TB_DMAT04 WHERE NombreGrupoEconomicoFinanciero IS NULL  
-- --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** --si no es GrupoEconomicoFinanciero = '2' puede estar en blanco
-- SELECT CodigoParroquia, * FROM jf77062.TB_DMAT04 WHERE CodigoParroquia IS NULL
-- SELECT PeriodoGraciaCapital, * FROM jf77062.TB_DMAT04 WHERE PeriodoGraciaCapital IS NULL
-- SELECT PeriodicidadPagoCapital, * FROM jf77062.TB_DMAT04 WHERE PeriodicidadPagoCapital IS NULL
-- SELECT PeriodicidadPagoInteresCredito, * FROM jf77062.TB_DMAT04 WHERE PeriodicidadPagoInteresCredito IS NULL
-- SELECT FechaVencimientoOriginal, * FROM jf77062.TB_DMAT04 WHERE FechaVencimientoOriginal IS NULL
-- SELECT FechaVencimientoActual, * FROM jf77062.TB_DMAT04 WHERE FechaVencimientoActual IS NULL
-- SELECT FechaReestructuracion, * FROM jf77062.TB_DMAT04 WHERE FechaReestructuracion IS NULL
-- SELECT CantidadProrroga, * FROM jf77062.TB_DMAT04 WHERE CantidadProrroga IS NULL
-- SELECT FechaProrroga, * FROM jf77062.TB_DMAT04 WHERE FechaProrroga IS NULL
-- SELECT CantidadRenovaciones, * FROM jf77062.TB_DMAT04 WHERE CantidadRenovaciones IS NULL
-- SELECT FechaUltimaRenovacion, * FROM jf77062.TB_DMAT04 WHERE FechaUltimaRenovacion IS NULL
-- SELECT FechaCancelacionTotal, * FROM jf77062.TB_DMAT04 WHERE FechaCancelacionTotal IS NULL
-- SELECT FechaVencimientoUltimaCoutaCapital, * FROM jf77062.TB_DMAT04 WHERE FechaVencimientoUltimaCoutaCapital IS NULL
-- SELECT UltimaFechaCancelacionCuotaCapital, * FROM jf77062.TB_DMAT04 WHERE UltimaFechaCancelacionCuotaCapital IS NULL
-- SELECT FechaVencimientoUltimaCuotaInteres, * FROM jf77062.TB_DMAT04 WHERE FechaVencimientoUltimaCuotaInteres IS NULL
-- SELECT UltimaFechaCancelacionCuotaIntereses, * FROM jf77062.TB_DMAT04 WHERE UltimaFechaCancelacionCuotaIntereses IS NULL
-- SELECT Moneda, * FROM jf77062.TB_DMAT04 WHERE Moneda IS NULL
-- SELECT TipoCambioOriginal, * FROM jf77062.TB_DMAT04 WHERE TipoCambioOriginal IS NULL
-- SELECT TipoCambioCierreMes, * FROM jf77062.TB_DMAT04 WHERE TipoCambioCierreMes IS NULL
-- SELECT MontoOriginal, * FROM jf77062.TB_DMAT04 WHERE MontoOriginal IS NULL
-- SELECT MontoInicial, * FROM jf77062.TB_DMAT04 WHERE MontoInicial IS NULL
-- SELECT MontoLiquidadoMes, * FROM jf77062.TB_DMAT04 WHERE MontoLiquidadoMes IS NULL
-- SELECT EntePublico, * FROM jf77062.TB_DMAT04 WHERE EntePublico IS NULL
-- SELECT MontoInicialTerceros, * FROM jf77062.TB_DMAT04 WHERE MontoInicialTerceros IS NULL
-- SELECT Saldo, * FROM jf77062.TB_DMAT04 WHERE Saldo IS NULL
-- SELECT RendimientosCobrar, * FROM jf77062.TB_DMAT04 WHERE RendimientosCobrar IS NULL
-- SELECT RendimientosCobrarVencidos, * FROM jf77062.TB_DMAT04 WHERE RendimientosCobrarVencidos IS NULL
-- SELECT RendimientosCobrarMora, * FROM jf77062.TB_DMAT04 WHERE RendimientosCobrarMora IS NULL
-- SELECT ProvisionEspecifica,PocentajeProvisionEspecifica, * FROM jf77062.TB_DMAT04 WHERE ProvisionEspecifica IS NULL

-- UPDATE jf77062.TB_DMAT04
-- SET ProvisionEspecifica = 0 
-- WHERE ProvisionEspecifica IS NULL


-- SELECT PocentajeProvisionEspecifica, * FROM jf77062.TB_DMAT04 WHERE PocentajeProvisionEspecifica IS NULL
-- SELECT ProvisionRendimientoCobrar, * FROM jf77062.TB_DMAT04 WHERE ProvisionRendimientoCobrar IS NULL
-- SELECT TasasInteresCobrada, * FROM jf77062.TB_DMAT04 WHERE TasasInteresCobrada IS NULL
-- SELECT TasasInteresActual, * FROM jf77062.TB_DMAT04 WHERE TasasInteresActual IS NULL
-- SELECT IndicadorTasaPreferencial, * FROM jf77062.TB_DMAT04 WHERE IndicadorTasaPreferencial IS NULL
-- SELECT TasaComision, * FROM jf77062.TB_DMAT04 WHERE TasaComision IS NULL
-- SELECT ComisionesCobrar, * FROM jf77062.TB_DMAT04 WHERE ComisionesCobrar IS NULL
-- SELECT ComisionesCobradas, * FROM jf77062.TB_DMAT04 WHERE ComisionesCobradas IS NULL
-- SELECT ErogacionesRecuperables, * FROM jf77062.TB_DMAT04 WHERE ErogacionesRecuperables IS NULL
-- SELECT TipoGarantiaPrincipal, * FROM jf77062.TB_DMAT04 WHERE TipoGarantiaPrincipal IS NULL
-- SELECT NumeroCuotas, * FROM jf77062.TB_DMAT04 WHERE NumeroCuotas IS NULL
-- SELECT NumeroCuotasVencidas, * FROM jf77062.TB_DMAT04 WHERE NumeroCuotasVencidas IS NULL
-- SELECT MontoVencido30dias, * FROM jf77062.TB_DMAT04 WHERE MontoVencido30dias IS NULL
-- SELECT MontoVencido60dias, * FROM jf77062.TB_DMAT04 WHERE MontoVencido60dias IS NULL
-- SELECT MontoVencido90dias, * FROM jf77062.TB_DMAT04 WHERE MontoVencido90dias IS NULL
-- SELECT MontoVencido120dias, * FROM jf77062.TB_DMAT04 WHERE MontoVencido120dias IS NULL
-- SELECT MontoVencido180dias, * FROM jf77062.TB_DMAT04 WHERE MontoVencido180dias IS NULL
-- SELECT MontoVencidoUnAno, * FROM jf77062.TB_DMAT04 WHERE MontoVencidoUnAno IS NULL
-- SELECT MontoVencidoMasUnAno, * FROM jf77062.TB_DMAT04 WHERE MontoVencidoMasUnAno IS NULL
-- SELECT MontoVencer30dias, * FROM jf77062.TB_DMAT04 WHERE MontoVencer30dias IS NULL
-- SELECT MontoVencer60dias, * FROM jf77062.TB_DMAT04 WHERE MontoVencer60dias IS NULL
-- SELECT MontoVencer90dias, * FROM jf77062.TB_DMAT04 WHERE MontoVencer90dias IS NULL
-- SELECT MontoVencer120dias, * FROM jf77062.TB_DMAT04 WHERE MontoVencer120dias IS NULL
-- SELECT MontoVencer180dias, * FROM jf77062.TB_DMAT04 WHERE MontoVencer180dias IS NULL
-- SELECT MontoVencerUnAno, * FROM jf77062.TB_DMAT04 WHERE MontoVencerUnAno IS NULL
-- SELECT MontoVencerMasUnAno, * FROM jf77062.TB_DMAT04 WHERE MontoVencerMasUnAno IS NULL
-- SELECT BancaSocial, * FROM jf77062.TB_DMAT04 WHERE BancaSocial IS NULL
-- SELECT UnidadProduccionSocial, * FROM jf77062.TB_DMAT04 WHERE UnidadProduccionSocial IS NULL
-- SELECT ModalidadMicrocredito, * FROM jf77062.TB_DMAT04 WHERE ModalidadMicrocredito IS NULL
-- SELECT UsoFinanciero, * FROM jf77062.TB_DMAT04 WHERE UsoFinanciero IS NULL
-- SELECT DestinoRecursosMicrofinancieros, * FROM jf77062.TB_DMAT04 WHERE DestinoRecursosMicrofinancieros IS NULL
-- SELECT CantidadTrabajadores, * FROM jf77062.TB_DMAT04 WHERE CantidadTrabajadores IS NULL
-- SELECT VentaAnuales, * FROM jf77062.TB_DMAT04 WHERE VentaAnuales IS NULL
-- SELECT FechaEstadoFinanciero, * FROM jf77062.TB_DMAT04 WHERE FechaEstadoFinanciero IS NULL
--  --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- ----PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- SELECT FechaEmisionFactibilidadSociotecnica_ConformidadTuristica, * FROM jf77062.TB_DMAT04 WHERE FechaEmisionFactibilidadSociotecnica_ConformidadTuristica IS NULL
-- SELECT NumeroExpedienteFactibilidadSociotecnica, * FROM jf77062.TB_DMAT04 WHERE NumeroExpedienteFactibilidadSociotecnica IS NULL
-- SELECT NumeroExpedienteConformidadTuristica, * FROM jf77062.TB_DMAT04 WHERE NumeroExpedienteConformidadTuristica IS NULL
-- --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
--  --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- SELECT CodigoTipoProyecto, * FROM jf77062.TB_DMAT04 WHERE CodigoTipoProyecto IS NULL
-- SELECT CodigoTipoOperacionesFinanciamiento, * FROM jf77062.TB_DMAT04 WHERE CodigoTipoOperacionesFinanciamiento IS NULL
-- SELECT CodigoSegmento, * FROM jf77062.TB_DMAT04 WHERE CodigoSegmento IS NULL
-- SELECT TipoZona, * FROM jf77062.TB_DMAT04 WHERE TipoZona IS NULL
-- SELECT FechaAutenticacionProtocolizacion, * FROM jf77062.TB_DMAT04 WHERE FechaAutenticacionProtocolizacion IS NULL
-- SELECT FechaUltimaInspeccion, * FROM jf77062.TB_DMAT04 WHERE FechaUltimaInspeccion IS NULL
-- SELECT PorcentajeEjecucionProyecto, * FROM jf77062.TB_DMAT04 WHERE PorcentajeEjecucionProyecto IS NULL
-- SELECT PagosEfectuadosDuranteMes, * FROM jf77062.TB_DMAT04 WHERE PagosEfectuadosDuranteMes IS NULL
-- SELECT MontosLiquidadosFechaCierre, * FROM jf77062.TB_DMAT04 WHERE MontosLiquidadosFechaCierre IS NULL
-- SELECT AmortizacionesCapitalAcumuladasFecha, * FROM jf77062.TB_DMAT04 WHERE AmortizacionesCapitalAcumuladasFecha IS NULL
-- SELECT TasaIncentivo, * FROM jf77062.TB_DMAT04 WHERE TasaIncentivo IS NULL
-- --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- SELECT NumeroRegistro_ConstanciaMPPAT, * FROM jf77062.TB_DMAT04 WHERE NumeroRegistro_ConstanciaMPPAT IS NULL
--  --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- SELECT FechaVencimientoRegistro_ConstanciaMPPAT, * FROM jf77062.TB_DMAT04 WHERE FechaVencimientoRegistro_ConstanciaMPPAT IS NULL
-- SELECT TipoSubsector, * FROM jf77062.TB_DMAT04 WHERE TipoSubsector IS NULL
-- SELECT Rubro, * FROM jf77062.TB_DMAT04 WHERE Rubro IS NULL
-- SELECT CodigoUso, * FROM jf77062.TB_DMAT04 WHERE CodigoUso IS NULL
-- SELECT CantidadUnidades, * FROM jf77062.TB_DMAT04 WHERE CantidadUnidades IS NULL
-- SELECT CodigoUnidadMedida, * FROM jf77062.TB_DMAT04 WHERE CodigoUnidadMedida IS NULL
-- SELECT SectorProduccion, * FROM jf77062.TB_DMAT04 WHERE SectorProduccion IS NULL
-- SELECT CantidadHectareas, * FROM jf77062.TB_DMAT04 WHERE CantidadHectareas IS NULL
-- SELECT SuperficieTotalPropiedad, * FROM jf77062.TB_DMAT04 WHERE SuperficieTotalPropiedad IS NULL
-- SELECT NumeroProductoresBeneficiarios, * FROM jf77062.TB_DMAT04 WHERE NumeroProductoresBeneficiarios IS NULL
-- SELECT Prioritario, * FROM jf77062.TB_DMAT04 WHERE Prioritario IS NULL
-- SELECT DestinoManufacturero, * FROM jf77062.TB_DMAT04 WHERE DestinoManufacturero IS NULL
-- SELECT DestinoEconomico, * FROM jf77062.TB_DMAT04 WHERE DestinoEconomico IS NULL
-- SELECT TipoBeneficiario, * FROM jf77062.TB_DMAT04 WHERE TipoBeneficiario IS NULL
-- SELECT ModalidadHipoteca, * FROM jf77062.TB_DMAT04 WHERE ModalidadHipoteca IS NULL
-- SELECT IngresoFamiliar, * FROM jf77062.TB_DMAT04 WHERE IngresoFamiliar IS NULL
-- SELECT MontoLiquidadoDuranteAnoCurso, * FROM jf77062.TB_DMAT04 WHERE MontoLiquidadoDuranteAnoCurso IS NULL
-- SELECT SaldoCredito31_12, * FROM jf77062.TB_DMAT04 WHERE SaldoCredito31_12 IS NULL
-- SELECT CantidadViviendasConstruir, * FROM jf77062.TB_DMAT04 WHERE CantidadViviendasConstruir IS NULL
-- SELECT RendimientosCobrarReestructurados, * FROM jf77062.TB_DMAT04 WHERE RendimientosCobrarReestructurados IS NULL
-- SELECT RendimientosCobrarAfectosReporto, * FROM jf77062.TB_DMAT04 WHERE RendimientosCobrarAfectosReporto IS NULL
-- SELECT RendimientosCobrarLitigio, * FROM jf77062.TB_DMAT04 WHERE RendimientosCobrarLitigio IS NULL
-- SELECT InteresEfectivamenteCobrado, * FROM jf77062.TB_DMAT04 WHERE InteresEfectivamenteCobrado IS NULL
-- SELECT PorcentajeComisionFlat, * FROM jf77062.TB_DMAT04 WHERE PorcentajeComisionFlat IS NULL
-- SELECT MontoComisionFlat, * FROM jf77062.TB_DMAT04 WHERE MontoComisionFlat IS NULL
-- SELECT PeriocidadPagoEspecialCapital, * FROM jf77062.TB_DMAT04 WHERE PeriocidadPagoEspecialCapital IS NULL
-- SELECT FechaCambioEstatusCredito, * FROM jf77062.TB_DMAT04 WHERE FechaCambioEstatusCredito IS NULL
-- SELECT FechaRegistroVencidaLitigiooCastigada, * FROM jf77062.TB_DMAT04 WHERE FechaRegistroVencidaLitigiooCastigada IS NULL
-- SELECT FechaExigibilidadPagoUltimaCuotaPagada, * FROM jf77062.TB_DMAT04 WHERE FechaExigibilidadPagoUltimaCuotaPagada IS NULL
-- SELECT CuentaContableProvisionEspecifica, * FROM jf77062.TB_DMAT04 WHERE CuentaContableProvisionEspecifica IS NULL
-- SELECT CuentaContableProvisionRendimiento, * FROM jf77062.TB_DMAT04 WHERE CuentaContableProvisionRendimiento IS NULL
-- SELECT CuentaContableInteresCuentaOrden, * FROM jf77062.TB_DMAT04 WHERE CuentaContableInteresCuentaOrden IS NULL
-- SELECT MontoInteresCuentaOrden, * FROM jf77062.TB_DMAT04 WHERE MontoInteresCuentaOrden IS NULL
-- SELECT TipoIndustria, * FROM jf77062.TB_DMAT04 WHERE TipoIndustria IS NULL
-- SELECT TipoBeneficiarioSectorManufacturero, * FROM jf77062.TB_DMAT04 WHERE TipoBeneficiarioSectorManufacturero IS NULL
-- SELECT TipoBeneficiarioSectorTurismo, * FROM jf77062.TB_DMAT04 WHERE TipoBeneficiarioSectorTurismo IS NULL
-- SELECT BeneficiarioEspecial, * FROM jf77062.TB_DMAT04 WHERE BeneficiarioEspecial IS NULL
-- SELECT FechaEmisionCertificacionBeneficiarioEspecial, * FROM jf77062.TB_DMAT04 WHERE FechaEmisionCertificacionBeneficiarioEspecial IS NULL
-- SELECT TipoVivienda, * FROM jf77062.TB_DMAT04 WHERE TipoVivienda IS NULL
-- SELECT FechaFinPeriodoGraciaPagoInteres, * FROM jf77062.TB_DMAT04 WHERE FechaFinPeriodoGraciaPagoInteres IS NULL
-- SELECT CapitalTransferido, * FROM jf77062.TB_DMAT04 WHERE CapitalTransferido IS NULL
-- SELECT FechaCambioEstatusCapitalTransferido, * FROM jf77062.TB_DMAT04 WHERE FechaCambioEstatusCapitalTransferido IS NULL
-- SELECT Fechanacimiento, * FROM jf77062.TB_DMAT04 WHERE Fechanacimiento IS NULL
 
-- ----------------------------------------------------------------------------------
-- --------para RPT 
-- SELECT NumeroCredito, * FROM TB_RPTAT04 WHERE NumeroCredito = '***'
-- SELECT FechaLiquidacion, * FROM TB_RPTAT04 WHERE FechaLiquidacion = '***'
-- SELECT FechaSolicitud, * FROM TB_RPTAT04 WHERE FechaSolicitud = '***'
-- SELECT FechaAprobacion, * FROM TB_RPTAT04 WHERE FechaAprobacion = '***'
-- SELECT Oficina, * FROM TB_RPTAT04 WHERE Oficina = '***'
-- SELECT CodigoContable, * FROM TB_RPTAT04 WHERE CodigoContable = '***'
-- SELECT NumeroCreditoPrimerDesembolso, * FROM TB_RPTAT04 WHERE NumeroCreditoPrimerDesembolso = '***'
-- SELECT NumeroDesembolso, * FROM TB_RPTAT04 WHERE NumeroDesembolso = '***'
-- SELECT CodigoLineaCredito, * FROM TB_RPTAT04 WHERE CodigoLineaCredito = '***'
-- SELECT MontoLineaCredito, * FROM TB_RPTAT04 WHERE MontoLineaCredito = '***'
-- SELECT EstadoCredito, * FROM TB_RPTAT04 WHERE EstadoCredito = '***'
-- SELECT TipoCredito, * FROM TB_RPTAT04 WHERE TipoCredito = '***'
-- SELECT SituacionCredito, * FROM TB_RPTAT04 WHERE SituacionCredito = '***'
-- SELECT PlazoCredito, * FROM TB_RPTAT04 WHERE PlazoCredito = '***'
-- SELECT ClasificacionRiesgo, * FROM TB_RPTAT04 WHERE ClasificacionRiesgo = '***'
-- SELECT DestinoCredito, * FROM TB_RPTAT04 WHERE DestinoCredito = '***'
-- SELECT NaturalezaCliente, * FROM TB_RPTAT04 WHERE NaturalezaCliente = '***'
-- SELECT TipoCliente, * FROM TB_RPTAT04 WHERE TipoCliente = '***'
-- SELECT IdentificacionCliente, * FROM TB_RPTAT04 WHERE IdentificacionCliente = '***'
-- SELECT Nombre_RazonSocial, * FROM TB_RPTAT04 WHERE Nombre_RazonSocial = '***'
-- SELECT Genero, * FROM TB_RPTAT04 WHERE Genero = '***'
-- SELECT TipoClienteRIF, * FROM TB_RPTAT04 WHERE TipoClienteRIF = '***'
-- SELECT IdentificacionTipoClienteRIF, * FROM TB_RPTAT04 WHERE IdentificacionTipoClienteRIF = '***'
-- SELECT ActividadCliente, * FROM TB_RPTAT04 WHERE ActividadCliente = '***'
-- SELECT PaisNacionalidad, * FROM TB_RPTAT04 WHERE PaisNacionalidad = '***'
-- SELECT DomicilioFiscal, * FROM TB_RPTAT04 WHERE DomicilioFiscal = '***'
-- SELECT ClienteNuevo, * FROM TB_RPTAT04 WHERE ClienteNuevo = '***'
-- SELECT Cooperativa, * FROM TB_RPTAT04 WHERE Cooperativa = '***'
-- SELECT Sindicado, * FROM TB_RPTAT04 WHERE Sindicado = '***'
-- SELECT BancoLiderSindicato, * FROM TB_RPTAT04 WHERE BancoLiderSindicato = '***'
-- SELECT RelacionCrediticia, * FROM TB_RPTAT04 WHERE RelacionCrediticia = '***'
-- SELECT GrupoEconomicoFinanciero, * FROM TB_RPTAT04 WHERE GrupoEconomicoFinanciero = '***'
-- SELECT NombreGrupoEconomicoFinanciero, * FROM TB_RPTAT04 WHERE NombreGrupoEconomicoFinanciero = '***'  
-- --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** --si no es GrupoEconomicoFinanciero = '2' puede estar en blanco
-- SELECT CodigoParroquia, * FROM TB_RPTAT04 WHERE CodigoParroquia = '***'
-- SELECT PeriodoGraciaCapital, * FROM TB_RPTAT04 WHERE PeriodoGraciaCapital = '***'
-- SELECT PeriodicidadPagoCapital, * FROM TB_RPTAT04 WHERE PeriodicidadPagoCapital = '***'
-- SELECT PeriodicidadPagoInteresCredito, * FROM TB_RPTAT04 WHERE PeriodicidadPagoInteresCredito = '***'
-- SELECT FechaVencimientoOriginal, * FROM TB_RPTAT04 WHERE FechaVencimientoOriginal = '***'
-- SELECT FechaVencimientoActual, * FROM TB_RPTAT04 WHERE FechaVencimientoActual = '***'
-- SELECT FechaReestructuracion, * FROM TB_RPTAT04 WHERE FechaReestructuracion = '***'
-- SELECT CantidadProrroga, * FROM TB_RPTAT04 WHERE CantidadProrroga = '***'
-- SELECT FechaProrroga, * FROM TB_RPTAT04 WHERE FechaProrroga = '***'
-- SELECT CantidadRenovaciones, * FROM TB_RPTAT04 WHERE CantidadRenovaciones = '***'
-- SELECT FechaUltimaRenovacion, * FROM TB_RPTAT04 WHERE FechaUltimaRenovacion = '***'
-- SELECT FechaCancelacionTotal, * FROM TB_RPTAT04 WHERE FechaCancelacionTotal = '***'
-- SELECT FechaVencimientoUltimaCoutaCapital, * FROM TB_RPTAT04 WHERE FechaVencimientoUltimaCoutaCapital = '***'
-- SELECT UltimaFechaCancelacionCuotaCapital, * FROM TB_RPTAT04 WHERE UltimaFechaCancelacionCuotaCapital = '***'
-- SELECT FechaVencimientoUltimaCuotaInteres, * FROM TB_RPTAT04 WHERE FechaVencimientoUltimaCuotaInteres = '***'
-- SELECT UltimaFechaCancelacionCuotaIntereses, * FROM TB_RPTAT04 WHERE UltimaFechaCancelacionCuotaIntereses = '***'
-- SELECT Moneda, * FROM TB_RPTAT04 WHERE Moneda = '***'
-- SELECT TipoCambioOriginal, * FROM TB_RPTAT04 WHERE TipoCambioOriginal = '***'
-- SELECT TipoCambioCierreMes, * FROM TB_RPTAT04 WHERE TipoCambioCierreMes = '***'
-- SELECT MontoOriginal, * FROM TB_RPTAT04 WHERE MontoOriginal = '***'
-- SELECT MontoInicial, * FROM TB_RPTAT04 WHERE MontoInicial = '***'
-- SELECT MontoLiquidadoMes, * FROM TB_RPTAT04 WHERE MontoLiquidadoMes = '***'
-- SELECT EntePublico, * FROM TB_RPTAT04 WHERE EntePublico = '***'
-- SELECT MontoInicialTerceros, * FROM TB_RPTAT04 WHERE MontoInicialTerceros = '***'
-- SELECT Saldo, * FROM TB_RPTAT04 WHERE Saldo = '***'
-- SELECT RendimientosCobrar, * FROM TB_RPTAT04 WHERE RendimientosCobrar = '***'
-- SELECT RendimientosCobrarVencidos, * FROM TB_RPTAT04 WHERE RendimientosCobrarVencidos = '***'
-- SELECT RendimientosCobrarMora, * FROM TB_RPTAT04 WHERE RendimientosCobrarMora = '***'
-- SELECT ProvisionEspecifica, * FROM TB_RPTAT04 WHERE ProvisionEspecifica = '***'
-- SELECT PocentajeProvisionEspecifica, * FROM TB_RPTAT04 WHERE PocentajeProvisionEspecifica = '***'
-- SELECT ProvisionRendimientoCobrar, * FROM TB_RPTAT04 WHERE ProvisionRendimientoCobrar = '***'
-- SELECT TasasInteresCobrada, * FROM TB_RPTAT04 WHERE TasasInteresCobrada = '***'
-- SELECT TasasInteresActual, * FROM TB_RPTAT04 WHERE TasasInteresActual = '***'
-- SELECT IndicadorTasaPreferencial, * FROM TB_RPTAT04 WHERE IndicadorTasaPreferencial = '***'
-- SELECT TasaComision, * FROM TB_RPTAT04 WHERE TasaComision = '***'
-- SELECT ComisionesCobrar, * FROM TB_RPTAT04 WHERE ComisionesCobrar = '***'
-- SELECT ComisionesCobradas, * FROM TB_RPTAT04 WHERE ComisionesCobradas = '***'
-- SELECT ErogacionesRecuperables, * FROM TB_RPTAT04 WHERE ErogacionesRecuperables = '***'
-- SELECT TipoGarantiaPrincipal, * FROM TB_RPTAT04 WHERE TipoGarantiaPrincipal = '***'
-- SELECT NumeroCuotas, * FROM TB_RPTAT04 WHERE NumeroCuotas = '***'
-- SELECT NumeroCuotasVencidas, * FROM TB_RPTAT04 WHERE NumeroCuotasVencidas = '***'
-- SELECT MontoVencido30dias, * FROM TB_RPTAT04 WHERE MontoVencido30dias = '***'
-- SELECT MontoVencido60dias, * FROM TB_RPTAT04 WHERE MontoVencido60dias = '***'
-- SELECT MontoVencido90dias, * FROM TB_RPTAT04 WHERE MontoVencido90dias = '***'
-- SELECT MontoVencido120dias, * FROM TB_RPTAT04 WHERE MontoVencido120dias = '***'
-- SELECT MontoVencido180dias, * FROM TB_RPTAT04 WHERE MontoVencido180dias = '***'
-- SELECT MontoVencidoUnAno, * FROM TB_RPTAT04 WHERE MontoVencidoUnAno = '***'
-- SELECT MontoVencidoMasUnAno, * FROM TB_RPTAT04 WHERE MontoVencidoMasUnAno = '***'
-- SELECT MontoVencer30dias, * FROM TB_RPTAT04 WHERE MontoVencer30dias = '***'
-- SELECT MontoVencer60dias, * FROM TB_RPTAT04 WHERE MontoVencer60dias = '***'
-- SELECT MontoVencer90dias, * FROM TB_RPTAT04 WHERE MontoVencer90dias = '***'
-- SELECT MontoVencer120dias, * FROM TB_RPTAT04 WHERE MontoVencer120dias = '***'
-- SELECT MontoVencer180dias, * FROM TB_RPTAT04 WHERE MontoVencer180dias = '***'
-- SELECT MontoVencerUnAno, * FROM TB_RPTAT04 WHERE MontoVencerUnAno = '***'
-- SELECT MontoVencerMasUnAno, * FROM TB_RPTAT04 WHERE MontoVencerMasUnAno = '***'
-- SELECT BancaSocial, * FROM TB_RPTAT04 WHERE BancaSocial = '***'
-- SELECT UnidadProduccionSocial, * FROM TB_RPTAT04 WHERE UnidadProduccionSocial = '***'
-- SELECT ModalidadMicrocredito, * FROM TB_RPTAT04 WHERE ModalidadMicrocredito = '***'
-- SELECT UsoFinanciero, * FROM TB_RPTAT04 WHERE UsoFinanciero = '***'
-- SELECT DestinoRecursosMicrofinancieros, * FROM TB_RPTAT04 WHERE DestinoRecursosMicrofinancieros = '***'
-- SELECT CantidadTrabajadores, * FROM TB_RPTAT04 WHERE CantidadTrabajadores = '***'
-- SELECT VentaAnuales, * FROM TB_RPTAT04 WHERE VentaAnuales = '***'
-- SELECT FechaEstadoFinanciero, * FROM TB_RPTAT04 WHERE FechaEstadoFinanciero = '***'
-- SELECT NumeroRTN, * FROM TB_RPTAT04 WHERE NumeroRTN = '***' --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- SELECT LicenciaTuristicaNacional, * FROM TB_RPTAT04 WHERE LicenciaTuristicaNacional = '***' ----PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- SELECT FechaEmisionFactibilidadSociotecnica_ConformidadTuristica, * FROM TB_RPTAT04 WHERE FechaEmisionFactibilidadSociotecnica_ConformidadTuristica = '***'
-- SELECT NumeroExpedienteFactibilidadSociotecnica, * FROM TB_RPTAT04 WHERE NumeroExpedienteFactibilidadSociotecnica = '***'
-- SELECT NumeroExpedienteConformidadTuristica, * FROM TB_RPTAT04 WHERE NumeroExpedienteConformidadTuristica = '***'
-- SELECT NombreProyectoUnidadProduccion, * FROM TB_RPTAT04 WHERE NombreProyectoUnidadProduccion = '***' --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- SELECT DireccionProyectoUnidadProduccion, * FROM TB_RPTAT04 WHERE DireccionProyectoUnidadProduccion = '***' --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- SELECT CodigoTipoProyecto, * FROM TB_RPTAT04 WHERE CodigoTipoProyecto = '***'
-- SELECT CodigoTipoOperacionesFinanciamiento, * FROM TB_RPTAT04 WHERE CodigoTipoOperacionesFinanciamiento = '***'
-- SELECT CodigoSegmento, * FROM TB_RPTAT04 WHERE CodigoSegmento = '***'
-- SELECT TipoZona, * FROM TB_RPTAT04 WHERE TipoZona = '***'
-- SELECT FechaAutenticacionProtocolizacion, * FROM TB_RPTAT04 WHERE FechaAutenticacionProtocolizacion = '***'
-- SELECT FechaUltimaInspeccion, * FROM TB_RPTAT04 WHERE FechaUltimaInspeccion = '***'
-- SELECT PorcentajeEjecucionProyecto, * FROM TB_RPTAT04 WHERE PorcentajeEjecucionProyecto = '***'
-- SELECT PagosEfectuadosDuranteMes, * FROM TB_RPTAT04 WHERE PagosEfectuadosDuranteMes = '***'
-- SELECT MontosLiquidadosFechaCierre, * FROM TB_RPTAT04 WHERE MontosLiquidadosFechaCierre = '***'
-- SELECT AmortizacionesCapitalAcumuladasFecha, * FROM TB_RPTAT04 WHERE AmortizacionesCapitalAcumuladasFecha = '***'
-- SELECT TasaIncentivo, * FROM TB_RPTAT04 WHERE TasaIncentivo = '***'
-- SELECT NumeroOficioIncentivo, * FROM TB_RPTAT04 WHERE NumeroOficioIncentivo = '***' --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- SELECT NumeroRegistro_ConstanciaMPPAT, * FROM TB_RPTAT04 WHERE NumeroRegistro_ConstanciaMPPAT = '***'
-- SELECT TipoRegistro_ConstanciaMPPAT, * FROM TB_RPTAT04 WHERE TipoRegistro_ConstanciaMPPAT = '***' --PARA ALGUNOS REGISTROS PUEDE ESTAR EN NULL *** VERIFICAR EN CALIDAD DE DATA
-- SELECT FechaVencimientoRegistro_ConstanciaMPPAT, * FROM TB_RPTAT04 WHERE FechaVencimientoRegistro_ConstanciaMPPAT = '***'
-- SELECT TipoSubsector, * FROM TB_RPTAT04 WHERE TipoSubsector = '***'
-- SELECT Rubro, * FROM TB_RPTAT04 WHERE Rubro = '***'
-- SELECT CodigoUso, * FROM TB_RPTAT04 WHERE CodigoUso = '***'
-- SELECT CantidadUnidades, * FROM TB_RPTAT04 WHERE CantidadUnidades = '***'
-- SELECT CodigoUnidadMedida, * FROM TB_RPTAT04 WHERE CodigoUnidadMedida = '***'
-- SELECT SectorProduccion, * FROM TB_RPTAT04 WHERE SectorProduccion = '***'
-- SELECT CantidadHectareas, * FROM TB_RPTAT04 WHERE CantidadHectareas = '***'
-- SELECT SuperficieTotalPropiedad, * FROM TB_RPTAT04 WHERE SuperficieTotalPropiedad = '***'
-- SELECT NumeroProductoresBeneficiarios, * FROM TB_RPTAT04 WHERE NumeroProductoresBeneficiarios = '***'
-- SELECT Prioritario, * FROM TB_RPTAT04 WHERE Prioritario = '***'
-- SELECT DestinoManufacturero, * FROM TB_RPTAT04 WHERE DestinoManufacturero = '***'
-- SELECT DestinoEconomico, * FROM TB_RPTAT04 WHERE DestinoEconomico = '***'
-- SELECT TipoBeneficiario, * FROM TB_RPTAT04 WHERE TipoBeneficiario = '***'
-- SELECT ModalidadHipoteca, * FROM TB_RPTAT04 WHERE ModalidadHipoteca = '***'
-- SELECT IngresoFamiliar, * FROM TB_RPTAT04 WHERE IngresoFamiliar = '***'
-- SELECT MontoLiquidadoDuranteAnoCurso, * FROM TB_RPTAT04 WHERE MontoLiquidadoDuranteAnoCurso = '***'
-- SELECT SaldoCredito31_12, * FROM TB_RPTAT04 WHERE SaldoCredito31_12 = '***'
-- SELECT CantidadViviendasConstruir, * FROM TB_RPTAT04 WHERE CantidadViviendasConstruir = '***'
-- SELECT RendimientosCobrarReestructurados, * FROM TB_RPTAT04 WHERE RendimientosCobrarReestructurados = '***'
-- SELECT RendimientosCobrarAfectosReporto, * FROM TB_RPTAT04 WHERE RendimientosCobrarAfectosReporto = '***'
-- SELECT RendimientosCobrarLitigio, * FROM TB_RPTAT04 WHERE RendimientosCobrarLitigio = '***'
-- SELECT InteresEfectivamenteCobrado, * FROM TB_RPTAT04 WHERE InteresEfectivamenteCobrado = '***'
-- SELECT PorcentajeComisionFlat, * FROM TB_RPTAT04 WHERE PorcentajeComisionFlat = '***'
-- SELECT MontoComisionFlat, * FROM TB_RPTAT04 WHERE MontoComisionFlat = '***'
-- SELECT PeriocidadPagoEspecialCapital, * FROM TB_RPTAT04 WHERE PeriocidadPagoEspecialCapital = '***'
-- SELECT FechaCambioEstatusCredito, * FROM TB_RPTAT04 WHERE FechaCambioEstatusCredito = '***'
-- SELECT FechaRegistroVencidaLitigiooCastigada, * FROM TB_RPTAT04 WHERE FechaRegistroVencidaLitigiooCastigada = '***'
-- SELECT FechaExigibilidadPagoUltimaCuotaPagada, * FROM TB_RPTAT04 WHERE FechaExigibilidadPagoUltimaCuotaPagada = '***'
-- SELECT CuentaContableProvisionEspecifica, * FROM TB_RPTAT04 WHERE CuentaContableProvisionEspecifica = '***'
-- SELECT CuentaContableProvisionRendimiento, * FROM TB_RPTAT04 WHERE CuentaContableProvisionRendimiento = '***'
-- SELECT CuentaContableInteresCuentaOrden, * FROM TB_RPTAT04 WHERE CuentaContableInteresCuentaOrden = '***'
-- SELECT MontoInteresCuentaOrden, * FROM TB_RPTAT04 WHERE MontoInteresCuentaOrden = '***'
-- SELECT TipoIndustria, * FROM TB_RPTAT04 WHERE TipoIndustria = '***'
-- SELECT TipoBeneficiarioSectorManufacturero, * FROM TB_RPTAT04 WHERE TipoBeneficiarioSectorManufacturero = '***'
-- SELECT TipoBeneficiarioSectorTurismo, * FROM TB_RPTAT04 WHERE TipoBeneficiarioSectorTurismo = '***'
-- SELECT BeneficiarioEspecial, * FROM TB_RPTAT04 WHERE BeneficiarioEspecial = '***'
-- SELECT FechaEmisionCertificacionBeneficiarioEspecial, * FROM TB_RPTAT04 WHERE FechaEmisionCertificacionBeneficiarioEspecial = '***'
-- SELECT TipoVivienda, * FROM TB_RPTAT04 WHERE TipoVivienda = '***'
-- SELECT FechaFinPeriodoGraciaPagoInteres, * FROM TB_RPTAT04 WHERE FechaFinPeriodoGraciaPagoInteres = '***'
-- SELECT CapitalTransferido, * FROM TB_RPTAT04 WHERE CapitalTransferido = '***'
-- SELECT FechaCambioEstatusCapitalTransferido, * FROM TB_RPTAT04 WHERE FechaCambioEstatusCapitalTransferido = '***'


 
 
 

