-- Buscar jf77062.TB_DMAT04_Transmitid y cambiar tabla
-- Buscar Ajustar
/*Como el valor del campo TIPO DE CREDITO es igual a 3, y el valor del 
campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: 
(1,2), y el valor del campo TIPO DE BENEFICIARIO es igual a 2, y 
el a?o de la fecha final del per�odo reportado es mayor que el a?o 
de el valor del campo FECHA DE LIQUIDACION entonces deber�a cumplirse
que el valor del campo SALDO DEL CREDITO AL 31 12 sea mayor que 0 */
--Solucion, colocarle en tipo beneficiario 1
-- SELECT 	NUMEROCREDITO, TIPOCREDITO,ESTADOCREDITO,TIPOBENEFICIARIO,FECHALIQUIDACION,MODALIDADHIPOTECA,SALDOCREDITO31_12,TIPODC
-- FROM 	jf77062.TB_DMAT04
-- WHERE	TIPOCREDITO = '3'
-- 	AND ESTADOCREDITO IN ('1','2')
-- 	AND TIPOBENEFICIARIO = '2'
-- 	AND SUBSTRING(FECHALIQUIDACION,1,4) < '2019' ----ajustar el a�o cuando corresponda
-- 	AND CONVERT(DECIMAL(18,2),REPLACE(SALDOCREDITO31_12,',','.')) <= 0
-- declare @UltFecha as varchar(20)
-- set @UltFecha='2019/10/31' ---mes a reportar -----------------------FECHA CAMBIAR OJO !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-- declare @PenFecha as varchar(20)
-- Set @Penfecha = substring(@UltFecha,1,8)  + convert(varchar(20),(convert(numeric(10),substring(@UltFecha,9,2))-1))
-- select @ultfecha as ultfecha, @penfecha as pencha into #fechasup
-- SELECT * INTO #TEMP_AT04_MesAnterior FROM jf77062.TB_DMAT04_TransmitidoSeptiembre2019 -- OJO Cambiar tabla !!!
-- DROP TABLE #fechasup
-- DROP TABLE #TEMP_AT04_MesAnterior
update jf77062.TB_DMAT04
set
  TIPOBENEFICIARIO = '1'
WHERE
  TIPOCREDITO = '3'
  AND ESTADOCREDITO IN ('1', '2')
  AND TIPOBENEFICIARIO = '2'
  AND SUBSTRING(FECHALIQUIDACION, 1, 4) < LEFT(
    (
      SELECT
        ultfecha
      FROM #fechasup), 4)
        AND CONVERT(
          DECIMAL(18, 2),
          REPLACE(SALDOCREDITO31_12, ',', '.')
        ) <= 0
      UPDATE JF77062.TB_DMAT04
      SET
        TIPOBENEFICIARIO = '1'
      WHERE
        TIPOCREDITO = '3'
        AND ESTADOCREDITO IN ('1', '2')
        AND TIPOBENEFICIARIO = '2'
        AND SUBSTRING(FECHALIQUIDACION, 1, 4) < LEFT(
          (
            SELECT
              ultfecha
            FROM #fechasup), 4)
              AND CONVERT(
                DECIMAL(18, 2),
                REPLACE(SALDOCREDITO31_12, ',', '.')
              ) <= 0 -----------------------
              --Como el valor del campo TIPO DE CREDITO es igual a 3, y el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,2),
              -- y el valor del campo TIPO DE BENEFICIARIO es distinto de 2 entonces debería cumplirse que el valor del campo MONTO LIQUIDADO ANO EN CURSO
              -- sea igual a 0
            UPDATE JF77062.TB_DMAT04
            SET
              MontoLiquidadoDuranteAnoCurso = '0.00'
            where
              TipoBeneficiario = '2'
              and EstadoCredito in ('1', '2')
              and TipoCredito = '3' -----------------------------------------------------
              /*Como el valor del campo TIPO DE CREDITO es igual a 6, y el valor del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL es mayor o igual que el
                        valor del campo FECHA DE LIQUIDACION entonces debería cumplirse que el valor del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL sea menor 
                        o igual que la fecha final del período reportado*/
              -- SELECT TipoCredito ,UltimaFechaCancelacionCuotaCapital,FechaVencimientoActual  ,FechaLiquidacion ,numerocredito,EstadoCredito , * FROM JF77062.TB_DMAT04
              -- WHERE TipoCredito  = '6'
              -- and UltimaFechaCancelacionCuotaCapital > = FechaLiquidacion
              -- UPDATE
              --   JF77062.TB_DMAT04
              -- SET
              --   UltimaFechaCancelacionCuotaCapital = (SELECT ultfecha FROM #fechasup)
              -- WHERE
              --   NumeroCredito = '8182980303' -----------------------------------------------------
              ---------------------------------------------------------------------------------------------------------------
              ----PARA ACTUALIZAR LAS FECHAS DE NACIMIENTO DE LOS CLIENTES
            UPDATE jf77062.TB_DMAT04
            SET
              FechaNacimiento = C.FechaNacimiento
            FROM jf77062.TB_DMAT04 DM
            INNER JOIN #TEMP_AT04_MesAnterior C ON C.NumeroCredito = DM.NUMEROCREDITO
              -- SELECT T1.TipoCliente + T1.IdentificacionCliente AS CId, T1.NumeroCredito, T1.FechaNacimiento, T2.FechaNacimiento
              -- FROM JF77062.TB_DMAT04 AS T1
              -- 	INNER JOIN TB_FDN AS T2
              -- 		ON T1.TipoCliente = T2.TipoCliente
              -- 		AND T1.IdentificacionCliente = T2.IdCliente
            UPDATE T1
            SET
              T1.FechaNacimiento = T2.FechaNacimiento
            FROM JF77062.TB_DMAT04 AS T1
            INNER JOIN TB_FDN AS T2 ON T1.TipoCliente = T2.TipoCliente
              AND CONVERT(DECIMAL(18, 0), T1.IdentificacionCliente) = T2.IdCliente -- SELECT FechaNacimiento, * FROM jf77062.TB_DMAT04 WHERE FechaNacimiento = ''
              -------------------------------------------------------------------------------------------------------------
              --Error de Fondo (Error Nro. 17): Por lo menos una de las siguientes afirmaciones deber�a cumplirse:
              --Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,2) entonces
              --deber�a cumplirse que el valor del campo TIPO DE CREDITO sea igual a 2 �
              --el valor del campo TIPO DE CREDITO sea igual a 6 �
              --el valor del campo TIPO DE CREDITO sea igual a 8 �
              --el valor del campo TIPO DE CREDITO sea igual a 4 �
              --el valor del campo TIPO DE CREDITO sea igual a 5 �
              --el valor del campo TIPO DE CREDITO sea igual a uno de los siguientes valores:(1,2) �
              --el valor del campo TIPO DE CREDITO sea igual a 1 �
              --el valor del campo TIPO DE CREDITO sea igual a 3
              --Como el valor del campo TIPO DE CREDITO es igual a 0 entonces
              --deber�a cumplirse que el valor del campo ESTADO DEL CREDITO sea igual a 3
              -- SELECT	TIPOCREDITO,ESTADOCREDITO,* FROM jf77062.TB_DMAT04
              -- WHERE	ESTADOCREDITO IN ('1','2') AND
              -- 	TIPOCREDITO NOT IN ('2','6','8','4','5','1','3')
              --------------------------------------------------------------------------------------------------------------
              --Como el valor del campo RENDIMIENTO POR COBRAR VENCIDOS es mayor que 0 por lo menos una de las
              --siguientes afirmaciones deber�a cumplirse: -  Como el valor del campo CODIGO CONTABLE es distinto de
              --1321810101 entonces deber�a cumplirse que el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR
              --sea menor que 0
              -- o -  Como el valor del campo PROVISION DEL RENDIMIENTO POR COBRAR es menor o igual que 0
              --entonces deber�a cumplirse que el valor del campo CODIGO CONTABLE sea igual a 1321810101
              --SOLUCION DADA:
              --L�nea 87562  64. Provisi�n = -0.01
            UPDATE jf77062.TB_DMAT04
            SET
              PROVISIONRENDIMIENTOCOBRAR = '-0.01'
            WHERE
              CONVERT(DECIMAL(18, 2), RENDIMIENTOSCOBRARVENCIDOS) > 0
              AND CODIGOCONTABLE <> '1321810101' --CASO 1
              --------------------------------------------------------------------------------------------------------------
              --EL SALDO DE MontoInteresCuentaOrden SE ESTABA TOMANDO DE SIF, Y SE DEBE DE TOMAR DE LA TABLA DE RENDIMIENTO DE  SaldoRendCuentaOrden
            UPDATE jf77062.TB_DMAT04
            SET
              MontoInteresCuentaOrden = TMR.SaldoRendCuentaOrden
            FROM jf77062.TB_DMAT04 DM
            INNER JOIN TMP_Rendimiento TMR ON TMR.Acct = DM.NUMEROCREDITO
            WHERE
              CodigoContable LIKE '13328101%'
              and NumeroCuotasVencidas >= 5
            update jf77062.TB_DMAT04
            set
              MontoInteresCuentaOrden = replace(
                convert(
                  decimal(18, 2),
                  replace(MontoInteresCuentaOrden, ',', '.')
                ),
                ',',
                '.'
              )
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableInteresCuentaOrden = '8190410400'
            WHERE
              CodigoContable LIKE '13328101%'
              and NumeroCuotasVencidas >= 5
              and (
                convert(decimal(18, 2),(MontoInteresCuentaOrden))
              ) > 0;
            update jf77062.TB_DMAT04
            set
              MontoInteresCuentaOrden = replace(
                convert(
                  decimal(18, 2),
                  replace(MontoInteresCuentaOrden, ',', '.')
                ),
                '.',
                ','
              ) -- SELECT DISTINCT (MontoInteresCuentaOrden) FROM  JF77062.TB_DMAT04
              -----------------------------------------------------------
              --ACTUALIZACION DE MontoVencerMasUnAno PARA LOS CLIENTES DEL CONSUMO --- Por Yelitza Teran.
            UPDATE JF77062.TB_DMAT04
            SET
              MontoVencerMasUnAno = '0.00'
            WHERE
              TIPODC IN (12, 6, 1, 3, 2, 4, 5, 14, 15, 16) ----------------------------------------------------------
              --Correr MIS PROVISIONES
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = C.PROVISION_ESPECIFICA,
              PocentajeProvisionEspecifica = C.PORCENTAJE_PROVISION_ESPECIFICA,
              ProvisionRendimientoCobrar = C.PROVISION_RENDIMIENTO_X_COBRAR,
              ClasificacionRiesgo = C.CLASE_RIESGO --NumeroCuotas = C.NUM_CUOTAS,
              --NumeroCuotasVencidas = C.NUM_CUOTAS_VENCIDAS
            FROM jf77062.TB_DMAT04 DM
            INNER JOIN RPT_STG_Dirigidas_TURISMO C ON C.NUM_CREDITO = DM.NUMEROCREDITO
              AND DM.TIPODC = ('8')
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = F.PROVISION_ESPECIFICA,
              PocentajeProvisionEspecifica = F.PORCENTAJE_PROVISION_ESPECIFICA,
              ProvisionRendimientoCobrar = F.PROVISION_RENDIMIENTO_X_COBRAR,
              ClasificacionRiesgo = F.CLASE_RIESGO --NumeroCuotas = F.NUM_CUOTAS,
              --NumeroCuotasVencidas = F.NUM_CUOTAS_VENCIDAS
            FROM jf77062.TB_DMAT04 DM
            INNER JOIN RPT_STG_Dirigidas_AGRICOLA_CORPORATE F ON F.NUM_CREDITO = DM.NUMEROCREDITO
              AND DM.TIPODC = ('11')
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = E.PROVISION_ESPECIFICA,
              PocentajeProvisionEspecifica = E.PORCENTAJE_PROVISION_ESPECIFICA,
              ProvisionRendimientoCobrar = E.PROVISION_RENDIMIENTO_X_COBRAR,
              ClasificacionRiesgo = E.CLASE_RIESGO --NumeroCuotas = E.NUM_CUOTAS,
              --NumeroCuotasVencidas = E.NUM_CUOTAS_VENCIDAS
            FROM jf77062.TB_DMAT04 DM
            INNER JOIN RPT_STG_Dirigidas_MANUFACTURA E ON E.NUM_CREDITO = DM.NUMEROCREDITO
              AND DM.TIPODC = ('10')
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = B.PROVISION_ESPECIFICA,
              PocentajeProvisionEspecifica = B.PORCENTAJE_PROVISION_ESPECIFICA,
              ProvisionRendimientoCobrar = B.PROVISION_RENDIMIENTO_X_COBRAR,
              ClasificacionRiesgo = B.CLASE_RIESGO --NumeroCuotas = B.NUM_CUOTAS,
              --NumeroCuotasVencidas = B.NUM_CUOTAS_VENCIDAS
            FROM jf77062.TB_DMAT04 DM
            INNER JOIN RPT_STG_Dirigidas_HIPOTECARIO_CORTO_PLAZO B ON B.NUM_CREDITO = DM.NUMEROCREDITO
              AND DM.TIPODC = ('7')
            UPDATE jf77062.TB_DMAT04
            SET
              PocentajeProvisionEspecifica = CAST(B.[Porcentaje provision] AS DECIMAL(38, 4)) * 100,
              ProvisionRendimientoCobrar = CAST(B.[Monto provision] AS DECIMAL(38, 2)) * -1
            FROM jf77062.TB_DMAT04 DM
            INNER JOIN tb_RendimientosCorporativos B ON B.Referencia = DM.NUMEROCREDITO
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = SOBC.SaldoProvision,
              PocentajeProvisionEspecifica = SOBC.Provision,
              ClasificacionRiesgo = SOBC.Riesgo --NumeroCuotas = 0,
              --NumeroCuotasVencidas = 0
            FROM jf77062.TB_DMAT04 DM
            INNER JOIN TMP_SobregirosConsumer SOBC ON SOBC.Acct = DM.NUMEROCREDITO
              AND DM.TIPODC = ('16')
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = PC.Saldo_Provision,
              PocentajeProvisionEspecifica = PC.Provision,
              ClasificacionRiesgo = PC.Riesgo --NumeroCuotasVencidas = PC.MaxOfCantCuotasVencidas
            FROM jf77062.TB_DMAT04 DM
            INNER JOIN TMP_PROVISONESCAPITAL PC ON PC.Account = DM.NUMEROCREDITO
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionRendimientoCobrar = PR.Saldo_Provision_REND
            FROM jf77062.TB_DMAT04 DM
            INNER JOIN TMP_PROVISONESRENDIMIENTO PR ON PR.Account = DM.NUMEROCREDITO
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = 0
            WHERE
              ProvisionEspecifica = ''
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = 0
            WHERE
              ProvisionEspecifica in ('-0.00', '-0')
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = '-' + ProvisionEspecifica
            WHERE
              ProvisionEspecifica NOT LIKE '-%'
              AND CONVERT(DECIMAL(18, 2),(ProvisionEspecifica)) <> 0
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = '0.00'
            WHERE
              EstadoCredito IN ('2', '3')
              AND CONVERT(DECIMAL(18, 2),(ProvisionEspecifica)) < 0
            UPDATE jf77062.TB_DMAT04
            SET
              ClasificacionRiesgo = '0'
            WHERE
              EstadoCredito IN ('2', '3')
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = '0.00'
            WHERE
              ProvisionEspecifica IS NULL
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionRendimientoCobrar = '0.00'
            WHERE
              ProvisionRendimientoCobrar IS NULL
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = '-0.01'
            WHERE
              ClasificacionRiesgo <> 'A'
              AND CONVERT(DECIMAL(18, 2), ISNULL(provisionespecifica, 0)) = 0
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = 0
            WHERE
              EstadoCredito IN ('2', '3')
              AND CONVERT(DECIMAL(18, 2), ISNULL(provisionespecifica, 0)) < 0
            UPDATE jf77062.TB_DMAT04
            SET
              ClasificacionRiesgo = '0'
            WHERE
              EstadoCredito IN ('2', '3')
            UPDATE jf77062.TB_DMAT04
            SET
              ProvisionEspecifica = '-0.01'
            WHERE
              ClasificacionRiesgo not in ('A', '0')
              AND CONVERT(DECIMAL(18, 2), ISNULL(provisionespecifica, 0)) = 0 --SELECT provisionespecifica, * FROM jf77062.TB_DMAT04 WHERE provisionespecifica = '-3e+006' --3000000.00
              --UPDATE jf77062.TB_DMAT04 SET provisionespecifica = '-3000000.00' WHERE provisionespecifica = '-3e+006'
              --QUERY TIPO DE VIVIENDA
            UPDATE Jf77062.TB_DMAT04
            SET
              TipoVivienda = T2.TipoVivienda
            FROM Jf77062.TB_DMAT04 T1
            INNER JOIN (
                SELECT
                  NUMEROCREDITO,
                  TipoVivienda
                FROM #TEMP_AT04_MesAnterior
              ) AS T2 ON T1.NumeroCredito = T2.NumeroCredito
            WHERE
              TIPOCREDITO = '3'
              AND ESTADOCREDITO = '1'
              AND T1.TIPOVIVIENDA = '0' -------------------------------
              --ERROR Como el valor del campo PROVISION ESPECIFICA es distinto de 0 entonces deber�a cumplirse que el valor del
              --campo CUENTA CONTABLE PROVISION ESPECIFICA empezara por algunos de los siguientes valores: (139)
              --para atajar el error
              -- select CuentaContableProvisionEspecifica,codigocontable, * from jf77062.TB_DMAT04
              -- where convert(decimal(18,2),ProvisionEspecifica) <> 0
              -- and SUBSTRING(CuentaContableProvisionEspecifica,1,3)<> '139'
              -- select CuentaContableProvisionEspecifica,codigocontable, * from jf77062.TB_DMAT04
              -- where convert(decimal(18,2),ProvisionEspecifica) <> 0
              -- and SUBSTRING(CuentaContableProvisionEspecifica,1,3)= '139'
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390310000'
            where
              convert(decimal(18, 2), ProvisionEspecifica) <> 0
              and SUBSTRING(CuentaContableProvisionEspecifica, 1, 3) <> '139' -- select CuentaContableProvisionRendimiento ,codigocontable, * from jf77062.TB_DMAT04
              -- where convert(decimal(18,2),ProvisionRendimientoCobrar ) = 0
              -- and SUBSTRING(CuentaContableProvisionRendimiento,1,3)= '149'
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableProvisionRendimiento = '0'
            where
              convert(decimal(18, 2), ProvisionRendimientoCobrar) = 0
              and SUBSTRING(CuentaContableProvisionRendimiento, 1, 3) = '149' ---Colocarle la siguiente cuentacontableprovisionespecifica 1390310000---
              --Para aquellos creditos que tienen por CuentaContableProvisionEspecifica 139, no se actualizaron
              -- select T1.CuentaContableProvisionEspecifica, T1.codigocontable, T1.ProvisionEspecifica, T1.ClasificacionRiesgo, T1.TipoDC, * from jf77062.TB_DMAT04_TransmitidoSeptiembre2018 AS T1
              -- inner join (select * from jf77062.TB_DMAT04
              -- where convert(decimal(18,2),ProvisionEspecifica) <> 0
              -- and SUBSTRING(CuentaContableProvisionEspecifica,1,3)<> '139') As T2
              -- on T1.NumeroCredito = T2.NumeroCredito
            UPDATE jf77062.TB_DMAT04
            SET
              CuentaContableProvisionRendimiento = '1490310000'
            WHERE
              ProvisionRendimientoCobrar <> '0.00'
              Or ProvisionRendimientoCobrar <> '0'
            UPDATE jf77062.TB_DMAT04
            SET
              CuentaContableProvisionRendimiento = '0'
            WHERE
              ProvisionRendimientoCobrar = '0'
              Or ProvisionRendimientoCobrar = '0.00'
            UPDATE jf77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390110000' -- Vigente
            WHERE
              (
                ProvisionEspecifica <> '0.00'
                Or ProvisionEspecifica <> '0'
              )
              AND CodigoContable LIKE '131%';
            UPDATE jf77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390310000' -- Vencido
            WHERE
              (
                ProvisionEspecifica <> '0.00'
                Or ProvisionEspecifica <> '0'
              )
              AND CodigoContable LIKE '133%';
            UPDATE jf77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '0'
            WHERE
              ProvisionEspecifica = '0'
              Or ProvisionEspecifica = '0.00' -- SELECT CuentaContableProvisionRendimiento, ProvisionRendimientoCobrar, CuentaContableProvisionEspecifica, ProvisionEspecifica, *  FROM jf77062.TB_DMAT04
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390110000'
            where
              SUBSTRING(codigocontable, 1, 3) = '131'
              and SUBSTRING(codigocontable, 1, 6) <> '131281'
              and (convert(decimal(18, 2),(saldo))) > 0
              and (convert(decimal(18, 2),(ProvisionEspecifica))) > 0;
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390210000'
            where
              SUBSTRING(codigocontable, 1, 3) = '132'
              and SUBSTRING(codigocontable, 1, 6) <> '132281'
              and (convert(decimal(18, 2),(saldo))) > 0
              and (convert(decimal(18, 2),(ProvisionEspecifica))) > 0;
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390310000'
            where
              SUBSTRING(codigocontable, 1, 3) = '133'
              and SUBSTRING(codigocontable, 1, 6) <> '133281'
              and (convert(decimal(18, 2),(saldo))) > 0
              and (convert(decimal(18, 2),(ProvisionEspecifica))) > 0;
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390410000'
            where
              SUBSTRING(codigocontable, 1, 3) = '134'
              and SUBSTRING(codigocontable, 1, 6) <> '134281'
              and (convert(decimal(18, 2),(saldo))) > 0
              and (convert(decimal(18, 2),(ProvisionEspecifica))) > 0;
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390610100'
            where
              SUBSTRING(codigocontable, 1, 6) = '131281'
              and (convert(decimal(18, 2),(saldo))) > 0
              and (convert(decimal(18, 2),(ProvisionEspecifica))) > 0;
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390610200'
            where
              SUBSTRING(codigocontable, 1, 6) = '132281'
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390610300'
            where
              SUBSTRING(codigocontable, 1, 6) = '133281'
              and (convert(decimal(18, 2),(saldo))) > 0
              and (convert(decimal(18, 2),(ProvisionEspecifica))) > 0;
            UPDATE JF77062.TB_DMAT04
            SET
              CuentaContableProvisionEspecifica = '1390610400'
            where
              SUBSTRING(codigocontable, 1, 6) = '134281'
              and (convert(decimal(18, 2),(saldo))) > 0
              and (convert(decimal(18, 2),(ProvisionEspecifica))) > 0;
            UPDATE JF77062.TB_DMAT04
            SET
              PocentajeProvisionEspecifica = '0'
            WHERE
              PocentajeProvisionEspecifica IS NULL
              OR PocentajeProvisionEspecifica = ''
            UPDATE JF77062.TB_DMAT04
            SET
              RelacionCrediticia = 1
            WHERE
              RelacionCrediticia IS NULL -- UPDATE
              --   JF77062.TB_DMAT04
              -- SET
              --   TipoBeneficiarioSectorTurismo = '0'
              -- WHERE
              --   NumeroCredito IN ('8143290307', '8153570306', '8161090304')
            update jf77062.TB_DMAT04
            set
              ProvisionRendimientoCobrar = '-0.01'
            where
              CONVERT(DECIMAL(18, 4), RendimientosCobrarVencidos) > 0
              and CONVERT(DECIMAL(15, 4), ProvisionRendimientoCobrar) = 0
            UPDATE jf77062.TB_DMAT04
            SET
              PROVISIONRENDIMIENTOCOBRAR = '-0.01'
            WHERE
              CONVERT(DECIMAL(18, 2), RENDIMIENTOSCOBRARVENCIDOS) > 0
              AND CODIGOCONTABLE <> '1321810101' --CASO 1
              AND CONVERT(DECIMAL(18, 2), PROVISIONRENDIMIENTOCOBRAR) >= 0
              AND CONVERT(DECIMAL(18, 2), PocentajeProvisionEspecifica) <> 0