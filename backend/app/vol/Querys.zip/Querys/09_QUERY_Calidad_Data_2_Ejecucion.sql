-- declare @UltFecha as varchar(20)
-- set
--   @UltFecha = '2019/10/31' ---mes a reportar -----------------------FECHA CAMBIAR OJO !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
--   declare @PenFecha as varchar(20)
-- Set
--   @Penfecha = substring(@UltFecha, 1, 8) + convert(
--     varchar(20),(
--       convert(numeric(10), substring(@UltFecha, 9, 2)) -1
--     )
--   )
-- select
--   @ultfecha as ultfecha,
--   @penfecha as pencha into #fechasup
-- SELECT
--   *
-- INTO #TEMP_AT04_MesAnterior
-- FROM
--   jf77062.TB_DMAT04_TransmitidoSeptiembre2019 -- OJO Cambiar tabla !!!
-- DROP TABLE #fechasup
-- DROP TABLE #TEMP_AT04_MesAnterior
-- SELECT NumeroCredito, EstadoCredito, PeriocidadPagoEspecialCapital, UltimaFechaCancelacionCuotaIntereses, FechaLiquidacion, TasasInteresActual
-- FROM JF77062.TB_DMAT04
-- WHERE EstadoCredito = '1'
-- 		And UltimaFechaCancelacionCuotaIntereses >= FechaLiquidacion
-- 		And UltimaFechaCancelacionCuotaIntereses > (SELECT UltFecha FROM fechasup)
-- 		And TasasInteresActual <> '0.0000'
UPDATE JF77062.TB_DMAT04
SET
  UltimaFechaCancelacionCuotaIntereses = (
    SELECT
      UltFecha
    FROM #fechasup
  )
WHERE
  EstadoCredito = '1'
  And UltimaFechaCancelacionCuotaIntereses >= FechaLiquidacion
  And UltimaFechaCancelacionCuotaIntereses > (
    SELECT
      UltFecha
    FROM #fechasup
  )
  And TasasInteresActual <> '0.0000' -- SELECT TipoCredito, DireccionProyectoUnidadProduccion, NumeroCredito
  -- FROM JF77062.TB_DMAT04
  -- WHERE TipoCredito IN ('4', '6')
  -- 		And (DireccionProyectoUnidadProduccion IS NULL Or DireccionProyectoUnidadProduccion = '')
  -- SELECT TipoCredito, DireccionProyectoUnidadProduccion, NumeroCredito FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						TipoCredito IN ('4', '6')
  -- 		                AND (DireccionProyectoUnidadProduccion IS NULL Or DireccionProyectoUnidadProduccion = ''))
UPDATE T1
SET
  T1.DireccionProyectoUnidadProduccion = T2.DireccionProyectoUnidadProduccion
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.TipoCredito IN ('4', '6')
  AND (
    T1.DireccionProyectoUnidadProduccion IS NULL
    Or T1.DireccionProyectoUnidadProduccion = ''
  )
UPDATE JF77062.TB_DMAT04
SET
  CodigoContable = RTRIM(CodigoContable) -- SELECT
  --   TipoCredito,
  --   EstadoCredito,
  --   LicenciaTuristicaNacional,
  --   NumeroCredito
  -- FROM
  --   JF77062.TB_DMAT04
  -- WHERE
  --   TipoCredito = '6'
  --   And EstadoCredito <> '1'
  --   And LicenciaTuristicaNacional <> ''
UPDATE T1
SET
  T1.LicenciaTuristicaNacional = T2.LicenciaTuristicaNacional
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.TipoCredito = '6'
  And T1.EstadoCredito <> '1'
  And T1.LicenciaTuristicaNacional <> '' ------------------------------------    FORMA    --------------------------------------
  -- Campo Error	 Valor	Descripci�n
  -- ComisionesCobrar	-1	No cumple con los par�metros de la tabla  -  0;99999999999.99
  -- SELECT DISTINCT ComisionesCobrar, NumeroCredito FROM JF77062.TB_DMAT04
  -- WHERE ComisionesCobrar = '-1'
  -- SELECT ComisionesCobrar, NumeroCredito FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						WHERE ComisionesCobrar = '-1')
UPDATE T1
SET
  T1.ComisionesCobrar = T2.ComisionesCobrar
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.ComisionesCobrar = '-1' ------------------------------------    FORMA    --------------------------------------
  -- Campo Error	 Valor	Descripci�n
  -- TipoGarantiaPrincipal	0	No cumple con los par�metros de la tabla  - TB_SB11.Garantia
  -- SELECT DISTINCT TipoGarantiaPrincipal, NumeroCredito FROM JF77062.TB_DMAT04
  -- WHERE TipoGarantiaPrincipal = '0'
  -- SELECT TipoGarantiaPrincipal, NumeroCredito FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						WHERE TipoGarantiaPrincipal = '0')
UPDATE T1
SET
  T1.TipoGarantiaPrincipal = T2.TipoGarantiaPrincipal
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.TipoGarantiaPrincipal = '0' ------------------------------------    FORMA    --------------------------------------
  -- Campo Error	 Valor	Descripci�n
  -- UsoFinanciero	8	No cumple con los par�metros de la tabla  - TB_SB82.Uso_Financiero
  -- SELECT DISTINCT UsoFinanciero, NumeroCredito, TipoDC FROM JF77062.TB_DMAT04
  -- WHERE UsoFinanciero = '8'
  -- SELECT UsoFinanciero, NumeroCredito FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						WHERE UsoFinanciero = '8')
  -- SELECT * FROM RPT_STG_Dirigidas_MICROFINANCIERO
  -- WHERE NUM_CREDITO IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						WHERE UsoFinanciero = '8')
UPDATE T1
SET
  T1.UsoFinanciero = T2.UsoFinanciero
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.UsoFinanciero = '8' ------------------------------------    FONDO     --------------------------------------
  -- Campo Error	 Valor	Descripci�n
  -- ProvisionRendimientoCobrar	0.00	Si el valor del campo [Rendimiento Por Cobrar Vencidos]
  --										es distinto de cero (�0�) y el valor del campo [Codigo Contable]
  --										es distinto que ("1321810101"), entonces el valor de este campo
  --										debe ser menor que cero (�0�).
  -- SELECT ProvisionRendimientoCobrar, NumeroCredito, CodigoContable, RendimientosCobrarVencidos
  -- FROM JF77062.TB_DMAT04
  -- WHERE ProvisionRendimientoCobrar = '0.00'
  -- 	  And CONVERT(DECIMAL(18, 2), RendimientosCobrarVencidos) <> 0
  -- 	  And CodigoContable <> '1321810101'
UPDATE JF77062.TB_DMAT04
SET
  ProvisionRendimientoCobrar = '-0.01'
WHERE
  ProvisionRendimientoCobrar = '0.00'
  And CONVERT(DECIMAL(18, 2), RendimientosCobrarVencidos) <> 0
  And CodigoContable <> '1321810101' ------------------------------------    FONDO     --------------------------------------
  -- Campo Error	 Valor	Descripci�n
  -- CuentaContableProvisionRendimiento	0	Si el valor del campo ["Provision del Rendimiento por Cobrar"]
  --											es distinto que ("0"); entonces el valor de este campo debe comenzar con "149"
  -- SELECT ProvisionRendimientoCobrar, NumeroCredito, CuentaContableProvisionRendimiento
  -- FROM JF77062.TB_DMAT04
  -- WHERE CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar, ',', '.')) <> 0
  -- 	  And CuentaContableProvisionRendimiento = '0'
UPDATE JF77062.TB_DMAT04
SET
  CuentaContableProvisionRendimiento = '1490310000'
WHERE
  CONVERT(
    DECIMAL(18, 2),
    REPLACE(ProvisionRendimientoCobrar, ',', '.')
  ) <> 0
  And CuentaContableProvisionRendimiento = '0' -- Casos Contrarios
  -- SELECT ProvisionRendimientoCobrar, NumeroCredito, CuentaContableProvisionRendimiento
  -- FROM JF77062.TB_DMAT04
  -- WHERE (ProvisionRendimientoCobrar = '0' Or ProvisionRendimientoCobrar = '0,00')-- CONVERT(DECIMAL(18, 2), ProvisionRendimientoCobrar) = 0
  -- 	  And CuentaContableProvisionRendimiento <> '0'
UPDATE JF77062.TB_DMAT04
SET
  CuentaContableProvisionRendimiento = '0'
WHERE
  (
    ProvisionRendimientoCobrar = '0'
    Or ProvisionRendimientoCobrar = '0,00'
  ) -- CONVERT(DECIMAL(18, 2), ProvisionRendimientoCobrar) = 0
  And CuentaContableProvisionRendimiento <> '0' -- Casos Provision Capitales
  -- SELECT ProvisionEspecifica, NumeroCredito, CuentaContableProvisionEspecifica
  -- FROM JF77062.TB_DMAT04
  -- WHERE CONVERT(DECIMAL(18, 2), REPLACE(ProvisionEspecifica , ',', '.')) <> 0
  -- 	  And CuentaContableProvisionEspecifica = '0'
UPDATE jf77062.TB_DMAT04
SET
  CuentaContableProvisionEspecifica = '1390110000' -- Vigente
WHERE
  (
    ProvisionEspecifica <> '0.00'
    Or ProvisionEspecifica <> '0'
  )
  AND CodigoContable LIKE '131%';
UPDATE jf77062.TB_DMAT04
SET
  CuentaContableProvisionEspecifica = '1390310000' -- Vencido
WHERE
  (
    ProvisionEspecifica <> '0.00'
    Or ProvisionEspecifica <> '0'
  )
  AND CodigoContable LIKE '133%';
-- SELECT ProvisionEspecifica, NumeroCredito, CuentaContableProvisionEspecifica
  -- FROM JF77062.TB_DMAT04
  -- WHERE (ProvisionEspecifica = '0' Or ProvisionEspecifica = '0,00' Or ProvisionEspecifica = '0.00')-- CONVERT(DECIMAL(18, 2), ProvisionEspecifica) = 0
  -- 	  And CuentaContableProvisionEspecifica <> '0'
UPDATE JF77062.TB_DMAT04
SET
  CuentaContableProvisionEspecifica = '0'
WHERE
  (
    ProvisionEspecifica = '0'
    Or ProvisionEspecifica = '0,00'
    Or ProvisionEspecifica = '0.00'
  ) -- CONVERT(DECIMAL(18, 2), ProvisionEspecifica) = 0
  And CuentaContableProvisionEspecifica <> '0' ------------------------------------    FONDO     --------------------------------------
  -- Campo Error	 Valor	Descripci�n
  -- LicenciaTuristicaNacional	0	Si el valor del campo [Tipo de Credito] es distinto que
  --									("6 - Turismo") entonces el valor de este campo es igual
  --									que ("Vacio" o cero ("0"))
  -- SELECT LicenciaTuristicaNacional, NumeroCredito, TipoCredito
  -- FROM JF77062.TB_DMAT04
  -- WHERE (LicenciaTuristicaNacional <> '' And LicenciaTuristicaNacional IS NOT NULL)
  -- 	  And TipoCredito <> '6'
UPDATE JF77062.TB_DMAT04
SET
  LicenciaTuristicaNacional = ''
WHERE
  (
    LicenciaTuristicaNacional <> ''
    And LicenciaTuristicaNacional IS NOT NULL
  )
  And TipoCredito <> '6' ------------------------------------    FONDO     --------------------------------------
  -- Campo Error	 Valor	Descripci�n
  -- SaldoCredito31_12	0.0100	Si el valor del campo [Tipo de Cr�dito] es igual que
  --							    (�3 � Hipotecario�) y el valor del campo [Estado del Cr�dito]
  --								es igual que (�1 - Activo�, �2 - Cancelado�) y el valor del campo
  --								[Tipo de Beneficiario] es igual que (�2 � SI�) y el a�o de la fecha
  --								del cierre del mes que se reporta es mayor que el a�o del campo
  --								[Fecha de liquidaci�n], entonces el valor de este campo debe ser mayor
  --								que cero (�0�).
  -- SELECT SaldoCredito31_12, NumeroCredito, TipoCredito, EstadoCredito, TipoBeneficiario, FechaLiquidacion
  -- FROM JF77062.TB_DMAT04
  -- WHERE SaldoCredito31_12 = '0.0100'
  -- SELECT SaldoCredito31_12, NumeroCredito, TipoCredito, EstadoCredito, TipoBeneficiario, FechaLiquidacion
  -- FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						WHERE SaldoCredito31_12 = '0.0100')
  -- SELECT SaldoCredito31_12, NumeroCredito, TipoCredito, EstadoCredito, TipoBeneficiario, FechaLiquidacion
  -- FROM JF77062.TB_DMAT04
  -- WHERE TipoCredito = '3'
  -- 	  And EstadoCredito IN ('1', '2')
  -- 	  And TipoBeneficiario = '2'
  -- 	  And REPLACE(FechaLiquidacion, '/', '') < REPLACE((SELECT UltFecha FROM fechasup), '/', '')
  -- 	  And CONVERT(DECIMAL(18, 4), SaldoCredito31_12) = 0
UPDATE JF77062.TB_DMAT04
SET
  SaldoCredito31_12 = CAST(
    REPLACE(SaldoCredito31_12, ',', '.') AS NUMERIC(19, 2)
  ) ------------------------------------    FONDO     --------------------------------------
  -- Campo Error	 Valor	Descripci�n
  -- TipoBeneficiarioSectorTurismo	1	Si el valor del campo [Tipo de Cr�dito] es distinto
  --										que (6 - Turismo); entonces el valor de este campo
  --										debe ser igual que (0 - No Aplica).
  -- SELECT TipoBeneficiarioSectorTurismo, NumeroCredito, TipoCredito
  -- FROM JF77062.TB_DMAT04
  -- WHERE TipoCredito <> '6'
  -- 	  AND TipoBeneficiarioSectorTurismo <> '0'
UPDATE JF77062.TB_DMAT04
SET
  TipoBeneficiarioSectorTurismo = '0'
WHERE
  TipoCredito <> '6'
  AND TipoBeneficiarioSectorTurismo <> '0' ----
  -- SELECT ProvisionRendimientoCobrar, NumeroCredito, CodigoContable, RendimientosCobrarVencidos, RendimientosCobrar, TipoDC
  -- FROM JF77062.TB_DMAT04
  -- WHERE CONVERT(DECIMAL(18, 2), REPLACE(RendimientosCobrarVencidos , ',', '.')) = 0
  -- 	  And CONVERT(DECIMAL(18, 2), REPLACE(RendimientosCobrar , ',', '.')) = 0
  -- 	  And CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar , ',', '.')) <> 0
  -- 	  And CodigoContable <> '1321810101'
UPDATE JF77062.TB_DMAT04
SET
  ProvisionRendimientoCobrar = '0,00'
WHERE
  CONVERT(
    DECIMAL(18, 2),
    REPLACE(RendimientosCobrarVencidos, ',', '.')
  ) = 0
  And CONVERT(
    DECIMAL(18, 2),
    REPLACE(RendimientosCobrar, ',', '.')
  ) = 0
  And CONVERT(
    DECIMAL(18, 2),
    REPLACE(ProvisionRendimientoCobrar, ',', '.')
  ) <> 0
  And CodigoContable <> '1321810101' ----------------------------- ERRORES PREVALIDACION ---------------------------------
  --- Error de Fondo: Como el valor del campo TIPO DE CREDITO es diferente
  --- de los siguientes valores: (4,6) entonces deber�a cumplirse que el valor del campo
  --- DIRECCION PROYECTO UNIDAD PRUDUCCION sea igual a VACIO
  -- SELECT NumeroCredito, TipoCredito, DireccionProyectoUnidadProduccion, FechaLiquidacion, UltimaFechaCancelacionCuotaCapital, UltimaFechaCancelacionCuotaIntereses, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE TipoCredito NOT IN ('4', '6')
  --       AND DireccionProyectoUnidadProduccion <> ''
  -- SELECT NumeroCredito, TipoCredito, DireccionProyectoUnidadProduccion, FechaLiquidacion, UltimaFechaCancelacionCuotaCapital, UltimaFechaCancelacionCuotaIntereses, *
  -- FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						TipoCredito NOT IN ('4', '6')
  --                         AND DireccionProyectoUnidadProduccion <> '')
UPDATE T1
SET
  T1.TipoCredito = T2.TipoCredito
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.TipoCredito NOT IN ('4', '6')
  AND T1.DireccionProyectoUnidadProduccion <> '' --- Error de Fondo: Como el valor del campo TIPO DE CREDITO es igual a 6, y el valor
  --- del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL es mayor o igual que el valor
  --- del campo FECHA DE LIQUIDACION entonces deber�a cumplirse que el valor del campo
  --- ULTIMA FECHA DE CANCELACION CUOTA CAPITAL sea menor o igual que la fecha final del
  --- per�odo reportado
  -- SELECT NumeroCredito, TipoCredito, FechaLiquidacion, UltimaFechaCancelacionCuotaCapital, UltimaFechaCancelacionCuotaIntereses, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE UltimaFechaCancelacionCuotaCapital> FechaLiquidacion
  -- 	  AND UltimaFechaCancelacionCuotaCapital > (SELECT UltFecha FROM fechasup)
  -- SELECT NumeroCredito, TipoCredito, FechaLiquidacion, UltimaFechaCancelacionCuotaCapital, UltimaFechaCancelacionCuotaIntereses, *
  -- FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						WHERE UltimaFechaCancelacionCuotaCapital> FechaLiquidacion
  -- 						AND UltimaFechaCancelacionCuotaCapital > (SELECT UltFecha FROM fechasup))
UPDATE T1
SET
  T1.TipoGarantiaPrincipal = T2.TipoGarantiaPrincipal
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.TipoGarantiaPrincipal = '0' -- Como el valor del campo TIPO DE CREDITO es igual a 6, y el valor del campo ESTADO DEL CREDITO
  -- es igual a 1 entonces deber�a cumplirse que el valor del campo TIPO DE BENEFICIARIO SECTOR TURISMO sea distinto de 0
  -- SELECT NumeroCredito, TipoCredito, EstadoCredito, TipoBeneficiarioSectorTurismo, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE TipoCredito = '6'
  -- 	  AND EstadoCredito = '1'
  -- 	  AND TipoBeneficiarioSectorTurismo <> '0'
  -- SELECT NumeroCredito, TipoCredito, EstadoCredito, TipoBeneficiarioSectorTurismo
  -- FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						WHERE TipoCredito = '6'
  -- 						  AND EstadoCredito = '1'
  -- 						  AND TipoBeneficiarioSectorTurismo <> '0')
UPDATE T1
SET
  T1.TipoBeneficiarioSectorTurismo = T2.TipoBeneficiarioSectorTurismo
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.TipoCredito = '6'
  AND T1.EstadoCredito = '1'
  AND T1.TipoBeneficiarioSectorTurismo <> '0' -- Como el valor del campo TIPO DE CREDITO es distinto de 8 entonces deber�a cumplirse que el valor del campo TIPO DE INDUSTRIA sea igual a 0
  -- SELECT NumeroCredito, TipoCredito, TipoIndustria, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE TipoCredito <> '8'
  -- 	  AND TipoIndustria <> '0.00' AND TipoIndustria <> '0'
UPDATE JF77062.TB_DMAT04
SET
  TipoIndustria = '0'
WHERE
  TipoCredito <> '8'
  AND TipoIndustria <> '0.00'
  AND TipoIndustria <> '0' -- El valor "8" no se encuentra entre los valores de referencia de la lista de valores 'USO_FINANCIERO' Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo
  -- SELECT
  --   NumeroCredito,
  --   UsoFinanciero,
  --   *
  -- FROM
  --   JF77062.TB_DMAT04
  -- WHERE
  --   UsoFinanciero = '8'
  -- SELECT
  --   NumeroCredito,
  --   UsoFinanciero
  -- FROM
  --   #TEMP_AT04_MesAnterior
  -- WHERE
  --   NumeroCredito IN (
  --     SELECT
  --       DISTINCT NumeroCredito
  --     FROM
  --       JF77062.TB_DMAT04
  --     WHERE
  --       UsoFinanciero = '8'
  --   )
UPDATE T1
SET
  T1.UsoFinanciero = T2.UsoFinanciero
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.UsoFinanciero = '8' -- UPDATE  JF77062.TB_DMAT04 SET UsoFinanciero = '1'
  -- WHERE UsoFinanciero = '8'
  -- Si el valor del campo [Tipo de Credito] es distinto que ("8 - Manufacturero"); entonces el valor de este campo debe ser igual que ("0 - No aplica")
  -- SELECT TipoBeneficiarioSectorManufacturero, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE TipoCredito <> '8' AND TipoBeneficiarioSectorManufacturero <> '0'
UPDATE JF77062.TB_DMAT04
SET
  TipoBeneficiarioSectorManufacturero = '0'
WHERE
  TipoCredito <> '8'
  AND TipoBeneficiarioSectorManufacturero <> '0' -- Validaciones SUDEBAN
  -- FONDO:
  -- Por lo menos una de las siguientes afirmaciones deber�a cumplirse:
  --  - Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,2) entonces deber�a cumplirse que el valor del campo TIPO DE CREDITO sea igual a 2 �el valor del campo TIPO DE CREDITO sea igual a 6 �el valor del campo TIPO DE CREDITO sea igual a 8 �el valor del campo TIPO DE CREDITO sea igual a 4 �el valor del campo TIPO DE CREDITO sea igual a 5 �el valor del campo TIPO DE CREDITO sea igual a uno de los siguientes valores:
  --    (1,2) �el valor del campo TIPO DE CREDITO sea igual a 1 �el valor del campo TIPO DE CREDITO sea igual a 3
  --  - Como el valor del campo TIPO DE CREDITO es igual a 0 entonces deber�a cumplirse que el valor del campo ESTADO DEL CREDITO sea igual a 3
  -- SELECT EstadoCredito, TipoCredito, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE EstadoCredito IN ('1', '2') AND TipoCredito NOT IN ('1', '2', '3', '6', '8', '4', '5')
  -- SELECT EstadoCredito, TipoCredito, * FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						WHERE EstadoCredito IN ('1', '2') AND TipoCredito NOT IN ('1', '2', '3', '6', '8', '4', '5'))
UPDATE T1
SET
  T1.TipoCredito = T2.TipoCredito
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.EstadoCredito IN ('1', '2')
  AND T1.TipoCredito NOT IN ('1', '2', '3', '6', '8', '4', '5') -- Como el valor del campo TIPO DE CREDITO es igual a 8, y el valor del campo ESTADO DEL CREDITO es distinto de 1 entonces deber�a cumplirse que el valor del campo TIPO DE INDUSTRIA sea igual a 0
  -- SELECT EstadoCredito, TipoCredito, TipoIndustria, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE EstadoCredito NOT IN ('1') AND TipoCredito IN ('8') AND TipoIndustria <> '0'
UPDATE JF77062.TB_DMAT04
SET
  TipoIndustria = '0'
WHERE
  EstadoCredito NOT IN ('1')
  AND TipoCredito IN ('8')
  AND TipoIndustria <> '0' -- El campo 'CLIENTE_NUEVO' es obligatorio, por ende no puede estar vac�o Error cr�tico, proceso de validaci�n abortado
  -- SELECT ClienteNuevo, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE ClienteNuevo = ''
  -- SELECT CLIENTE_NUEVO, *
  -- FROM RPT_STG_Dirigidas_MICROFINANCIERO
  -- WHERE NUM_CREDITO IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 					  WHERE ClienteNuevo = '')
UPDATE JF77062.TB_DMAT04
SET
  ClienteNuevo = '1'
WHERE
  ClienteNuevo = '' -- Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (4,6) entonces deber�a cumplirse que el valor del campo DIRECCION PROYECTO UNIDAD PRUDUCCION sea distinto de VACIO
  -- SELECT TipoCredito, DireccionProyectoUnidadProduccion, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE TipoCredito IN ('4', '6') AND DireccionProyectoUnidadProduccion = ''
  -- SELECT TipoCredito, DireccionProyectoUnidadProduccion, * FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						WHERE TipoCredito IN ('4', '6') AND DireccionProyectoUnidadProduccion = '')
UPDATE T1
SET
  T1.DireccionProyectoUnidadProduccion = T2.DireccionProyectoUnidadProduccion
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.TipoCredito IN ('4', '6')
  AND T1.DireccionProyectoUnidadProduccion = '' -- Tipo Garantia Principal
  -- SELECT AT04.NumeroCredito, AT07.CodigoContable, AT04.TipoGarantiaPrincipal, ISNULL(GP.TipoGarantiaPrincipal_AT04, '10') AS TipoGarantiaPrincipal_New
  -- FROM
  --     JF77062.TB_DMAT04 AS AT04
  --     LEFT JOIN (
  -- 	SELECT NumeroCredito, MIN(CodigoContable) AS CodigoContable FROM TB_AT07
  -- 	GROUP BY NumeroCredito
  --   ) AS AT07
  --     ON AT04.NumeroCredito = AT07.NumeroCredito
  --     LEFT JOIN tb_GarantiaPrincipal AS GP
  --     ON AT07.CodigoContable = GP.CodigoContable_AT07
UPDATE AT04
SET
  AT04.TipoGarantiaPrincipal = ISNULL(GP.TipoGarantiaPrincipal_AT04, '10')
FROM JF77062.TB_DMAT04 AS AT04
LEFT JOIN (
    SELECT
      NumeroCredito,
      MIN(CodigoContable) AS CodigoContable
    FROM TB_AT07
    GROUP BY
      NumeroCredito
  ) AS AT07 ON AT04.NumeroCredito = AT07.NumeroCredito
LEFT JOIN tb_GarantiaPrincipal AS GP ON AT07.CodigoContable = GP.CodigoContable_AT07 --- ComisionesCobrar No cumple con los parámetros de la tabla  -  0;99999999999.99
  -- SELECT ComisionesCobrar, *
  --   FROM JF77062.TB_DMAT04
  --   WHERE ComisionesCobrar = '-1'
  -- SELECT ComisionesCobrar, *
  --   FROM #TEMP_AT04_MesAnterior
  --   WHERE ComisionesCobrar <> 0
  --   SELECT ComisionesCobrar, * FROM #TEMP_AT04_MesAnterior
  --   WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  --   						WHERE ComisionesCobrar = '-1')
UPDATE JF77062.TB_DMAT04
SET
  ComisionesCobrar = '0'
WHERE
  ComisionesCobrar = '-1' -- Si el valor del campo [Tipo de Cliente] es igual que (“E – Extranjero”), entonces el valor de este campo debe estar entre 1 y 1.500.000 o entre 80.000.000 y 100.000.000.
  -- SELECT *
  --   FROM JF77062.TB_DMAT04
  --   WHERE IdentificacionCliente = '79401882'
  -- SELECT IdentificacionCliente, * FROM #TEMP_AT04_MesAnterior
  --   WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  --   						WHERE IdentificacionCliente = '79401882')
  -- SELECT *
  -- FROM JF77062.TB_DMAT04
  -- WHERE (CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 1 AND 1500000)
  -- 	  AND (CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 80000000 AND 100000000)
  -- 	  AND (TipoCliente = 'E')
UPDATE JF77062.TB_DMAT04
SET
  TipoCliente = 'P'
WHERE
  (
    CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 1
    AND 1500000
  )
  AND (
    CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 80000000
    AND 100000000
  )
  AND (TipoCliente = 'E') -- Si el valor del campo [Estado del Crédito] es igual que (“2 - Cancelado” ó “3 – Castigado) entonces el valor de PocentajeProvisionEspecifica debe ser cero (“0”).
  -- SELECT RendimientosCobrar, RendimientosCobrarVencidos, Saldo, EstadoCredito, ProvisionEspecifica, ProvisionRendimientoCobrar, PocentajeProvisionEspecifica, CuentaContableProvisionRendimiento, CuentaContableProvisionEspecifica, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE EstadoCredito IN ('2', '3')
  -- 	  AND CONVERT(DECIMAL(18, 0), PocentajeProvisionEspecifica) <> 0
UPDATE JF77062.TB_DMAT04
SET
  PocentajeProvisionEspecifica = '0.0000'
WHERE
  EstadoCredito IN ('2', '3')
  AND CONVERT(DECIMAL(18, 0), PocentajeProvisionEspecifica) <> 0 -- Si el valor del campo ["Provision del Rendimiento por Cobrar"] es igual que ("0"); entonces el valor de CuentaContableProvisionRendimiento debe ser igual que ("0 - No aplica")
  -- SELECT RendimientosCobrar, RendimientosCobrarVencidos, Saldo, EstadoCredito, ProvisionEspecifica, ProvisionRendimientoCobrar, PocentajeProvisionEspecifica, CuentaContableProvisionRendimiento, CuentaContableProvisionEspecifica, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar, ',', '.')) = 0
  -- 	  AND CuentaContableProvisionRendimiento <> '0'
UPDATE JF77062.TB_DMAT04
SET
  CuentaContableProvisionRendimiento = '0'
WHERE
  CONVERT(
    DECIMAL(18, 2),
    REPLACE(ProvisionRendimientoCobrar, ',', '.')
  ) = 0
  AND CuentaContableProvisionRendimiento <> '0' # TODO:
  --- ComisionesCobrar No cumple con los par�metros de la tabla  -  0;99999999999.99
  -- SELECT ComisionesCobrar, *
  --   FROM JF77062.TB_DMAT04
  --   WHERE ComisionesCobrar = '-1'
  -- SELECT ComisionesCobrar, *
  --   FROM jf77062.TB_DMAT04_TransmitidoSeptiembre2019
  --   WHERE ComisionesCobrar <> 0
  -- SELECT ComisionesCobrar, * FROM #TEMP_AT04_MesAnterior
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 						WHERE ComisionesCobrar = '-1')
UPDATE JF77062.TB_DMAT04
SET
  ComisionesCobrar = '0'
WHERE
  ComisionesCobrar = '-1' -- Si el valor del campo [Tipo de Cliente] es igual que (�E � Extranjero�), entonces el valor de este campo debe estar entre 1 y 1.500.000 o entre 80.000.000 y 100.000.000.
  -- SELECT *
  --   FROM JF77062.TB_DMAT04
  --   WHERE IdentificacionCliente = '79401882'
  -- SELECT IdentificacionCliente, * FROM jf77062.TB_DMAT04_TransmitidoSeptiembre2019
  --   WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  --   						WHERE IdentificacionCliente = '79401882')
  -- SELECT *
  -- FROM JF77062.TB_DMAT04
  -- WHERE (CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 1 AND 1500000)
  -- 	  AND (CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 80000000 AND 100000000)
  -- 	  AND (TipoCliente = 'E')
UPDATE JF77062.TB_DMAT04
SET
  TipoCliente = 'P'
WHERE
  (
    CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 1
    AND 1500000
  )
  AND (
    CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 80000000
    AND 100000000
  )
  AND (TipoCliente = 'E') -- Si el valor del campo [Estado del Cr�dito] es igual que (�2 - Cancelado� � �3 � Castigado) entonces el valor de PocentajeProvisionEspecifica debe ser cero (�0�).
  -- SELECT RendimientosCobrar, RendimientosCobrarVencidos, Saldo, EstadoCredito, ProvisionEspecifica, ProvisionRendimientoCobrar, PocentajeProvisionEspecifica, CuentaContableProvisionRendimiento, CuentaContableProvisionEspecifica, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE EstadoCredito IN ('2', '3')
  -- 	  AND CONVERT(DECIMAL(18, 0), PocentajeProvisionEspecifica) <> 0
UPDATE JF77062.TB_DMAT04
SET
  PocentajeProvisionEspecifica = '0.0000'
WHERE
  EstadoCredito IN ('2', '3')
  AND CONVERT(DECIMAL(18, 0), PocentajeProvisionEspecifica) <> 0 -- Si el valor del campo ["Provision del Rendimiento por Cobrar"] es igual que ("0"); entonces el valor de CuentaContableProvisionRendimiento debe ser igual que ("0 - No aplica")
  -- SELECT RendimientosCobrar, RendimientosCobrarVencidos, Saldo, EstadoCredito, ProvisionEspecifica, ProvisionRendimientoCobrar, PocentajeProvisionEspecifica, CuentaContableProvisionRendimiento, CuentaContableProvisionEspecifica, *
  -- FROM JF77062.TB_DMAT04
  -- WHERE CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar, ',', '.')) = 0
  -- 	  AND CuentaContableProvisionRendimiento <> '0'
UPDATE JF77062.TB_DMAT04
SET
  CuentaContableProvisionRendimiento = '0'
WHERE
  CONVERT(
    DECIMAL(18, 2),
    REPLACE(ProvisionRendimientoCobrar, ',', '.')
  ) = 0
  AND CuentaContableProvisionRendimiento <> '0' -- SELECT ProvisionRendimientoCobrar, NumeroCredito, CuentaContableProvisionRendimiento
  -- FROM JF77062.TB_DMAT04
  -- WHERE CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar, ',', '.')) <> 0
  -- And CuentaContableProvisionRendimiento = '0'
  -- SELECT ProvisionRendimientoCobrar, NumeroCredito, CuentaContableProvisionRendimiento
  -- FROM JF77062.TB_DMAT04
  -- WHERE NumeroCredito = '7026702997'
  -- SELECT NumeroCredito, FechaNacimiento, TipoCliente, IdentificacionCliente, *
  -- FROM jf77062.TB_DMAT04_TransmitidoSeptiembre2019
  -- WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  -- 		WHERE NumeroCredito IN ('1110157', '119657', '153086', '156626', '18986', '19930'))
  -- SELECT DISTINCT NumeroCredito, FechaNacimiento, TipoCliente, IdentificacionCliente, * FROM JF77062.TB_DMAT04
  -- 		WHERE NumeroCredito IN ('1110157', '119657', '153086', '156626', '18986', '19930')
UPDATE T1
SET
  T1.IdentificacionCliente = T2.IdentificacionCliente
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.NumeroCredito IN (
    '1110157',
    '119657',
    '153086',
    '156626',
    '18986',
    '19930'
  )
UPDATE T1
SET
  T1.IdentificacionTipoClienteRIF = T2.IdentificacionCliente
FROM JF77062.TB_DMAT04 AS T1
INNER JOIN #TEMP_AT04_MesAnterior AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.NumeroCredito IN (
    '1110157',
    '119657',
    '153086',
    '156626',
    '18986',
    '19930'
  )