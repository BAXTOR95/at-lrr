  -- DROP TABLE #SUMMARY_SALDOS_FULL
  -- DROP TABLE #SUMMARY_RENDIMIENTOS
  -- DROP TABLE #SUMMARY_DETALLE_POR_MUNDOS
  -- DROP TABLE #saldosvencidos
  -- DROP TABLE #saldoscapital
  -- DROP TABLE #saldovencidocastigados
  -- DROP TABLE #saldocastigado
  -- DROP TABLE #saldoreestruccturado
  -- DROP TABLE #rendimientosporcobrar
  -- DROP TABLE #rendimientosporcobrarMundos
  -- drop table #SUMMARY_DETALLE_POR_MUNDOS
  ----------------------------------------------------------------------------------------------------------
  --------------------------------------------------------------------------------------------------------
  ---------------------------------------------------------------------------------------------------------
  ----------------------------------/*** S A L D O S ***/----------------------------------------
  ----------------------------------/*** S A L D O S ***/----------------------------------------
  --creo la tabla temporal  #SUMMARY_SALDOS_FULL
SELECT
  'TOTALES   ' AS CodigoContable,
  CONVERT(DECIMAL(18, 2), 0.00) AS SaldoCapital,
  CONVERT(DECIMAL(18, 2), 0.00) AS SaldoVencido,
  CONVERT(DECIMAL(18, 2), 0.00) AS SaldoVencidoCAStigado,
  CONVERT(DECIMAL(18, 2), 0.00) AS SaldoCAStigado,
  CONVERT(DECIMAL(18, 2), 0.00) AS SaldoReestructurados INTO #SUMMARY_SALDOS_FULL
  --ingreso valores a la tabla temporal #SUMMARY_SALDOS_FULL desde datos existentes en  la tabla jf77062.TB_DMAT04
INSERT INTO
  #SUMMARY_SALDOS_FULL
SELECT
  DISTINCT CODIGOCONTABLE,
  '0 ',
  ' 0',
  '0 ',
  '0 ',
  ' 0 '
FROM
  jf77062.TB_DMAT04 -------------------------------------------------------------------------------------------------------------------------
  --    SELECT (131, 133, 819, 132)  DE LA TABLA TEMPORAL #SUMMARY_SALDOS_FULL
  ------------------------------------------------------------------------------------------------------------------------
  --Temporal con suma de saldos por codigocontable
SELECT
  codigocontable,
  sum(
    convert(decimal(18, 2), isnull(replace(saldo, ',', '.'), 0))
  ) AS 'saldocapital' into #saldoscapital from jf77062.TB_DMAT04 group by codigocontable
  --select  sumar Montosvencidos de codigoscontables (30,60,90,120, 180, UnAno, MASUnAno)
SELECT
  codigocontable,
  sum(
    convert(
      decimal(18, 2),
      isnull(replace(MontoVencido30diAS, ',', '.'), 0)
    )
  ) AS 'saldovencido30',
  sum(
    convert(
      decimal(18, 2),
      isnull(replace(MontoVencido60diAS, ',', '.'), 0)
    )
  ) AS 'saldovencido60',
  sum(
    convert(
      decimal(18, 2),
      isnull(replace(MontoVencido90diAS, ',', '.'), 0)
    )
  ) AS 'saldovencido90',
  sum(
    convert(
      decimal(18, 2),
      isnull(replace(MontoVencido120diAS, ',', '.'), 0)
    )
  ) AS 'saldovencido120',
  sum(
    convert(
      decimal(18, 2),
      isnull(replace(MontoVencido180diAS, ',', '.'), 0)
    )
  ) AS 'saldovencido180',
  sum(
    convert(
      decimal(18, 2),
      isnull(replace(MontoVencidoUnAno, ',', '.'), 0)
    )
  ) AS 'saldovencidoUnAnno',
  sum(
    convert(
      decimal(18, 2),
      isnull(replace(MontoVencidoMASUnAno, ',', '.'), 0)
    )
  ) AS 'saldovencidoMASUnAnno' INTO #saldosvencidos FROM jf77062.TB_DMAT04 GROUP BY codigocontable
  --select  sumar SaldosVencidosCAStigados de codigoscontables
SELECT
  codigocontable,
  sum(
    convert(decimal(18, 2), isnull(replace(saldo, ',', '.'), 0))
  ) AS 'saldovencidocastigado' into #saldovencidocastigados from jf77062.TB_DMAT04 group by codigocontable
  --select  sumar SaldosCAStigados de codigoscontables
SELECT
  codigocontable,
  sum(
    convert(decimal(18, 2), isnull(replace(saldo, ',', '.'), 0))
  ) AS 'saldocastigado' into #saldocastigado from jf77062.TB_DMAT04 group by codigocontable
  --select  sumar SaldosReestructurados de codigoscontables
SELECT
  codigocontable,
  sum(
    convert(decimal(18, 2), isnull(replace(saldo, ',', '.'), 0))
  ) AS 'saldoreestructurado' into #saldoreestruccturado from jf77062.TB_DMAT04 group by codigocontable
  -----------------------------------------------------------------------------------------------------------
  --UPDATE 	TABLA TEMPORAL #SUMMARY_SALDOS_FULL
  -----------------------------------------------------------------------------------------------------------
  --Update  de saldocapital y saldosvencidos (30+ 60+ 90+ 120+ 180+ UnAno+ MASUnAno), por codigocontable
UPDATE
  #SUMMARY_SALDOS_FULL
SET
  saldocapital = (
    case
      when #SUMMARY_SALDOS_FULL.codigocontable like '131%' then #saldoscapital.saldocapital else  0 end),
      SaldoVencido =(
        case
          when #SUMMARY_SALDOS_FULL.codigocontable like '13[1-2]%'then  #saldosvencidos.saldovencido30
          + #saldosvencidos.saldovencido60
          + #saldosvencidos.saldovencido90
          + #saldosvencidos.saldovencido120
          + #saldosvencidos.saldovencido180
          + #saldosvencidos.saldovencidoUnAnno
          + #saldosvencidos.saldovencidoMASUnAnno else  0 end),
          SaldoVencidoCAStigado =(
            case
              when #SUMMARY_SALDOS_FULL.codigocontable like '133%' then #saldovencidocastigados.saldovencidocastigado else  0 end),
              SaldoCAStigado =(
                case
                  when #SUMMARY_SALDOS_FULL.codigocontable like '819%' then #saldocastigado.saldocastigado else 0 end),
                  SaldoReestructurados =(
                    case
                      when #SUMMARY_SALDOS_FULL.codigocontable like '132%' then  #saldoreestruccturado.saldoreestructurado else 0 end)
                      from
                        #SUMMARY_SALDOS_FULL
                        join #saldosvencidos on #SUMMARY_SALDOS_FULL.CodigoContable=#saldosvencidos.codigocontable
                        join #saldoscapital on #SUMMARY_SALDOS_FULL.CodigoContable=#saldoscapital.codigocontable
                        join #saldovencidocastigados on #SUMMARY_SALDOS_FULL.CodigoContable=#saldovencidocastigados.codigocontable
                        join #saldocastigado on #SUMMARY_SALDOS_FULL.CodigoContable=#saldocastigado.codigocontable
                        join #saldoreestruccturado on #SUMMARY_SALDOS_FULL.CodigoContable=#saldoreestruccturado.codigocontable
                        ----------------------------------------------------------------------------------------------------------
                        --------------------------------------------------------------------------------------------------------
                        ---------------------------------------------------------------------------------------------------------
                        ----------------------------------/***RENDIMIENTOS POR COBRAR***/----------------------------------------
                        ----------------------------------/***RENDIMIENTOS POR COBRAR***/----------------------------------------
                        ----------------------------------/***RENDIMIENTOS POR COBRAR***/----------------------------------------
                        --creo la tabla temporal  #SUMMARY_RENDIMIENTOS
                      SELECT
                        'TOTALES   ' AS CodigoContable,
                        CONVERT(DECIMAL(18, 2), 0.00) AS RendimientoPorCobrar,
                        CONVERT(DECIMAL(18, 2), 0.00) AS RendimientoPorCobrarVencidos,
                        CONVERT(DECIMAL(18, 2), 0.00) AS RendimientoPorCobrarEnMora INTO #SUMMARY_RENDIMIENTOS
                        --ingreso valores a la tabla temporal #SUMMARY_RENDIMIENTOS desde datos existentes en  la tabla jf77062.TB_DMAT04
                      INSERT INTO
                        #SUMMARY_RENDIMIENTOS
                      SELECT
                        DISTINCT CODIGOCONTABLE,
                        '0',
                        '0',
                        '0'
                      FROM
                        jf77062.TB_DMAT04 -------------------------------------------------------------------------------------------------------------------------
                        --  SELECT   DE LA TABLA TEMPORAL #SUMMARY_RENDIMIENTOS
                        ------------------------------------------------------------------------------------------------------------------------
                        --select  sumar RendimientosPorCobrar de codigoscontables
                      SELECT
                        codigocontable,
                        sum(
                          convert(
                            decimal(18, 2),
                            isnull(replace(RendimientosCobrar, ',', '.'), 0)
                          )
                        ) AS 'rendimientosporcobrar',
                        sum(
                          convert(
                            decimal(18, 2),
                            isnull(replace(RendimientosCobrarVencidos, ',', '.'), 0)
                          )
                        ) AS 'rendimientoporcobrarvencidos',
                        sum(
                          convert(
                            decimal(18, 2),
                            isnull(replace(RendimientosCobrarMora, ',', '.'), 0)
                          )
                        ) AS 'rendimientoporcobrarenmora' into #rendimientosporcobrar from jf77062.TB_DMAT04 group by codigocontable
                        ----------------------------------------------------------------------------------------------------------
                        --UPDATE DE LA TABLA TEMPORAL   #SUMMARY_RENDIMIENTOS
                        -----------------------------------------------------------------------------------------------------------
                        --update  sumar RendimientosPorCobrar de codigoscontables
                      UPDATE
                        #SUMMARY_RENDIMIENTOS
                      SET
                        RendimientoPorCobrar = #rendimientosporcobrar.rendimientosporcobrar,
                        RendimientoPorCobrarVencidos = #rendimientosporcobrar.rendimientoporcobrarvencidos,
                        RendimientoPorCobrarEnMora = #rendimientosporcobrar.rendimientoporcobrarenmora
                      from
                        #SUMMARY_RENDIMIENTOS
                        join #rendimientosporcobrar on #SUMMARY_RENDIMIENTOS.CodigoContable=#rendimientosporcobrar.codigocontable
                        ---------------------------------------------------------------------------------------------------------
                        ---------------------------------------------------------------------------------------------------------
                        -------*************************DETALLE POR MUNDO CONSUMER Y CORPORATIVO***************************------
                        -------*************************DETALLE POR MUNDO CONSUMER Y CORPORATIVO***************************------
                        -------*************************DETALLE POR MUNDO CONSUMER Y CORPORATIVO***************************------
                        ----------------------------------/*** R E N D I M I E N T O S ***/--------------------------------------
                        ---------------------------------------------------------------------------------------------------------
                        ----------------------------------------------------------------------------------------------------------
                        --  SELECT   DE LA TABLA TEMPORAL #SUMMARY_DETALLE_POR_MUNDOS
                        ------------------------------------------------------------------------------------------------------------------------
                        
                      SELECT
                        CodigoContable,
                        -- CONSUMER--
                        sum(
                          case
                            when jf77062.TB_DMAT04.TipoDc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') then convert(
                              decimal(18, 2),
                              isnull(replace(RendimientosCobrar, ',', '.'), 0)
                            )
                            else 0
                          end
                        ) as 'CON_RendimientoPorCobrar ',
                        sum(
                          case
                            when jf77062.TB_DMAT04.TipoDc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') then convert(
                              decimal(18, 2),
                              isnull(replace(RendimientosCobrarVencidos, ',', '.'), 0)
                            )
                            else 0
                          end
                        ) AS 'CON_RendimientoPorCobrarVencidos',
                        sum(
                          case
                            when jf77062.TB_DMAT04.TipoDc in ('1', '2', '3', '4', '5', '6', '9', '12', '14', '15') then convert(
                              decimal(18, 2),
                              isnull(replace(RendimientosCobrarMora, ',', '.'), 0)
                            )
                            else 0
                          end
                        ) AS 'CON_RendimientoPorCobrarEnMora',
                        --CORPORATIVO
                        sum(
                          case
                            when jf77062.TB_DMAT04.TipoDc in ('7', '8', '10', '11', '13', '16') then convert(
                              decimal(18, 2),
                              isnull(replace(RendimientosCobrar, ',', '.'), 0)
                            )
                            else 0
                          end
                        ) AS 'COR_RendimientoPorCobrar',
                        sum(
                          case
                            when jf77062.TB_DMAT04.TipoDc in ('7', '8', '10', '11', '13', '16') then convert(
                              decimal(18, 2),
                              isnull(replace(RendimientosCobrarVencidos, ',', '.'), 0)
                            )
                            else 0
                          end
                        ) AS 'COR_RendimientoPorCobrarVencidos',
                        sum(
                          case
                            when jf77062.TB_DMAT04.TipoDc in ('7', '8', '10', '11', '13', '16') then convert(
                              decimal(18, 2),
                              isnull(replace(RendimientosCobrarMora, ',', '.'), 0)
                            )
                            else 0
                          end
                        ) AS 'COR_RendimientoPorCobrarEnMora' into #SUMMARY_DETALLE_POR_MUNDOS from jf77062.TB_DMAT04 group by codigocontable
                        --
                        -- SELECT * FROM  #SUMMARY_SALDOS_FULL ORDER BY CodigoContable
                        -- SELECT * FROM   #SUMMARY_RENDIMIENTOS
                        -- SELECT * FROM   #SUMMARY_DETALLE_POR_MUNDOS
                        -- SELECT * FROM #SUMMARY_DETALLE_POR_MUNDOS order BY CODIGOCONTABLE
                        ---PARA SOLICITUD DE DETALLES
                        --RENDIMIENTOS
                        /*SELECT 	codigocontable,
                        	numerocredito, 
                        	RendimientosCobrar,
                        	RendimientosCobrarVencidos,
                        	RendimientosCobrarMora,
                        	REPLACE(RendimientosCobrarReestructurados,',','.')AS RendimientosCobrarReestructurados,
                        	REPLACE(RendimientosCobrarAfectosReporto,',','.')AS RendimientosCobrarAfectosReporto ,
                        	REPLACE(RendimientosCobrarLitigio,',','.') AS RendimientosCobrarLitigio
                        FROM 	jf77062.TB_DMAT04 where codigocontable IN ()
                        
                        --SALDOS
                        SELECT 	codigocontable,
                        	numerocredito, 
                        	Saldo,
                        	MontoVencido30dias,
                        	MontoVencido60dias,
                        	MontoVencido90dias,
                        	MontoVencido120dias,
                        	MontoVencido180dias,
                        	MontoVencidoUnAno
                        FROM 	jf77062.TB_DMAT04 where codigocontable IN ()*/