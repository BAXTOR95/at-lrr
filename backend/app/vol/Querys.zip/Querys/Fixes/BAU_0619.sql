SELECT * FROM JF77062.TB_DMAT04
WHERE NumeroCredito = '8182980303'

SELECT NumeroCredito, EstadoCredito, PeriocidadPagoEspecialCapital, UltimaFechaCancelacionCuotaIntereses, FechaLiquidacion, TasasInteresActual 
FROM JF77062.TB_DMAT04
WHERE EstadoCredito = '1'
		And UltimaFechaCancelacionCuotaIntereses >= FechaLiquidacion
		And UltimaFechaCancelacionCuotaIntereses > '2019/06/30'
		And TasasInteresActual <> '0.0000'

UPDATE JF77062.TB_DMAT04
SET UltimaFechaCancelacionCuotaIntereses = '2019/06/30'
WHERE EstadoCredito = '1'
		And UltimaFechaCancelacionCuotaIntereses >= FechaLiquidacion
		And UltimaFechaCancelacionCuotaIntereses > '2019/06/30'
		And TasasInteresActual <> '0.0000'

----

SELECT TipoCredito, DireccionProyectoUnidadProduccion, NumeroCredito 
FROM JF77062.TB_DMAT04
WHERE TipoCredito IN ('4', '6')
		And (DireccionProyectoUnidadProduccion IS NULL Or DireccionProyectoUnidadProduccion = '')

UPDATE JF77062.TB_DMAT04
SET DireccionProyectoUnidadProduccion = 'VIA PANAME. KM 16 SCTOR GUADAUP��CTRO. INDUST.KELLY�S�151301�SAN ANTONIO DE LOS ALTOS0001204'
WHERE NumeroCredito = '8181800301'

-----

SELECT ClasificacionRiesgo, PocentajeProvisionEspecifica, NumeroCredito 
FROM JF77062.TB_DMAT04
WHERE (ClasificacionRiesgo NOT IN ('A', '0'))
		And (PocentajeProvisionEspecifica = '0' Or PocentajeProvisionEspecifica = '0.0000')

UPDATE JF77062.TB_DMAT04
SET PocentajeProvisionEspecifica = '5.0000'
WHERE NumeroCredito = '8190880304'

--- 8190880304

SELECT CuentaContableProvisionEspecifica, CuentaContableProvisionRendimiento, ProvisionRendimientoCobrar, ClasificacionRiesgo, PocentajeProvisionEspecifica, NumeroCredito, ProvisionEspecifica, * FROM JF77062.TB_DMAT04
WHERE NumeroCredito = '8190880304'

----

SELECT NumeroCredito, FechaVencimientoUltimaCoutaCapital, FechaVencimientoUltimaCuotaInteres, CodigoContable, FechaLiquidacion, FechaVencimientoActual 
FROM JF77062.TB_DMAT04
WHERE NumeroCredito IN ('8151870305',
'8161960328',
'8173270302',
'8182980303',
'8191290301',
'8191780303')

SELECT NumeroCredito, FechaVencimientoUltimaCoutaCapital, FechaVencimientoUltimaCuotaInteres, CodigoContable, FechaLiquidacion, FechaVencimientoActual, UltimaFechaCancelacionCuotaCapital
FROM JF77062.TB_DMAT04_TransmitidoMayo2019
WHERE NumeroCredito IN ('8151870305',
'8161960328',
'8173270302',
'8182980303',
'8191290301',
'8191780303')


UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCoutaCapital = '2019/06/03' WHERE NumeroCredito = '8151870305'
UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCoutaCapital = '2019/06/17' WHERE NumeroCredito = '8161960328'
UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCoutaCapital = '2019/06/24' WHERE NumeroCredito = '8173270302'
UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCoutaCapital = '2019/06/24' WHERE NumeroCredito = '8182980303'
UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCoutaCapital = '2019/06/10' WHERE NumeroCredito = '8191290301'
UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCoutaCapital = '2019/06/30' WHERE NumeroCredito = '8191780303'

UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCuotaInteres = '2019/06/03' WHERE NumeroCredito = '8151870305'
UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCuotaInteres = '2019/06/17' WHERE NumeroCredito = '8161960328'
UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCuotaInteres = '2019/06/24' WHERE NumeroCredito = '8173270302'
UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCuotaInteres = '2019/06/24' WHERE NumeroCredito = '8182980303'
UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCuotaInteres = '2019/06/10' WHERE NumeroCredito = '8191290301'
UPDATE  JF77062.TB_DMAT04 SET FechaVencimientoUltimaCuotaInteres = '2019/06/30' WHERE NumeroCredito = '8191780303'


SELECT CodigoContable, LEN(CodigoContable), NumeroCredito 
FROM JF77062.TB_DMAT04
WHERE LEN(CodigoContable) > 10

SELECT CodigoContable, LEN(CodigoContable), RTRIM(CodigoContable) NumeroCredito, * FROM JF77062.TB_DMAT04
WHERE NumeroCredito = '8191630301'

UPDATE JF77062.TB_DMAT04
SET CodigoContable = RTRIM(CodigoContable)

UPDATE JF77062.TB_DMAT04
SET LicenciaTuristicaNacional = ''
WHERE NumeroCredito = '8182980303'

SELECT TipoCredito, EstadoCredito, LicenciaTuristicaNacional, NumeroCredito 
FROM JF77062.TB_DMAT04
WHERE TipoCredito = '6'
		And EstadoCredito <> '1'
		And LicenciaTuristicaNacional <> ''
