------------------------------------    FORMA    --------------------------------------
-- Campo Error	 Valor	Descripci�n
-- ComisionesCobrar	-1	No cumple con los par�metros de la tabla  -  0;99999999999.99

SELECT DISTINCT ComisionesCobrar, NumeroCredito FROM JF77062.TB_DMAT04
WHERE ComisionesCobrar = '-1'

SELECT ComisionesCobrar, NumeroCredito FROM JF77062.TB_DMAT04_TransmitidoJulio2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE ComisionesCobrar = '-1')

UPDATE T1
SET T1.ComisionesCobrar = T2.ComisionesCobrar
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN JF77062.TB_DMAT04_TransmitidoJulio2019 AS T2
		ON T1.NumeroCredito = T2.NumeroCredito
WHERE T1.ComisionesCobrar = '-1'

------------------------------------    FORMA    --------------------------------------
-- Campo Error	 Valor	Descripci�n
-- TipoGarantiaPrincipal	0	No cumple con los par�metros de la tabla  - TB_SB11.Garantia

SELECT DISTINCT TipoGarantiaPrincipal, NumeroCredito FROM JF77062.TB_DMAT04
WHERE TipoGarantiaPrincipal = '0'

SELECT TipoGarantiaPrincipal, NumeroCredito FROM JF77062.TB_DMAT04_TransmitidoJulio2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE TipoGarantiaPrincipal = '0')

UPDATE T1
SET T1.TipoGarantiaPrincipal = T2.TipoGarantiaPrincipal
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN JF77062.TB_DMAT04_TransmitidoJulio2019 AS T2
		ON T1.NumeroCredito = T2.NumeroCredito
WHERE T1.TipoGarantiaPrincipal = '0'

------------------------------------    FORMA    --------------------------------------
-- Campo Error	 Valor	Descripci�n
-- UsoFinanciero	8	No cumple con los par�metros de la tabla  - TB_SB82.Uso_Financiero

SELECT DISTINCT UsoFinanciero, NumeroCredito, TipoDC FROM JF77062.TB_DMAT04
WHERE UsoFinanciero = '8'

SELECT UsoFinanciero, NumeroCredito FROM JF77062.TB_DMAT04_TransmitidoJulio2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE UsoFinanciero = '8')

SELECT * FROM RPT_STG_Dirigidas_MICROFINANCIERO
WHERE NUM_CREDITO IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE UsoFinanciero = '8')

UPDATE T1
SET T1.UsoFinanciero = T2.UsoFinanciero
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN JF77062.TB_DMAT04_TransmitidoJulio2019 AS T2
		ON T1.NumeroCredito = T2.NumeroCredito
WHERE T1.UsoFinanciero = '8'

------------------------------------    FONDO     --------------------------------------
-- Campo Error	 Valor	Descripci�n
-- ProvisionRendimientoCobrar	0.00	Si el valor del campo [Rendimiento Por Cobrar Vencidos] 
--										es distinto de cero (�0�) y el valor del campo [Codigo Contable] 
--										es distinto que ("1321810101"), entonces el valor de este campo 
--										debe ser menor que cero (�0�).

SELECT ProvisionRendimientoCobrar, NumeroCredito, CodigoContable, RendimientosCobrarVencidos
FROM JF77062.TB_DMAT04
WHERE ProvisionRendimientoCobrar = '0.00' 
	  And CONVERT(DECIMAL(18, 2), RendimientosCobrarVencidos) <> 0
	  And CodigoContable <> '1321810101'

UPDATE JF77062.TB_DMAT04
SET ProvisionRendimientoCobrar = '-0.01'
WHERE ProvisionRendimientoCobrar = '0.00' 
	  And CONVERT(DECIMAL(18, 2), RendimientosCobrarVencidos) <> 0
	  And CodigoContable <> '1321810101'

------------------------------------    FONDO     --------------------------------------
-- Campo Error	 Valor	Descripci�n
-- CuentaContableProvisionRendimiento	0	Si el valor del campo ["Provision del Rendimiento por Cobrar"] 
--											es distinto que ("0"); entonces el valor de este campo debe comenzar con "149"

SELECT ProvisionRendimientoCobrar, NumeroCredito, CuentaContableProvisionRendimiento
FROM JF77062.TB_DMAT04
WHERE CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar, ',', '.')) <> 0
	  And CuentaContableProvisionRendimiento = '0'

UPDATE JF77062.TB_DMAT04
SET CuentaContableProvisionRendimiento = '1490310000'
WHERE CONVERT(DECIMAL(18, 2), ProvisionRendimientoCobrar) <> 0
	  And CuentaContableProvisionRendimiento = '0'

-- Casos Contrarios
SELECT ProvisionRendimientoCobrar, NumeroCredito, CuentaContableProvisionRendimiento
FROM JF77062.TB_DMAT04
WHERE (ProvisionRendimientoCobrar = '0' Or ProvisionRendimientoCobrar = '0,00')-- CONVERT(DECIMAL(18, 2), ProvisionRendimientoCobrar) = 0
	  And CuentaContableProvisionRendimiento <> '0'

UPDATE JF77062.TB_DMAT04
SET CuentaContableProvisionRendimiento = '0'
WHERE (ProvisionRendimientoCobrar = '0' Or ProvisionRendimientoCobrar = '0,00')-- CONVERT(DECIMAL(18, 2), ProvisionRendimientoCobrar) = 0
	  And CuentaContableProvisionRendimiento <> '0'

-- Casos Provision Capitales
SELECT ProvisionEspecifica, NumeroCredito, CuentaContableProvisionEspecifica
FROM JF77062.TB_DMAT04
WHERE CONVERT(DECIMAL(18, 2), REPLACE(ProvisionEspecifica , ',', '.')) <> 0
	  And CuentaContableProvisionEspecifica = '0'

UPDATE
  jf77062.TB_DMAT04
SET
  CuentaContableProvisionEspecifica = '1390110000' -- Vigente
WHERE
  (
    ProvisionEspecifica <> '0.00'
    Or ProvisionEspecifica <> '0'
  )
  AND CodigoContable LIKE '131%';
UPDATE
  jf77062.TB_DMAT04
SET
  CuentaContableProvisionEspecifica = '1390310000' -- Vencido
WHERE
  (
    ProvisionEspecifica <> '0.00'
    Or ProvisionEspecifica <> '0'
  )
  AND CodigoContable LIKE '133%';

SELECT ProvisionEspecifica, NumeroCredito, CuentaContableProvisionEspecifica
FROM JF77062.TB_DMAT04
WHERE (ProvisionEspecifica = '0' Or ProvisionEspecifica = '0,00' Or ProvisionEspecifica = '0.00')-- CONVERT(DECIMAL(18, 2), ProvisionEspecifica) = 0
	  And CuentaContableProvisionEspecifica <> '0'

UPDATE JF77062.TB_DMAT04
SET CuentaContableProvisionEspecifica = '0'
WHERE (ProvisionEspecifica = '0' Or ProvisionEspecifica = '0,00' Or ProvisionEspecifica = '0.00')-- CONVERT(DECIMAL(18, 2), ProvisionEspecifica) = 0
	  And CuentaContableProvisionEspecifica <> '0'

------------------------------------    FONDO     --------------------------------------
-- Campo Error	 Valor	Descripci�n
-- LicenciaTuristicaNacional	0	Si el valor del campo [Tipo de Credito] es distinto que 
--									("6 - Turismo") entonces el valor de este campo es igual 
--									que ("Vacio" o cero ("0"))

SELECT LicenciaTuristicaNacional, NumeroCredito, TipoCredito
FROM JF77062.TB_DMAT04
WHERE (LicenciaTuristicaNacional <> '' And LicenciaTuristicaNacional IS NOT NULL) 
	  And TipoCredito <> '6'

UPDATE JF77062.TB_DMAT04
SET LicenciaTuristicaNacional = ''
WHERE (LicenciaTuristicaNacional <> '' And LicenciaTuristicaNacional IS NOT NULL) 
	  And TipoCredito <> '6'

------------------------------------    FONDO     --------------------------------------
-- Campo Error	 Valor	Descripci�n
-- SaldoCredito31_12	0.0100	Si el valor del campo [Tipo de Cr�dito] es igual que 
--							    (�3 � Hipotecario�) y el valor del campo [Estado del Cr�dito]
--								es igual que (�1 - Activo�, �2 - Cancelado�) y el valor del campo 
--								[Tipo de Beneficiario] es igual que (�2 � SI�) y el a�o de la fecha 
--								del cierre del mes que se reporta es mayor que el a�o del campo 
--								[Fecha de liquidaci�n], entonces el valor de este campo debe ser mayor 
--								que cero (�0�).

SELECT SaldoCredito31_12, NumeroCredito, TipoCredito, EstadoCredito, TipoBeneficiario, FechaLiquidacion
FROM JF77062.TB_DMAT04
WHERE SaldoCredito31_12 = '0.0100'

SELECT SaldoCredito31_12, NumeroCredito, TipoCredito, EstadoCredito, TipoBeneficiario, FechaLiquidacion
FROM JF77062.TB_DMAT04_TransmitidoJunio2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE SaldoCredito31_12 = '0.0100')

SELECT SaldoCredito31_12, NumeroCredito, TipoCredito, EstadoCredito, TipoBeneficiario, FechaLiquidacion
FROM JF77062.TB_DMAT04
WHERE TipoCredito = '3'
	  And EstadoCredito IN ('1', '2')
	  And TipoBeneficiario = '2'
	  And REPLACE(FechaLiquidacion, '/', '') < '20190731'
	  And CONVERT(DECIMAL(18, 4), SaldoCredito31_12) = 0

UPDATE JF77062.TB_DMAT04
SET SaldoCredito31_12 = '0.01'
WHERE SaldoCredito31_12 = '0.0100'

------------------------------------    FONDO     --------------------------------------
-- Campo Error	 Valor	Descripci�n
-- TipoBeneficiarioSectorTurismo	1	Si el valor del campo [Tipo de Cr�dito] es distinto 
--										que (6 - Turismo); entonces el valor de este campo 
--										debe ser igual que (0 - No Aplica).

SELECT TipoBeneficiarioSectorTurismo, NumeroCredito, TipoCredito
FROM JF77062.TB_DMAT04
WHERE TipoCredito <> '6'
	  AND TipoBeneficiarioSectorTurismo <> '0'

UPDATE JF77062.TB_DMAT04
SET TipoBeneficiarioSectorTurismo = '0'
WHERE TipoCredito <> '6'
	  AND TipoBeneficiarioSectorTurismo <> '0'

----------------------------- ACTUALIZACIONES PUNTUALES ---------------------------------
-- PROVISIONES MIS
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '15,0000' WHERE NumeroCredito = '6000000116'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '0,0000' WHERE NumeroCredito = '9019714601'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '0,0000' WHERE NumeroCredito = '9019736301'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '0,0000' WHERE NumeroCredito = '9019737501'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '0,0000' WHERE NumeroCredito = '9019737601'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '0,0000' WHERE NumeroCredito = '9019737801'

UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '-0,10' WHERE NumeroCredito = '6000000116'
UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '0,00' WHERE NumeroCredito = '9019737501'
UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '0,00' WHERE NumeroCredito = '9019737801'

UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '0,00' WHERE NumeroCredito = '5197230000351374'


-- FDN
SELECT FechaNacimiento, NumeroCredito FROM JF77062.TB_DMAT04
WHERE FechaNacimiento IS NULL Or FechaNacimiento = '19000101'

UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19750129' WHERE NumeroCredito = '5464900000591791'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19700221' WHERE NumeroCredito = '5464900001070514'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19590901' WHERE NumeroCredito = '5464900001070514'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19750129' WHERE NumeroCredito = '5464900001089563'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19671112' WHERE NumeroCredito = '5464900001090959'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19671112' WHERE NumeroCredito = '5549290000087878'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19910403' WHERE NumeroCredito = '9019869601'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20190731' WHERE NumeroCredito = '8191930301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20190731' WHERE NumeroCredito = '8192040302'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20190731' WHERE NumeroCredito = '8192060305'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20190731' WHERE NumeroCredito = '8192120301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20190731' WHERE NumeroCredito = '8192120302'

----

SELECT ProvisionRendimientoCobrar, NumeroCredito, CodigoContable, RendimientosCobrarVencidos, RendimientosCobrar, TipoDC
FROM JF77062.TB_DMAT04
WHERE CONVERT(DECIMAL(18, 2), REPLACE(RendimientosCobrarVencidos , ',', '.')) = 0
	  And CONVERT(DECIMAL(18, 2), REPLACE(RendimientosCobrar , ',', '.')) = 0
	  And CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar , ',', '.')) <> 0
	  And CodigoContable <> '1321810101'


UPDATE JF77062.TB_DMAT04
SET ProvisionRendimientoCobrar = '0,00'
WHERE CONVERT(DECIMAL(18, 2), REPLACE(RendimientosCobrarVencidos , ',', '.')) = 0
	  And CONVERT(DECIMAL(18, 2), REPLACE(RendimientosCobrar , ',', '.')) = 0
	  And CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar , ',', '.')) <> 0
	  And CodigoContable <> '1321810101'

SELECT ClasificacionRiesgo, NumeroCredito, CodigoContable, PocentajeProvisionEspecifica, ProvisionEspecifica
FROM JF77062.TB_DMAT04
WHERE NumeroCredito IN ('8192040302',
'8192120301')

UPDATE  JF77062.TB_DMAT04 SET ClasificacionRiesgo = 'B' WHERE NumeroCredito = '8192040302'
UPDATE  JF77062.TB_DMAT04 SET ClasificacionRiesgo = 'A' WHERE NumeroCredito = '8192120301'

UPDATE  JF77062.TB_DMAT04 SET ClasificacionRiesgo = 'B' WHERE NumeroCredito = '8191930301'
UPDATE  JF77062.TB_DMAT04 SET ClasificacionRiesgo = 'B' WHERE NumeroCredito = '8192060305'
UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '-2500000,00' WHERE NumeroCredito = '8191930301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '-4800000,00' WHERE NumeroCredito = '8192040302'
UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '-2400000,00' WHERE NumeroCredito = '8192060305'
UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '0,00' WHERE NumeroCredito = '8192120301'

UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '0' WHERE PocentajeProvisionEspecifica IS NULL OR PocentajeProvisionEspecifica = ''

----------------------------- ERRORES PREVALIDACION ---------------------------------
--- Error de Fondo: Como el valor del campo TIPO DE CREDITO es diferente 
--- de los siguientes valores: (4,6) entonces deber�a cumplirse que el valor del campo 
--- DIRECCION PROYECTO UNIDAD PRUDUCCION sea igual a VACIO 
SELECT NumeroCredito, TipoCredito, DireccionProyectoUnidadProduccion, FechaLiquidacion, UltimaFechaCancelacionCuotaCapital, UltimaFechaCancelacionCuotaIntereses, * 
FROM JF77062.TB_DMAT04 
WHERE NumeroCredito IN ('8151870305',
'8161960328',
'8173270302',
'8191290301',
'8191780303')

SELECT NumeroCredito, TipoCredito, DireccionProyectoUnidadProduccion, FechaLiquidacion, UltimaFechaCancelacionCuotaCapital, UltimaFechaCancelacionCuotaIntereses, * 
FROM JF77062.TB_DMAT04_TransmitidoJunio2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE NumeroCredito IN ('8151870305',
												'8161960328',
												'8173270302',
												'8191290301',
												'8191780303'))

SELECT NumeroCredito, TipoCredito, DireccionProyectoUnidadProduccion, FechaLiquidacion, UltimaFechaCancelacionCuotaCapital, UltimaFechaCancelacionCuotaIntereses, * 
FROM JF77062.TB_DMAT04
WHERE TipoCredito NOT IN ('4', '6')
	  AND DireccionProyectoUnidadProduccion <> ''

SELECT NumeroCredito, TipoCredito, DireccionProyectoUnidadProduccion, FechaLiquidacion, UltimaFechaCancelacionCuotaCapital, UltimaFechaCancelacionCuotaIntereses, * 
FROM JF77062.TB_DMAT04_TransmitidoJulio2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE TipoCredito NOT IN ('4', '6')
						AND DireccionProyectoUnidadProduccion <> '')

UPDATE T1
SET T1.TipoCredito = T2.TipoCredito
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN JF77062.TB_DMAT04_TransmitidoJulio2019 AS T2
		ON T1.NumeroCredito = T2.NumeroCredito
WHERE T1.TipoCredito NOT IN ('4', '6')
	  AND T1.DireccionProyectoUnidadProduccion <> ''

--- Error de Fondo: Como el valor del campo TIPO DE CREDITO es igual a 6, y el valor 
--- del campo ULTIMA FECHA DE CANCELACION CUOTA CAPITAL es mayor o igual que el valor 
--- del campo FECHA DE LIQUIDACION entonces deber�a cumplirse que el valor del campo 
--- ULTIMA FECHA DE CANCELACION CUOTA CAPITAL sea menor o igual que la fecha final del 
--- per�odo reportado

SELECT NumeroCredito, TipoCredito, FechaLiquidacion, UltimaFechaCancelacionCuotaCapital, UltimaFechaCancelacionCuotaIntereses, * 
FROM JF77062.TB_DMAT04
WHERE UltimaFechaCancelacionCuotaCapital> FechaLiquidacion
	  AND UltimaFechaCancelacionCuotaCapital > '2019/08/30'

SELECT NumeroCredito, TipoCredito, FechaLiquidacion, UltimaFechaCancelacionCuotaCapital, UltimaFechaCancelacionCuotaIntereses, * 
FROM JF77062.TB_DMAT04_TransmitidoJunio2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE UltimaFechaCancelacionCuotaCapital> FechaLiquidacion
						AND UltimaFechaCancelacionCuotaCapital > '2019/07/31')

UPDATE  JF77062.TB_DMAT04 SET UltimaFechaCancelacionCuotaCapital = '2019/07/22' WHERE NumeroCredito = '8173270302'
UPDATE  JF77062.TB_DMAT04 SET UltimaFechaCancelacionCuotaCapital = '2019/07/15' WHERE NumeroCredito = '8191290301'
UPDATE  JF77062.TB_DMAT04 SET UltimaFechaCancelacionCuotaCapital = '2019/07/26' WHERE NumeroCredito = '8191780303'
UPDATE  JF77062.TB_DMAT04 SET UltimaFechaCancelacionCuotaIntereses = '2019/07/22' WHERE NumeroCredito = '8173270302'
UPDATE  JF77062.TB_DMAT04 SET UltimaFechaCancelacionCuotaIntereses = '2019/07/15' WHERE NumeroCredito = '8191290301'
UPDATE  JF77062.TB_DMAT04 SET UltimaFechaCancelacionCuotaIntereses = '2019/07/26' WHERE NumeroCredito = '8191780303'
