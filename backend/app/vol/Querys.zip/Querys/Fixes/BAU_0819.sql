SELECT NUM_CREDITO, SALDO_CREDITO_31_12, SaldoCredito31_12, EstadoCredito, TipoBeneficiario, FechaLiquidacion, TipoCredito
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN RPT_STG_Dirigidas_HIPOTECARIO_LARGO_PLAZO AS T2
		ON T1.NumeroCredito = T2.NUM_CREDITO
WHERE T1.TipoCredito = '3'
	  AND T1.EstadoCredito IN ('1', '2')
	  AND T1.TipoBeneficiario = '2'

SELECT NUM_CREDITO, SALDO_CREDITO_31_12, SaldoCredito31_12, EstadoCredito, TipoBeneficiario, FechaLiquidacion, TipoCredito
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN RPT_STG_Dirigidas_HIPOTECARIO_CORTO_PLAZO AS T2
		ON T1.NumeroCredito = T2.NUM_CREDITO
WHERE T1.TipoCredito = '3'
	  AND T1.EstadoCredito IN ('1', '2')
	  AND T1.TipoBeneficiario = '2'

SELECT NUM_CREDITO, SALDO_CREDITO_31_12, SaldoCredito31_12, EstadoCredito, TipoBeneficiario, FechaLiquidacion, TipoCredito
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN RPT_STG_Dirigidas_HIPOTECARIO_LARGO_PLAZO AS T2
		ON T1.NumeroCredito = T2.NUM_CREDITO
WHERE CAST(REPLACE(SaldoCredito31_12, ',', '.') AS NUMERIC(19, 0)) > 50
	  AND T1.TipoCredito = '3'
	  AND T1.EstadoCredito IN ('1', '2')
	  AND T1.TipoBeneficiario = '2'

SELECT NUM_CREDITO, SALDO_CREDITO_31_12, SaldoCredito31_12, EstadoCredito, TipoBeneficiario, FechaLiquidacion
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN RPT_STG_Dirigidas_HIPOTECARIO_LARGO_PLAZO AS T2
		ON T1.NumeroCredito = T2.NUM_CREDITO


UPDATE T1
SET T1.TipoGarantiaPrincipal = T2.TipoGarantiaPrincipal
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN JF77062.TB_DMAT04_TransmitidoJulio2019 AS T2
		ON T1.NumeroCredito = T2.NumeroCredito
WHERE T1.TipoGarantiaPrincipal = '0'

UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '1.2000' WHERE NumeroCredito = '6700000243'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '15.6900' WHERE NumeroCredito = '6000003023'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '2.0900' WHERE NumeroCredito = '6000002201'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '2.1400' WHERE NumeroCredito = '6000002195'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '0.9100' WHERE NumeroCredito = '6700000066'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '0.5600' WHERE NumeroCredito = '6700000187'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '1.4300' WHERE NumeroCredito = '6700000237'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '1.5000' WHERE NumeroCredito = '6700000071'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '1.0000' WHERE NumeroCredito = '6700000159'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '1.0000' WHERE NumeroCredito = '6700000063'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '1.2500' WHERE NumeroCredito = '6700000158'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '0.3000' WHERE NumeroCredito = '6700000178'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '0.8200' WHERE NumeroCredito = '6700000064'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '1.0300' WHERE NumeroCredito = '6700000195'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '1.2500' WHERE NumeroCredito = '6700000255'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '0.8900' WHERE NumeroCredito = '6700000020'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '0.8100' WHERE NumeroCredito = '6700000201'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '1.4400' WHERE NumeroCredito = '6700000248'
UPDATE  JF77062.TB_DMAT04 SET SaldoCredito31_12 = '1.2300' WHERE NumeroCredito = '6700000176'

UPDATE  JF77062.TB_DMAT04 SET Saldo = '0.16' WHERE NumeroCredito = '6700000064'

-- Como el valor del campo TIPO DE CREDITO es igual a 6, y el valor del campo ESTADO DEL CREDITO 
-- es igual a 1 entonces deber�a cumplirse que el valor del campo TIPO DE BENEFICIARIO SECTOR TURISMO sea distinto de 0 
SELECT NumeroCredito, TipoCredito, EstadoCredito, TipoBeneficiarioSectorTurismo, * 
FROM JF77062.TB_DMAT04
WHERE TipoCredito = '6'
	  AND EstadoCredito = '1'
	  AND TipoBeneficiarioSectorTurismo <> '0'

SELECT NumeroCredito, TipoCredito, EstadoCredito, TipoBeneficiarioSectorTurismo
FROM JF77062.TB_DMAT04_TransmitidoJulio2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE TipoCredito = '6'
						  AND EstadoCredito = '1'
						  AND TipoBeneficiarioSectorTurismo <> '0')

UPDATE T1
SET T1.TipoBeneficiarioSectorTurismo = T2.TipoBeneficiarioSectorTurismo
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN JF77062.TB_DMAT04_TransmitidoJulio2019 AS T2
		ON T1.NumeroCredito = T2.NumeroCredito
WHERE T1.TipoCredito = '6'
	  AND T1.EstadoCredito = '1'
	  AND T1.TipoBeneficiarioSectorTurismo <> '0'

-- Como el valor del campo TIPO DE CREDITO es distinto de 8 entonces deber�a cumplirse que el valor del campo TIPO DE INDUSTRIA sea igual a 0

SELECT NumeroCredito, TipoCredito, TipoIndustria, * 
FROM JF77062.TB_DMAT04
WHERE TipoCredito <> '8'
	  AND TipoIndustria <> '0.00' AND TipoIndustria <> '0'

UPDATE  JF77062.TB_DMAT04 SET TipoIndustria = '0'
WHERE TipoCredito <> '8'
	  AND TipoIndustria <> '0.00' AND TipoIndustria <> '0'

-- El valor "8" no se encuentra entre los valores de referencia de la lista de valores 'USO_FINANCIERO' Consulte el manual respectivo para ver la lista de todos los valores admitidos por este campo 
SELECT NumeroCredito, UsoFinanciero, * 
FROM JF77062.TB_DMAT04
WHERE UsoFinanciero = '8'

SELECT NumeroCredito, UsoFinanciero
FROM JF77062.TB_DMAT04_TransmitidoJulio2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE UsoFinanciero = '8')

UPDATE T1
SET T1.UsoFinanciero = T2.UsoFinanciero
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN JF77062.TB_DMAT04_TransmitidoJulio2019 AS T2
		ON T1.NumeroCredito = T2.NumeroCredito
WHERE T1.UsoFinanciero = '8'

UPDATE  JF77062.TB_DMAT04 SET UsoFinanciero = '1'
WHERE UsoFinanciero = '8'

--

UPDATE  JF77062.TB_DMAT04 SET Saldo = '12473.88' WHERE NumeroCredito = '1300384028'
