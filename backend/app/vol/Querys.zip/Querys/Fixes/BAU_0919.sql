UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '15,0000' WHERE NumeroCredito = '6000000116'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '0,0000' WHERE NumeroCredito = '9019714601'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '0,0000' WHERE NumeroCredito = '9019736301'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '0,0000' WHERE NumeroCredito = '9019737601'
UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '-0,10' WHERE NumeroCredito = '6000000116'
UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '0,00' WHERE NumeroCredito = '9019714601'
UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '0,00' WHERE NumeroCredito = '9019736301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '0,00' WHERE NumeroCredito = '9019737601'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-303000.00' WHERE NumeroCredito = '8190880304'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-1098217.90' WHERE NumeroCredito = '8191340308'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-1407940.74' WHERE NumeroCredito = '8192320301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-40740.74' WHERE NumeroCredito = '8191290301'

UPDATE  JF77062.TB_DMAT04 SET RendimientosCobrar = '3366666.67' WHERE NumeroCredito = '8190880304'
UPDATE  JF77062.TB_DMAT04 SET RendimientosCobrar = '814814.81' WHERE NumeroCredito = '8191290301'

SELECT * FROM JF77062.TB_DMAT04 WHERE NumeroCredito = '6700000249'

-- Si el valor del campo [Tipo de Credito] es distinto que ("8 - Manufacturero"); entonces el valor de este campo debe ser igual que ("0 - No aplica")
SELECT TipoBeneficiarioSectorManufacturero, * 
FROM JF77062.TB_DMAT04 
WHERE TipoCredito <> '8' AND TipoBeneficiarioSectorManufacturero <> '0'

UPDATE  JF77062.TB_DMAT04 
SET TipoBeneficiarioSectorManufacturero = '0' 
WHERE TipoCredito <> '8' AND TipoBeneficiarioSectorManufacturero <> '0'

--- Garantia

UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '8191780303'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '8191290301'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '10' WHERE NumeroCredito = '8173270302'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019762001'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019761901'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019761401'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019757801'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019751201'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019742901'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019741701'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019736301'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019735901'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019730301'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019725001'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '10' WHERE NumeroCredito = '9019717301'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019714601'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019707401'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '10' WHERE NumeroCredito = '9019698201'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019762001'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019761901'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019761401'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019757801'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019751201'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019742901'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019741701'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019736301'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019735901'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019730301'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019725001'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019714601'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019707401'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '8192320301'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '8191780303'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '8191340308'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '8191290301'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019737801' --Excluidos
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '9019737501' --Excluidos
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '6700000017'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '6700000049'
UPDATE  JF77062.TB_DMAT04 SET TipoGarantiaPrincipal = '8' WHERE NumeroCredito = '6700000249'

-- Validaciones SUDEBAN

-- FONDO:
-- Por lo menos una de las siguientes afirmaciones deber�a cumplirse:
--  - Como el valor del campo ESTADO DEL CREDITO es igual a uno de los siguientes valores: (1,2) entonces deber�a cumplirse que el valor del campo TIPO DE CREDITO sea igual a 2 �el valor del campo TIPO DE CREDITO sea igual a 6 �el valor del campo TIPO DE CREDITO sea igual a 8 �el valor del campo TIPO DE CREDITO sea igual a 4 �el valor del campo TIPO DE CREDITO sea igual a 5 �el valor del campo TIPO DE CREDITO sea igual a uno de los siguientes valores:
--    (1,2) �el valor del campo TIPO DE CREDITO sea igual a 1 �el valor del campo TIPO DE CREDITO sea igual a 3 
--  - Como el valor del campo TIPO DE CREDITO es igual a 0 entonces deber�a cumplirse que el valor del campo ESTADO DEL CREDITO sea igual a 3 

SELECT EstadoCredito, TipoCredito, * 
FROM JF77062.TB_DMAT04 
WHERE EstadoCredito IN ('1', '2') AND TipoCredito NOT IN ('1', '2', '3', '6', '8', '4', '5')

SELECT EstadoCredito, TipoCredito, * FROM JF77062.TB_DMAT04_TransmitidoAgosto2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE EstadoCredito IN ('1', '2') AND TipoCredito NOT IN ('1', '2', '3', '6', '8', '4', '5'))

UPDATE T1
SET T1.TipoCredito = T2.TipoCredito
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN JF77062.TB_DMAT04_TransmitidoAgosto2019 AS T2
		ON T1.NumeroCredito = T2.NumeroCredito
WHERE T1.EstadoCredito IN ('1', '2') AND T1.TipoCredito NOT IN ('1', '2', '3', '6', '8', '4', '5')

-- Como el valor del campo TIPO DE CREDITO es igual a 8, y el valor del campo ESTADO DEL CREDITO es distinto de 1 entonces deber�a cumplirse que el valor del campo TIPO DE INDUSTRIA sea igual a 0 

SELECT EstadoCredito, TipoCredito, TipoIndustria, * 
FROM JF77062.TB_DMAT04 
WHERE EstadoCredito NOT IN ('1') AND TipoCredito IN ('8') AND TipoIndustria <> '0'

UPDATE  JF77062.TB_DMAT04 
SET TipoIndustria = '0' 
WHERE EstadoCredito NOT IN ('1') AND TipoCredito IN ('8') AND TipoIndustria <> '0'

-- El campo 'CLIENTE_NUEVO' es obligatorio, por ende no puede estar vac�o Error cr�tico, proceso de validaci�n abortado

SELECT ClienteNuevo, * 
FROM JF77062.TB_DMAT04 
WHERE ClienteNuevo = ''

SELECT CLIENTE_NUEVO, * 
FROM RPT_STG_Dirigidas_MICROFINANCIERO 
WHERE NUM_CREDITO IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
					  WHERE ClienteNuevo = '')

UPDATE  JF77062.TB_DMAT04 
SET ClienteNuevo = '1' 
WHERE ClienteNuevo = ''

-- Como el valor del campo TIPO DE CREDITO es igual a uno de los siguientes valores: (4,6) entonces deber�a cumplirse que el valor del campo DIRECCION PROYECTO UNIDAD PRUDUCCION sea distinto de VACIO 
SELECT TipoCredito, DireccionProyectoUnidadProduccion, * 
FROM JF77062.TB_DMAT04 
WHERE TipoCredito IN ('4', '6') AND DireccionProyectoUnidadProduccion = ''

SELECT TipoCredito, DireccionProyectoUnidadProduccion, * FROM JF77062.TB_DMAT04_TransmitidoAgosto2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
						WHERE TipoCredito IN ('4', '6') AND DireccionProyectoUnidadProduccion = '')

UPDATE T1
SET T1.DireccionProyectoUnidadProduccion = T2.DireccionProyectoUnidadProduccion
FROM JF77062.TB_DMAT04 AS T1 
	INNER JOIN JF77062.TB_DMAT04_TransmitidoAgosto2019 AS T2
		ON T1.NumeroCredito = T2.NumeroCredito
WHERE T1.TipoCredito IN ('4', '6') AND T1.DireccionProyectoUnidadProduccion = ''
