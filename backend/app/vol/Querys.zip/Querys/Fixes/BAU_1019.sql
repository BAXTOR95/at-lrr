--- ComisionesCobrar No cumple con los par�metros de la tabla  -  0;99999999999.99

SELECT ComisionesCobrar, *
  FROM JF77062.TB_DMAT04
  WHERE ComisionesCobrar = '-1'

SELECT ComisionesCobrar, *
  FROM jf77062.TB_DMAT04_TransmitidoSeptiembre2019
  WHERE ComisionesCobrar <> 0

  SELECT ComisionesCobrar, * FROM jf77062.TB_DMAT04_TransmitidoSeptiembre2019
  WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  						WHERE ComisionesCobrar = '-1')

UPDATE JF77062.TB_DMAT04
SET ComisionesCobrar = '0'
WHERE ComisionesCobrar = '-1'

-- Si el valor del campo [Tipo de Cliente] es igual que (�E � Extranjero�), entonces el valor de este campo debe estar entre 1 y 1.500.000 o entre 80.000.000 y 100.000.000.

SELECT *
  FROM JF77062.TB_DMAT04
  WHERE IdentificacionCliente = '79401882'

SELECT IdentificacionCliente, * FROM jf77062.TB_DMAT04_TransmitidoSeptiembre2019
  WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04
  						WHERE IdentificacionCliente = '79401882')

SELECT *
FROM JF77062.TB_DMAT04
WHERE (CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 1 AND 1500000)
	  AND (CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 80000000 AND 100000000)
	  AND (TipoCliente = 'E')


UPDATE JF77062.TB_DMAT04
SET TipoCliente = 'P'
WHERE (CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 1 AND 1500000)
	  AND (CONVERT(DECIMAL(18, 0), IdentificacionCliente) NOT BETWEEN 80000000 AND 100000000)
	  AND (TipoCliente = 'E')

-- Si el valor del campo [Estado del Cr�dito] es igual que (�2 - Cancelado� � �3 � Castigado) entonces el valor de PocentajeProvisionEspecifica debe ser cero (�0�).

SELECT RendimientosCobrar, RendimientosCobrarVencidos, Saldo, EstadoCredito, ProvisionEspecifica, ProvisionRendimientoCobrar, PocentajeProvisionEspecifica, CuentaContableProvisionRendimiento, CuentaContableProvisionEspecifica, *
FROM JF77062.TB_DMAT04
WHERE EstadoCredito IN ('2', '3')
	  AND CONVERT(DECIMAL(18, 0), PocentajeProvisionEspecifica) <> 0

UPDATE JF77062.TB_DMAT04
SET PocentajeProvisionEspecifica = '0.0000'
WHERE EstadoCredito IN ('2', '3')
	  AND CONVERT(DECIMAL(18, 0), PocentajeProvisionEspecifica) <> 0

-- Si el valor del campo ["Provision del Rendimiento por Cobrar"] es igual que ("0"); entonces el valor de CuentaContableProvisionRendimiento debe ser igual que ("0 - No aplica")
SELECT RendimientosCobrar, RendimientosCobrarVencidos, Saldo, EstadoCredito, ProvisionEspecifica, ProvisionRendimientoCobrar, PocentajeProvisionEspecifica, CuentaContableProvisionRendimiento, CuentaContableProvisionEspecifica, *
FROM JF77062.TB_DMAT04
WHERE CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar, ',', '.')) = 0
	  AND CuentaContableProvisionRendimiento <> '0'

UPDATE JF77062.TB_DMAT04
SET CuentaContableProvisionRendimiento = '0'
WHERE CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar, ',', '.')) = 0
	  AND CuentaContableProvisionRendimiento <> '0'

-- UPDATES PUNTUALES

UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '4,0000' WHERE NumeroCredito = '8173270302'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '8,0000' WHERE NumeroCredito = '8183240301'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '8,0000' WHERE NumeroCredito = '8190520301'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '7,0000' WHERE NumeroCredito = '8190880304'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '3,0000' WHERE NumeroCredito = '8191780303'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '6,0000' WHERE NumeroCredito = '8192200301'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '6,0000' WHERE NumeroCredito = '8192280303'
UPDATE  JF77062.TB_DMAT04 SET PocentajeProvisionEspecifica = '3,0000' WHERE NumeroCredito = '8192840301'

UPDATE  JF77062.TB_DMAT04 SET ProvisionEspecifica = '-9000000,00' WHERE NumeroCredito = '8192840301'

UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-0.18' WHERE NumeroCredito = '8173270302'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-767.64' WHERE NumeroCredito = '8183240301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-1501.5' WHERE NumeroCredito = '8183310302'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-32.9' WHERE NumeroCredito = '8183410301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-1031.25' WHERE NumeroCredito = '8190510301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-837.23' WHERE NumeroCredito = '8190520301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-52888.89' WHERE NumeroCredito = '8190880303'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-52888.89' WHERE NumeroCredito = '8190880304'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-41261.57' WHERE NumeroCredito = '8191290301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-482902.1' WHERE NumeroCredito = '8191340308'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-228895.01' WHERE NumeroCredito = '8191370302'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-409360' WHERE NumeroCredito = '8191440301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-5333.33' WHERE NumeroCredito = '8191780303'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-34000' WHERE NumeroCredito = '8191980301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-10200' WHERE NumeroCredito = '8192040301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-448939.73' WHERE NumeroCredito = '8192200301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-352339.17' WHERE NumeroCredito = '8192280302'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-686070' WHERE NumeroCredito = '8192280303'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-880968.63' WHERE NumeroCredito = '8192320301'
UPDATE  JF77062.TB_DMAT04 SET ProvisionRendimientoCobrar = '-189000' WHERE NumeroCredito = '8192840301'

UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19980217' WHERE NumeroCredito = '8112800309'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19980217' WHERE NumeroCredito = '8112800339'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19980217' WHERE NumeroCredito = '8112800340'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19980217' WHERE NumeroCredito = '8112800341'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19980217' WHERE NumeroCredito = '8112800342'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19980217' WHERE NumeroCredito = '8112800343'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19980217' WHERE NumeroCredito = '8120900305'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20190504' WHERE NumeroCredito = '8121520302'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19980504' WHERE NumeroCredito = '8121520303'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20060518' WHERE NumeroCredito = '8173270302'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20140820' WHERE NumeroCredito = '8182900306'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19720828' WHERE NumeroCredito = '8183040302'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19720828' WHERE NumeroCredito = '8183240301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19990803' WHERE NumeroCredito = '8183310302'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20151014' WHERE NumeroCredito = '8183410301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19990803' WHERE NumeroCredito = '8190510301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19720828' WHERE NumeroCredito = '8190520301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20161222' WHERE NumeroCredito = '8190880303'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20161221' WHERE NumeroCredito = '8190880304'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20140324' WHERE NumeroCredito = '8191340308'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20151014' WHERE NumeroCredito = '8191370302'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19990803' WHERE NumeroCredito = '8191440301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20060411' WHERE NumeroCredito = '8191780303'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19990803' WHERE NumeroCredito = '8191980301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20151014' WHERE NumeroCredito = '8192040301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20130820' WHERE NumeroCredito = '8192200301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19990803' WHERE NumeroCredito = '8192280302'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20141120' WHERE NumeroCredito = '8192280303'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20141229' WHERE NumeroCredito = '8192320301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20151014' WHERE NumeroCredito = '8192760302'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19990803' WHERE NumeroCredito = '8192760303'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '20151014' WHERE NumeroCredito = '8192830301'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19990803' WHERE NumeroCredito = '8192830304'
UPDATE  JF77062.TB_DMAT04 SET FechaNacimiento = '19980326' WHERE NumeroCredito = '8192840301'


SELECT ProvisionRendimientoCobrar, NumeroCredito, CuentaContableProvisionRendimiento
FROM JF77062.TB_DMAT04
WHERE CONVERT(DECIMAL(18, 2), REPLACE(ProvisionRendimientoCobrar, ',', '.')) <> 0
And CuentaContableProvisionRendimiento = '0'

SELECT ProvisionRendimientoCobrar, NumeroCredito, CuentaContableProvisionRendimiento
FROM JF77062.TB_DMAT04
WHERE NumeroCredito = '7026702997'


SELECT NumeroCredito, FechaNacimiento, TipoCliente, IdentificacionCliente, *
FROM jf77062.TB_DMAT04_TransmitidoSeptiembre2019
WHERE NumeroCredito IN (SELECT DISTINCT NumeroCredito FROM JF77062.TB_DMAT04 
		WHERE NumeroCredito IN ('1110157', '119657', '153086', '156626', '18986', '19930'))

SELECT DISTINCT NumeroCredito, FechaNacimiento, TipoCliente, IdentificacionCliente, * FROM JF77062.TB_DMAT04 
		WHERE NumeroCredito IN ('1110157', '119657', '153086', '156626', '18986', '19930')

UPDATE
  T1
SET
  T1.IdentificacionCliente = T2.IdentificacionCliente
FROM
  JF77062.TB_DMAT04 AS T1
  INNER JOIN jf77062.TB_DMAT04_TransmitidoSeptiembre2019 AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.NumeroCredito IN ('1110157', '119657', '153086', '156626', '18986', '19930')

UPDATE
  T1
SET
  T1.IdentificacionTipoClienteRIF = T2.IdentificacionCliente
FROM
  JF77062.TB_DMAT04 AS T1
  INNER JOIN jf77062.TB_DMAT04_TransmitidoSeptiembre2019 AS T2
  ON T1.NumeroCredito = T2.NumeroCredito
WHERE
  T1.NumeroCredito IN ('1110157', '119657', '153086', '156626', '18986', '19930')

UPDATE
  JF77062.TB_DMAT04
SET
  FechaNacimiento = '19780215'
WHERE
  NumeroCredito = '7026702997'