-- PARA TITAN
SELECT
  NumeroCredito,
  REPLACE(FechaLiquidacion, '/', '') AS FechaLiquidacion,
  REPLACE(FechaSolicitud, '/', '') AS FechaSolicitud,
  REPLACE(FechaAprobacion, '/', '') AS FechaAprobacion,
  CAST(
    CAST (Oficina AS NUMERIC(19, 4)) AS INT
  ) AS Oficina,
  CodigoContable,
  NumeroCreditoPrimerDesembolso,
  NumeroDesembolso,
  CodigoLineaCredito,
  REPLACE(MontoLineaCredito, ',', '.') AS MontoLineaCredito,
  EstadoCredito,
  TipoCredito,
  SituacionCredito,
  PlazoCredito,
  ClasificacionRiesgo,
  DestinoCredito,
  NaturalezaCliente,
  TipoCliente,
  IdentificacionCliente,
  Nombre_RazonSocial,
  Genero,
  TipoClienteRIF,
  IdentificacionTipoClienteRIF,
  ActividadCliente,
  PaisNacionalidad,
  DomicilioFiscal,
  ClienteNuevo,
  Cooperativa,
  Sindicado,
  BancoLiderSindicato,
  RelacionCrediticia,
  GrupoEconomicoFinanciero,
  NombreGrupoEconomicoFinanciero,
  CodigoParroquia,
  PeriodoGraciaCapital,
  PeriodicidadPagoCapital,
  PeriodicidadPagoInteresCredito,
  REPLACE(FechaVencimientoOriginal, '/', '') AS FechaVencimientoOriginal,
  REPLACE(FechaVencimientoActual, '/', '') AS FechaVencimientoActual,
  REPLACE(FechaReestructuracion, '/', '') AS FechaReestructuracion,
  CantidadProrroga,
  REPLACE(FechaProrroga, '/', '') AS FechaProrroga,
  CantidadRenovaciones,
  REPLACE(FechaUltimaRenovacion, '/', '') AS FechaUltimaRenovacion,
  REPLACE(FechaCancelacionTotal, '/', '') AS FechaCancelacionTotal,
  REPLACE(FechaVencimientoUltimaCoutaCapital, '/', '') AS FechaVencimientoUltimaCoutaCapital,
  REPLACE(UltimaFechaCancelacionCuotaCapital, '/', '') AS UltimaFechaCancelacionCuotaCapital,
  REPLACE(FechaVencimientoUltimaCuotaInteres, '/', '') AS FechaVencimientoUltimaCuotaInteres,
  REPLACE(UltimaFechaCancelacionCuotaIntereses, '/', '') AS UltimaFechaCancelacionCuotaIntereses,
  Moneda,
  TipoCambioOriginal,
  TipoCambioCierreMes,
  REPLACE(MontoOriginal, ',', '.') AS MontoOriginal,
  REPLACE(MontoInicial, ',', '.') AS MontoInicial,
  MontoLiquidadoMes,
  EntePublico,
  MontoInicialTerceros,
  REPLACE(Saldo, ',', '.') AS Saldo,
  REPLACE(RendimientosCobrar, ',', '.') AS RendimientosCobrar,
  REPLACE(RendimientosCobrarVencidos, ',', '.') AS RendimientosCobrarVencidos,
  REPLACE(RendimientosCobrarMora, ',', '.') AS RendimientosCobrarMora,
  REPLACE(ProvisionEspecifica, ',', '.') AS ProvisionEspecifica,
  REPLACE(PocentajeProvisionEspecifica, ',', '.') AS PocentajeProvisionEspecifica,
  REPLACE(ProvisionRendimientoCobrar, ',', '.') AS ProvisionRendimientoCobrar,
  REPLACE(TasasInteresCobrada, ',', '.') AS TasasInteresCobrada,
  REPLACE(TasasInteresActual, ',', '.') AS TasasInteresActual,
  IndicadorTasaPreferencial,
  REPLACE(TasaComision, ',', '.') AS TasaComision,
  ComisionesCobrar,
  ComisionesCobradas,
  REPLACE(ErogacionesRecuperables, ',', '.') AS ErogacionesRecuperables,
  TipoGarantiaPrincipal,
  NumeroCuotas,
  NumeroCuotasVencidas,
  REPLACE(MontoVencido30dias, ',', '.') AS MontoVencido30dias,
  REPLACE(MontoVencido60dias, ',', '.') AS MontoVencido60dias,
  REPLACE(MontoVencido90dias, ',', '.') AS MontoVencido90dias,
  REPLACE(MontoVencido120dias, ',', '.') AS MontoVencido120dias,
  REPLACE(MontoVencido180dias, ',', '.') AS MontoVencido180dias,
  REPLACE(MontoVencidoUnAno, ',', '.') AS MontoVencidoUnAno,
  REPLACE(MontoVencidoMasUnAno, ',', '.') AS MontoVencidoMasUnAno,
  REPLACE(MontoVencer30dias, ',', '.') AS MontoVencer30dias,
  REPLACE(MontoVencer60dias, ',', '.') AS MontoVencer60dias,
  REPLACE(MontoVencer90dias, ',', '.') AS MontoVencer90dias,
  REPLACE(MontoVencer120dias, ',', '.') AS MontoVencer120dias,
  REPLACE(MontoVencer180dias, ',', '.') AS MontoVencer180dias,
  REPLACE(MontoVencerUnAno, ',', '.') AS MontoVencerUnAno,
  REPLACE(MontoVencerMasUnAno, ',', '.') AS MontoVencerMasUnAno,
  BancaSocial,
  UnidadProduccionSocial,
  ModalidadMicrocredito,
  UsoFinanciero,
  DestinoRecursosMicrofinancieros,
  CantidadTrabajadores,
  VentaAnuales,
  REPLACE(FechaEstadoFinanciero, '/', '') AS FechaEstadoFinanciero,
  NumeroRTN,
  LicenciaTuristicaNacional,
  REPLACE(
    FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
    '/',
    ''
  ) AS FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
  NumeroExpedienteFactibilidadSociotecnica,
  NumeroExpedienteConformidadTuristica,
  NombreProyectoUnidadProduccion,
  DireccionProyectoUnidadProduccion,
  CodigoTipoProyecto,
  CodigoTipoOperacionesFinanciamiento,
  CodigoSegmento,
  TipoZona,
  REPLACE(FechaAutenticacionProtocolizacion, '/', '') AS FechaAutenticacionProtocolizacion,
  REPLACE(FechaUltimaInspeccion, '/', '') AS FechaUltimaInspeccion,
  REPLACE(PorcentajeEjecucionProyecto, ',', '.') AS PorcentajeEjecucionProyecto,
  REPLACE(PagosEfectuadosDuranteMes, ',', '.') AS PagosEfectuadosDuranteMes,
  REPLACE(MontosLiquidadosFechaCierre, ',', '.') AS MontosLiquidadosFechaCierre,
  REPLACE(AmortizacionesCapitalAcumuladasFecha, ',', '.') AS AmortizacionesCapitalAcumuladasFecha,
  TasaIncentivo,
  NumeroOficioIncentivo,
  NumeroRegistro_ConstanciaMPPAT,
  TipoRegistro_ConstanciaMPPAT,
  REPLACE(
    FechaVencimientoRegistro_ConstanciaMPPAT,
    '/',
    ''
  ) AS FechaVencimientoRegistro_ConstanciaMPPAT,
  CAST(TipoSubsector AS NUMERIC(19, 0)) AS TipoSubsector,
  Rubro,
  CodigoUso,
  REPLACE(CantidadUnidades, ',', '.') AS CantidadUnidades,
  CodigoUnidadMedida,
  SectorProduccion,
  CantidadHectareas,
  SuperficieTotalPropiedad,
  NumeroProductoresBeneficiarios,
  Prioritario,
  DestinoManufacturero,
  DestinoEconomico,
  CAST(TipoBeneficiario AS NUMERIC(19, 0)) AS TipoBeneficiario,
  ModalidadHipoteca,
  IngresoFamiliar,
  MontoLiquidadoDuranteAnoCurso,
  SaldoCredito31_12,
  CantidadViviendasConstruir,
  REPLACE(RendimientosCobrarReestructurados, ',', '.') AS RendimientosCobrarReestructurados,
  REPLACE(RendimientosCobrarAfectosReporto, ',', '.') AS RendimientosCobrarAfectosReporto,
  REPLACE(RendimientosCobrarLitigio, ',', '.') AS RendimientosCobrarLitigio,
  REPLACE(InteresEfectivamenteCobrado, ',', '.') AS InteresEfectivamenteCobrado,
  REPLACE(PorcentajeComisionFlat, ',', '.') AS PorcentajeComisionFlat,
  REPLACE(MontoComisionFlat, ',', '.') AS MontoComisionFlat,
  CAST(
    CAST (PeriocidadPagoEspecialCapital AS NUMERIC(19, 4)) AS INT
  ) AS PeriocidadPagoEspecialCapital,
  REPLACE(FechaCambioEstatusCredito, '/', '') AS FechaCambioEstatusCredito,
  REPLACE(FechaRegistroVencidaLitigiooCastigada, '/', '') AS FechaRegistroVencidaLitigiooCastigada,
  REPLACE(FechaExigibilidadPagoUltimaCuotaPagada, '/', '') AS FechaExigibilidadPagoUltimaCuotaPagada,
  CuentaContableProvisionEspecifica,
  CuentaContableProvisionRendimiento,
  CuentaContableInteresCuentaOrden,
  REPLACE(MontoInteresCuentaOrden, ',', '.') AS MontoInteresCuentaOrden,
  CAST(TipoIndustria AS NUMERIC(19, 0)) AS TipoIndustria,
  CAST(
    TipoBeneficiarioSectorManufacturero AS NUMERIC(19, 0)
  ) AS TipoBeneficiarioSectorManufacturero,
  CAST(TipoBeneficiarioSectorTurismo AS NUMERIC(19, 0)) AS TipoBeneficiarioSectorTurismo,
  CAST(BeneficiarioEspecial AS NUMERIC(19, 0)) AS BeneficiarioEspecial,
  FechaEmisionCertificacionBeneficiarioEspecial,
  CAST(TipoVivienda AS NUMERIC(19, 0)) AS TipoVivienda,
  REPLACE(FechaFinPeriodoGraciaPagoInteres, '/', '') AS FechaFinPeriodoGraciaPagoInteres,
  REPLACE(CapitalTransferido, ',', '.') AS CapitalTransferido,
  REPLACE(FechaCambioEstatusCapitalTransferido, '/', '') AS FechaCambioEstatusCapitalTransferido
FROM JF77062.TB_DMAT04
ORDER BY
  NumeroCredito;
-- REPORTE FINAL
SELECT
  NumeroCredito,
  REPLACE(FechaLiquidacion, '/', '') AS FechaLiquidacion,
  REPLACE(FechaSolicitud, '/', '') AS FechaSolicitud,
  REPLACE(FechaAprobacion, '/', '') AS FechaAprobacion,
  RIGHT(
    '0000' + CAST(
      CAST(
        CAST (Oficina AS NUMERIC(19, 4)) AS INT
      ) AS VARCHAR(4)
    ),
    4
  ) AS Oficina,
  CodigoContable,
  NumeroCreditoPrimerDesembolso,
  NumeroDesembolso,
  CodigoLineaCredito,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoLineaCredito, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoLineaCredito,
  EstadoCredito,
  TipoCredito,
  SituacionCredito,
  PlazoCredito,
  ClasificacionRiesgo,
  DestinoCredito,
  NaturalezaCliente,
  TipoCliente,
  IdentificacionCliente,
  Nombre_RazonSocial,
  Genero,
  TipoClienteRIF,
  IdentificacionTipoClienteRIF,
  ActividadCliente,
  PaisNacionalidad,
  DomicilioFiscal,
  ClienteNuevo,
  Cooperativa,
  REPLACE(
    CAST(
      CAST(REPLACE(Sindicado, ',', '.') AS NUMERIC(19, 4)) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS Sindicado,
  BancoLiderSindicato,
  RelacionCrediticia,
  GrupoEconomicoFinanciero,
  NombreGrupoEconomicoFinanciero,
  CodigoParroquia,
  PeriodoGraciaCapital,
  PeriodicidadPagoCapital,
  PeriodicidadPagoInteresCredito,
  REPLACE(FechaVencimientoOriginal, '/', '') AS FechaVencimientoOriginal,
  REPLACE(FechaVencimientoActual, '/', '') AS FechaVencimientoActual,
  REPLACE(FechaReestructuracion, '/', '') AS FechaReestructuracion,
  CantidadProrroga,
  REPLACE(FechaProrroga, '/', '') AS FechaProrroga,
  CantidadRenovaciones,
  REPLACE(FechaUltimaRenovacion, '/', '') AS FechaUltimaRenovacion,
  REPLACE(FechaCancelacionTotal, '/', '') AS FechaCancelacionTotal,
  REPLACE(FechaVencimientoUltimaCoutaCapital, '/', '') AS FechaVencimientoUltimaCoutaCapital,
  REPLACE(UltimaFechaCancelacionCuotaCapital, '/', '') AS UltimaFechaCancelacionCuotaCapital,
  REPLACE(FechaVencimientoUltimaCuotaInteres, '/', '') AS FechaVencimientoUltimaCuotaInteres,
  REPLACE(UltimaFechaCancelacionCuotaIntereses, '/', '') AS UltimaFechaCancelacionCuotaIntereses,
  Moneda,
  REPLACE(
    CAST(
      CAST(
        REPLACE(TipoCambioOriginal, ',', '.') AS NUMERIC(19, 4)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS TipoCambioOriginal,
  REPLACE(
    CAST(
      CAST(
        REPLACE(TipoCambioCierreMes, ',', '.') AS NUMERIC(19, 4)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS TipoCambioCierreMes,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoOriginal, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoOriginal,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoInicial, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoInicial,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoLiquidadoMes, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoLiquidadoMes,
  EntePublico,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoInicialTerceros, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoInicialTerceros,
  --
  REPLACE(
    CAST(
      CAST(REPLACE(Saldo, ',', '.') AS NUMERIC(19, 2)) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS Saldo,
  REPLACE(
    CAST(
      CAST(
        REPLACE(RendimientosCobrar, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS RendimientosCobrar,
  REPLACE(
    CAST(
      CAST(
        REPLACE(RendimientosCobrarVencidos, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS RendimientosCobrarVencidos,
  REPLACE(
    CAST(
      CAST(
        REPLACE(RendimientosCobrarMora, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS RendimientosCobrarMora,
  REPLACE(
    CAST(
      CAST(
        REPLACE(ProvisionEspecifica, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS ProvisionEspecifica,
  REPLACE(
    CAST(
      CAST(
        REPLACE(PocentajeProvisionEspecifica, ',', '.') AS NUMERIC(19, 4)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS PocentajeProvisionEspecifica,
  REPLACE(
    CAST(
      CAST(
        REPLACE(ProvisionRendimientoCobrar, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS ProvisionRendimientoCobrar,
  REPLACE(
    CAST(
      CAST(
        REPLACE(TasasInteresCobrada, ',', '.') AS NUMERIC(19, 4)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS TasasInteresCobrada,
  REPLACE(
    CAST(
      CAST(
        REPLACE(TasasInteresActual, ',', '.') AS NUMERIC(19, 4)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS TasasInteresActual,
  IndicadorTasaPreferencial,
  REPLACE(
    CAST(
      CAST(
        REPLACE(TasaComision, ',', '.') AS NUMERIC(19, 4)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS TasaComision,
  REPLACE(
    CAST(
      CAST(
        REPLACE(ComisionesCobrar, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS ComisionesCobrar,
  REPLACE(
    CAST(
      CAST(
        REPLACE(ComisionesCobradas, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS ComisionesCobradas,
  REPLACE(
    CAST(
      CAST(
        REPLACE(ErogacionesRecuperables, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS ErogacionesRecuperables,
  TipoGarantiaPrincipal,
  NumeroCuotas,
  NumeroCuotasVencidas,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencido30dias, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencido30dias,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencido60dias, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencido60dias,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencido90dias, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencido90dias,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencido120dias, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencido120dias,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencido180dias, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencido180dias,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencidoUnAno, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencidoUnAno,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencidoMasUnAno, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencidoMasUnAno,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencer30dias, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencer30dias,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencer60dias, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencer60dias,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencer90dias, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencer90dias,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencer120dias, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencer120dias,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencer180dias, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencer180dias,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencerUnAno, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencerUnAno,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoVencerMasUnAno, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoVencerMasUnAno,
  BancaSocial,
  UnidadProduccionSocial,
  ModalidadMicrocredito,
  UsoFinanciero,
  DestinoRecursosMicrofinancieros,
  CantidadTrabajadores,
  REPLACE(
    CAST(
      CAST(
        REPLACE(VentaAnuales, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS VentaAnuales,
  REPLACE(FechaEstadoFinanciero, '/', '') AS FechaEstadoFinanciero,
  NumeroRTN,
  LicenciaTuristicaNacional,
  REPLACE(
    FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
    '/',
    ''
  ) AS FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
  NumeroExpedienteFactibilidadSociotecnica,
  NumeroExpedienteConformidadTuristica,
  NombreProyectoUnidadProduccion,
  DireccionProyectoUnidadProduccion,
  CodigoTipoProyecto,
  CodigoTipoOperacionesFinanciamiento,
  CodigoSegmento,
  TipoZona,
  REPLACE(FechaAutenticacionProtocolizacion, '/', '') AS FechaAutenticacionProtocolizacion,
  REPLACE(FechaUltimaInspeccion, '/', '') AS FechaUltimaInspeccion,
  REPLACE(
    CAST(
      CAST(
        REPLACE(PorcentajeEjecucionProyecto, ',', '.') AS NUMERIC(19, 4)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS PorcentajeEjecucionProyecto,
  REPLACE(
    CAST(
      CAST(
        REPLACE(PagosEfectuadosDuranteMes, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS PagosEfectuadosDuranteMes,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontosLiquidadosFechaCierre, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontosLiquidadosFechaCierre,
  REPLACE(
    CAST(
      CAST(
        REPLACE(AmortizacionesCapitalAcumuladasFecha, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS AmortizacionesCapitalAcumuladasFecha,
  TasaIncentivo,
  NumeroOficioIncentivo,
  NumeroRegistro_ConstanciaMPPAT,
  TipoRegistro_ConstanciaMPPAT,
  REPLACE(
    FechaVencimientoRegistro_ConstanciaMPPAT,
    '/',
    ''
  ) AS FechaVencimientoRegistro_ConstanciaMPPAT,
  CAST(TipoSubsector AS NUMERIC(19, 0)) AS TipoSubsector,
  Rubro,
  CodigoUso,
  REPLACE(
    CAST(
      CAST(
        REPLACE(CantidadUnidades, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS CantidadUnidades,
  CodigoUnidadMedida,
  SectorProduccion,
  REPLACE(
    CAST(
      CAST(
        REPLACE(CantidadHectareas, ',', '.') AS NUMERIC(19, 4)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS CantidadHectareas,
  REPLACE(
    CAST(
      CAST(
        REPLACE(SuperficieTotalPropiedad, ',', '.') AS NUMERIC(19, 4)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS SuperficieTotalPropiedad,
  NumeroProductoresBeneficiarios,
  Prioritario,
  DestinoManufacturero,
  DestinoEconomico,
  CAST(TipoBeneficiario AS NUMERIC(19, 0)) AS TipoBeneficiario,
  ModalidadHipoteca,
  REPLACE(
    CAST(
      CAST(
        REPLACE(IngresoFamiliar, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS IngresoFamiliar,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoLiquidadoDuranteAnoCurso, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoLiquidadoDuranteAnoCurso,
  REPLACE(
    CAST(
      CAST(
        REPLACE(SaldoCredito31_12, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS SaldoCredito31_12,
  CantidadViviendasConstruir,
  REPLACE(
    CAST(
      CAST(
        REPLACE(RendimientosCobrarReestructurados, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS RendimientosCobrarReestructurados,
  REPLACE(
    CAST(
      CAST(
        REPLACE(RendimientosCobrarAfectosReporto, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS RendimientosCobrarAfectosReporto,
  REPLACE(
    CAST(
      CAST(
        REPLACE(RendimientosCobrarLitigio, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS RendimientosCobrarLitigio,
  REPLACE(
    CAST(
      CAST(
        REPLACE(InteresEfectivamenteCobrado, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS InteresEfectivamenteCobrado,
  REPLACE(
    CAST(
      CAST(
        REPLACE(PorcentajeComisionFlat, ',', '.') AS NUMERIC(19, 4)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS PorcentajeComisionFlat,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoComisionFlat, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoComisionFlat,
  CAST(
    CAST (PeriocidadPagoEspecialCapital AS NUMERIC(19, 4)) AS INT
  ) AS PeriocidadPagoEspecialCapital,
  REPLACE(FechaCambioEstatusCredito, '/', '') AS FechaCambioEstatusCredito,
  REPLACE(FechaRegistroVencidaLitigiooCastigada, '/', '') AS FechaRegistroVencidaLitigiooCastigada,
  REPLACE(FechaExigibilidadPagoUltimaCuotaPagada, '/', '') AS FechaExigibilidadPagoUltimaCuotaPagada,
  CuentaContableProvisionEspecifica,
  CuentaContableProvisionRendimiento,
  CuentaContableInteresCuentaOrden,
  REPLACE(
    CAST(
      CAST(
        REPLACE(MontoInteresCuentaOrden, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS MontoInteresCuentaOrden,
  CAST(TipoIndustria AS NUMERIC(19, 0)) AS TipoIndustria,
  CAST(
    TipoBeneficiarioSectorManufacturero AS NUMERIC(19, 0)
  ) AS TipoBeneficiarioSectorManufacturero,
  CAST(TipoBeneficiarioSectorTurismo AS NUMERIC(19, 0)) AS TipoBeneficiarioSectorTurismo,
  CAST(BeneficiarioEspecial AS NUMERIC(19, 0)) AS BeneficiarioEspecial,
  FechaEmisionCertificacionBeneficiarioEspecial,
  CAST(TipoVivienda AS NUMERIC(19, 0)) AS TipoVivienda,
  REPLACE(FechaFinPeriodoGraciaPagoInteres, '/', '') AS FechaFinPeriodoGraciaPagoInteres,
  REPLACE(
    CAST(
      CAST(
        REPLACE(CapitalTransferido, ',', '.') AS NUMERIC(19, 2)
      ) AS VARCHAR(26)
    ),
    '.',
    ','
  ) AS CapitalTransferido,
  REPLACE(FechaCambioEstatusCapitalTransferido, '/', '') AS FechaCambioEstatusCapitalTransferido,
  REPLACE(FechaNacimiento, '/', '') AS FechaNacimiento,
  '0,00' AS UnidadValoracionAT04
FROM JF77062.TB_DMAT04
ORDER BY
  NumeroCredito;