USE [FINDWH_1]
GO
/****** Object:  StoredProcedure [dbo].[SP_AT04Transformada]    Script Date: 06/28/2018 15:55:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

ALTER PROCEDURE [dbo].[SP_AT04Transformada] 
(
@FechaReportar AS VARCHAR (10)
)
AS

--DECLARO VARIBLES DE MANEJO DE ERROR
DECLARE @SpProcess NVARCHAR(4000);
DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity NVARCHAR(4000);
DECLARE @ErrorState NVARCHAR(4000); 
DECLARE @ErrorLine NVARCHAR(4000);

---
--variable para comparar
DECLARE @Cero DECIMAL(18,2);
SET @Cero = 0.00;

/*
******INDICE QUERY******
Tipo DC 8 Cartera Turismo
Tipo DC 12 Cartera Agricola Consumer
Tipo DC 11 Cartera Agricola Corporate
Tipo DC 10 Cartera Manufactura
Tipo DC 7 Cartera Hipotecario Corto Plazo
Tipo DC 6 Cartera Hipotecario Largo Plazo
Tipo DC 6 Cartera Hipotecario Largo Plazo (actualizaciones posteriores)
Tipo DC 9 Cartera MicroFinanciero
Tipo DC 9 Cartera MicroFinanciero (ajustes posteriores)
Tipo DC 1 Cartera Creditos al Consumo
Tipo DC 1 Cartera Creditos al Consumo (Ajustes Posteriores)
Tipo DC 3 PIL
Tipo DC 3 RRHH
Tipo DC 3 (Actualizaciones Posteriores)
Tipo DC 2 Credicheque
Tipo DC 2 Credicheque (Actualizaciones Posteriores)
Tipo DC 4 Rewrites 
Tipo DC 4 Rewrites (Actualizaciones Posteriores)
Tipo DC 5 TDC
Tipo DC 5 TDC (Actualizaciones posteriores)
Tipo DC 13 Corporativa No Dirigida 
Tipo DC 14 CARROS
Tipo DC 15 PIL SEGUROS
Tipo DC 16 SOBREGIROS
Tipo DC Actualizaciones Puntuales
*/

SET NOCOUNT ON;

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Inicio el proceso de ejecución de transformada del AT04 - ', NULL, NULL, 'ATOMATICO'
------------------------------------------------ COMIENZO DE EJECUCION TRANSFORMADA -----------------------------------------------------
--limpio la tabla	
TRUNCATE TABLE jf77062.TB_DMAT04 
EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se limpia la tabla DM del AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
BEGIN TRY -- Tipo DC 8 Cartera Turismo
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	SELECT 
		NUM_CREDITO AS 'NUM_CREDITO',
		CONVERT(VARCHAR(10),C.FECHA_LIQUIDACION,111) AS 'FECHA_LIQUIDACION',
		CONVERT(VARCHAR(10),C.FECHA_SOLICITUD,111) AS 'FECHA_SOLICITUD',
		CONVERT(VARCHAR(10),C.FECHA_APROBACION,111) AS 'FECHA_APROBACION',
	
		CASE 
			WHEN CONVERT(INT,C.COD_OFICINA) = 1 THEN '02'  
			ELSE CONVERT(INT,C.COD_OFICINA)
		END AS 'Oficina',--YR 14/08/2012
	
		C.COD_CONTABLE,
		CONVERT(DECIMAL,RTRIM(LTRIM(C.NUM_CREDITO_PRIMER_DESEMBOLSO))) AS 'NUM_CREDITO_PRIMER_DESEMBOLSO',
		CONVERT(INT,C.NUM_DESEMBOLSO) AS 'NUM_DESEMBOLSO',
		'1' AS 'CodigodeLineadeCredito',
		CONVERT(DECIMAL(15,4),RTRIM(LTRIM(C.MONTO_INICIAL))) AS 'MONTO_INICIAL', 
		C.ESTADO_CREDITO,
		CASE 
			WHEN C.ESTADO_CREDITO = '3' THEN '0'  
			ELSE C.TIPO_CREDITO
		END AS 'TipoCredito',--YR 14/08/2012
	
		C.SITUACION_CREDITO,
		CASE C.PLAZO_CREDITO
			WHEN '1' THEN 'C'
			WHEN '2' THEN 'M'
			WHEN '3' THEN 'L'
			ELSE PLAZO_CREDITO
		END AS 'PLAZO_CREDITO', --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		C.CLASE_RIESGO,
		'N77' AS 'DestinoDelCredito', --fz
		C.NATURALEZA_CLIENTE,
		C.TIPO_CLIENTE,
		RIGHT(C.NUM_CLIENTE,9) AS 'NUM_CLIENTE', --fz
		REPLACE(LTRIM(RTRIM(UPPER(C.NOMBRE_CLIENTE))),'''','´') AS 'NOMBRE_CLIENTE',
		CASE 
			WHEN C.GENERO IN ('1','2', '0') THEN C.GENERO --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		C.TIPO_CLIENTE AS 'TipoClienteRIF',
		RIGHT(C.NUM_CLIENTE,9) AS 'IdentificacionTipoClienteRIF',
		ISNULL(Equi.CodigoSIF,'XXX') AS 'Actividad del Cliente', --OJO actualizar y obtener del SICVEN ---YR 14/08/2012 XXX
		CASE 
			WHEN UPPER(C.TIPO_CLIENTE) IN ('V','J','G') THEN 'VE' --fz
			ELSE 'XX'
		END AS 'Pais_Nacionalidad',
		LEFT(REPLACE(LTRIM(RTRIM(UPPER(DC04.ADDRESS3 + ' ' + DC04.ADDRESS4  + ' ' +  DC04.ADDRESS5  + ' ' +  DC04.ADDRESS6))),'''','´'),200) AS 'Domicilio_Fiscal', --fz
		CLIENTE_NUEVO,
		COOPERATIVA,
		'0' AS Sindicado, --Valor por defecto
		'0' As 'BancoLiderSindicado', --Valor por defecto
		'1' AS 'RelacionCrediticia', --Valor por defecto
		'1' AS 'GrupoEconomicoFinanciero', --Valor por defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por defecto
		ISNULL(COD_PARROQUIA,'010109') AS 'COD_PARROQUIA',
		CONVERT(INT,PERIODO_GRACIA_CAPITAL) AS PERIODO_GRACIA_CAPITAL,
		CONVERT(INT,PERIODO_PAGO_CAPITAL) AS PERIODO_PAGO_CAPITAL,
		CONVERT(INT,PERIODO_PAGO_INTERES) AS PERIODO_PAGO_INTERES,
		CONVERT(VARCHAR(10),FECHA_VENC_ORIGINAL,111) AS 'FECHA_VENC_ORIGINAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ACTUAL,111) AS 'FECHA_VENC_ACTUAL',
		CONVERT(VARCHAR(10),FECHA_REESTRUCTURACION,111) AS 'FECHA_REESTRUCTURACION',
		CONVERT(INT,CANT_PRORROGAS) AS 'CANT_PRORROGAS',
		CONVERT(VARCHAR(10),FECHA_PRORROGA,111) AS 'FECHA_PRORROGA',
		CONVERT(INT,CANT_RENOVACIONES) AS 'CANT_RENOVACIONES',
		CONVERT(VARCHAR(10),FECHA_ULTIMA_RENOVACION,111) AS 'FECHA_ULTIMA_RENOVACION',
		CONVERT(VARCHAR(10),FECHA_CANCEL,111) AS 'FECHA_CANCEL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_CAPITAL,111) AS 'FECHA_VENC_ULTIMA_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_INTERES,111) AS 'FECHA_VENC_ULTIMA_CUOTA_INTERES',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_INTERES,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_INTERES',
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),MONTO_ORIGINAL) AS 'MONTO_ORIGINAL',
		CONVERT(DECIMAL(15,4),MONTO_INICIAL) AS 'MONTO_INICIAL',
		CONVERT(DECIMAL(15,4),MONTO_LIQUIDADO_MES) AS 'MONTO_LIQUIDADO_MES',
		'0' As 'EntePublico', -- Valor por Defecto
		'0' AS 'MontoInicialTerceros', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),C.SALDO) AS 'SALDO',
		RENDIMIENTOS_X_COBRAR AS 'RENDIMIENTOS_X_COBRAR',
		RENDIMIENTOS_X_COBRAR_VENCIDOS AS 'RENDIMIENTOS_X_COBRAR_VENCIDOS',
		0.00 AS 'RendimientosCobrarMora', 
		CASE 
		WHEN C.ESTADO_CREDITO IN ('2','3') THEN '0'  
		END,
		
		--	ELSE CONVERT(DECIMAL(15,4),PROVISION_ESPECIFICA)
		--END AS 'PROVISION_ESPECIFICA',--YR 14/08/2012
		--CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		
		C.PROVISION_ESPECIFICA AS 'PROVISION_ESPECIFICA',
		C.PORCENTAJE_PROVISION_ESPECIFICA AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		C.PROVISION_RENDIMIENTO_X_COBRAR AS 'PROVISION_RENDIMIENTO_X_COBRAR',
	
		CASE 
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS = @Cero THEN '0'  
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS > @Cero AND CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) = 0.0000 THEN -0.01 
			ELSE CONVERT(DECIMAL(15,4),PROVISION_RENDIMIENTO_X_COBRAR)
		END AS 'PROVISION_RENDIMIENTO_X_COBRAR',--YR 14/08/2012
	
		CONVERT(DECIMAL(15,4),TASA_INTERES_COBRADA) AS 'TASA_INTERES_COBRADA',
		CONVERT(DECIMAL(15,4),TASA_INTERES_ACTUAL) AS 'TASA_INTERES_ACTUAL',
		'1' AS 'IndicadorTasaPreferencial',
		CONVERT(DECIMAL(15,4),TASA_COMISION) AS 'TASA_COMISION',
		'0' AS 'ComisionesPorCobrar',
		'0' AS 'ComisionesCobradas',
		CONVERT(DECIMAL(15,4),EROGACIONES_RECUPERABLES) AS 'EROGACIONES_RECUPERABLES',
		CONVERT(INT,TIPO_GARANTIA_PRINCIPAL) AS 'TIPO_GARANTIA_PRINCIPAL', --fz
		CONVERT(INT,NUM_CUOTAS) AS 'NUM_CUOTAS',
		CONVERT(INT,NUM_CUOTAS_VENCIDAS) AS 'NUM_CUOTAS_VENCIDAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_30_DIAS, '0')) AS 'MONTO_VENCIDO_30_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_60_DIAS, '0')) AS 'MONTO_VENCIDO_60_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_90_DIAS, '0')) AS 'MONTO_VENCIDO_90_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_120_DIAS, '0')) AS 'MONTO_VENCIDO_120_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_180_DIAS, '0')) AS 'MONTO_VENCIDO_180_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_ANUAL, '0')) AS 'MONTO_VENCIDO_ANUAL',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_MAYOR_ANUAL, '0')) AS 'MONTO_VENCIDO_MAYOR_ANUAL',
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N030DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N030DMONTOAVENCER,17,2) AS 'MontoVencer30dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N060DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N060DMONTOAVENCER,17,2) AS 'MontoVencer60dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N090DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N090DMONTOAVENCER,17,2) AS 'MontoVencer90dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N120DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N120DMONTOAVENCER,17,2) AS 'MontoVencer120dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N180DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N180DMONTOAVENCER,17,2) AS 'MontoVencer180dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N360DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N360DMONTOAVENCER,17,2) AS 'MontoVencerUnAno', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.MA1AMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.MA1AMONTOAVENCER,17,2) AS 'MontoVencerMasUnAno', --busqueda desde cosmos YR	
		CONVERT(INT,BANCA_SOCIAL) AS BANCA_SOCIAL,
		CONVERT(INT,PRODUCCION_SOCIAL) AS PRODUCCION_SOCIAL,
		'0' AS 'INTMODALIDAD_MICROCREDITO',
		'0' AS 'USO_FINANCIERO',
		'0' AS 'DESTINO_RECURSOS_MICROFINANCIEROS',
		'0' AS 'CANT_TRABAJADORES',
		'0' AS 'VENTAS_ANUALES',
		'1900/01/01' AS 'FECHA_ESTADO_FINANCIERO',
		Num_RTN,
		LICENCIA_TURISTICA_NACIONAL,
		CONVERT(VARCHAR(10),FECHA_EMISION_FACTIBILIDAD_TECNICA,111) AS 'FECHA_EMISION_FACTIBILIDAD_TECNICA',
		ISNULL(LTRIM(RTRIM(NUM_EXPEDIENTE_FACTIBILIDAD_SOCIOTECNICA)), '0') AS 'NUM_EXPEDIENTE_FACTIBILIDAD_SOCIOTECNICA',
		LTRIM(RTRIM(NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA)) AS 'NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA',
		REPLACE(LTRIM(RTRIM(UPPER(C.NOMBRE_PROYECTO))),'''','´') AS 'NOMBRE_PROYECTO',
		LEFT(REPLACE(LTRIM(RTRIM(UPPER(DC04.ADDRESS3 + ' ' + DC04.ADDRESS4  + ' ' +  DC04.ADDRESS5  + ' ' +  DC04.ADDRESS6))),'''','´'),200) AS 'DireccionProyectooUnidadProduccion', --fz
		CONVERT(INT,COD_TIPO_PROYECTO) AS 'COD_TIPO_PROYECTO',
		CONVERT(INT,COD_TIPO_OPERACIONES_FINANCIAMIENTO) AS 'COD_TIPO_OPERACIONES_FINANCIAMIENTO',
		COD_SEGMENTO,
		TIPO_ZONA,
		CONVERT(VARCHAR(10),FECHA_AUTENTICACION,111) AS 'FECHA_AUTENTICACION',
		CONVERT(VARCHAR(10),FECHA_ULTIMA_INSPECCION,111) AS 'FECHA_ULTIMA_INSPECCION',
		CONVERT(DECIMAL(15,4),PORCENTAJE_EJECUCION_PROYECTO) AS 'PORCENTAJE_EJECUCION_PROYECTO',
		CONVERT(DECIMAL(15,2),PAGOS_EFECTUADOS_MENSUALES) AS 'PAGOS_EFECTUADOS_MENSUALES',
		CONVERT(DECIMAL(15,2),MONTOS_LIQUIDADOS_CIERRE) AS 'MONTOS_LIQUIDADOS_CIERRE',
		CONVERT(DECIMAL(15,2),AMORTIZACIONES_CAPITAL_ACUMULADAS) AS 'AMORTIZACIONES_CAPITAL_ACUMULADAS',
		TASA_INCENTIVO,
		CONVERT(DECIMAL(15),NUMERO_OFICIO_INCENTIVO) AS 'NUMERO_OFICIO_INCENTIVO',
		'0' AS 'NUM_REGISTRO',
		'' AS 'TIPO_REGISTRO',
		'1900/01/01' AS 'FECHA_VENC_REGISTRO',
		'0' AS 'TIPO_SUBSECTOR',
		'0' AS 'RUBRO',
		'0' AS 'COD_USO',
		'0' AS 'CANT',
		'0' AS 'COD_UNIDAD_MEDIDA',
		'0' AS 'SECTOR_PRODUCCION',
		'0' AS 'CANT_HECTAREAS',
		'0' AS 'SUPERFICIE_TOTAL',
		'0' AS 'NUM_BENEFICIARIOS',
		'0' AS 'PRIORITARIO',
		'0' AS 'DESTINO_MANUFACTURERO',
		'0' AS 'DESTINO_ECONOMICO',
		'0' AS 'TIPO_BENEFICIARIO',
		'0' AS 'MODALIDAD_HIPOTECARIA',
		'0' AS 'INGRESO_FAMILIAR',
		'0' AS 'MONTO_LIQUIDADO_ANUAL',
		'0' AS 'SALDO_CREDITO_31_12',
		'0' AS 'CANT_VIVIENDAS',
		'0' AS 'RendimientosCobrarReestructurados',
		'0' AS 'RendimientosCobrarAfectosReporto',
		'0' AS 'RendimientosCobrarLitigio',
		ISNULL(GAV.[Intereses Efectivamente Cobrados], ISNULL(TMP.InteresesEfectivamenteCobrados,@Cero)) AS 'InteresEfectivamenteCobrado',
		ISNULL(GAV.[Porcentaje de Comisión FLAT], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(GAV.[Monto Comisión FLAT],ISNULL(TMP.MontoComisionFLAT,'0,00')) AS	'MontoComisionFlat',
		ISNULL(GAV.[Periodicidad de Pago Especial de Capital], ISNULL(TMP.PeriodicidadPagoEspecialCapital,'0')) AS 'PeriocidadPagoEspecialCapital',
		ISNULL(GAV.[Fecha de Cambio de Estatus del Crédito], ISNULL(TMP.FechaCambioEstatusCredito,'19000101')) AS	'FechaCambioEstatusCredito',
		ISNULL(GAV.[Fecha de Registro en Vencida, Litigio o Castigada], ISNULL(TMP.FechaRegistroVencidaLitigioCastigada,ISNULL(SC.[Fecha_Registro_Vencida_Litigio_Castigada],ISNULL(SCS.[Fecha_Registro_Vencida_Litigio_Castigada],'19000101')))) AS 'FechaRegistroVencidaLitigiooCastigada',
		ISNULL(GAV.[Fecha de Exigibilidad de Pago de la última Cuota Pagada], ISNULL(TMP.FechaExigibilidadPagoUltimaCuotaPagada,'19000101')) AS 'FechaExigibilidadPagoUltimaCuotaPagada',
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		'0,00' AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0')AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(R.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(R.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(GAV.[Capital Transferido], ISNULL(TMP.CapitalTransferido,@Cero)) AS 'CapitalTransferido',
		ISNULL(GAV.[Fecha de Cambio de Estatus Capital Transferido], ISNULL(TMP.CapitalTransferido,'19000101')) AS	'FechaCambioEstatusCapitalTransferido',
		8 AS 'TipoDC',---- Turismo, Cartera 8
		0 AS 'IdLote',
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM RPT_STG_Dirigidas_TURISMO C
	LEFT JOIN TB_DCAT04_04 DC04 ON C.NUM_CREDITO = DC04.REFERNO --Data Corporativo
	LEFT JOIN tbGavetas GAV on C.NUM_CREDITO = GAV.[Número de Crédito] 
	LEFT JOIN TB_CarteraNoDirigidaFINAL TMP ON  C.NUM_CREDITO = TMP.REFERENCIA
	LEFT JOIN TMP_SobregirosCorporativo SC ON C.NUM_CREDITO  = SC.REFERENCIA
	LEFT JOIN TMP_SobregirosConsumer SCS ON  C.NUM_CREDITO = SCS.ACCT
	LEFT JOIN tb_dcat04_01 R on C.NUM_CREDITO = R.Acct
	LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC04.SICVENCLI = Equi.CodigoCiti 
		AND Equi.AtomoSif = 'CTE'
		AND Equi.TablaSif = 'SB10'
		AND Equi.Insumo = 'COSMOS'
		
	
		
EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Turismo AT04 - ', NULL, NULL, 'ATOMATICO'
		
--------------------------
END TRY -- Fin Tipo DC 8 Cartera Turismo
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera Turismo', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 
-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 12 Cartera Agricola Consumer
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)--
	SELECT 
		G.NUM_CREDITO AS 'NUM_CREDITO',
		CONVERT(VARCHAR(10),G.FECHA_LIQUIDACION,111) AS 'FECHA_LIQUIDACION',
		CONVERT(VARCHAR(10),G.FECHA_SOLICITUD,111) AS 'FECHA_SOLICITUD',
		CONVERT(VARCHAR(10),G.FECHA_APROBACION,111) AS 'FECHA_APROBACION',
	
		CASE 
			WHEN CONVERT(INT,G.COD_OFICINA) = 1 THEN '02'  
			ELSE CONVERT(INT,G.COD_OFICINA)
		END AS 'Oficina',--YR 14/08/2012
	
		G.COD_CONTABLE,
		CONVERT(DECIMAL,G.NUM_CREDITO_PRIMER_DESEMBOLSO) AS 'NUM_CREDITO_PRIMER_DESEMBOLSO',
		CONVERT(INT,G.NUM_DESEMBOLSO) AS 'NUM_DESEMBOLSO',
		'1' AS 'CodigodeLineadeCredito', --Valor por defecto NO
		'0' AS 'MontoLineaCredito',
		G.ESTADO_CREDITO,
		CASE 
			WHEN G.ESTADO_CREDITO = '3' THEN '0'  
			ELSE G.TIPO_CREDITO
		END AS 'TipoCredito',--YR 14/08/2012
	
		G.SITUACION_CREDITO,
		CASE G.PLAZO_CREDITO
			WHEN '1' THEN 'C'
			WHEN '2' THEN 'M'
			WHEN '3' THEN 'L'
			ELSE PLAZO_CREDITO
		END AS 'PLAZO_CREDITO',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		G.CLASE_RIESGO,
		'A01' AS 'DestinoDelCredito', --fz
		G.NATURALEZA_CLIENTE,
		G.TIPO_CLIENTE,
		CONVERT(DECIMAL,G.NUM_CLIENTE) AS 'NUM_CLIENTE',
		REPLACE(LTRIM(RTRIM(UPPER(G.NOMBRE_CLIENTE))),'''','´') AS 'NOMBRE_CLIENTE',
		CASE 
			WHEN G.GENERO IN ('1','2', '0') THEN G.GENERO --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		G.TIPO_CLIENTE AS 'TipoClienteRIF',
		CASE 
			WHEN G.TIPO_CLIENTE = 'V' OR G.TIPO_CLIENTE = 'E' THEN SUBSTRING(dbo.GetRif(G.TIPO_CLIENTE + CAST(CONVERT(DECIMAL,G.NUM_CLIENTE) AS VARCHAR)),2,20)
			ELSE CAST(CONVERT(DECIMAL,G.NUM_CLIENTE) AS VARCHAR)
		END AS 'IdentificacionTipoClienteRIF',
		'' AS 'Actividad_Cliente',
		CASE UPPER(G.TIPO_CLIENTE)
			WHEN 'V' THEN 'VE'
			WHEN 'J' THEN 'VE'
			WHEN 'G' THEN 'VE'
			ELSE ISNULL(UPPER(DC05.Nacionalidad),'XX')
		END AS 'Pais_Nacionalidad',
		DC01.DireccionH AS 'Domicilio_Fiscal', --fz
		CLIENTE_NUEVO,
		COOPERATIVA,
		'0' AS 'Sindicado', --Valor por defecto
		'0' As 'BancoLiderSindicado', --Valor por defecto
		'1' AS 'RelacionCrediticia', --Valor por defecto
		'1' AS 'GrupoEconomicoFinanciero', --Valor por defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por defecto
		ISNULL(COD_PARROQUIA,'010109') AS 'COD_PARROQUIA',
		CONVERT(INT,PERIODO_GRACIA_CAPITAL) AS 'PERIODO_GRACIA_CAPITAL',
		CONVERT(INT,PERIODO_PAGO_CAPITAL) AS 'PERIODO_PAGO_CAPITAL',
		CONVERT(INT,PERIODO_PAGO_CAPITAL) AS 'PERIODO_PAGO_INTERES',  --YR 14/08/2012 ANTERIORMENTE CONVERT(INT,PERIODO_PAGO_INTERES)
		CONVERT(VARCHAR(10),FECHA_VENC_ORIGINAL,111) AS 'FECHA_VENC_ORIGINAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ACTUAL,111) AS 'FECHA_VENC_ACTUAL',
		CONVERT(VARCHAR(10),FECHA_REESTRUCTURACION,111) AS 'FECHA_REESTRUCTURACION',
		CONVERT(INT,CANT_PRORROGAS) AS 'CANT_PRORROGAS',
		CONVERT(VARCHAR(10),FECHA_PRORROGA,111) AS 'FECHA_PRORROGA',
		CONVERT(INT,CANT_RENOVACIONES) AS 'CANT_RENOVACIONES',
		CONVERT(VARCHAR(10),FECHA_ULTIMA_RENOVACION,111) AS 'FECHA_ULTIMA_RENOVACION',
		CONVERT(VARCHAR(10),FECHA_CANCEL,111) AS 'FECHA_CANCEL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_CAPITAL,111) AS 'FECHA_VENC_ULTIMA_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_INTERES,111) AS 'FECHA_VENC_ULTIMA_CUOTA_INTERES',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_INTERES,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_INTERES',
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),MONTO_ORIGINAL) AS 'MONTO_ORIGINAL',
		CONVERT(DECIMAL(15,4),MONTO_INICIAL) AS 'MONTO_INICIAL',
		CONVERT(DECIMAL(15,4),MONTO_LIQUIDADO_MES) AS 'MONTO_LIQUIDADO_MES',
		'0' As 'EntePublico', -- Valor por Defecto
		'0' AS 'MontoInicialTerceros', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),SALDO) AS 'SALDO',
		CASE
			WHEN TMPR.SaldoRendXcobrar = @Cero OR TMPR.SaldoRendXcobrar IS NULL
			THEN RENDIMIENTOS_X_COBRAR
			ELSE TMPR.SaldoRendXcobrar
		END AS 'RendimientosCobrar', 
		CASE
			WHEN TMPR.SaldoRendXcobrarVenc = @Cero OR TMPR.SaldoRendXcobrarVenc IS NULL
			THEN RENDIMIENTOS_X_COBRAR_VENCIDOS
			ELSE TMPR.SaldoRendXcobrarVenc
		END AS 'RendimientosCobrarVencidos',
		ISNULL(TMPR.SaldoRendXMora,@Cero) AS 'RendimientosCobrarMora', 
		CASE 
		WHEN G.ESTADO_CREDITO IN ('2','3') THEN '0'  
		END,
		
		--CASE 
		--	WHEN G.ESTADO_CREDITO IN ('2','3') THEN '0'  
		--	ELSE CONVERT(DECIMAL(15,4),PROVISION_ESPECIFICA)
		--END AS 'PROVISION_ESPECIFICA',--YR 14/08/2012
		--CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) AS 'PORCENTAJE_PROVISION_ESPECIFICA',	
		
		G.PROVISION_ESPECIFICA AS 'PROVISION_ESPECIFICA',
		G.PORCENTAJE_PROVISION_ESPECIFICA AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		G.PROVISION_RENDIMIENTO_X_COBRAR AS 'PROVISION_RENDIMIENTO_X_COBRAR',
	
		CASE 
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS = @Cero THEN '0'
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS > @Cero AND CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) = 0.0000 THEN -0.01   
			ELSE CONVERT(DECIMAL(15,4),PROVISION_RENDIMIENTO_X_COBRAR)
		END AS 'PROVISION_RENDIMIENTO_X_COBRAR',--YR 14/08/2012
	
		CONVERT(DECIMAL(15,4),TASA_INTERES_COBRADA) AS 'TASA_INTERES_COBRADA',
		CONVERT(DECIMAL(15,4),TASA_INTERES_ACTUAL) AS 'TASA_INTERES_ACTUAL',
		'1' AS 'IndicadorTasaPreferencial', --Valor por Defecto
		CONVERT(DECIMAL(15,4),TASA_COMISION) AS 'TASA_COMISION',
		'0' AS 'ComisionesPorCobrar',
		'0' AS 'ComisionesCobradas',
		CONVERT(DECIMAL(15,4),EROGACIONES_RECUPERABLES) AS 'EROGACIONES_RECUPERABLES',
		CONVERT(INT,TIPO_GARANTIA_PRINCIPAL) AS 'TIPO_GARANTIA_PRINCIPAL', --fz
		CONVERT(INT,NUM_CUOTAS) AS 'NUM_CUOTAS',
		ISNULL(CONVERT(INT,NUM_CUOTAS_VENCIDAS), '0') AS 'NUM_CUOTAS_VENCIDAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_30_DIAS, '0')) AS 'MONTO_VENCIDO_30_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_60_DIAS, '0')) AS 'MONTO_VENCIDO_60_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_90_DIAS, '0')) AS 'MONTO_VENCIDO_90_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_120_DIAS, '0')) AS 'MONTO_VENCIDO_120_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_180_DIAS, '0')) AS 'MONTO_VENCIDO_180_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_ANUAL, '0')) AS 'MONTO_VENCIDO_ANUAL',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_MAYOR_ANUAL, '0')) AS 'MONTO_VENCIDO_MAYOR_ANUAL',
		'0' AS 'MontoVencer30dias', --Valor por defecto
		'0' AS 'MontoVencer60dias', --Valor por defecto
		'0' AS 'MontoVencer90dias', --Valor por defecto
		'0' AS 'MontoVencer120dias', --Valor por defecto
		'0' AS 'MontoVencer180dias', --Valor por defecto
		'0' AS 'MontoVencerUnAño', --Valor por defecto
		'0' AS 'MontoVencerMasDeUnAño', --Valor por defecto
		CONVERT(INT,BANCA_SOCIAL) AS BANCA_SOCIAL,
		CONVERT(INT,PRODUCCION_SOCIAL) AS PRODUCCION_SOCIAL,
		'0' AS 'INTMODALIDAD_MICROCREDITO',
		'0' AS 'USO_FINANCIERO',
		'0' AS 'DESTINO_RECURSOS_MICROFINANCIEROS',
		'0' AS 'CANT_TRABAJADORES',
		'0' AS 'VENTAS_ANUALES',
		'1900/01/01' AS 'FECHA_ESTADO_FINANCIERO',
		'' AS 'NUM_RTN',
		'' AS 'LICENCIA_TURISTICA_NACIONAL',
		'1900/01/01' AS 'FECHA_EMISION_FACTIBILIDAD_TECNICA',
		'0' AS 'NUM_EXPEDIENTE_FACTIBILIDAD_SOCIOTECNICA',
		'0' AS 'NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA',
		CASE 
			WHEN G.ESTADO_CREDITO = '3' THEN '' 
			WHEN G.ESTADO_CREDITO = '2' THEN '' 
			ELSE RTRIM(LTRIM(UPPER(G.NOMBRE_PROYECTO)))
		END AS 'NOMBRE_PROYECTO',--YR 14/08/2012
	
		DC01.DireccionH AS 'DireccionProyectooUnidadProduccion', --YR 14/08/2012
		'0' AS 'COD_TIPO_PROYECTO',
		'0' AS 'COD_TIPO_OPERACIONES_FINANCIAMIENTO',
		'0' AS 'COD_SEGMENTO',
		'0' AS 'TIPO_ZONA',
		'1900/01/01' AS 'FECHA_AUTENTICACION',
		CONVERT(VARCHAR(10),G.FECHA_ULTIMA_INSPECCION,111) AS 'FECHA_ULTIMA_INSPECCION',  --fz
		G.PORCENTAJE_EJECUCION_PROYECTO AS 'PORCENTAJE_EJECUCION_PROYECTO',
		'0' AS 'PAGOS_EFECTUADOS_MENSUALES',
		'0' AS 'MONTOS_LIQUIDADOS_CIERRE',
		'0' AS 'AMORTIZACIONES_CAPITAL_ACUMULADAS',
		'0' AS 'TASA_INCENTIVO',
		'' AS 'NUMERO_OFICIO_INCENTIVO',
		CASE -- fz
			WHEN LTRIM(RTRIM(G.NUM_REGISTRO)) = '' THEN '0'
			ELSE CONVERT(DECIMAL,G.NUM_REGISTRO)
		END  AS 'NUM_REGISTRO',
		RTRIM(LTRIM(UPPER(TIPO_REGISTRO))) AS TIPO_REGISTRO, --fz
		CONVERT(VARCHAR(10),FECHA_VENC_REGISTRO,111) AS 'FECHA_VENC_REGISTRO',
		CONVERT(DECIMAL,TIPO_SUBSECTOR) AS 'TIPO_SUBSECTOR', --fz
		CONVERT(DECIMAL(15),RUBRO) AS 'RUBRO',
		CONVERT(DECIMAL(15),COD_USO) AS 'COD_USO',
		CONVERT(DECIMAL(15,2),CANT) AS 'CANT',
		CONVERT(DECIMAL(15),COD_UNIDAD_MEDIDA) AS 'COD_UNIDAD_MEDIDA',
		SECTOR_PRODUCCION,
		CONVERT(DECIMAL(15),CANT_HECTAREAS) AS 'CANT_HECTAREAS',
		CONVERT(DECIMAL(15),SUPERFICIE_TOTAL) AS 'SUPERFICIE_TOTAL',
		CONVERT(DECIMAL(15),NUM_BENEFICIARIOS) AS 'NUM_BENEFICIARIOS',
		PRIORITARIO,
		'0' AS 'DESTINO_MANUFACTURERO', --Valor por defecto
		'0' AS 'DESTINO_ECONOMICO', --Valor por defecto
		'0' AS 'TIPO_BENEFICIARIO',
		'0' AS 'MODALIDAD_HIPOTECARIA',
		'0' AS 'INGRESO_FAMILIAR',
		'0' AS 'MONTO_LIQUIDADO_ANUAL',
		'0' AS 'SALDO_CREDITO_31_12',
		'0' AS 'CANT_VIVIENDAS',
		--
		CASE 
			WHEN DC01.CtaLocal LIKE '132%' 
			THEN TMPR.SaldoRendXcobrar
			ELSE @Cero END  AS 'RendimientosCobrarReestructurados',
		@Cero AS 'RendimientosCobrarAfectosReporto',
		@Cero AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS	'FechaCambioEstatusCapitalTransferido',
		12 AS 'TipoDC',
		0 AS 'IdLote',
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM RPT_STG_Dirigidas_AGRICOLA_CONSUMER G
	LEFT JOIN TB_DCAT04_01 DC01 ON G.NUM_CREDITO = DC01.ACCT --LDWH
	LEFT JOIN TB_DCAT04_02 DC02 ON RIGHT(G.NUM_CREDITO,11) = DC02.P8NOTE --LNP860
	LEFT JOIN TB_DCAT04_05 DC05 ON G.TIPO_CLIENTE + CAST(G.NUM_CLIENTE AS VARCHAR) = DC05.IdentificadorCliente --Datos Clientes
	LEFT JOIN tbGavetas GAV on G.NUM_CREDITO = GAV.[Número de Crédito]  
	LEFT JOIN TMP_Rendimiento TMPR on TMPR.acct = DC01.Acct
	
	
	UPDATE jf77062.TB_DMAT04
	SET ActividadCliente = ISNULL(Equi.CodigoSIF,'G45')
	FROM TB_DCAT04_01 DC01
	LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC01.ActivityID = Equi.CodigoCiti
		AND Equi.AtomoSif = 'CTE'
		AND Equi.TablaSif = 'SB10'
		AND Equi.Insumo = 'CORE'
		
EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Agricola Consumer AT04 - ', NULL, NULL, 'ATOMATICO'		
--------------------------
END TRY -- Fin Tipo DC 12 Cartera Agricola Consumer
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera Agricola Consumer', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 		
-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 11 Cartera Agricola Corporate
--------------------------
	INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	SELECT 
		F.NUM_CREDITO AS 'NUM_CREDITO',
		CONVERT(VARCHAR(10),F.FECHA_LIQUIDACION,111) AS 'FECHA_LIQUIDACION',
		CONVERT(VARCHAR(10),F.FECHA_SOLICITUD,111) AS 'FECHA_SOLICITUD',
		CONVERT(VARCHAR(10),F.FECHA_APROBACION,111) AS 'FECHA_APROBACION',
	
		CASE 
			WHEN CONVERT(INT,F.COD_OFICINA) = 1 THEN '02'  
			ELSE CONVERT(INT,F.COD_OFICINA)
		END AS 'Oficina',--YR 14/08/2012
	
		F.COD_CONTABLE,
		CONVERT(DECIMAL,F.NUM_CREDITO_PRIMER_DESEMBOLSO) AS 'NUM_CREDITO_PRIMER_DESEMBOLSO',
		CONVERT(INT,F.NUM_DESEMBOLSO) AS 'NUM_DESEMBOLSO',
		'1' AS 'CodigodeLineadeCredito', --Valor por defecto NO --fz
		'0' AS 'MontoLineaCredito',
		F.ESTADO_CREDITO,
		CASE 
			WHEN F.ESTADO_CREDITO = '3' THEN '0'  
			ELSE F.TIPO_CREDITO
		END AS 'TipoCredito',--YR 14/08/2012
	
		F.SITUACION_CREDITO,
		CASE F.PLAZO_CREDITO
			WHEN '1' THEN 'C'
			WHEN '2' THEN 'M'
			WHEN '3' THEN 'L'
			ELSE PLAZO_CREDITO
		END AS 'PLAZO_CREDITO',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		F.CLASE_RIESGO,
		'A01' AS 'DestinoDelCredito', --fz
		F.NATURALEZA_CLIENTE,
		F.TIPO_CLIENTE,
		RIGHT(F.NUM_CLIENTE,9) AS 'NUM_CLIENTE', --fz
		REPLACE(LTRIM(RTRIM(UPPER(F.NOMBRE_CLIENTE))),'''','´') AS 'NOMBRE_CLIENTE',
		CASE 
			WHEN F.GENERO IN ('1','2', '0') THEN F.GENERO --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		F.TIPO_CLIENTE AS 'TipoClienteRIF',
		RIGHT(F.NUM_CLIENTE,9) AS 'IdentificacionTipoClienteRIF', --fz
		ISNULL(Equi.CodigoSIF,'A01') AS 'Actividad del Cliente', --fz
		CASE 
			WHEN UPPER(F.TIPO_CLIENTE) IN ('V','J','G') THEN 'VE' --fz
			ELSE 'XX' --YR 14/08/2012
		END AS 'Pais_Nacionalidad',
		LEFT(REPLACE(LTRIM(RTRIM(UPPER(DC04.ADDRESS3 + ' ' + DC04.ADDRESS4  + ' ' +  DC04.ADDRESS5  + ' ' +  DC04.ADDRESS6))),'''','´'),200) AS 'Domicilio_Fiscal', --fz
		CLIENTE_NUEVO,
		COOPERATIVA,
		'0' AS 'Sindicado', --Valor por defecto
		'0' As 'BancoLiderSindicado', --Valor por defecto
		'1' AS 'RelacionCrediticia', --Valor por defecto
		'1' AS 'GrupoEconomicoFinanciero', --Valor por defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por defecto
		ISNULL(F.COD_PARROQUIA,'010109') AS 'COD_PARROQUIA',
		CONVERT(INT,PERIODO_GRACIA_CAPITAL) AS PERIODO_GRACIA_CAPITAL,
		CONVERT(INT,PERIODO_PAGO_CAPITAL) AS PERIODO_PAGO_CAPITAL,
		CONVERT(INT,PERIODO_PAGO_INTERES) AS PERIODO_PAGO_INTERES,
		CONVERT(VARCHAR(10),FECHA_VENC_ORIGINAL,111) AS 'FECHA_VENC_ORIGINAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ACTUAL,111) AS 'FECHA_VENC_ACTUAL',
		CONVERT(VARCHAR(10),FECHA_REESTRUCTURACION,111) AS 'FECHA_REESTRUCTURACION',
		CONVERT(INT,CANT_PRORROGAS) AS 'CANT_PRORROGAS',
		CONVERT(VARCHAR(10),FECHA_PRORROGA,111) AS 'FECHA_PRORROGA',
		CONVERT(INT,CANT_RENOVACIONES) AS 'CANT_RENOVACIONES',
		CONVERT(VARCHAR(10),FECHA_ULTIMA_RENOVACION,111) AS 'FECHA_ULTIMA_RENOVACION',
		CONVERT(VARCHAR(10),FECHA_CANCEL,111) AS 'FECHA_CANCEL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_CAPITAL,111) AS 'FECHA_VENC_ULTIMA_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_INTERES,111) AS 'FECHA_VENC_ULTIMA_CUOTA_INTERES',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_INTERES,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_INTERES',
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),MONTO_ORIGINAL) AS 'MONTO_ORIGINAL',
		CONVERT(DECIMAL(15,4),MONTO_INICIAL) AS 'MONTO_INICIAL',
		CONVERT(DECIMAL(15,4),MONTO_LIQUIDADO_MES) AS 'MONTO_LIQUIDADO_MES',
		'0' As 'EntePublico', -- Valor por Defecto
		'0' AS 'MontoInicialTerceros', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),F.SALDO) AS 'SALDO',
		RENDIMIENTOS_X_COBRAR AS 'RENDIMIENTOS_X_COBRAR',
		RENDIMIENTOS_X_COBRAR_VENCIDOS AS 'RENDIMIENTOS_X_COBRAR_VENCIDOS',
		'0' AS 'RendimientosPorCobrarMora', --fz
	
		--CASE 
		--	WHEN F.ESTADO_CREDITO IN ('2','3') THEN '0'  
		--	ELSE CONVERT(DECIMAL(15,4),PROVISION_ESPECIFICA)
		--END AS 'PROVISION_ESPECIFICA',--YR 14/08/2012
		--CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) AS 'PORCENTAJE_PROVISION_ESPECIFICA',
	
		CASE 
		WHEN F.ESTADO_CREDITO IN ('2','3') THEN '0'
		END,
		
		F.PROVISION_ESPECIFICA AS 'PROVISION_ESPECIFICA',
		F.PORCENTAJE_PROVISION_ESPECIFICA AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		F.PROVISION_RENDIMIENTO_X_COBRAR AS 'PROVISION_RENDIMIENTO_X_COBRAR',
	
		
		--CASE 
		--	WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS = @Cero THEN '0'  
		--	WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS > @Cero AND CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) = 0.0000 THEN -0.01   
		--	ELSE CONVERT(DECIMAL(15,4),PROVISION_RENDIMIENTO_X_COBRAR)
		--END AS 'PROVISION_RENDIMIENTO_X_COBRAR',--YR 14/08/2012
	
		CONVERT(DECIMAL(15,4),TASA_INTERES_COBRADA) AS 'TASA_INTERES_COBRADA',
		CONVERT(DECIMAL(15,4),TASA_INTERES_ACTUAL) AS 'TASA_INTERES_ACTUAL',
		'1' AS 'IndicadorTasaPreferencial', --fz
		CONVERT(DECIMAL(15,4),TASA_COMISION) AS 'TASA_COMISION',
		'0' AS 'ComisionesPorCobrar',
		'0' AS 'ComisionesCobradas',
		CONVERT(DECIMAL(15,4),EROGACIONES_RECUPERABLES) AS 'EROGACIONES_RECUPERABLES',
		CONVERT(INT,TIPO_GARANTIA_PRINCIPAL) AS 'TIPO_GARANTIA_PRINCIPAL', --fz
		CONVERT(INT,NUM_CUOTAS) AS 'NUM_CUOTAS',
		CONVERT(INT,NUM_CUOTAS_VENCIDAS) AS 'NUM_CUOTAS_VENCIDAS',
		CONVERT(DECIMAL(15,4),ISNULL (MONTO_VENCIDO_30_DIAS, '0')) AS 'MONTO_VENCIDO_30_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL (MONTO_VENCIDO_60_DIAS, '0')) AS 'MONTO_VENCIDO_60_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL (MONTO_VENCIDO_90_DIAS, '0')) AS 'MONTO_VENCIDO_90_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL (MONTO_VENCIDO_120_DIAS, '0')) AS 'MONTO_VENCIDO_120_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL (MONTO_VENCIDO_180_DIAS, '0')) AS 'MONTO_VENCIDO_180_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL (MONTO_VENCIDO_ANUAL, '0')) AS 'MONTO_VENCIDO_ANUAL',
		CONVERT(DECIMAL(15,4),ISNULL (MONTO_VENCIDO_MAYOR_ANUAL, '0')) AS 'MONTO_VENCIDO_MAYOR_ANUAL',
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N030DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N030DMONTOAVENCER,17,2) AS 'MontoVencer30dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N060DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N060DMONTOAVENCER,17,2) AS 'MontoVencer60dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N090DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N090DMONTOAVENCER,17,2) AS 'MontoVencer90dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N120DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N120DMONTOAVENCER,17,2) AS 'MontoVencer120dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N180DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N180DMONTOAVENCER,17,2) AS 'MontoVencer180dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N360DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N360DMONTOAVENCER,17,2) AS 'MontoVencerUnAno', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.MA1AMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.MA1AMONTOAVENCER,17,2) AS 'MontoVencerMasUnAno', --busqueda desde cosmos YR
	
		CONVERT(INT,BANCA_SOCIAL) AS BANCA_SOCIAL,
		CONVERT(INT,PRODUCCION_SOCIAL) AS PRODUCCION_SOCIAL,
		'0' AS 'INTMODALIDAD_MICROCREDITO',
		'0' AS 'USO_FINANCIERO',
		'0' AS 'DESTINO_RECURSOS_MICROFINANCIEROS',
		'0' AS 'CANT_TRABAJADORES',
		'0' AS 'VENTAS_ANUALES',
		'1900/01/01' AS 'FECHA_ESTADO_FINANCIERO',
		'' AS 'NUM_RTN',
		'' AS 'LICENCIA_TURISTICA_NACIONAL',
		'1900/01/01' AS 'FECHA_EMISION_FACTIBILIDAD_TECNICA',
		'0' AS 'NUM_EXPEDIENTE_FACTIBILIDAD_SOCIOTECNICA',
		'0' AS 'NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA',
		RTRIM(LTRIM(UPPER(F.NOMBRE_PROYECTO ))) AS 'NOMBRE_PROYECTO', --fz
		LEFT(REPLACE(LTRIM(RTRIM(UPPER(DC04.ADDRESS3 + ' ' + DC04.ADDRESS4  + ' ' +  DC04.ADDRESS5  + ' ' +  DC04.ADDRESS6))),'''','´'),200) AS 'DireccionProyectooUnidadProduccion', --yr 14/08/2012
		'0' AS 'COD_TIPO_PROYECTO',
		'0' AS 'COD_TIPO_OPERACIONES_FINANCIAMIENTO',
		'0' AS 'COD_SEGMENTO',
		'0' AS 'TIPO_ZONA',
		'1900/01/01' AS 'FECHA_AUTENTICACION',
		CONVERT(VARCHAR(10),F.FECHA_ULTIMA_INSPECCION,111) AS 'FECHA_ULTIMA_INSPECCION',  --fz	
		
		CASE 
			WHEN CONVERT(VARCHAR(10),F.FECHA_ULTIMA_INSPECCION,111) = '1900/01/01' THEN '0' 
			ELSE F.PORCENTAJE_EJECUCION_PROYECTO
		END AS 'PORCENTAJE_EJECUCION_PROYECTO',  --YR 14/08/2012
	
		'0' AS 'PAGOS_EFECTUADOS_MENSUALES',
		'0' AS 'MONTOS_LIQUIDADOS_CIERRE',
		'0' AS 'AMORTIZACIONES_CAPITAL_ACUMULADAS',
		'0' AS 'TASA_INCENTIVO',
		'' AS 'NUMERO_OFICIO_INCENTIVO',
		NUM_REGISTRO,
		TIPO_REGISTRO,
		CONVERT(VARCHAR(10),FECHA_VENC_REGISTRO,111) AS 'FECHA_VENC_REGISTRO',
		TIPO_SUBSECTOR,
		CONVERT(DECIMAL(15),RUBRO) AS 'RUBRO',
		CONVERT(DECIMAL(15),COD_USO) AS 'COD_USO',
		CONVERT(DECIMAL(15,2),CANT) AS 'CANT',
		CONVERT(DECIMAL(15),COD_UNIDAD_MEDIDA) AS 'COD_UNIDAD_MEDIDA',
		SECTOR_PRODUCCION,
		CONVERT(DECIMAL(15),CANT_HECTAREAS) AS 'CANT_HECTAREAS',
		CONVERT(DECIMAL(15),SUPERFICIE_TOTAL) AS 'SUPERFICIE_TOTAL',
		CONVERT(DECIMAL(15),NUM_BENEFICIARIOS) AS 'NUM_BENEFICIARIOS',
		PRIORITARIO,
		'0' AS 'DESTINO_MANUFACTURERO',
		'0' AS 'DESTINO_ECONOMICO',
		'0' AS 'TIPO_BENEFICIARIO',
		'0' AS 'MODALIDAD_HIPOTECARIA',
		'0' AS 'INGRESO_FAMILIAR',
		'0' AS 'MONTO_LIQUIDADO_ANUAL',
		'0' AS 'SALDO_CREDITO_31_12',
		'0' AS 'CANT_VIVIENDAS',
		'0' AS 'RendimientosCobrarReestructurados',
		'0' AS 'RendimientosCobrarAfectosReporto',
		'0' AS 'RendimientosCobrarLitigio',
		ISNULL(GAV.[Intereses Efectivamente Cobrados], ISNULL(TMP.InteresesEfectivamenteCobrados,@Cero)) AS 'InteresEfectivamenteCobrado',
		ISNULL(GAV.[Porcentaje de Comisión FLAT], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(GAV.[Monto Comisión FLAT],ISNULL(TMP.MontoComisionFLAT,'0,00')) AS	'MontoComisionFlat',
		ISNULL(GAV.[Periodicidad de Pago Especial de Capital], ISNULL(TMP.PeriodicidadPagoEspecialCapital,'0')) AS 'PeriocidadPagoEspecialCapital',
		ISNULL(GAV.[Fecha de Cambio de Estatus del Crédito], ISNULL(TMP.FechaCambioEstatusCredito,'19000101')) AS	'FechaCambioEstatusCredito',
		ISNULL(GAV.[Fecha de Registro en Vencida, Litigio o Castigada], ISNULL(TMP.FechaRegistroVencidaLitigioCastigada,ISNULL(SC.[Fecha_Registro_Vencida_Litigio_Castigada],ISNULL(SCS.[Fecha_Registro_Vencida_Litigio_Castigada],'19000101'))))AS 'FechaRegistroVencidaLitigiooCastigada',
		ISNULL(GAV.[Fecha de Exigibilidad de Pago de la última Cuota Pagada], ISNULL(TMP.FechaExigibilidadPagoUltimaCuotaPagada,'19000101')) AS 'FechaExigibilidadPagoUltimaCuotaPagada',
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		'0,00' AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0')AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(GAV.[Capital Transferido], ISNULL(TMP.CapitalTransferido,@Cero)) AS 'CapitalTransferido',
		ISNULL(GAV.[Fecha de Cambio de Estatus Capital Transferido], ISNULL(TMP.FechaCambioEstatusCapitalTransferido,'19000101')) AS	'FechaCambioEstatusCapitalTransferido',
		11 AS 'TipoDC',
		0 AS 'IdLote',
		'Manual' AS 'Usuario'
	FROM RPT_STG_Dirigidas_AGRICOLA_CORPORATE F
	LEFT JOIN TB_DCAT04_04 DC04 ON F.NUM_CREDITO = DC04.REFERNO 
	LEFT JOIN tbGavetas GAV on F.NUM_CREDITO = GAV.[Número de Crédito]
	LEFT JOIN TB_CarteraNoDirigidaFINAL TMP ON  F.NUM_CREDITO = TMP.REFERENCIA
	LEFT JOIN TMP_SobregirosCorporativo SC ON F.NUM_CREDITO  = SC.REFERENCIA
	LEFT JOIN TMP_SobregirosConsumer SCS ON  F.NUM_CREDITO = SCS.ACCT
	LEFT JOIN TB_DCAT04_01 DC01 ON F.NUM_CREDITO = DC01.ACCT --LDWH
	LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC04.SICVENCLI = Equi.CodigoCiti 
		AND Equi.AtomoSif = 'CTE'
		AND Equi.TablaSif = 'SB10'
		AND Equi.Insumo = 'COSMOS'	
		
EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Agricola Corporate AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 11 Cartera Agricola Corporate
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera Agricola Corporate', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 	

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 10 Cartera Manufactura
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	SELECT 
		E.NUM_CREDITO AS 'NUM_CREDITO',
		CONVERT(VARCHAR(10),E.FECHA_LIQUIDACION,111) AS 'FECHA_LIQUIDACION',
		CONVERT(VARCHAR(10),E.FECHA_SOLICITUD,111) AS 'FECHA_SOLICITUD',
		CONVERT(VARCHAR(10),E.FECHA_APROBACION,111) AS 'FECHA_APROBACION',
	
		CASE 
			WHEN CONVERT(INT,E.COD_OFICINA) = 1 THEN '02'  
			ELSE CONVERT(INT,E.COD_OFICINA)
		END AS 'Oficina',--YR 14/08/2012
	
		E.COD_CONTABLE,
		CONVERT(DECIMAL,E.NUM_CREDITO_PRIMER_DESEMBOLSO) AS 'NUM_CREDITO_PRIMER_DESEMBOLSO',
		CONVERT(INT,E.NUM_DESEMBOLSO) AS 'NUM_DESEMBOLSO',
		'1' AS 'CodigodeLineadeCredito', --Valor por defecto NO
		'0' AS 'MONTO_INICIAL',
		E.ESTADO_CREDITO,
		CASE 
			WHEN E.ESTADO_CREDITO = '3' THEN '0'  
			ELSE E.TIPO_CREDITO
		END AS 'TipoCredito',--YR 14/08/2012
	
		E.SITUACION_CREDITO,
		CASE E.PLAZO_CREDITO
			WHEN '1' THEN 'C'
			WHEN '2' THEN 'M'
			WHEN '3' THEN 'L'
			ELSE PLAZO_CREDITO
		END AS 'PLAZO_CREDITO',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		E.CLASE_RIESGO,
		ISNULL(Equi.CodigoSIF,'') AS 'DestinoDelCredito', --Pendiente Definición
		E.NATURALEZA_CLIENTE,
		E.TIPO_CLIENTE,
		RIGHT(E.NUM_CLIENTE,9) AS 'NUM_CLIENTE', --fz
		REPLACE(LTRIM(RTRIM(UPPER(E.NOMBRE_CLIENTE))),'''','´') AS 'NOMBRE_CLIENTE',
		CASE 
			WHEN E.GENERO IN ('1','2', '0') THEN E.GENERO --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		E.TIPO_CLIENTE AS 'TipoClienteRIF',
		RIGHT(E.NUM_CLIENTE,9) AS 'IdentificacionTipoClienteRIF', --fz
		ISNULL(Equi.CodigoSIF,'XXX') AS 'Actividad del Cliente', --YR 14/08/2012 XXX
		CASE 
			WHEN UPPER(E.TIPO_CLIENTE) IN ('V','J','G') THEN 'VE' --fz
			ELSE 'XX' --YR 14/08/2012 
		END AS 'Pais_Nacionalidad',
		LEFT(REPLACE(LTRIM(RTRIM(UPPER(DC04.ADDRESS3 + ' ' + DC04.ADDRESS4  + ' ' +  DC04.ADDRESS5  + ' ' +  DC04.ADDRESS6))),'''','´'),200) AS 'Domicilio_Fiscal', --fz OJO VALIDAR CRUCE
		CLIENTE_NUEVO,
		COOPERATIVA,
		'0' AS 'Sindicado', --Valor por defecto
		'0' As 'BancoLiderSindicado', --Valor por defecto
		'1' AS 'RelacionCrediticia', --Valor por defecto --fz
		'1' AS 'GrupoEconomicoFinanciero', --Valor por defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por defecto
		ISNULL(COD_PARROQUIA,'010109') AS 'COD_PARROQUIA',
		CONVERT(INT,PERIODO_GRACIA_CAPITAL) AS PERIODO_GRACIA_CAPITAL,
		CONVERT(INT,PERIODO_PAGO_CAPITAL) AS PERIODO_PAGO_CAPITAL,
		CONVERT(INT,PERIODO_PAGO_INTERES) AS PERIODO_PAGO_INTERES,
		CONVERT(VARCHAR(10),FECHA_VENC_ORIGINAL,111) AS 'FECHA_VENC_ORIGINAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ACTUAL,111) AS 'FECHA_VENC_ACTUAL',
		CONVERT(VARCHAR(10),FECHA_REESTRUCTURACION,111) AS 'FECHA_REESTRUCTURACION',
		CONVERT(INT,CANT_PRORROGAS) AS 'CANT_PRORROGAS',
		CONVERT(VARCHAR(10),FECHA_PRORROGA,111) AS 'FECHA_PRORROGA',
		CONVERT(INT,CANT_RENOVACIONES) AS 'CANT_RENOVACIONES',
		CONVERT(VARCHAR(10),FECHA_ULTIMA_RENOVACION,111) AS 'FECHA_ULTIMA_RENOVACION',
		CONVERT(VARCHAR(10),FECHA_CANCEL,111) AS 'FECHA_CANCEL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_CAPITAL,111) AS 'FECHA_VENC_ULTIMA_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_INTERES,111) AS 'FECHA_VENC_ULTIMA_CUOTA_INTERES',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_INTERES,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_INTERES',
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),MONTO_ORIGINAL) AS 'MONTO_ORIGINAL',
		CONVERT(DECIMAL(15,4),MONTO_INICIAL) AS 'MONTO_INICIAL',
		CONVERT(DECIMAL(15,4),MONTO_LIQUIDADO_MES) AS 'MONTO_LIQUIDADO_MES',
		'0' As 'EntePublico', -- Valor por Defecto
		'0' AS 'MontoInicialTerceros', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),E.SALDO) AS 'SALDO',
		RENDIMIENTOS_X_COBRAR AS 'RENDIMIENTOS_X_COBRAR',
		RENDIMIENTOS_X_COBRAR_VENCIDOS AS 'RENDIMIENTOS_X_COBRAR_VENCIDOS',
		'0' AS 'RendimientosCobrarMora', --YR 06/09/2012 SETEAR 0 POR DEFECTO --'' AS 'RendimientosPorCobrarMora', --fz
	
		--CASE 
		--	WHEN E.ESTADO_CREDITO IN ('2','3') THEN '0'  
		--	ELSE CONVERT(DECIMAL(15,4),PROVISION_ESPECIFICA)
		--END AS 'PROVISION_ESPECIFICA',--YR 14/08/2012
		--CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		
		CASE 
			WHEN E.ESTADO_CREDITO IN ('2','3') THEN '0'
		END,
	
		E.PROVISION_ESPECIFICA AS 'PROVISION_ESPECIFICA',
		E.PORCENTAJE_PROVISION_ESPECIFICA AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		E.PROVISION_RENDIMIENTO_X_COBRAR AS 'PROVISION_RENDIMIENTO_X_COBRAR',
	
		CASE 
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS = @Cero THEN '0'  
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS > @Cero AND CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) = 0.0000 THEN -0.01   
			ELSE CONVERT(DECIMAL(15,4),PROVISION_RENDIMIENTO_X_COBRAR)
		END AS 'PROVISION_RENDIMIENTO_X_COBRAR',--YR 14/08/2012
	
		CONVERT(DECIMAL(15,4),TASA_INTERES_COBRADA) AS 'TASA_INTERES_COBRADA',
		CONVERT(DECIMAL(15,4),TASA_INTERES_ACTUAL) AS 'TASA_INTERES_ACTUAL',
		'1' AS 'IndicadorTasaPreferencial',
		CONVERT(DECIMAL(15,4),TASA_COMISION) AS 'TASA_COMISION',
		'0' AS 'ComisionesPorCobrar',
		'0' AS 'ComisionesCobradas',
		CONVERT(DECIMAL(15,4),EROGACIONES_RECUPERABLES) AS 'EROGACIONES_RECUPERABLES',
		CONVERT(INT,TIPO_GARANTIA_PRINCIPAL) AS 'TIPO_GARANTIA_PRINCIPAL', --fz
		CONVERT(INT,NUM_CUOTAS) AS 'NUM_CUOTAS',
		CONVERT(INT,NUM_CUOTAS_VENCIDAS) AS 'NUM_CUOTAS_VENCIDAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_30_DIAS, '0')) AS 'MONTO_VENCIDO_30_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_60_DIAS, '0')) AS 'MONTO_VENCIDO_60_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_90_DIAS, '0')) AS 'MONTO_VENCIDO_90_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_120_DIAS, '0')) AS 'MONTO_VENCIDO_120_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_180_DIAS, '0')) AS 'MONTO_VENCIDO_180_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_ANUAL, '0')) AS 'MONTO_VENCIDO_ANUAL',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_MAYOR_ANUAL, '0')) AS 'MONTO_VENCIDO_MAYOR_ANUAL',
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N030DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N030DMONTOAVENCER,17,2) AS 'MontoVencer30dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N060DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N060DMONTOAVENCER,17,2) AS 'MontoVencer60dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N090DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N090DMONTOAVENCER,17,2) AS 'MontoVencer90dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N120DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N120DMONTOAVENCER,17,2) AS 'MontoVencer120dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N180DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N180DMONTOAVENCER,17,2) AS 'MontoVencer180dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N360DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N360DMONTOAVENCER,17,2) AS 'MontoVencerUnAno', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.MA1AMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.MA1AMONTOAVENCER,17,2) AS 'MontoVencerMasUnAno', --busqueda desde cosmos YR
	
		CONVERT(INT,BANCA_SOCIAL) AS BANCA_SOCIAL,
		CONVERT(INT,PRODUCCION_SOCIAL) AS PRODUCCION_SOCIAL,
		'0' AS 'MODALIDAD_MICROCREDITO',
		CONVERT(INT,USO_FINANCIERO) AS 'USO_FINANCIERO',
		'0' AS 'DESTINO_RECURSOS_MICROFINANCIEROS',
		CONVERT(INT,CANT_TRABAJADORES) AS 'CANT_TRABAJADORES',
		CONVERT(DECIMAL(15,2),VENTAS_ANUALES) AS 'VENTAS_ANUALES',
		CONVERT(VARCHAR(10),FECHA_ESTADO_FINANCIERO,111) AS 'FECHA_ESTADO_FINANCIERO',
		'' AS 'NUM_RTN',
		'' AS 'LICENCIA_TURISTICA_NACIONAL',
		'1900/01/01' AS 'FECHA_EMISION_FACTIBILIDAD_TECNICA',
		'0' AS 'NUM_EXPEDIENTE_FACTIBILIDAD_SOCIOTECNICA',
		'0' AS 'NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA',
		'' AS 'NOMBRE_PROYECTO',
		'' AS 'DireccionProyectooUnidadProduccion',
		'0' AS 'COD_TIPO_PROYECTO',
		'0' AS 'COD_TIPO_OPERACIONES_FINANCIAMIENTO',
		'0' AS 'COD_SEGMENTO',
		'0' AS 'TIPO_ZONA',
		'1900/01/01' AS 'FECHA_AUTENTICACION',
		'1900/01/01' AS 'FECHA_ULTIMA_INSPECCION',
		'0' AS 'PORCENTAJE_EJECUCION_PROYECTO',
		'0' AS 'PAGOS_EFECTUADOS_MENSUALES',
		'0' AS 'MONTOS_LIQUIDADOS_CIERRE',
		'0' AS 'AMORTIZACIONES_CAPITAL_ACUMULADAS',
		'0' AS 'TASA_INCENTIVO',
		'' AS 'NUMERO_OFICIO_INCENTIVO',
		'0' AS 'NUM_REGISTRO',
		'' AS 'TIPO_REGISTRO',
		'1900/01/01' AS 'FECHA_VENC_REGISTRO',
		'0' AS 'TIPO_SUBSECTOR',
		'0' AS 'RUBRO',
		'0' AS 'COD_USO',
		'0' AS 'CANT',
		'0' AS 'COD_UNIDAD_MEDIDA',
		'0' AS 'SECTOR_PRODUCCION',
		'0' AS 'CANT_HECTAREAS',
		'0' AS 'SUPERFICIE_TOTAL',
		'0' AS 'NUM_BENEFICIARIOS',
		'0' AS 'PRIORITARIO',
		CONVERT(DECIMAL,DESTINO_MANUFACTURERO) AS 'DESTINO_MANUFACTURERO',
		CONVERT(DECIMAL,DESTINO_ECONOMICO) AS 'DESTINO_ECONOMICO',
		'0' AS 'TIPO_BENEFICIARIO',
		'0' AS 'MODALIDAD_HIPOTECARIA',
		'0' AS 'INGRESO_FAMILIAR',
		'0' AS 'MONTO_LIQUIDADO_ANUAL',
		'0' AS 'SALDO_CREDITO_31_12',
		'0' AS 'CANT_VIVIENDAS',
		'0' AS 'RendimientosCobrarReestructurados',
		'0' AS 'RendimientosCobrarAfectosReporto',
		'0' AS 'RendimientosCobrarLitigio',
		ISNULL(GAV.[Intereses Efectivamente Cobrados], ISNULL(TMP.InteresesEfectivamenteCobrados,@Cero)) AS 'InteresEfectivamenteCobrado',
		ISNULL(GAV.[Porcentaje de Comisión FLAT], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(GAV.[Monto Comisión FLAT],ISNULL(TMP.MontoComisionFLAT,'0,00')) AS	'MontoComisionFlat',
		ISNULL(GAV.[Periodicidad de Pago Especial de Capital], ISNULL(TMP.PeriodicidadPagoEspecialCapital,'0')) AS 'PeriocidadPagoEspecialCapital',
		ISNULL(GAV.[Fecha de Cambio de Estatus del Crédito], ISNULL(TMP.FechaCambioEstatusCredito,'19000101')) AS	'FechaCambioEstatusCredito',
		ISNULL(GAV.[Fecha de Registro en Vencida, Litigio o Castigada], ISNULL(TMP.FechaRegistroVencidaLitigioCastigada,ISNULL(SC.[Fecha_Registro_Vencida_Litigio_Castigada],ISNULL(SCS.[Fecha_Registro_Vencida_Litigio_Castigada],'19000101')))) AS 'FechaRegistroVencidaLitigiooCastigada',
		ISNULL(GAV.[Fecha de Exigibilidad de Pago de la última Cuota Pagada], ISNULL(TMP.FechaExigibilidadPagoUltimaCuotaPagada,'19000101')) AS 'FechaExigibilidadPagoUltimaCuotaPagada',
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		'0,00' AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0')AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(GAV.[Capital Transferido], ISNULL(TMP.CapitalTransferido,@Cero)) AS 'CapitalTransferido',
		ISNULL(GAV.[Fecha de Cambio de Estatus Capital Transferido], ISNULL(TMP.FechaCambioEstatusCapitalTransferido,'19000101')) AS	'FechaCambioEstatusCapitalTransferido',
		10 AS 'TipoDC',
		0 AS 'IdLote',
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM RPT_STG_Dirigidas_MANUFACTURA E
	LEFT JOIN TB_DCAT04_04 DC04 ON E.NUM_CREDITO = DC04.REFERNO --Data Corporativo
	LEFT JOIN tbGavetas GAV on E.NUM_CREDITO = GAV.[Número de Crédito] 
	LEFT JOIN TB_CarteraNoDirigidaFINAL TMP ON  E.NUM_CREDITO = TMP.REFERENCIA
	LEFT JOIN TMP_SobregirosCorporativo SC ON E.NUM_CREDITO  = SC.REFERENCIA
	LEFT JOIN TMP_SobregirosConsumer SCS ON  E.NUM_CREDITO = SCS.ACCT
	LEFT JOIN tb_dcat04_01 DC01 on E.NUM_CREDITO = DC01.Acct
	LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC04.SICVENCLI = Equi.CodigoCiti 
		AND Equi.AtomoSif = 'CTE'
		AND Equi.TablaSif = 'SB10'
		AND Equi.Insumo = 'COSMOS'	
		
EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Manufactura AT04 - ', NULL, NULL, 'ATOMATICO'		
--------------------------
END TRY -- Fin Tipo DC 10 Cartera Manufactura
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera Manufactura', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 7 Cartera Hipotecario Corto Plazo
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	SELECT 
		RTRIM(LTRIM(B.NUM_CREDITO)) AS 'NUM_CREDITO',
		CONVERT(VARCHAR(10),B.FECHA_LIQUIDACION,111) AS 'FECHA_LIQUIDACION',
		CONVERT(VARCHAR(10),B.FECHA_SOLICITUD,111) AS 'FECHA_SOLICITUD',
		CONVERT(VARCHAR(10),B.FECHA_APROBACION,111) AS 'FECHA_APROBACION',
	
		CASE 
			WHEN CONVERT(INT,B.COD_OFICINA) = 1 THEN '02'  
			ELSE CONVERT(INT,B.COD_OFICINA)
		END AS 'Oficina',--YR 14/08/2012
	
		B.COD_CONTABLE,
		CONVERT(DECIMAL,RTRIM(LTRIM(B.NUM_CREDITO_PRIMER_DESEMBOLSO))) AS 'NUM_CREDITO_PRIMER_DESEMBOLSO',
		CONVERT(INT,B.NUM_DESEMBOLSO) AS 'NUM_DESEMBOLSO',
		'1' AS 'CodigodeLineadeCredito', --Valor por defecto NO
		'0' AS 'MontoLineaCredito', 
		B.ESTADO_CREDITO,
	
		CASE 
			WHEN B.ESTADO_CREDITO = '3' THEN '0'  
			ELSE B.TIPO_CREDITO
		END AS 'TipoCredito',--YR 14/08/2012
	
		B.SITUACION_CREDITO,
		CASE B.PLAZO_CREDITO
			WHEN '1' THEN 'C'
			WHEN '2' THEN 'M'
			WHEN '3' THEN 'L'
			ELSE B.PLAZO_CREDITO
		END AS 'PLAZO_CREDITO',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		B.CLASE_RIESGO,
		'F41' AS 'DestinoDelCredito',
		B.NATURALEZA_CLIENTE,
		B.TIPO_CLIENTE,
		RIGHT(B.NUM_CLIENTE,9) AS 'NUM_CLIENTE', --fz
		REPLACE(LTRIM(RTRIM(UPPER(B.NOMBRE_CLIENTE))),'''','´') AS 'NOMBRE_CLIENTE',
		CASE 
			WHEN B.GENERO IN ('1','2', '0') THEN B.GENERO --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		B.TIPO_CLIENTE AS 'TipoClienteRIF', 
		RIGHT(B.NUM_CLIENTE,9) AS 'IdentificacionTipoClienteRIF', --fz
		ISNULL(Equi.CodigoSIF,'F41') AS 'Actividad del Cliente', --fz
		CASE 
			WHEN UPPER(B.TIPO_CLIENTE) IN ('V','J','G') THEN 'VE' --fz
			ELSE 'XX' --YR 14/08/2012
		END AS 'Pais_Nacionalidad',
		LEFT(REPLACE(LTRIM(RTRIM(UPPER(DC04.ADDRESS3 + ' ' + DC04.ADDRESS4  + ' ' +  DC04.ADDRESS5  + ' ' +  DC04.ADDRESS6))),'''','´'),200) AS 'Domicilio_Fiscal', --fz
		B.CLIENTE_NUEVO,
		B.COOPERATIVA,
		'0' AS Sindicado, --Valor por defecto
		'0' As 'BancoLiderSindicado', --Valor por defecto
		'1' AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero', --Valor por defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por defecto
		ISNULL(B.COD_PARROQUIA,'010109') AS 'COD_PARROQUIA',
		CONVERT(INT,B.PERIODO_GRACIA_CAPITAL) AS PERIODO_GRACIA_CAPITAL,
		CONVERT(INT,B.PERIODO_PAGO_CAPITAL) AS PERIODO_PAGO_CAPITAL,
		CONVERT(INT,B.PERIODO_PAGO_INTERES) AS PERIODO_PAGO_INTERES,
		CONVERT(VARCHAR(10),B.FECHA_VENC_ORIGINAL,111) AS 'FECHA_VENC_ORIGINAL',
		CONVERT(VARCHAR(10),B.FECHA_VENC_ACTUAL,111) AS 'FECHA_VENC_ACTUAL',
		CONVERT(VARCHAR(10),B.FECHA_REESTRUCTURACION,111) AS 'FECHA_REESTRUCTURACION',
		CONVERT(INT,B.CANT_PRORROGAS) AS 'CANT_PRORROGAS',
		CONVERT(VARCHAR(10),B.FECHA_PRORROGA,111) AS 'FECHA_PRORROGA',
		CONVERT(INT,CANT_RENOVACIONES) AS 'CANT_RENOVACIONES',
		CONVERT(VARCHAR(10),FECHA_ULTIMA_RENOVACION,111) AS 'FECHA_ULTIMA_RENOVACION',
		CONVERT(VARCHAR(10),FECHA_CANCEL,111) AS 'FECHA_CANCEL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_CAPITAL,111) AS 'FECHA_VENC_ULTIMA_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_INTERES,111) AS 'FECHA_VENC_ULTIMA_CUOTA_INTERES',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_INTERES,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_INTERES',
		'VEB' AS 'Moneda', --Valor por defecto
		'1' AS 'TipoCambioOriginal', --Valor por defecto
		'1' AS 'TipoCambioCierreMes', --Valor por defecto
		CONVERT(DECIMAL(15,2),MONTO_ORIGINAL) AS 'MONTO_ORIGINAL',
		CONVERT(DECIMAL(15,2),MONTO_INICIAL) AS 'MONTO_INICIAL',
		CONVERT(DECIMAL(15,2),MONTO_LIQUIDADO_MES) AS 'MONTO_LIQUIDADO_MES',
		'0' As 'EntePublico', --Valor por defecto
		'0' AS 'MontoInicialTerceros', --Valor por defecto
		CONVERT(DECIMAL(15,2),B.SALDO) AS 'SALDO',
		RENDIMIENTOS_X_COBRAR AS 'RENDIMIENTOS_X_COBRAR',
		RENDIMIENTOS_X_COBRAR_VENCIDOS AS 'RENDIMIENTOS_X_COBRAR_VENCIDOS',
		'0' AS 'RendimientosCobrarMora', --YR 06/09/2012 SETEAR 0 POR DEFECTO --'' AS 'RendimientosPorCobrarMora',	--Pendiente definición
	
		--CASE 
		--	WHEN B.ESTADO_CREDITO IN ('2','3') THEN '0'  
		--	ELSE CONVERT(DECIMAL(15,4),PROVISION_ESPECIFICA)
		--END AS 'PROVISION_ESPECIFICA',--YR 14/08/2012
		--CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		
		CASE 
		WHEN B.ESTADO_CREDITO IN ('2','3') THEN '0'
		END,
		
		
		B.PROVISION_ESPECIFICA AS 'PROVISION_ESPECIFICA',
		B.PORCENTAJE_PROVISION_ESPECIFICA AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		B.PROVISION_RENDIMIENTO_X_COBRAR AS 'PROVISION_RENDIMIENTO_X_COBRAR',
	
		CASE 
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS = @Cero THEN '0'  
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS > @Cero AND CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) = 0.0000 THEN -0.01   
			ELSE CONVERT(DECIMAL(15,4),PROVISION_RENDIMIENTO_X_COBRAR)
		END AS 'PROVISION_RENDIMIENTO_X_COBRAR',--YR 14/08/2012
	
		CONVERT(DECIMAL(15,4),TASA_INTERES_COBRADA) AS 'TASA_INTERES_COBRADA',
		CONVERT(DECIMAL(15,4),TASA_INTERES_ACTUAL) AS 'TASA_INTERES_ACTUAL',
		'1' AS 'IndicadorTasaPreferencial', --FZ
		CONVERT(DECIMAL(15,4),TASA_COMISION) AS 'TASA_COMISION', --fz
		'0' AS 'ComisionesPorCobrar',
		'0' AS 'ComisionesCobradas',
		CONVERT(DECIMAL(15,2),EROGACIONES_RECUPERABLES) AS 'EROGACIONES_RECUPERABLES',
		CONVERT(INT,TIPO_GARANTIA_PRINCIPAL) AS 'TIPO_GARANTIA_PRINCIPAL', --fz
		CONVERT(INT,NUM_CUOTAS) AS 'NUM_CUOTAS',
		CONVERT(INT,NUM_CUOTAS_VENCIDAS) AS 'NUM_CUOTAS_VENCIDAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_30_DIAS, '0')) AS 'MONTO_VENCIDO_30_DIAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_60_DIAS, '0')) AS 'MONTO_VENCIDO_60_DIAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_90_DIAS, '0')) AS 'MONTO_VENCIDO_90_DIAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_120_DIAS, '0')) AS 'MONTO_VENCIDO_120_DIAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_180_DIAS, '0')) AS 'MONTO_VENCIDO_180_DIAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_ANUAL, '0')) AS 'MONTO_VENCIDO_ANUAL',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_MAYOR_ANUAL, '0')) AS 'MONTO_VENCIDO_MAYOR_ANUAL',

		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N030DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N030DMONTOAVENCER,17,2) AS 'MontoVencer30dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N060DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N060DMONTOAVENCER,17,2) AS 'MontoVencer60dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N090DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N090DMONTOAVENCER,17,2) AS 'MontoVencer90dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N120DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N120DMONTOAVENCER,17,2) AS 'MontoVencer120dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N180DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N180DMONTOAVENCER,17,2) AS 'MontoVencer180dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N360DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N360DMONTOAVENCER,17,2) AS 'MontoVencerUnAno', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.MA1AMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.MA1AMONTOAVENCER,17,2) AS 'MontoVencerMasUnAno', --busqueda desde cosmos YR
		
		CONVERT(INT,BANCA_SOCIAL) AS BANCA_SOCIAL, --fz
		CONVERT(INT,PRODUCCION_SOCIAL) AS PRODUCCION_SOCIAL, --fz
		'0' AS 'INTMODALIDAD_MICROCREDITO', --Valor por defecto
		'0' AS 'USO_FINANCIERO', --Valor por defecto
		'0' AS 'DESTINO_RECURSOS_MICROFINANCIEROS', --Valor por defecto
		'0' AS 'CANT_TRABAJADORES', --Valor por defecto
		'0' AS 'VENTAS_ANUALES', --Valor por defecto
		'1900/01/01' AS 'FECHA_ESTADO_FINANCIERO', --Valor por defecto
		'' AS 'NUM_RTN', --Valor por defecto
		'' AS 'LICENCIA_TURISTICA_NACIONAL', --Valor por defecto
		'1900/01/01' AS 'FECHA_EMISION_FACTIBILIDAD_TECNICA', --Valor por defecto
		'0' AS 'NUM_EXPEDIENTE_FACTIBILIDAD_SOCIOTECNICA', --Valor por defecto
		'0' AS 'NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA', --Valor por defecto
		'' AS 'NOMBRE_PROYECTO', --Valor por defecto
		'' AS 'DireccionProyectooUnidadProduccion',
		'0' AS 'COD_TIPO_PROYECTO', --Valor por defecto
		'0' AS 'COD_TIPO_OPERACIONES_FINANCIAMIENTO', --Valor por defecto
		'0' AS 'COD_SEGMENTO', --Valor por defecto
		'0' AS 'TIPO_ZONA', --Valor por defecto
		'1900/01/01' AS 'FECHA_AUTENTICACION', --Valor por defecto
		'1900/01/01' AS 'FECHA_ULTIMA_INSPECCION', --Valor por defecto
		'0' AS 'PORCENTAJE_EJECUCION_PROYECTO', --Valor por defecto
		'0' AS 'PAGOS_EFECTUADOS_MENSUALES', --Valor por defecto
		'0' AS 'MONTOS_LIQUIDADOS_CIERRE', --Valor por defecto
		'0' AS 'AMORTIZACIONES_CAPITAL_ACUMULADAS', --Valor por defecto
		'0' AS 'TASA_INCENTIVO', --Valor por defecto
		'' AS 'NUMERO_OFICIO_INCENTIVO', --Valor por defecto
		'0' AS 'NUM_REGISTRO', --Valor por defecto
		'' AS 'TIPO_REGISTRO', --Valor por defecto
		'1900/01/01' AS 'FECHA_VENC_REGISTRO', --Valor por defecto
		'0' AS 'TIPO_SUBSECTOR',
		'0' AS 'RUBRO',
		'0' AS 'COD_USO',
		'0' AS 'CANT',
		'0' AS 'COD_UNIDAD_MEDIDA',
		'0' AS 'SECTOR_PRODUCCION',
		'0' AS 'CANT_HECTAREAS',
		'0' AS 'SUPERFICIE_TOTAL',
		'0' AS 'NUM_BENEFICIARIOS',
		'0' AS 'PRIORITARIO',
		'0' AS 'DESTINO_MANUFACTURERO',
		'0' AS 'DESTINO_ECONOMICO',
		CONVERT(INT,TIPO_BENEFICIARIO) AS 'TIPO_BENEFICIARIO',
		CONVERT(INT,MODALIDAD_HIPOTECARIA) AS 'MODALIDAD_HIPOTECARIA',
		CONVERT(DECIMAL(15,4),INGRESO_FAMILIAR) AS 'INGRESO_FAMILIAR',
		CONVERT(DECIMAL(15,4),MONTO_LIQUIDADO_ANUAL) AS 'MONTO_LIQUIDADO_ANUAL',
		CONVERT(DECIMAL(15,4),SALDO_CREDITO_31_12) AS 'SALDO_CREDITO_31_12',
		CONVERT(DECIMAL(15),CANT_VIVIENDAS) AS 'CANT_VIVIENDAS',
		----------------
		'0' AS 'RendimientosCobrarReestructurados',
		'0' AS 'RendimientosCobrarAfectosReporto',
		'0' AS 'RendimientosCobrarLitigio',
		ISNULL(GAV.[Intereses Efectivamente Cobrados], ISNULL(TMP.InteresesEfectivamenteCobrados,@Cero)) AS 'InteresEfectivamenteCobrado',
		ISNULL(GAV.[Porcentaje de Comisión FLAT], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(GAV.[Monto Comisión FLAT],ISNULL(TMP.MontoComisionFLAT,'0,00')) AS	'MontoComisionFlat',
		ISNULL(GAV.[Periodicidad de Pago Especial de Capital], ISNULL(TMP.PeriodicidadPagoEspecialCapital,'0')) AS 'PeriocidadPagoEspecialCapital',
		ISNULL(GAV.[Fecha de Cambio de Estatus del Crédito], ISNULL(TMP.FechaCambioEstatusCredito,'19000101')) AS	'FechaCambioEstatusCredito',
		ISNULL(GAV.[Fecha de Registro en Vencida, Litigio o Castigada], ISNULL(TMP.FechaRegistroVencidaLitigioCastigada,ISNULL(SC.[Fecha_Registro_Vencida_Litigio_Castigada],ISNULL(SCS.[Fecha_Registro_Vencida_Litigio_Castigada],'19000101')))) AS 'FechaRegistroVencidaLitigiooCastigada',
		ISNULL(GAV.[Fecha de Exigibilidad de Pago de la última Cuota Pagada], ISNULL(TMP.FechaExigibilidadPagoUltimaCuotaPagada,'19000101')) AS 'FechaExigibilidadPagoUltimaCuotaPagada',
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		'0,00' AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0')AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(GAV.[Capital Transferido], ISNULL(TMP.CapitalTransferido,@Cero)) AS 'CapitalTransferido',
		ISNULL(GAV.[Fecha de Cambio de Estatus Capital Transferido], ISNULL(TMP.FechaCambioEstatusCapitalTransferido,'19000101')) AS	'FechaCambioEstatusCapitalTransferido',
		----------------
		7 AS 'TipoDC',
		0 AS 'IdLote',
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM RPT_STG_Dirigidas_HIPOTECARIO_CORTO_PLAZO B
	LEFT JOIN TB_DCAT04_04 DC04 ON B.NUM_CREDITO = DC04.REFERNO --Data Corporativo
	LEFT JOIN tbGavetas GAV on B.NUM_CREDITO = GAV.[Número de Crédito] 
	LEFT JOIN TB_CarteraNoDirigidaFINAL TMP ON  B.NUM_CREDITO = TMP.REFERENCIA
	LEFT JOIN TMP_SobregirosCorporativo SC ON B.NUM_CREDITO  = SC.REFERENCIA
	LEFT JOIN TMP_SobregirosConsumer SCS ON  B.NUM_CREDITO = SCS.ACCT	
	LEFT JOIN TB_DCAT04_01 DC01 ON B.NUM_CREDITO = DC01.ACCT --LDWH
	LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC04.SICVENCLI = Equi.CodigoCiti 
		AND Equi.AtomoSif = 'CTE'
		AND Equi.TablaSif = 'SB10'
		AND Equi.Insumo = 'COSMOS'
		
EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Hipotecario Corto Plazo AT04 - ', NULL, NULL, 'ATOMATICO'		
--------------------------
END TRY -- Fin Tipo DC 7 Cartera Hipotecario Corto Plazo
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera Hipotecario Corto Plazo', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 6 Cartera Hipotecario Largo Plazo
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,			
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	
	SELECT
		A.NUM_CREDITO AS 'NUM_CREDITO',
		CONVERT(VARCHAR(10),A.FECHA_LIQUIDACION,111) AS 'FECHA_LIQUIDACION',
		CONVERT(VARCHAR(10),A.FECHA_SOLICITUD,111) AS 'FECHA_SOLICITUD',
		CONVERT(VARCHAR(10),A.FECHA_APROBACION,111) AS 'FECHA_APROBACION',
	
		CASE 
			WHEN CONVERT(INT,A.COD_OFICINA) = 1 THEN '02'  
			ELSE CONVERT(INT,A.COD_OFICINA)
		END AS 'Oficina',--YR 14/08/2012
	
		A.COD_CONTABLE,
		CONVERT(DECIMAL,A.NUM_CREDITO_PRIMER_DESEMBOLSO) AS 'NUM_CREDITO_PRIMER_DESEMBOLSO',
		CONVERT(INT,A.NUM_DESEMBOLSO) AS 'NUM_DESEMBOLSO',
		'1' AS 'CodigodeLineadeCredito', --Valor por defecto NO
		'0' AS 'MONTO_INICIAL',
		A.ESTADO_CREDITO,
		CASE 
			WHEN A.ESTADO_CREDITO = '3' THEN '0'  
			ELSE A.TIPO_CREDITO
		END AS 'TipoCredito',--YR 14/08/2012
	
		A.SITUACION_CREDITO,
		CASE A.PLAZO_CREDITO
			WHEN '1' THEN 'C'
			WHEN '2' THEN 'M'
			WHEN '3' THEN 'L'
			ELSE PLAZO_CREDITO
		END AS 'PLAZO_CREDITO',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		A.CLASE_RIESGO,
		'L68' AS 'DestinoDelCredito', --fz
		A.NATURALEZA_CLIENTE,
		A.TIPO_CLIENTE,
		CONVERT(DECIMAL,A.NUM_CLIENTE) AS 'NUM_CLIENTE', 
		REPLACE(LTRIM(RTRIM(UPPER(A.NOMBRE_CLIENTE))),'''','´') AS 'NOMBRE_CLIENTE',
		CASE 
			WHEN A.GENERO IN ('1','2', '0') THEN A.GENERO --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		A.TIPO_CLIENTE AS 'TipoClienteRIF',
		CASE 
			WHEN A.TIPO_CLIENTE = 'V' OR A.TIPO_CLIENTE = 'E' THEN SUBSTRING(dbo.GetRif(A.TIPO_CLIENTE + CAST(CONVERT(DECIMAL,A.NUM_CLIENTE) AS VARCHAR)),2,20)
			ELSE CAST(CONVERT(DECIMAL,A.NUM_CLIENTE) AS VARCHAR)
		END AS 'IdentificacionTipoClienteRIF',
		ISNULL(Equi.CodigoSIF,'XXX') AS 'Actividad_Cliente', --YR 14/08/2012 XXX
		CASE 
			WHEN UPPER(A.TIPO_CLIENTE) IN ('V','J','G') THEN 'VE' --fz
			ELSE ISNULL(UPPER(DC05.Nacionalidad),'XX')
		END AS 'Pais_Nacionalidad',
		LEFT(REPLACE(LTRIM(RTRIM(UPPER(DC01.DireccionH))),'''','´'),200) AS 'Domicilio_Fiscal', --fz
		A.CLIENTE_NUEVO, --fz
		A.COOPERATIVA, --fz
		'0' AS 'Sindicado', --Valor por defecto
		'0' As 'BancoLiderSindicado', --Valor por defecto
		DC01.Staff AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero', --Valor por defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por defecto
		ISNULL(COD_PARROQUIA,'010109') AS 'COD_PARROQUIA',
		CONVERT(INT,PERIODO_GRACIA_CAPITAL) AS 'PERIODO_GRACIA_CAPITAL',
		CONVERT(INT,PERIODO_PAGO_CAPITAL) AS 'PERIODO_PAGO_CAPITAL',
		CONVERT(INT,PERIODO_PAGO_CAPITAL) AS 'PERIODO_PAGO_INTERES',  --YR 14/08/2012 ANTERIORMENTE CONVERT(INT,PERIODO_PAGO_INTERES)
		CONVERT(VARCHAR(10),FECHA_VENC_ORIGINAL,111) AS 'FECHA_VENC_ORIGINAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ACTUAL,111) AS 'FECHA_VENC_ACTUAL',
		CONVERT(VARCHAR(10),FECHA_REESTRUCTURACION,111) AS 'FECHA_REESTRUCTURACION',
		CONVERT(INT,CANT_PRORROGAS) AS 'CANT_PRORROGAS',
		CONVERT(VARCHAR(10),FECHA_PRORROGA,111) AS 'FECHA_PRORROGA',
		CONVERT(INT,CANT_RENOVACIONES) AS 'CANT_RENOVACIONES',
		CONVERT(VARCHAR(10),FECHA_ULTIMA_RENOVACION,111) AS 'FECHA_ULTIMA_RENOVACION',
		CONVERT(VARCHAR(10),FECHA_CANCEL,111) AS 'FECHA_CANCEL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_CAPITAL,111) AS 'FECHA_VENC_ULTIMA_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_INTERES,111) AS 'FECHA_VENC_ULTIMA_CUOTA_INTERES',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_INTERES,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_INTERES',
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),MONTO_ORIGINAL) AS 'MONTO_ORIGINAL',
		CONVERT(DECIMAL(15,4),MONTO_INICIAL) AS 'MONTO_INICIAL',
		CONVERT(DECIMAL(15,4),MONTO_LIQUIDADO_MES) AS 'MONTO_LIQUIDADO_MES',
		'0' As 'EntePublico', -- Valor por Defecto
		'0' AS 'MontoInicialTerceros', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),SALDO) AS 'SALDO',
		CASE
			WHEN TMPR.SaldoRendXcobrar = @Cero OR TMPR.SaldoRendXcobrar IS NULL
			THEN RENDIMIENTOS_X_COBRAR
			ELSE TMPR.SaldoRendXcobrar
		END AS 'RendimientosCobrar', 
		CASE
			WHEN TMPR.SaldoRendXcobrarVenc = @Cero OR RENDIMIENTOS_X_COBRAR_VENCIDOS IS NULL
			THEN RENDIMIENTOS_X_COBRAR_VENCIDOS
			ELSE TMPR.SaldoRendXcobrarVenc
		END AS 'RendimientosCobrarVencidos', 
		ISNULL(TMPR.SaldoRendXMora,@Cero) AS 'RendimientosCobrarMora', 
		--CASE 
		--	WHEN A.ESTADO_CREDITO IN ('2','3') THEN '0'  
		--	ELSE CONVERT(DECIMAL(15,4),PROVISION_ESPECIFICA)
		--END AS 'PROVISION_ESPECIFICA',--YR 14/08/2012
		--CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		
		CASE 
			WHEN A.ESTADO_CREDITO IN ('2','3') THEN '0'  
		END,
		
		A.PROVISION_ESPECIFICA AS 'PROVISION_ESPECIFICA',
		A.PORCENTAJE_PROVISION_ESPECIFICA AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		A.PROVISION_RENDIMIENTO_X_COBRAR AS 'PROVISION_RENDIMIENTO_X_COBRAR',
	
	
		CASE 
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS = @Cero THEN '0' 
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS > @Cero AND CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) = 0.0000 THEN -0.01    
			ELSE CONVERT(DECIMAL(15,4),PROVISION_RENDIMIENTO_X_COBRAR)
		END AS 'PROVISION_RENDIMIENTO_X_COBRAR',--YR 14/08/2012
	
		CONVERT(DECIMAL(15,4),TASA_INTERES_COBRADA) AS 'TASA_INTERES_COBRADA',
		CONVERT(DECIMAL(15,4),TASA_INTERES_ACTUAL) AS 'TASA_INTERES_ACTUAL',
		DC01.Staff  AS 'IndicadorTasaPreferencial', 
		CONVERT(DECIMAL(15,4),TASA_COMISION) AS 'TASA_COMISION',
		'0' AS 'ComisionesPorCobrar',
		'0' AS 'ComisionesCobradas', --OJO pendiente calculo cuando se liquida en el mes
		CONVERT(DECIMAL(15,4),EROGACIONES_RECUPERABLES) AS 'EROGACIONES_RECUPERABLES',
		CONVERT(INT,TIPO_GARANTIA_PRINCIPAL) AS 'TIPO_GARANTIA_PRINCIPAL',
		CONVERT(INT,NUM_CUOTAS) AS 'NUM_CUOTAS',
		ISNULL(CONVERT(INT,NUM_CUOTAS_VENCIDAS), '0') AS 'NUM_CUOTAS_VENCIDAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_30_DIAS, '0')) AS 'MONTO_VENCIDO_30_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_60_DIAS, '0')) AS 'MONTO_VENCIDO_60_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_90_DIAS, '0')) AS 'MONTO_VENCIDO_90_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_120_DIAS, '0')) AS 'MONTO_VENCIDO_120_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_180_DIAS, '0')) AS 'MONTO_VENCIDO_180_DIAS',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_ANUAL, '0')) AS 'MONTO_VENCIDO_ANUAL',
		CONVERT(DECIMAL(15,4),ISNULL(MONTO_VENCIDO_MAYOR_ANUAL, '0')) AS 'MONTO_VENCIDO_MAYOR_ANUAL',
		'0' AS 'MontoVencer30dias', --Valor por defecto
		'0' AS 'MontoVencer60dias', --Valor por defecto
		'0' AS 'MontoVencer90dias', --Valor por defecto
		'0' AS 'MontoVencer120dias', --Valor por defecto
		'0' AS 'MontoVencer180dias', --Valor por defecto
		'0' AS 'MontoVencerUnAño', --Valor por defecto
		'0' AS 'MontoVencerMasDeUnAño', --Valor por defecto
		CONVERT(INT,BANCA_SOCIAL) AS BANCA_SOCIAL,
		CONVERT(INT,PRODUCCION_SOCIAL) AS PRODUCCION_SOCIAL,
		'0' AS 'INTMODALIDAD_MICROCREDITO',
		'0' AS 'USO_FINANCIERO',
		'0' AS 'DESTINO_RECURSOS_MICROFINANCIEROS',
		'0' AS 'CANT_TRABAJADORES',
		'0' AS 'VENTAS_ANUALES',
		'1900/01/01' AS 'FECHA_ESTADO_FINANCIERO',
		'' AS 'NUM_RTN',
		'' AS 'LICENCIA_TURISTICA_NACIONAL',
		'1900/01/01' AS 'FECHA_EMISION_FACTIBILIDAD_TECNICA',
		'0' AS 'NUM_EXPEDIENTE_FACTIBILIDAD_SOCIOTECNICA',
		'0' AS 'NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA',
		'' AS 'NOMBRE_PROYECTO',
		'' AS 'DireccionProyectooUnidadProduccion', --fz
		'0' AS 'COD_TIPO_PROYECTO',
		'0' AS 'COD_TIPO_OPERACIONES_FINANCIAMIENTO',
		'0' AS 'COD_SEGMENTO',
		'0' AS 'TIPO_ZONA',
		'1900/01/01' AS 'FECHA_AUTENTICACION',
		'1900/01/01' AS 'FECHA_ULTIMA_INSPECCION',
		'0' AS 'PORCENTAJE_EJECUCION_PROYECTO',
		'0' AS 'PAGOS_EFECTUADOS_MENSUALES',
		'0' AS 'MONTOS_LIQUIDADOS_CIERRE',
		'0' AS 'AMORTIZACIONES_CAPITAL_ACUMULADAS',
		'0' AS 'TASA_INCENTIVO',
		'' AS 'NUMERO_OFICIO_INCENTIVO',
		'0' AS 'NUM_REGISTRO',
		'' AS 'TIPO_REGISTRO',
		'1900/01/01' AS 'FECHA_VENC_REGISTRO',
		'0' AS 'TIPO_SUBSECTOR',
		'0' AS 'RUBRO',
		'0' AS 'COD_USO',
		'0' AS 'CANT',
		'0' AS 'COD_UNIDAD_MEDIDA',
		'0' AS 'SECTOR_PRODUCCION',
		'0' AS 'CANT_HECTAREAS',
		'0' AS 'SUPERFICIE_TOTAL',
		'0' AS 'NUM_BENEFICIARIOS',
		'0' AS 'PRIORITARIO',
		'0' AS 'DESTINO_MANUFACTURERO',
		'0' AS 'DESTINO_ECONOMICO',
		CONVERT(INT,TIPO_BENEFICIARIO) AS 'TIPO_BENEFICIARIO',		
		CONVERT(INT,MODALIDAD_HIPOTECARIA) AS 'MODALIDAD_HIPOTECARIA', --PENDIENTE ACTUALIZACION YR
		CONVERT(DECIMAL(15,4),INGRESO_FAMILIAR) AS 'INGRESO_FAMILIAR',
		CONVERT(DECIMAL(15,4),MONTO_LIQUIDADO_ANUAL) AS 'MONTO_LIQUIDADO_ANUAL',
		CONVERT(DECIMAL(15,4),SALDO_CREDITO_31_12) AS 'SALDO_CREDITO_31_12',
		CONVERT(DECIMAL(15),CANT_VIVIENDAS) AS 'CANT_VIVIENDAS',
		----------
		CASE 
			WHEN DC01.CtaLocal LIKE '132%' 
			THEN TMPR.SaldoRendXcobrar
			ELSE @Cero 
		END  AS 'RendimientosCobrarReestructurados',
		@Cero AS 'RendimientosCobrarAfectosReporto',
		@Cero AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS 'FechaCambioEstatusCapitalTransferido',
		----------
		6 AS 'TipoDC',
		0 AS 'IdLote',
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM RPT_STG_Dirigidas_HIPOTECARIO_LARGO_PLAZO A
		LEFT JOIN TB_DCAT04_01 DC01 ON A.NUM_CREDITO = DC01.ACCT --LDWH
		LEFT JOIN TB_DCAT04_05 DC05 ON A.TIPO_CLIENTE + CAST(CONVERT(DECIMAL,A.NUM_CLIENTE) AS VARCHAR) = DC05.IdentificadorCliente --Datos Clientes
		LEFT JOIN tbGavetas GAV on A.NUM_CREDITO = GAV.[Número de Crédito]
		LEFT JOIN TMP_Rendimiento TMPR on TMPR.acct = DC01.Acct	
		LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC01.ActivityID = Equi.CodigoCiti 
			AND Equi.AtomoSif = 'CTE'
			AND Equi.TablaSif = 'SB10'
			AND Equi.Insumo = 'CORE'
			
EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Hipotecario Largo Plazo - ', NULL, NULL, 'ATOMATICO'			
--------------------------
END TRY -- Fin Tipo DC 6 Cartera Hipotecario Largo Plazo
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera Hipotecario Largo Plazo', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 			

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 6 Cartera Hipotecario Largo Plazo (actualizaciones posteriores)
--------------------------
--Actualizar domicilio FISCAL de los creditos migrados.
UPDATE jf77062.TB_DMAT04 SET jf77062.TB_DMAT04.DomicilioFiscal = LEFT(REPLACE(LTRIM(RTRIM(UPPER(DC01.DireccionH))),'''','´'),200)
FROM TB_DCAT04_02 DC02
	LEFT JOIN TB_DCAT04_01 DC01 ON DC02.P8PRAN = DC01.ACCT --LDWH
WHERE jf77062.TB_DMAT04.TIPODC = 6 AND jf77062.TB_DMAT04.DomicilioFiscal is NULL and
CONVERT(DECIMAL,jf77062.TB_DMAT04.NUMEROCREDITO) = CONVERT(DECIMAL,DC02.P8NOTE) --LNP860
-------------------------------
--Actualizar RelacionCrediticia y IndicadorTasaPreferencial de los migrados
UPDATE jf77062.TB_DMAT04 SET 
	jf77062.TB_DMAT04.RelacionCrediticia = DC01.Staff,
	jf77062.TB_DMAT04.IndicadorTasaPreferencial = DC01.Staff
FROM TB_DCAT04_02 DC02
	LEFT JOIN TB_DCAT04_01 DC01 ON DC02.P8PRAN = DC01.ACCT --LDWH
WHERE jf77062.TB_DMAT04.TIPODC = 6 AND jf77062.TB_DMAT04.RelacionCrediticia is NULL and
CONVERT(DECIMAL,jf77062.TB_DMAT04.NUMEROCREDITO) = DC02.P8NOTE --LNP860
------------------------------
UPDATE jf77062.TB_DMAT04 SET ModalidadHipoteca =	'0'
WHERE TIPODC = 6 AND TipoCredito <> '3'  --YR 14/08/2012

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó actualizaciones posteriores de la cartera Hipotecario Largo Plazo - ', NULL, NULL, 'ATOMATICO'	
--------------------------
END TRY -- Fin Tipo DC 6 Cartera Hipotecario Largo Plazo (actualizaciones posteriores)
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera Hipotecario Largo Plazo (actualizaciones posteriores)', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 9 Cartera MicroFinanciero
--------------------------
INSERT INTO JF77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	SELECT 
		D.NUM_CREDITO AS 'NUM_CREDITO',
		CONVERT(VARCHAR(10),D.FECHA_LIQUIDACION,111) AS 'FECHA_LIQUIDACION',
		CONVERT(VARCHAR(10),D.FECHA_SOLICITUD,111) AS 'FECHA_SOLICITUD',
		CONVERT(VARCHAR(10),D.FECHA_APROBACION,111) AS 'FECHA_APROBACION',
		
		CASE 
			WHEN CONVERT(INT,D.COD_OFICINA) = 1 THEN '02'  
			ELSE CONVERT(INT,D.COD_OFICINA)
		END AS 'Oficina',--YR 14/08/2012
	
		D.COD_CONTABLE,
		CONVERT(DECIMAL,D.NUM_CREDITO_PRIMER_DESEMBOLSO) AS 'NUM_CREDITO_PRIMER_DESEMBOLSO',
		CONVERT(INT,D.NUM_DESEMBOLSO) AS 'NUM_DESEMBOLSO',			
		CASE
			WHEN DC01.TypeId IN (5) THEN '2'
			WHEN DC01.TypeId IN (16,17) THEN '1'
			WHEN DC01.TypeId IN (999) THEN '1' --TDC
			WHEN CONVERT(INT,D.ESTADO_CREDITO) = '3' THEN '1' 
			ELSE '-1' --fz
		END AS 'CodigodeLineadeCredito', 
		
		CASE 
			WHEN DC01.TypeId IN (5) THEN CONVERT(DECIMAL(15,4),MONTO_INICIAL) --fz
			WHEN DC01.TypeId IN (16,17) THEN 0
			WHEN DC01.TypeId IN (999) THEN 	0
			ELSE NULL --fz
		END AS 'MONTO_INICIAL',--PENDIENTE ACTUALIZACION YR 
		D.ESTADO_CREDITO,
	
		CASE 
			WHEN D.ESTADO_CREDITO = '3' THEN '0'  
			ELSE D.TIPO_CREDITO
		END AS 'TipoCredito',--YR 14/08/2012
	
		D.SITUACION_CREDITO,
		CASE D.PLAZO_CREDITO
			WHEN '1' THEN 'C'
			WHEN '2' THEN 'M'
			WHEN '3' THEN 'L'
			ELSE PLAZO_CREDITO
		END AS 'PLAZO_CREDITO',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		D.CLASE_RIESGO,
		ISNULL(Equi.CodigoSIF,'G45') AS 'DestinoDelCredito', --fz
		D.NATURALEZA_CLIENTE,
		D.TIPO_CLIENTE,
		CONVERT(DECIMAL,NUM_CLIENTE) AS 'NUM_CLIENTE',
		REPLACE(LTRIM(RTRIM(UPPER(NOMBRE_CLIENTE))),'''','´') AS 'NOMBRE_CLIENTE',
		CASE 
			WHEN D.GENERO IN ('1','2', '0') THEN D.GENERO --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		D.TIPO_CLIENTE AS 'TipoClienteRIF',
		CASE 
			WHEN D.TIPO_CLIENTE = 'V' OR D.TIPO_CLIENTE = 'E' THEN SUBSTRING(dbo.GetRif(D.TIPO_CLIENTE + CAST(CONVERT(DECIMAL,D.NUM_CLIENTE) AS VARCHAR)),2,20)
			ELSE CAST(CONVERT(DECIMAL,D.NUM_CLIENTE) AS VARCHAR)
		END AS 'IdentificacionTipoClienteRIF',
		ISNULL(Equi.CodigoSIF,'G45') AS 'Actividad del Cliente', --fz
		CASE 
			WHEN UPPER(D.TIPO_CLIENTE) in ('V','J','G') THEN 'VE' --fz
			ELSE ISNULL(UPPER(DC05.Nacionalidad),'XX')
		END AS 'Pais_Nacionalidad',
		DC01.DireccionH AS 'Domicilio_Fiscal', --fz
		D.CLIENTE_NUEVO, --fz
		D.COOPERATIVA,  --fz
		'0' AS 'Sindicado',
		'0' As 'BancoLiderSindicado',
		DC01.Staff AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero',
		'' AS 'NombreGrupoEconomicoFinanciero',
		ISNULL(COD_PARROQUIA,'010109') AS 'COD_PARROQUIA',
		CONVERT(INT,PERIODO_GRACIA_CAPITAL) AS 'PERIODO_GRACIA_CAPITAL',
		CONVERT(INT,PERIODO_PAGO_CAPITAL) AS 'PERIODO_PAGO_CAPITAL',
		CONVERT(INT,PERIODO_PAGO_CAPITAL) AS 'PERIODO_PAGO_INTERES',  --YR 14/08/2012 ANTERIORMENTE CONVERT(INT,PERIODO_PAGO_INTERES)
		CONVERT(VARCHAR(10),FECHA_VENC_ORIGINAL,111) AS 'FECHA_VENC_ORIGINAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ACTUAL,111) AS 'FECHA_VENC_ACTUAL',
		CONVERT(VARCHAR(10),FECHA_REESTRUCTURACION,111) AS 'FECHA_REESTRUCTURACION',
		CONVERT(INT,CANT_PRORROGAS) AS 'CANT_PRORROGAS',
		CONVERT(VARCHAR(10),FECHA_PRORROGA,111) AS 'FECHA_PRORROGA',
		CONVERT(INT,CANT_RENOVACIONES) AS 'CANT_RENOVACIONES',
		CONVERT(VARCHAR(10),FECHA_ULTIMA_RENOVACION,111) AS 'FECHA_ULTIMA_RENOVACION',
		CONVERT(VARCHAR(10),FECHA_CANCEL,111) AS 'FECHA_CANCEL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_CAPITAL,111) AS 'FECHA_VENC_ULTIMA_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_CAPITAL',
		CONVERT(VARCHAR(10),FECHA_VENC_ULTIMA_CUOTA_INTERES,111) AS 'FECHA_VENC_ULTIMA_CUOTA_INTERES',
		CONVERT(VARCHAR(10),ULTIMA_FECHA_CANCEL_CUOTA_INTERES,111) AS 'ULTIMA_FECHA_CANCEL_CUOTA_INTERES',
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),MONTO_ORIGINAL) AS 'MONTO_ORIGINAL',
		CONVERT(DECIMAL(15,4),MONTO_INICIAL) AS 'MONTO_INICIAL',	
		CONVERT(DECIMAL(15,4),MONTO_LIQUIDADO_MES) AS 'MONTO_LIQUIDADO_MES',
		'0' As 'EntePublico', -- Valor por Defecto
		'0' AS 'MontoInicialTerceros', -- Valor por Defecto
		CONVERT(DECIMAL(15,4),SALDO) AS 'SALDO',
		CASE
			WHEN TMPR.SaldoRendXcobrar = @Cero OR TMPR.SaldoRendXcobrar IS NULL
			THEN RENDIMIENTOS_X_COBRAR 
			ELSE TMPR.SaldoRendXcobrar
			END AS 'RendimientosCobrar', 
		CASE
			WHEN TMPR.SaldoRendXcobrarVenc = @Cero OR TMPR.SaldoRendXcobrarVenc IS NULL
			THEN RENDIMIENTOS_X_COBRAR_VENCIDOS
			ELSE TMPR.SaldoRendXcobrarVenc
			END AS 'RendimientosCobrarVencidos', 
		ISNULL(TMPR.SaldoRendXMora,@Cero) AS 'RendimientosCobrarMora', 		
		--CASE 
		--	WHEN D.ESTADO_CREDITO IN ('2','3') THEN '0'  
		--	ELSE CONVERT(DECIMAL(15,4),PROVISION_ESPECIFICA)
		--END AS 'PROVISION_ESPECIFICA',--YR 14/08/2012
		--CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) AS 'PORCENTAJE_PROVISION_ESPECIFICA',
			CASE 
			WHEN D.ESTADO_CREDITO IN ('2','3') THEN '0'  	
			END,
		D.PROVISION_ESPECIFICA AS 'PROVISION_ESPECIFICA',
		D.PORCENTAJE_PROVISION_ESPECIFICA AS 'PORCENTAJE_PROVISION_ESPECIFICA',
		D.PROVISION_RENDIMIENTO_X_COBRAR AS 'PROVISION_RENDIMIENTO_X_COBRAR',
				
		CASE 
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS = @Cero THEN '0'  
			WHEN RENDIMIENTOS_X_COBRAR_VENCIDOS > @Cero AND CONVERT(DECIMAL(15,4),PORCENTAJE_PROVISION_ESPECIFICA) = 0.0000 THEN -0.01   
			ELSE CONVERT(DECIMAL(15,4),PROVISION_RENDIMIENTO_X_COBRAR)
		END AS 'PROVISION_RENDIMIENTO_X_COBRAR',--YR 14/08/2012
		CONVERT(DECIMAL(15,4),TASA_INTERES_COBRADA) AS 'TASA_INTERES_COBRADA',
		CONVERT(DECIMAL(15,4),TASA_INTERES_ACTUAL) AS 'TASA_INTERES_ACTUAL',
		'1' AS 'IndicadorTasaPreferencial',
		CONVERT(DECIMAL(15,4),TASA_COMISION) AS 'TASA_COMISION',
		CASE --ojo optimizar
			WHEN DC01.TypeId IN (16,17,610,611) THEN 0
			WHEN DC01.TypeId IN (190,196) THEN  CONVERT(DECIMAL,DC03.TNBFEE)
			WHEN DC01.TypeId IN (999) THEN 0 --TDC
			ELSE NULL --fz
		END AS 'ComisionesPorCobrar',
		CASE 
			WHEN DC01.TypeId IN (610,611) THEN 0
			WHEN DC01.TypeId IN (16,17) THEN 
			CASE
				WHEN CONVERT(DATETIME, D.FECHA_LIQUIDACION) < (@FechaReportar)  THEN 0
				ELSE CONVERT(DECIMAL(15,4),DC01.Creditlimit) * 0.02
			END
			WHEN DC01.TypeId IN (190,196) THEN 0
			WHEN DC01.TypeId IN (999) THEN CONVERT(DECIMAL(15,4),DC01.FeePaid) --TDC
			ELSE NULL --fz
		END AS 'ComisionesCobradas',
		CONVERT(DECIMAL(15,2),EROGACIONES_RECUPERABLES) AS 'EROGACIONES_RECUPERABLES',
		CONVERT(INT,TIPO_GARANTIA_PRINCIPAL) AS 'TIPO_GARANTIA_PRINCIPAL', --fz
		CONVERT(INT,NUM_CUOTAS) AS 'NUM_CUOTAS',
		ISNULL(CONVERT(INT,NUM_CUOTAS_VENCIDAS), '0') AS 'NUM_CUOTAS_VENCIDAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_30_DIAS, '0')) AS 'MONTO_VENCIDO_30_DIAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_60_DIAS, '0')) AS 'MONTO_VENCIDO_60_DIAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_90_DIAS, '0')) AS 'MONTO_VENCIDO_90_DIAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_120_DIAS, '0')) AS 'MONTO_VENCIDO_120_DIAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_180_DIAS, '0')) AS 'MONTO_VENCIDO_180_DIAS',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_ANUAL, '0')) AS 'MONTO_VENCIDO_ANUAL',
		CONVERT(DECIMAL(15,2),ISNULL(MONTO_VENCIDO_MAYOR_ANUAL, '0')) AS 'MONTO_VENCIDO_MAYOR_ANUAL',
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N030DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N030DMONTOAVENCER,17,2) AS 'MontoVencer30dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N060DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N060DMONTOAVENCER,17,2) AS 'MontoVencer60dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N090DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N090DMONTOAVENCER,17,2) AS 'MontoVencer90dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N120DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N120DMONTOAVENCER,17,2) AS 'MontoVencer120dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N180DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N180DMONTOAVENCER,17,2) AS 'MontoVencer180dias', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.N360DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.N360DMONTOAVENCER,17,2) AS 'MontoVencerUnAno', --busqueda desde cosmos YR
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(DC04.MA1AMONTOAVENCER,1,16))) +  '.' + SUBSTRING(DC04.MA1AMONTOAVENCER,17,2) AS 'MontoVencerMasUnAno', --busqueda desde cosmos YR
		
		CONVERT(INT,BANCA_SOCIAL) AS BANCA_SOCIAL,
		CONVERT(INT,PRODUCCION_SOCIAL) AS PRODUCCION_SOCIAL,
		CONVERT(INT,MODALIDAD_MICROCREDITO) AS 'MODALIDAD_MICROCREDITO',
		CONVERT(INT,USO_FINANCIERO) AS 'USO_FINANCIERO',
		CONVERT(INT,DESTINO_RECURSOS_MICROFINANCIEROS) AS 'DESTINO_RECURSOS_MICROFINANCIEROS',
		CONVERT(INT,CANT_TRABAJADORES) AS 'CANT_TRABAJADORES',
		CONVERT(DECIMAL(15,2),VENTAS_ANUALES) AS 'VENTAS_ANUALES',
		CONVERT(VARCHAR(10),FECHA_ESTADO_FINANCIERO,111) AS 'FECHA_ESTADO_FINANCIERO',
		'' AS 'NUM_RTN', --Valor por defecto
		'' AS 'LICENCIA_TURISTICA_NACIONAL', --Valor por defecto
		'1900/01/01' AS 'FECHA_EMISION_FACTIBILIDAD_TECNICA', --Valor por defecto
		'0' AS 'NUM_EXPEDIENTE_FACTIBILIDAD_SOCIOTECNICA', --Valor por defecto
		'0' AS 'NUM_EXPEDIENTE_CONFORMIDAD_TURISTICA', --Valor por defecto
		'' AS 'NOMBRE_PROYECTO', --Valor por defecto
		'' AS 'DireccionProyectooUnidadProduccion', --Valor por defecto
		'0' AS 'COD_TIPO_PROYECTO', --Valor por defecto
		'0' AS 'COD_TIPO_OPERACIONES_FINANCIAMIENTO', --Valor por defecto
		'0' AS 'COD_SEGMENTO', --Valor por defecto 
		'0' AS 'TIPO_ZONA', --Valor por defecto
		'1900/01/01' AS 'FECHA_AUTENTICACION', --Valor por defecto
		'1900/01/01' AS 'FECHA_ULTIMA_INSPECCION', --Valor por defecto
		'0' AS 'PORCENTAJE_EJECUCION_PROYECTO', --Valor por defecto
		'0' AS 'PAGOS_EFECTUADOS_MENSUALES', --Valor por defecto
		'0' AS 'MONTOS_LIQUIDADOS_CIERRE', --Valor por defecto
		'0' AS 'AMORTIZACIONES_CAPITAL_ACUMULADAS', --Valor por defecto
		'0' AS 'TASA_INCENTIVO', --Valor por defecto
		'' AS 'NUMERO_OFICIO_INCENTIVO', --Valor por defecto
		'0' AS 'NUM_REGISTRO', --Valor por defecto
		'' AS 'TIPO_REGISTRO', --Valor por defecto
		'1900/01/01' AS 'FECHA_VENC_REGISTRO', --Valor por defecto
		'0' AS 'TIPO_SUBSECTOR', --Valor por defecto
		'0' AS 'RUBRO', --Valor por defecto
		'0' AS 'COD_USO', --Valor por defecto
		'0' AS 'CANT', --Valor por defecto
		'0' AS 'COD_UNIDAD_MEDIDA', --Valor por defecto
		'0' AS 'SECTOR_PRODUCCION', --Valor por defecto
		'0' AS 'CANT_HECTAREAS', --Valor por defecto
		'0' AS 'SUPERFICIE_TOTAL', --Valor por defecto
		'0' AS 'NUM_BENEFICIARIOS', --Valor por defecto
		'0' AS 'PRIORITARIO', --Valor por defecto
		'0' AS 'DESTINO_MANUFACTURERO', --Valor por defecto
		CASE 
			WHEN D.ESTADO_CREDITO = '1' THEN '4' 
			ELSE '0'
		END AS 'DESTINO_ECONOMICO', --YR 14/08/2012
		'0' AS 'TIPO_BENEFICIARIO', --Valor por defecto
		'0' AS 'MODALIDAD_HIPOTECARIA', --Valor por defecto
		'0' AS 'INGRESO_FAMILIAR', --Valor por defecto
		'0' AS 'MONTO_LIQUIDADO_ANUAL', --Valor por defecto
		'0' AS 'SALDO_CREDITO_31_12', --Valor por defecto
		'0' AS 'CANT_VIVIENDAS',--Valor por defecto
		----------
		CASE 
			WHEN DC01.CtaLocal LIKE '132%' 
			THEN TMPR.SaldoRendXcobrar
			ELSE @Cero 
		END  AS 'RendimientosCobrarReestructurados',
		@Cero AS 'RendimientosCobrarAfectosReporto',
		@Cero AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS 'FechaCambioEstatusCapitalTransferido',
		----------
		9 AS 'TipoDC',--Valor por defecto
		0 AS 'IdLote',--Valor por defecto
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM RPT_STG_Dirigidas_MICROFINANCIERO D
	LEFT JOIN TB_DCAT04_01 DC01 ON D.NUM_CREDITO = DC01.ACCT --LDWH
	LEFT JOIN TB_DCAT04_02 DC02 ON RIGHT(D.NUM_CREDITO,11) = DC02.P8NOTE --LNP860
	LEFT JOIN TB_DCAT04_03 DC03 ON D.NUM_CREDITO = DC03.DACCTA AND DC03.DAPPNA = 50 --VNP03T
	LEFT JOIN TB_DCAT04_05 DC05 ON D.TIPO_CLIENTE + CAST(D.NUM_CLIENTE AS VARCHAR) = DC05.IdentificadorCliente --Datos Clientes
	LEFT JOIN tbGavetas GAV on D.NUM_CREDITO = GAV.[Número de Crédito]
	LEFT JOIN TMP_Rendimiento TMPR on TMPR.acct = DC01.Acct		
	LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC01.ActivityID = Equi.CodigoCiti 
		AND Equi.AtomoSif = 'CTE'
		AND Equi.TablaSif = 'SB10'
		AND Equi.Insumo = 'CORE'
	LEFT JOIN TB_DCAT04_04 DC04 ON D.NUM_CREDITO = DC04.REFERNO --Data Corporativo

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera MicroFinanciero AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 9 Cartera MicroFinanciero
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera MicroFinanciero', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 9 Cartera MicroFinanciero (ajustes posteriores)
--------------------------
--ACTUALIZACIONES Monto de la Linea de Credito
UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13106101%')
----	
UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13106201%')
----
UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13106102%')
---
UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13106202%')
-----
UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13206101%')
---
UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
	CodigoContable NOT LIKE ('13206201%')
----
UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
CodigoContable NOT LIKE ('13206102%')
----
UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
CodigoContable NOT LIKE ('13206202%')
----
UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
CodigoContable NOT LIKE ('13306101%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
CodigoContable NOT LIKE ('13306201%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
CodigoContable NOT LIKE ('13306102%')


UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
CodigoContable NOT LIKE ('13306202%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
CodigoContable NOT LIKE ('13406101%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
CodigoContable NOT LIKE ('13406201%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
CodigoContable NOT LIKE ('13406102%')

UPDATE jf77062.TB_DMAT04 SET MontoLineaCredito = '0'
WHERE CodigoLineaCredito <> '2' AND TipoDC = '9'AND 
CodigoContable NOT LIKE ('13406202%')	

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera MicroFinanciero (Ajustes posteriores) AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 1 Cartera MicroFinanciero (Ajustes posteriores)
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera MicroFinanciero (Ajustes posteriores)', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 1 Cartera Creditos al Consumo
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,			
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	SELECT 
		DC01.Acct AS 'NumeroCredito',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaLiquidacion',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaSolicitud',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaAprobacion',
		
		CASE 
			WHEN CONVERT(INT,DC01.BranchId) = 1 THEN '02'  
			ELSE ISNULL(CONVERT(INT,DC01.BranchId),-1)
		END AS 'Oficina',--YR 14/08/2012
	
		DC01.CtaLocal AS 'CodigoContable',
		'0' AS 'NumeroCreditoPrimerDesembolso', --Valor por Defecto
		'0' AS 'NumeroDesembolso', --Valor por defecto
	
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) = '3' THEN '1'  
			ELSE '2'
		END AS 'CodigoLineaCredito',--YR 14/08/2012
	
		DC01.Creditlimit AS 'MontoLineaCredito', 
		CONVERT(INT,DC01.EstadoCredito) AS 'EstadoCredito', --fz
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) = '3' THEN '0'  
			ELSE '1'
		END AS 'TipoCredito',--YR 14/08/2012
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) <> 1 THEN '0' --fz
			ELSE DC01.Situacion_Credito
		END AS 'SituacionCredito',
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN 'C' --fz
			ELSE '0'
		END AS 'PlazoCredito',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) <> 1 THEN '0' --fz
			ELSE CONVERT(VARCHAR,DC01.ClaseRiesgo)
		END AS 'ClasificacionRiesgo',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'DestinoCredito',  --fz
		'1' AS 'NaturalezaCliente', --Valor por Defecto
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoCliente',
		SUBSTRING(CId, 2, 20) AS 'IdentificacionCliente',
		REPLACE(LTRIM(RTRIM(UPPER(DC01.FullName))),'''','´') AS 'Nombre_RazonSocial', --fz
		CASE 
			WHEN DC01.Gender IN ('1','2', '0') THEN DC01.Gender --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoClienteRIF',
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) IN ('V','E') THEN SUBSTRING(dbo.GetRif(DC01.CId), 2, 20) --fz
			ELSE SUBSTRING(DC01.CId, 2, 10)  --RIGHT(CId, 9) YR
		END AS 'IdentificacionTipoClienteRIF',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'ActividadCliente',  --fz
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) in ('V','J','G') THEN 'VE' --fz
			ELSE ISNULL(UPPER(DC05.Nacionalidad),'XX')
		END AS 'Pais_Nacionalidad',
		DC01.DireccionH AS 'Domicilio_Fiscal', --fz
		CASE
			WHEN CONVERT(DATETIME, DC01.OpenDate) < (@FechaReportar) THEN '1' --fz
			ELSE '2'
		END AS 'ClienteNuevo',  --++++++++++++++++++++
		'1' AS 'Cooperativa', --Valor por Defecto
		'0' AS 'Sindicado', --Valor por Defecto
		'0' AS 'BancoLiderSindicato', --Valor por Defecto
		DC01.Staff AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero', --Valor por Defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por Defecto
		'010109' AS 'CodigoParroquia', --Valor por Defecto
		'0' AS 'PeriodoGraciaCapital', --Valor por Defecto
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) IN (2,3) THEN '0' --fz
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN '512' 
			ELSE '-1'
		END AS 'PeriodicidadPagoCapital',
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) IN (2,3) THEN '0'
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN '8'
			ELSE '-1'
		END AS 'PeriodicidadPagoInteresCredito',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoOriginal',
		'' AS 'FechaVencimientoActual', --CAMPO CON ACTUALIZACION AL FINAL
		'1900/01/01' AS 'FechaReestructuracion', --Valor por Defecto
		'0' AS 'CantidadProrroga', --Valor por Defecto
		'1900/01/01' AS 'FechaProrroga', --Valor por Defecto
		CASE
			WHEN DC01.DivisionTypeId='E' THEN CONVERT(VARCHAR(10),CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36)))
			ELSE '0'
		END AS 'CantidadRenovaciones',
		CASE
			WHEN DC01.Divisiontypeid='E' And CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36))>0 THEN CONVERT(VARCHAR(10),DATEADD(MONTH,CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36))*36,CONVERT(DATETIME,OpenDate)),111) 
			ELSE '1900/01/01'
		END AS 'FechaUltimaRenovacion',
		SUBSTRING(DC02.P8FCTC,5,4) + '/' +  SUBSTRING(DC02.P8FCTC,3,2) + '/' + SUBSTRING(DC02.P8FCTC,1,2) AS 'FechaCancelacionTotal', --PENDIENTE ACTUALIZACION YR
		SUBSTRING(DC02.P8FVUC,5,4) + '/' +  SUBSTRING(DC02.P8FVUC,3,2) + '/' + SUBSTRING(DC02.P8FVUC,1,2) AS 'FechaVencimientoUltimaCoutaCapital', ---PENDIENTE ACTUALIZACION YR
		SUBSTRING(DC02.P8FCCC,5,4) + '/' +  SUBSTRING(DC02.P8FCCC,3,2) + '/' + SUBSTRING(DC02.P8FCCC,1,2) AS 'UltimaFechaCancelacionCuotaCapital', --PENDIENTE ACTUALIZACION YR
		SUBSTRING(DC02.P8FVUI,5,4) + '/' +  SUBSTRING(DC02.P8FVUI,3,2) + '/' + SUBSTRING(DC02.P8FVUI,1,2) AS 'FechaVencimientoUltimaCuotaInteres', --PENDIENTE ACTUALIZACION YR
		SUBSTRING(DC02.P8FCCI,5,4) + '/' +  SUBSTRING(DC02.P8FCCI,3,2) + '/' + SUBSTRING(DC02.P8FCCI,1,2) AS 'UltimaFechaCancelacionCuotaIntereses', ---PENDIENTE ACTUALIZACION YR
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		DC01.Creditlimit AS 'MontoOriginal',
		DC01.Creditlimit AS 'MontoInicial',
		DC01.Purchases AS 'MontoLiquidadoMes', --fz --	DC01.AmountPurchase AS 'MontoLiquidadoMes', 
		'0' AS 'EntePublico', --Valor por Defecto
		'0' AS 'MontoInicialTerceros', --Valor por Defecto
		 CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito)= '3' THEN CONVERT(DECIMAL(15,4),DC01.SaldoCastigado)
			WHEN CONVERT(INT,DC01.EstadoCredito) = '2' THEN '0'
			WHEN CONVERT(INT,DC01.EstadoCredito) = '1' THEN CONVERT(DECIMAL(15,4),DC01.SaldoCapital)
		END AS 'SALDO',--YR 14/08/2012
		CASE
			WHEN TMPR.SaldoRendXcobrar = @Cero OR TMPR.SaldoRendXcobrar IS NULL
			THEN DC01.SaldoRendimientos
			ELSE TMPR.SaldoRendXcobrar 
			END AS 'RendimientosCobrar', 
		CASE
			WHEN TMPR.SaldoRendXcobrarVenc = @Cero OR TMPR.SaldoRendXcobrarVenc IS NULL
			THEN CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8RPCV,LEN(DC02.P8RPCV)-2))) + '.' + RIGHT(DC02.P8RPCV,2)
			ELSE TMPR.SaldoRendXcobrarVenc
			END AS 'RendimientosCobrarVencidos', 
		ISNULL(TMPR.SaldoRendXMora,@Cero) AS 'RendimientosCobrarMora', 
		--CASE
		--	WHEN CONVERT(INT,DC01.EstadoCredito) = 3 THEN '0'
		--	ELSE ''-- Ojo William
		--END AS 'ProvisionEspecifica', --CAMPO CON ACTUALIZACION AL FINAL
		--'' AS 'PocentajeProvisionEspecifica',	--CAMPO CON ACTUALIZACION AL FINAL
		--'' AS 'ProvisionRendimientoCobrar',	--CAMPO CON ACTUALIZACION AL FINAL
		
			CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) = 3 THEN '0'
			END,
		
		DC01.Provision  AS 'Provision',
	    DC01.SaldoProvision  AS 'SaldoProvision',
		
		CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8TINC,LEN(DC02.P8TINC)-6))) + '.' + RIGHT(DC02.P8TINC,6) AS 'TasasInteresCobrada', --ffzz
		CONVERT(DECIMAL(15,4),ISNULL(DC01.Rate,0)) * 100 AS 'TasasInteresActual',
		'1' AS 'IndicadorTasaPreferencial', --Valor por Defecto
		'0' AS 'TasaComision', --Valor por Defecto
		'0' AS 'ComisionesCobrar', --Valor por Defecto
		'0' AS 'ComisionesCobradas', --Valor por Defecto
		'0' AS 'ErogacionesRecuperables', --Valor por Defecto
		'12' AS 'TipoGarantiaPrincipal', --Valor por Defecto			
		CASE
			WHEN DC01.Divisiontypeid IN ('R','E','V') THEN 0
			WHEN DC01.Agro=0 THEN DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,MaturityDate))
			ELSE ROUND(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,MaturityDate))/6,0)
		END AS NumCuotas,  --PENDIENTE POR ACTUALIZAR YR
		ISNULL(CONVERT(INT,DC02.P8NRCV), '0') AS 'NumeroCuotasVencidas', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV30,LEN(DC02.P8MV30)-2))) + '.' + RIGHT(DC02.P8MV30,2), '0') AS 'MontoVencido30dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV60,LEN(DC02.P8MV60)-2))) + '.' + RIGHT(DC02.P8MV60,2), '0') AS 'MontoVencido60dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV90,LEN(DC02.P8MV90)-2))) + '.' + RIGHT(DC02.P8MV90,2), '0') AS 'MontoVencido90dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV12,LEN(DC02.P8MV12)-2))) + '.' + RIGHT(DC02.P8MV12,2), '0') AS 'MontoVencido120dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV18,LEN(DC02.P8MV18)-2))) + '.' + RIGHT(DC02.P8MV18,2), '0') AS 'MontoVencido180dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV1A,LEN(DC02.P8MV1A)-2))) + '.' + RIGHT(DC02.P8MV1A,2), '0') AS 'MontoVencidoUnAno', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MVM1,LEN(DC02.P8MVM1)-2))) + '.' + RIGHT(DC02.P8MVM1,2), '0') AS 'MontoVencidoMasUnAno', --fz
		'0' AS 'MontoVencer30dias', --Valor por Defecto
		'0' AS 'MontoVencer60dias', --Valor por Defecto
		'0' AS 'MontoVencer90dias', --Valor por Defecto
		'0' AS 'MontoVencer120dias', --Valor por Defecto
		'0' AS 'MontoVencer180dias', --Valor por Defecto
		'0' AS 'MontoVencerUnAno', --Valor por Defecto
		'0' AS 'MontoVencerMasUnAno', --Valor por Defecto
		'1' AS 'BancaSocial', --Valor por Defecto
		'1' AS 'UnidadProduccionSocial', --Valor por Defecto
		'0' AS 'ModalidadMicrocredito', --Valor por Defecto
		'0' AS 'UsoFinanciero', --Valor por Defecto
		'0' AS 'DestinoRecursosMicrofinancieros', --Valor por Defecto
		'0' AS 'CantidadTrabajadores', --Valor por Defecto
		'0' AS 'VentaAnuales', --Valor por Defecto
		'1900/01/01' AS 'FechaEstadoFinanciero',
		'' AS 'NumeroRTN',
		'' AS 'LicenciaTuristicaNacional',
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica',
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica',
		'0' AS 'NumeroExpedienteConformidadTuristica',
		'' AS 'NombreProyectoUnidadProduccion',
		'' AS 'DireccionProyectoUnidadProduccion',
		'0' AS 'CodigoTipoProyecto',
		'0' AS 'CodigoTipoOperacionesFinanciamiento',
		'0' AS 'CodigoSegmento',
		'0' AS 'TipoZona',
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion',
		'1900/01/01' AS 'FechaUltimaInspeccion',
		'0' AS 'PorcentajeEjecucionProyecto',
		'0' AS 'PagosEfectuadosDuranteMes',
		'0' AS 'MontosLiquidadosFechaCierre',
		'0' AS 'AmortizacionesCapitalAcumuladasFecha',
		'0' AS 'TasaIncentivo',
		'' AS 'NumeroOficioIncentivo',
		'0' AS 'NumeroRegistro_ConstanciaMPPAT',
		'' AS 'TipoRegistro_ConstanciaMPPAT',
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT',
		'0' AS 'TipoSubsector',
		'0' AS 'Rubro',
		'0' AS 'CodigoUso',
		'0' AS 'CantidadUnidades',
		'0' AS 'CodigoUnidadMedida',
		'0' AS 'SectorProduccion',			
		'0' AS 'CantidadHectareas',
		'0' AS 'SuperficieTotalPropiedad',
		'0' AS 'NumeroProductoresBeneficiarios',
		'0' AS 'Prioritario',
		'0' AS 'DestinoManufacturero',
		'0' AS 'DestinoEconomico',
		'0' AS 'TipoBeneficiario',
		'0' AS 'ModalidadHipoteca',
		'0' AS 'IngresoFamiliar',
		'0' AS 'MontoLiquidadoDuranteAnoCurso',
		'0' AS 'SaldoCredito31_12',
		'0' AS 'CantidadViviendasConstruir',
		--------------
		CASE 
			WHEN DC01.CtaLocal LIKE '132%' 
			THEN TMPR.SaldoRendXcobrar
			ELSE @Cero 
		END  AS 'RendimientosCobrarReestructurados',
		@Cero AS 'RendimientosCobrarAfectosReporto',
		@Cero AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS 'FechaCambioEstatusCapitalTransferido',
		-------------
		1 AS  'TipoDC',
		0 AS 'IdLote',
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM TB_DCAT04_01 DC01 --LDWH
		LEFT JOIN TB_DCAT04_02 DC02 ON DC01.Acct = DC02.P8NOTE or DC01.Acct = DC02.P8PRAN--LNP860
		LEFT JOIN TB_DCAT04_05 DC05 ON DC01.CId = DC05.IdentificadorCliente --Datos Clientes Consumer
		LEFT JOIN tbGavetas GAV on DC01.Acct = GAV.[Número de Crédito]
		LEFT JOIN TMP_Rendimiento TMPR on TMPR.acct = DC01.Acct
		LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC01.ActivityID = Equi.CodigoCiti  --Equivalencias Act. Eco.
					AND Equi.AtomoSif = 'CTE'
					AND Equi.TablaSif = 'SB10'
					AND Equi.Insumo = 'CORE'
	WHERE
		DC01.TypeId IN (593,594,190,196,610,611)

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Creditos al Consumo AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 1 Cartera Creditos al Consumo
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera Creditos al Consumo', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 


-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 1 Cartera Creditos al Consumo (Ajustes Posteriores)
--------------------------
--ACTUALIZACION DE CAMPOS, CREDITOS AL CONSUMER
UPDATE jf77062.TB_DMAT04 SET
ClienteNuevo = 1 
WHERE 
TipoCredito = 2
AND TipoDC = 1
AND	(TipoCliente + IdentificacionCliente) IN (SELECT 
Cid 
FROM TB_DCAT04_01 DC01
WHERE 
	EstadoCredito = 1
	AND CONVERT(DATETIME, DC01.OpenDate) < (@FechaReportar)
	AND DC01.TypeId IN (593,594))
----------
UPDATE jf77062.TB_DMAT04 SET
FechaVencimientoActual = CASE 
				WHEN CONVERT(INTEGER, ISNULL(CantidadRenovaciones,0)) = 0 THEN FechaVencimientoOriginal
				ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,SUBSTRING(FechaUltimaRenovacion,1,4) + '/' + SUBSTRING(FechaUltimaRenovacion,6,2) + '/' + SUBSTRING(FechaUltimaRenovacion,9,2))),111) 
			END
WHERE 
TipoDC = 1
---------
--UPDATE jf77062.TB_DMAT04 SET
--PocentajeProvisionEspecifica = CASE ClasificacionRiesgo
--					WHEN 'A' THEN '0'
--					WHEN 'B' THEN '10'
--					WHEN 'C' THEN '30' --SE ACTUALIZO SEGUN BI JF77062
--					WHEN 'D' THEN '60'
--					WHEN 'E' THEN '95' --SE ACTUALIZO DE 99 A 95 JF77062
--					ELSE '0'
--				END
--WHERE 
--	TipoDC = 1
------------			
--UPDATE jf77062.TB_DMAT04 SET
--ProvisionEspecifica = (CONVERT(DECIMAL(17,4),ISNULL(Saldo,0)) * (CONVERT(INTEGER,ISNULL(PocentajeProvisionEspecifica,0))/100))* -1
--WHERE 
--	TipoDC = 1
--	AND ProvisionEspecifica = ''					
------------------
UPDATE jf77062.TB_DMAT04 SET-----Pendiente preguntar a Brian
	ProvisionRendimientoCobrar = (((CONVERT(DECIMAL(15,4),replace(RendimientosCobrar,',','')) 
	+ CONVERT(DECIMAL(15,4),replace(RendimientosCobrarVencidos,',',''))) 
	* (CONVERT(INTEGER,PocentajeProvisionEspecifica)))/100)
	 * -1  --SE ACTUALIZO SEGUN BI JF77062	
WHERE TipoDC = 1
-------------------	
UPDATE jf77062.TB_DMAT04 SET
	NumeroCuotas = '36'
WHERE NumeroCuotas = '0' AND TipoDC = 1 --YR 14/08/2012

-------		

UPDATE jf77062.TB_DMAT04 SET FechaVencimientoUltimaCoutaCapital = '1900/01/01'
WHERE TipoDC = 1 AND FechaVencimientoUltimaCoutaCapital = '0000/00/00' OR FechaVencimientoUltimaCoutaCapital IS NULL --YR 14/08/2012
-------	
UPDATE jf77062.TB_DMAT04 SET UltimaFechaCancelacionCuotaCapital = '1900/01/01'				
WHERE TipoDC = 1 AND UltimaFechaCancelacionCuotaCapital = '0000/00/00' OR UltimaFechaCancelacionCuotaCapital IS NULL --YR 14/08/2012 
-------	
UPDATE jf77062.TB_DMAT04 SET FechaVencimientoUltimaCuotaInteres = '1900/01/01'				
WHERE TipoDC = 1 AND FechaVencimientoUltimaCuotaInteres = '0000/00/00' OR FechaVencimientoUltimaCuotaInteres IS NULL --YR 14/08/2012 
-------	
UPDATE jf77062.TB_DMAT04 SET UltimaFechaCancelacionCuotaIntereses = '1900/01/01'
WHERE TipoDC = 1 AND UltimaFechaCancelacionCuotaIntereses = '0000/00/00' OR UltimaFechaCancelacionCuotaIntereses IS NULL --YR 14/08/2012

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Consumo (Ajustes Posteriores) AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 1 Cartera Creditos al Consumo (Ajustes Posteriores)
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera Creditos al Consumo (Ajustes Posteriores)', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 



-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 3 PIL 
--------------------------

INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,			
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	SELECT 
		DC01.Acct AS 'NumeroCredito',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaLiquidacion',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaSolicitud',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaAprobacion',
	
		CASE 
			WHEN CONVERT(INT,DC01.BranchId) = 1 THEN '02'  
			ELSE ISNULL(CONVERT(INT,DC01.BranchId),-1)
		END AS 'Oficina',--YR 14/08/2012
	
		DC01.CtaLocal AS 'CodigoContable',
		DC01.Acct AS 'NumeroCreditoPrimerDesembolso', --fz
		'1' AS 'NumeroDesembolso', --Valor por defecto
		'1' AS 'CodigoLineaCredito', --Valor por defecto
		'0' AS 'MontoLineaCredito', --Valor por defecto 
		CONVERT(INT,DC01.EstadoCredito) AS 'EstadoCredito', --fz
		
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) = '3' THEN '0'  
			WHEN DC01.CtaLocal in ('1310510102', '1330510102') THEN '1'
			ELSE '2'
		END AS 'TipoCredito',--YR 14/08/2012
	
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) <> 1 THEN '0' --fz
			ELSE DC01.Situacion_Credito
		END AS 'SituacionCredito',
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN 'C' --fz
			ELSE '0'
		END AS 'PlazoCredito',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) <> 1 THEN '0' --fz
			ELSE CONVERT(VARCHAR,DC01.ClaseRiesgo)
		END AS 'ClasificacionRiesgo',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'DestinoCredito',  --fz
		'1' AS 'NaturalezaCliente', --Valor por Defecto
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoCliente',
		SUBSTRING(CId, 2, 20) AS 'IdentificacionCliente',
		REPLACE(LTRIM(RTRIM(UPPER(DC01.FullName))),'''','´') AS 'Nombre_RazonSocial', --fz
		CASE 
			WHEN DC01.Gender IN ('1','2', '0') THEN DC01.Gender --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoClienteRIF',
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) IN ('V','E') THEN SUBSTRING(dbo.GetRif(DC01.CId), 2, 20) --fz
			ELSE SUBSTRING(DC01.CId, 2, 10)  --RIGHT(CId, 9) YR
		END AS 'IdentificacionTipoClienteRIF',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'ActividadCliente',  --fz
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) in ('V','J','G') THEN 'VE' --fz
			ELSE ISNULL(UPPER(DC05.Nacionalidad),'XX')
		END AS 'Pais_Nacionalidad',
		DC01.DireccionH AS 'Domicilio_Fiscal', --fz
		CASE
			WHEN CONVERT(DATETIME, DC01.OpenDate) < (@FechaReportar) THEN '1' --fz
			ELSE '2'
		END AS 'ClienteNuevo',  --CAMPO CON ACTUALIZACION AL FINAL
		'1' AS 'Cooperativa', --Valor por Defecto
		'0' AS 'Sindicado', --Valor por Defecto
		'0' AS 'BancoLiderSindicato', --Valor por Defecto
		DC01.Staff AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero', --Valor por Defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por Defecto
		'010109' AS 'CodigoParroquia', --Valor por Defecto
		'0' AS 'PeriodoGraciaCapital', --Valor por Defecto
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) IN (2,3) THEN '0' --fz
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN '8' 
			ELSE '-1'
		END AS 'PeriodicidadPagoCapital',
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) IN (2,3) THEN '0' --fz
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN '8'
			ELSE '-1'
		END AS 'PeriodicidadPagoInteresCredito',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoOriginal',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoActual',
		'1900/01/01' AS 'FechaReestructuracion', --Valor por Defecto
		'0' AS 'CantidadProrroga', --Valor por Defecto
		'1900/01/01' AS 'FechaProrroga', --Valor por Defecto
		CASE
			WHEN DC01.DivisionTypeId='E' THEN CONVERT(VARCHAR(10),CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36)))
			ELSE '0'
		END AS 'CantidadRenovaciones',
		CASE
			WHEN DC01.Divisiontypeid='E' And CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36))>0 THEN CONVERT(VARCHAR(10),DATEADD(MONTH,CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36))*36,CONVERT(DATETIME,OpenDate)),111) 
			ELSE '1900/01/01'
		END AS 'FechaUltimaRenovacion',
	
		ISNULL(SUBSTRING(DC02.P8FCTC,5,4) + '/' +  SUBSTRING(DC02.P8FCTC,3,2) + '/' + SUBSTRING(DC02.P8FCTC,1,2), '1900/01/01') AS 'FechaCancelacionTotal', --YR 14/08/2012
	
		SUBSTRING(DC02.P8FVUC,5,4) + '/' +  SUBSTRING(DC02.P8FVUC,3,2) + '/' + SUBSTRING(DC02.P8FVUC,1,2) AS 'FechaVencimientoUltimaCoutaCapital', --fz
		SUBSTRING(DC02.P8FCCC,5,4) + '/' +  SUBSTRING(DC02.P8FCCC,3,2) + '/' + SUBSTRING(DC02.P8FCCC,1,2) AS 'UltimaFechaCancelacionCuotaCapital', --fz
		SUBSTRING(DC02.P8FVUI,5,4) + '/' +  SUBSTRING(DC02.P8FVUI,3,2) + '/' + SUBSTRING(DC02.P8FVUI,1,2) AS 'FechaVencimientoUltimaCuotaInteres', --fz
		SUBSTRING(DC02.P8FCCI,5,4) + '/' +  SUBSTRING(DC02.P8FCCI,3,2) + '/' + SUBSTRING(DC02.P8FCCI,1,2) AS 'UltimaFechaCancelacionCuotaIntereses', --fz
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		DC01.Creditlimit AS 'MontoOriginal',
		DC01.Creditlimit AS 'MontoInicial',
		CASE
			WHEN CONVERT(DATETIME, DC01.OpenDate) < (@FechaReportar) THEN '0' --fz
			ELSE REPLACE(DC01.Creditlimit,'Bs ','') 
		END AS 'MontoLiquidadoMes', 
		'0' AS 'EntePublico', --Valor por Defecto
		'0' AS 'MontoInicialTerceros', --Valor por Defecto
	
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito)= '3' THEN CONVERT(DECIMAL(15,4),DC01.SaldoCastigado)
			WHEN CONVERT(INT,DC01.EstadoCredito) = '2' THEN '0'
			WHEN CONVERT(INT,DC01.EstadoCredito) = '1' THEN CONVERT(DECIMAL(15,4),DC01.SaldoCapital)
		END AS 'SALDO',--YR 14/08/2012
		CASE
			WHEN TMPR.SaldoRendXcobrar = @Cero OR TMPR.SaldoRendXcobrar IS NULL
			THEN DC01.SaldoRendimientos
			ELSE TMPR.SaldoRendXcobrar
			END AS 'RendimientosCobrar', 
		CASE
			WHEN TMPR.SaldoRendXcobrarVenc = @Cero OR TMPR.SaldoRendXcobrarVenc IS NULL
			THEN CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8RPCV,LEN(DC02.P8RPCV)-2))) + '.' + RIGHT(DC02.P8RPCV,2)
			ELSE TMPR.SaldoRendXcobrarVenc
			END AS 'RendimientosCobrarVencidos', 
			ISNULL(TMPR.SaldoRendXMora,@Cero) AS 'RendimientosCobrarMora', 
		--CASE
		--	WHEN CONVERT(INT,DC01.EstadoCredito) = 3 THEN '0'
		--	ELSE ''
		--END AS 'ProvisionEspecifica',		--CAMPO CON ACTUALIZACION AL FINAL
		--'' AS 'PocentajeProvisionEspecifica',	--CAMPO CON ACTUALIZACION AL FINAL
		--'' AS 'ProvisionRendimientoCobrar',	--CAMPO CON ACTUALIZACION AL FINAL
		
			CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) = 3 THEN '0'
			END,
		
		DC01.Provision  AS 'Provision',
		DC01.SaldoProvision  AS 'SaldoProvision',
		
		CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8TINC,LEN(DC02.P8TINC)-6))) + '.' + RIGHT(DC02.P8TINC,6) AS 'TasasInteresCobrada', --ffzz
		CONVERT(DECIMAL(15,4),ISNULL(DC01.Rate,0)) * 100 AS 'TasasInteresActual', --fz
		'1' AS 'IndicadorTasaPreferencial', --Valor por Defecto
		CASE DC01.TypeId 
			WHEN 18 THEN '2'
			ELSE '3'
		END AS 'TasaComision', 
		'0' AS 'ComisionesCobrar',
		CASE 
			WHEN CONVERT(DATETIME, DC01.OpenDate) < (@FechaReportar) THEN 0
			ElSE
				CASE DC01.TypeId
					WHEN 18 THEN CONVERT(DECIMAL(15,4), DC01.Creditlimit) * 0.02
					ELSE CONVERT(DECIMAL(15,4), DC01.Creditlimit) * 0.03
				END 
		END AS 'ComisionesCobradas',
		'0' AS 'ErogacionesRecuperables', --Valor por Defecto
		'10' AS 'TipoGarantiaPrincipal', --Valor por Defecto	
		CASE
			WHEN DC01.Divisiontypeid IN ('R','E','V') THEN 0
			WHEN DC01.Agro=0 THEN DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,MaturityDate))
			ELSE ROUND(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,MaturityDate))/6,0)
		END AS NumCuotas,
		ISNULL(CONVERT(INT,DC02.P8NRCV), '0') AS 'NumeroCuotasVencidas', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV30,LEN(DC02.P8MV30)-2))) + '.' + RIGHT(DC02.P8MV30,2), '0') AS 'MontoVencido30dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV60,LEN(DC02.P8MV60)-2))) + '.' + RIGHT(DC02.P8MV60,2), '0') AS 'MontoVencido60dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV90,LEN(DC02.P8MV90)-2))) + '.' + RIGHT(DC02.P8MV90,2), '0') AS 'MontoVencido90dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV12,LEN(DC02.P8MV12)-2))) + '.' + RIGHT(DC02.P8MV12,2), '0') AS 'MontoVencido120dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV18,LEN(DC02.P8MV18)-2))) + '.' + RIGHT(DC02.P8MV18,2), '0') AS 'MontoVencido180dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV1A,LEN(DC02.P8MV1A)-2))) + '.' + RIGHT(DC02.P8MV1A,2), '0') AS 'MontoVencidoUnAno', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MVM1,LEN(DC02.P8MVM1)-2))) + '.' + RIGHT(DC02.P8MVM1,2), '0') AS 'MontoVencidoMasUnAno', --fz
		'0' AS 'MontoVencer30dias', --Valor por Defecto
		'0' AS 'MontoVencer60dias', --Valor por Defecto
		'0' AS 'MontoVencer90dias', --Valor por Defecto
		'0' AS 'MontoVencer120dias', --Valor por Defecto
		'0' AS 'MontoVencer180dias', --Valor por Defecto
		'0' AS 'MontoVencerUnAno', --Valor por Defecto
		'0' AS 'MontoVencerMasUnAno', --Valor por Defecto
		'1' AS 'BancaSocial', --Valor por Defecto
		'1' AS 'UnidadProduccionSocial', --Valor por Defecto
		'0' AS 'ModalidadMicrocredito', --Valor por Defecto
		'0' AS 'UsoFinanciero', --Valor por Defecto
		'0' AS 'DestinoRecursosMicrofinancieros', --Valor por Defecto
		'0' AS 'CantidadTrabajadores', --Valor por Defecto
		'0' AS 'VentaAnuales', --Valor por Defecto
		'1900/01/01' AS 'FechaEstadoFinanciero',
		'' AS 'NumeroRTN',
		'' AS 'LicenciaTuristicaNacional',
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica',
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica',
		'0' AS 'NumeroExpedienteConformidadTuristica',
		'' AS 'NombreProyectoUnidadProduccion',
		'' AS 'DireccionProyectoUnidadProduccion',
		'0' AS 'CodigoTipoProyecto',
		'0' AS 'CodigoTipoOperacionesFinanciamiento',
		'0' AS 'CodigoSegmento',
		'0' AS 'TipoZona',
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion',
		'1900/01/01' AS 'FechaUltimaInspeccion',
		'0' AS 'PorcentajeEjecucionProyecto',
		'0' AS 'PagosEfectuadosDuranteMes',
		'0' AS 'MontosLiquidadosFechaCierre',
		'0' AS 'AmortizacionesCapitalAcumuladasFecha',
		'0' AS 'TasaIncentivo',
		'' AS 'NumeroOficioIncentivo',
		'2' AS 'NumeroRegistro_ConstanciaMPPAT',
		'' AS 'TipoRegistro_ConstanciaMPPAT',
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT',
		'0' AS 'TipoSubsector',
		'0' AS 'Rubro',
		'0' AS 'CodigoUso',
		'0' AS 'CantidadUnidades',
		'0' AS 'CodigoUnidadMedida',
		'0' AS 'SectorProduccion',			
		'0' AS 'CantidadHectareas',
		'0' AS 'SuperficieTotalPropiedad',
		'0' AS 'NumeroProductoresBeneficiarios',
		'0' AS 'Prioritario',
		'0' AS 'DestinoManufacturero',
		'0' AS 'DestinoEconomico',
		'0' AS 'TipoBeneficiario',
		'0' AS 'ModalidadHipoteca',
		'0' AS 'IngresoFamiliar',
		'0' AS 'MontoLiquidadoDuranteAnoCurso',
		'0' AS 'SaldoCredito31_12',
		'0' AS 'CantidadViviendasConstruir',
		-------------
		CASE 
			WHEN DC01.CtaLocal LIKE '132%' 
			THEN TMPR.SaldoRendXcobrar
			ELSE @Cero 
		END  AS 'RendimientosCobrarReestructurados',
		@Cero AS 'RendimientosCobrarAfectosReporto',
		@Cero AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS 'FechaCambioEstatusCapitalTransferido',
		---------------
		3 AS 'TipoDC',
		0 AS 'IdLote',
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
		FROM TB_DCAT04_01 DC01 --LDWH
			LEFT JOIN TB_DCAT04_02 DC02 ON DC01.Acct = DC02.P8NOTE or DC01.Acct = DC02.P8PRAN--LNP860
			LEFT JOIN TB_DCAT04_05 DC05 ON DC01.CId = DC05.IdentificadorCliente --Datos Clientes Consumer
			LEFT JOIN tbGavetas GAV on DC01.Acct = GAV.[Número de Crédito]
			LEFT JOIN TMP_Rendimiento TMPR on TMPR.acct = DC01.Acct
			LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC01.ActivityID = Equi.CodigoCiti  --Equivalencias Act. Eco.
						AND Equi.AtomoSif = 'CTE'
						AND Equi.TablaSif = 'SB10'
						AND Equi.Insumo = 'CORE'
		WHERE
			DC01.TypeId IN (10,11,12,13,14,15,18,35,36,640,224)-- JF77062 Ajustado a correo Fri 11/14/2014 3:55 PM de Padilla Salmeron, Maria Enriqueta [ICG-CORP] <mp32867@imcla.lac.nsroot.net>

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Cartera PIL AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 3 PIL
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera PIL', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 3 RRHH
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	
	SELECT CONVERT(DECIMAL,TMP.GEID) AS 'NumeroCredito',
		CONVERT(VARCHAR(10),TMP.FechaOtorgamiento,111) AS 'FechaLiquidacion',
		CONVERT(VARCHAR(10),TMP.FechaOtorgamiento,111) AS 'FechaSolicitud',
		CONVERT(VARCHAR(10),TMP.FechaOtorgamiento,111) AS 'FechaAprobacion',
		'0002' AS 'Oficina',
		'1311510000' AS 'CodigoContable', 
		CONVERT(DECIMAL,TMP.GEID) AS 'NumeroCreditoPrimerDesembolso',
		'1' AS 'NumeroDesembolso',
		'1' AS 'CodigoLineaCredito',
		@Cero AS 'MontoLineaCredito',
		'1' AS 'EstadoCredito',
		'2' AS 'TipoCredito',
		'1' AS 'SituacionCredito',
		'C' AS 'PlazoCredito',
		'A' AS 'ClasificacionRiesgo',
		'K64' AS 'DestinoCredito',
		'1' AS 'NaturalezaCliente',
		TMP.TipoCliente AS 'TipoCliente',
		TMP.IdentificacionCliente AS 'IdentificacionCliente',
		TMP.NombreCliente AS 'Nombre_RazonSocial',
		'2' AS 'Genero',
		TMP.TipoCliente AS 'TipoClienteRIF',
		CASE 
			WHEN SUBSTRING(TMP.TipoCliente, 1, 1) IN ('V','E') THEN SUBSTRING(dbo.GetRif(TMP.TipoCliente + TMP.IdentificacionCliente), 2, 20) 
			ELSE TMP.IdentificacionCliente 
		END AS 'IdentificacionTipoClienteRIF',
		'K64' AS 'ActividadCliente',
		'VE' AS 'PaisNacionalidad',
		'Av. Casanova Centro Comercial el Recreo Torre Norte Citibank' AS 'DomicilioFiscal',
		'1' AS 'ClienteNuevo',
		'1' AS 'Cooperativa',
		'0' AS 'Sindicado',
		'0' AS 'BancoLiderSindicato',
		'2' AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero',
		'' AS 'NombreGrupoEconomicoFinanciero',
		'010109' AS 'CodigoParroquia',
		'0' AS 'PeriodoGraciaCapital',
		'8' AS 'PeriodicidadPagoCapital',
		'8' AS 'PeriodicidadPagoInteresCredito',
		CONVERT(VARCHAR(10),DATEADD (mm, +12, FechaOtorgamiento), 111) AS 'FechaVencimientoOriginal',
		CONVERT(VARCHAR(10),DATEADD (mm, +12, FechaOtorgamiento), 111) AS 'FechaVencimientoActual',
		'1900/01/01' AS 'FechaReestructuracion',
		'0' AS 'CantidadProrroga',
		'1900/01/01' AS 'FechaProrroga',
		'0' AS 'CantidadRenovaciones',
		'1900/01/01' AS 'FechaUltimaRenovacion',
		'1900/01/01' AS 'FechaCancelacionTotal',
		CONVERT(VARCHAR(10),(@FechaReportar),111) AS 'FechaVencimientoUltimaCoutaCapital',
		CONVERT(VARCHAR(10),(@FechaReportar),111) AS 'UltimaFechaCancelacionCuotaCapital',
		CONVERT(VARCHAR(10),(@FechaReportar),111) AS 'FechaVencimientoUltimaCuotaInteres',
		CONVERT(VARCHAR(10),(@FechaReportar),111) AS 'UltimaFechaCancelacionCuotaIntereses',
		'VEB' AS 'Moneda',
		'1' AS 'TipoCambioOriginal',
		'1' AS 'TipoCambioCierreMes',
		TMP.MontoOriginal AS 'MontoOriginal',
		TMP.MontoOriginal AS 'MontoInicial',
		'0' AS 'MontoLiquidadoMes',
		'0' AS 'EntePublico',
		'0' AS 'MontoInicialTerceros',
		TMP.SaldoActual AS 'Saldo',
		@Cero AS 'RendimientosCobrar',
		@Cero AS 'RendimientosCobrarVencidos',
		@Cero AS 'RendimientosCobrarMora',
		@Cero AS 'ProvisionEspecifica',
		'0.0000' AS 'PocentajeProvisionEspecifica',
		@Cero AS 'ProvisionRendimientoCobrar',
		'17' AS 'TasasInteresCobrada',
		'17' AS 'TasasInteresActual',
		'1' AS 'IndicadorTasaPreferencial',
		'3' AS 'TasaComision',
		'0' AS 'ComisionesCobrar',
		'0' AS 'ComisionesCobradas',
		'0' AS 'ErogacionesRecuperables',
		'10' AS 'TipoGarantiaPrincipal',
		'12' AS 'NumeroCuotas',
		'0' AS 'NumeroCuotasVencidas',
		@Cero AS 'MontoVencido30dias',
		@Cero AS 'MontoVencido60dias',
		@Cero AS 'MontoVencido90dias',
		@Cero AS 'MontoVencido120dias',
		@Cero AS 'MontoVencido180dias',
		@Cero AS 'MontoVencidoUnAno',
		@Cero AS 'MontoVencidoMasUnAno',
		@Cero AS 'MontoVencer30dias',
		@Cero AS 'MontoVencer60dias',
		@Cero AS 'MontoVencer90dias',
		@Cero AS 'MontoVencer120dias',
		@Cero AS 'MontoVencer180dias',
		@Cero AS 'MontoVencerUnAno',
		@Cero AS 'MontoVencerMasUnAno',
		'1' AS 'BancaSocial',
		'1' AS 'UnidadProduccionSocial',
		'0' AS 'ModalidadMicrocredito',
		'0' AS 'UsoFinanciero',
		'0' AS 'DestinoRecursosMicrofinancieros',
		'0' AS 'CantidadTrabajadores',
		'0' AS 'VentaAnuales',
		'1900/01/01' AS 'FechaEstadoFinanciero',
		'' AS 'NumeroRTN',
		'' AS 'LicenciaTuristicaNacional',
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica',
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica',
		'0' AS 'NumeroExpedienteConformidadTuristica',
		'' AS 'NombreProyectoUnidadProduccion',
		'' AS 'DireccionProyectoUnidadProduccion',
		'0' AS 'CodigoTipoProyecto',
		'0' AS 'CodigoTipoOperacionesFinanciamiento',
		'0' AS 'CodigoSegmento',
		'0' AS 'TipoZona',
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion',
		'1900/01/01' AS 'FechaUltimaInspeccion',
		'0' AS 'PorcentajeEjecucionProyecto',
		'0' AS 'PagosEfectuadosDuranteMes',
		'0' AS 'MontosLiquidadosFechaCierre',
		'0' AS 'AmortizacionesCapitalAcumuladasFecha',
		'0' AS 'TasaIncentivo',
		'' AS 'NumeroOficioIncentivo',
		'0' AS 'NumeroRegistro_ConstanciaMPPAT',
		'' AS 'TipoRegistro_ConstanciaMPPAT',
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT',
		'0' AS 'TipoSubsector',
		'0' AS 'Rubro',
		'0' AS 'CodigoUso',
		'0' AS 'CantidadUnidades',
		'0' AS 'CodigoUnidadMedida',
		'0' AS 'SectorProduccion',
		'0' AS 'CantidadHectareas',
		'0' AS 'SuperficieTotalPropiedad',
		'0' AS 'NumeroProductoresBeneficiarios',
		'0' AS 'Prioritario',
		'0' AS 'DestinoManufacturero',
		'0' AS 'DestinoEconomico',
		'0' AS 'TipoBeneficiario',
		'0' AS 'ModalidadHipoteca',
		'0' AS 'IngresoFamiliar',
		'0' AS 'MontoLiquidadoDuranteAnoCurso',
		'0' AS 'SaldoCredito31_12',
		'0' AS 'CantidadViviendasConstruir',
		'0' AS 'RendimientosCobrarReestructurados',
		'0' AS 'RendimientosCobrarAfectosReporto',
		'0' AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS 'FechaCambioEstatusCapitalTransferido',
		--------------------
		3 AS 'TipoDC',
		0  AS 'IdLote',
		'Manual' AS 'Usuario'
	FROM TMP_RRHH TMP
		LEFT JOIN tbGavetas GAV on TMP.GEID = GAV.[Número de Crédito] 
		LEFT JOIN TB_DCAT04_01 DC01 ON TMP.GEID = DC01.ACCT --LDWH
		
		
EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera RRHH AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 3 RRHH
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Cartera RRHH', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 


-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 3 (Actualizaciones Posteriores)
--------------------------
UPDATE jf77062.TB_DMAT04 SET
ClienteNuevo = 1 
WHERE 
TipoCredito = 2
AND TipoDC = 3
AND	(TipoCliente + IdentificacionCliente) IN (SELECT 
		Cid 
		FROM TB_DCAT04_01 DC01
		WHERE 
			EstadoCredito = 1
			AND CONVERT(DATETIME, DC01.OpenDate) < (@FechaReportar) 
			AND DC01.TypeId IN (10,11,12,13,14,15,18,35,36))
-----------			
			
--UPDATE jf77062.TB_DMAT04 SET
--PocentajeProvisionEspecifica = CASE ClasificacionRiesgo
--					WHEN 'A' THEN '0'
--					WHEN 'B' THEN '10'
--					WHEN 'C' THEN '30' --SE ACTUALIZO SEGUN BI JF77062
--					WHEN 'D' THEN '60'
--					WHEN 'E' THEN '95' --SE ACTUALIZO SEGUN BI JF77062
--					ELSE '0'
--				END
--WHERE 
--	TipoDC = 3			

-----------
--UPDATE jf77062.TB_DMAT04 SET
--ProvisionEspecifica = (CONVERT(DECIMAL(17,4),ISNULL(Saldo,0)) * (CONVERT(INTEGER,ISNULL(PocentajeProvisionEspecifica,0))/100))* -1
--WHERE 
--TipoDC = 3
--AND ProvisionEspecifica = ''
-----------
UPDATE jf77062.TB_DMAT04 SET
ProvisionRendimientoCobrar = (((CONVERT(DECIMAL(15,4),replace(RendimientosCobrar,',','')) + CONVERT(DECIMAL(15,4),replace(RendimientosCobrarVencidos,',',''))) * (CONVERT(INTEGER,PocentajeProvisionEspecifica)))/100) * -1  --SE ACTUALIZO SEGUN BI JF77062
WHERE TipoDC = 3

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera 3 (Actualizaciones Posteriores) AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 3 (Actualizaciones Posteriores)
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada 3 (Actualizaciones Posteriores)', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 



-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 2 Credicheque
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,			
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	
	SELECT 
		DC01.Acct AS 'NumeroCredito',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaLiquidacion',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaSolicitud',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaAprobacion',
	
		CASE 
			WHEN CONVERT(INT,DC01.BranchId) = 1 THEN '02'  
			ELSE ISNULL(CONVERT(INT,DC01.BranchId),-1)
		END AS 'Oficina',--YR 14/08/2012
	
		DC01.CtaLocal AS 'CodigoContable',
		'0' AS 'NumeroCreditoPrimerDesembolso', --Valor por Defecto
		'0' AS 'NumeroDesembolso', --Valor por defecto
	
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) = '3' THEN '1'  
			ELSE '2'
		END AS 'CodigoLineaCredito',--YR 14/08/2012
	
		DC01.Creditlimit AS 'MontoLineaCredito', 
		CONVERT(INT,DC01.EstadoCredito) AS 'EstadoCredito', --fz
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) = '3' THEN '0'  
			ELSE '1'
		END AS 'TipoCredito',--YR 14/08/2012	
	
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) <> 1 THEN '0' --fz
			ELSE DC01.Situacion_Credito
		END AS 'SituacionCredito',
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN 'C' --fz
			ELSE '0'
		END AS 'PlazoCredito',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) <> 1 THEN '0' --fz
			ELSE CONVERT(VARCHAR,DC01.ClaseRiesgo)
		END AS 'ClasificacionRiesgo',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'DestinoCredito',  --fz
		'1' AS 'NaturalezaCliente', --Valor por Defecto
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoCliente',
		SUBSTRING(CId, 2, 20) AS 'IdentificacionCliente',
		REPLACE(LTRIM(RTRIM(UPPER(DC01.FullName))),'''','´') AS 'Nombre_RazonSocial', --fz
		CASE 
			WHEN DC01.Gender IN ('1','2', '0') THEN DC01.Gender --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',	
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoClienteRIF',
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) IN ('V','E') THEN SUBSTRING(dbo.GetRif(DC01.CId), 2, 20) --fz
			ELSE SUBSTRING(DC01.CId, 2, 10)  --RIGHT(CId, 9) YR
		END AS 'IdentificacionTipoClienteRIF',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'ActividadCliente',  --fz
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) in ('V','J','G') THEN 'VE' --fz
			ELSE ISNULL(UPPER(DC05.Nacionalidad),'XX')
		END AS 'Pais_Nacionalidad',
		DC01.DireccionH AS 'Domicilio_Fiscal', --fz
		CASE
			WHEN CONVERT(DATETIME, DC01.OpenDate) < (@FechaReportar) THEN '1' --fz
			ELSE '2'
		END AS 'ClienteNuevo',  --CAMPO CON ACTUALIZACION AL FINAL
		'1' AS 'Cooperativa', --Valor por Defecto
		'0' AS 'Sindicado', --Valor por Defecto
		'0' AS 'BancoLiderSindicato', --Valor por Defecto
		DC01.Staff AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero', --Valor por Defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por Defecto
		'010109' AS 'CodigoParroquia', --Valor por Defecto
		'0' AS 'PeriodoGraciaCapital', --Valor por Defecto
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) IN (2,3) THEN '0' --fz
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN '8' 
			ELSE '-1'
		END AS 'PeriodicidadPagoCapital',
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) IN (2,3) THEN '0'
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN '8'
			ELSE '-1'
		END AS 'PeriodicidadPagoInteresCredito',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoOriginal',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoActual',
		'1900/01/01' AS 'FechaReestructuracion', --Valor por Defecto
		'0' AS 'CantidadProrroga', --Valor por Defecto
		'1900/01/01' AS 'FechaProrroga', --Valor por Defecto
		CASE
			WHEN DC01.DivisionTypeId='E' THEN CONVERT(VARCHAR(10),CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36)))
			ELSE '0'
		END AS 'CantidadRenovaciones',
		CASE
			WHEN DC01.Divisiontypeid='E' And CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36))>0 THEN CONVERT(VARCHAR(10),DATEADD(MONTH,CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36))*36,CONVERT(DATETIME,OpenDate)),111) 
			ELSE '1900/01/01'
		END AS 'FechaUltimaRenovacion',
		ISNULL(SUBSTRING(DC02.P8FCTC,5,4) + '/' +  SUBSTRING(DC02.P8FCTC,3,2) + '/' + SUBSTRING(DC02.P8FCTC,1,2), '1900/01/01') AS 'FechaCancelacionTotal', --YR 14/08/2012
	
		ISNULL(SUBSTRING(DC02.P8FVUC,5,4) + '/' +  SUBSTRING(DC02.P8FVUC,3,2) + '/' + SUBSTRING(DC02.P8FVUC,1,2), CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111)) AS 'FechaVencimientoUltimaCoutaCapital', ----YR 14/08/2012
		
		SUBSTRING(DC02.P8FCCC,5,4) + '/' +  SUBSTRING(DC02.P8FCCC,3,2) + '/' + SUBSTRING(DC02.P8FCCC,1,2) AS 'UltimaFechaCancelacionCuotaCapital', ---fz
		
		ISNULL(SUBSTRING(DC02.P8FVUI,5,4) + '/' +  SUBSTRING(DC02.P8FVUI,3,2) + '/' + SUBSTRING(DC02.P8FVUI,1,2), CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111)) AS 'FechaVencimientoUltimaCuotaInteres', ----YR 14/08/2012
		
		SUBSTRING(DC02.P8FCCI,5,4) + '/' +  SUBSTRING(DC02.P8FCCI,3,2) + '/' + SUBSTRING(DC02.P8FCCI,1,2) AS 'UltimaFechaCancelacionCuotaIntereses', ---fz
	
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		DC01.Creditlimit AS 'MontoOriginal',
		DC01.Creditlimit AS 'MontoInicial',
		DC01.Purchases AS 'MontoLiquidadoMes', --fz --	DC01.AmountPurchase AS 'MontoLiquidadoMes', 
		'0' AS 'EntePublico', --Valor por Defecto
		'0' AS 'MontoInicialTerceros', --Valor por Defecto
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito)= '3' THEN CONVERT(DECIMAL(15,4),DC01.SaldoCastigado)
			WHEN CONVERT(INT,DC01.EstadoCredito) = '2' THEN '0'
			WHEN CONVERT(INT,DC01.EstadoCredito) = '1' THEN CONVERT(DECIMAL(15,4),DC01.SaldoCapital)
		END AS 'SALDO',--YR 14/08/2012
		CASE
			WHEN TMPR.SaldoRendXcobrar = @Cero OR TMPR.SaldoRendXcobrar IS NULL
			THEN DC01.SaldoRendimientos
			ELSE TMPR.SaldoRendXcobrar
			END AS 'RendimientosCobrar', 
		CASE
			WHEN 
			TMPR.SaldoRendXcobrarVenc = @Cero OR TMPR.SaldoRendXcobrarVenc IS NULL
			THEN CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8RPCV,LEN(DC02.P8RPCV)-2))) + '.' + RIGHT(DC02.P8RPCV,2)
			ELSE TMPR.SaldoRendXcobrarVenc
			END AS 'RendimientosCobrarVencidos', 
		ISNULL(TMPR.SaldoRendXMora,@Cero) AS 'RendimientosCobrarMora', 
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) = 3 THEN '0'
			ELSE ''
		END AS 'ProvisionEspecifica',		--CAMPO CON ACTUALIZACION AL FINAL
		'' AS 'PocentajeProvisionEspecifica',	--CAMPO CON ACTUALIZACION AL FINAL
		'' AS 'ProvisionRendimientoCobrar',	--CAMPO CON ACTUALIZACION AL FINAL
		CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8TINC,LEN(DC02.P8TINC)-6))) + '.' + RIGHT(DC02.P8TINC,6) AS 'TasasInteresCobrada', --ffzz
		CONVERT(DECIMAL(15,4),ISNULL(DC01.Rate,0)) * 100 AS 'TasasInteresActual',
		'1' AS 'IndicadorTasaPreferencial', --Valor por Defecto
		'0' AS 'TasaComision', --Valor por Defecto
		CONVERT(DECIMAL,DC03.TNBFEE) AS 'ComisionesCobrar', --fzfz
		REPLACE(DC01.FeePaid,'Bs ','') AS 'ComisionesCobradas',
		'0' AS 'ErogacionesRecuperables', --Valor por Defecto
		'10' AS 'TipoGarantiaPrincipal', --Valor por Defecto	
		CASE
			WHEN DC01.Divisiontypeid IN ('R','E','V') THEN 0
			WHEN DC01.Agro=0 THEN DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,MaturityDate))
			ELSE ROUND(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,MaturityDate))/6,0)
		END AS NumCuotas, --PENDIENTE POR ACTUALIZAR YR
		ISNULL(CONVERT(INT,DC02.P8NRCV), '0') AS 'NumeroCuotasVencidas', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV30,LEN(DC02.P8MV30)-2))) + '.' + RIGHT(DC02.P8MV30,2), '0') AS 'MontoVencido30dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV60,LEN(DC02.P8MV60)-2))) + '.' + RIGHT(DC02.P8MV60,2), '0') AS 'MontoVencido60dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV90,LEN(DC02.P8MV90)-2))) + '.' + RIGHT(DC02.P8MV90,2), '0') AS 'MontoVencido90dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV12,LEN(DC02.P8MV12)-2))) + '.' + RIGHT(DC02.P8MV12,2), '0') AS 'MontoVencido120dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV18,LEN(DC02.P8MV18)-2))) + '.' + RIGHT(DC02.P8MV18,2), '0') AS 'MontoVencido180dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV1A,LEN(DC02.P8MV1A)-2))) + '.' + RIGHT(DC02.P8MV1A,2), '0') AS 'MontoVencidoUnAno', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MVM1,LEN(DC02.P8MVM1)-2))) + '.' + RIGHT(DC02.P8MVM1,2), '0') AS 'MontoVencidoMasUnAno', --fz
		'0' AS 'MontoVencer30dias', --Valor por Defecto
		'0' AS 'MontoVencer60dias', --Valor por Defecto
		'0' AS 'MontoVencer90dias', --Valor por Defecto
		'0' AS 'MontoVencer120dias', --Valor por Defecto
		'0' AS 'MontoVencer180dias', --Valor por Defecto
		'0' AS 'MontoVencerUnAno', --Valor por Defecto
		'0' AS 'MontoVencerMasUnAno', --Valor por Defecto
		'1' AS 'BancaSocial', --Valor por Defecto
		'1' AS 'UnidadProduccionSocial', --Valor por Defecto
		'0' AS 'ModalidadMicrocredito', --Valor por Defecto
		'0' AS 'UsoFinanciero', --Valor por Defecto
		'0' AS 'DestinoRecursosMicrofinancieros', --Valor por Defecto
		'0' AS 'CantidadTrabajadores', --Valor por Defecto
		'0' AS 'VentaAnuales', --Valor por Defecto
		'1900/01/01' AS 'FechaEstadoFinanciero',
		'' AS 'NumeroRTN',
		'' AS 'LicenciaTuristicaNacional',
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica',
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica',
		'0' AS 'NumeroExpedienteConformidadTuristica',
		'' AS 'NombreProyectoUnidadProduccion',
		'' AS 'DireccionProyectoUnidadProduccion',
		'0' AS 'CodigoTipoProyecto',
		'0' AS 'CodigoTipoOperacionesFinanciamiento',
		'0' AS 'CodigoSegmento',
		'0' AS 'TipoZona',
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion',
		'1900/01/01' AS 'FechaUltimaInspeccion',
		'0' AS 'PorcentajeEjecucionProyecto',
		'0' AS 'PagosEfectuadosDuranteMes',
		'0' AS 'MontosLiquidadosFechaCierre',
		'0' AS 'AmortizacionesCapitalAcumuladasFecha',
		'0' AS 'TasaIncentivo',
		'' AS 'NumeroOficioIncentivo',
		'1' AS 'NumeroRegistro_ConstanciaMPPAT',
		'' AS 'TipoRegistro_ConstanciaMPPAT',
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT',
		'0' AS 'TipoSubsector',
		'0' AS 'Rubro',
		'0' AS 'CodigoUso',
		'0' AS 'CantidadUnidades',
		'0' AS 'CodigoUnidadMedida',
		'0' AS 'SectorProduccion',			
		'0' AS 'CantidadHectareas',
		'0' AS 'SuperficieTotalPropiedad',
		'0' AS 'NumeroProductoresBeneficiarios',
		'0' AS 'Prioritario',
		'0' AS 'DestinoManufacturero',
		'0' AS 'DestinoEconomico',
		'0' AS 'TipoBeneficiario',
		'0' AS 'ModalidadHipoteca',
		'0' AS 'IngresoFamiliar',
		'0' AS 'MontoLiquidadoDuranteAnoCurso',
		'0' AS 'SaldoCredito31_12',
		'0' AS 'CantidadViviendasConstruir',
		--------------
		CASE 
		WHEN DC01.CtaLocal LIKE '132%' 
		THEN TMPR.SaldoRendXcobrar
		ELSE @Cero END  AS 'RendimientosCobrarReestructurados',
		'0' AS 'RendimientosCobrarAfectosReporto',
		'0' AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS 'FechaCambioEstatusCapitalTransferido',
		-------------
		2 AS TipoDC,
		0 AS IdLote,
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM TB_DCAT04_01 DC01
		LEFT JOIN TB_DCAT04_02 DC02 ON DC01.Acct = DC02.P8NOTE or DC01.Acct = DC02.P8PRAN--LNP860
		LEFT JOIN TB_DCAT04_03 DC03 ON DC01.Acct = DC03.DACCTA AND DC03.DAPPNA = 50 --VNP03T
		LEFT JOIN TB_DCAT04_05 DC05 ON DC01.CId = DC05.IdentificadorCliente
		LEFT JOIN tbGavetas GAV on DC01.Acct = GAV.[Número de Crédito] 
		LEFT JOIN TMP_Rendimiento TMPR on TMPR.acct = DC01.Acct
		LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC01.ActivityID = Equi.CodigoCiti 
					AND Equi.AtomoSif = 'CTE'
					AND Equi.TablaSif = 'SB10'
					AND Equi.Insumo = 'CORE'
	WHERE
		DC01.TypeId IN (590,591,592,596,603,605)

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Credicheque AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 2 Credicheque
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada Credicheque', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 2 Credicheque (Actualizaciones Posteriores)
--------------------------
		
UPDATE jf77062.TB_DMAT04 SET
ClienteNuevo = 1 
WHERE 
TipoCredito = 1
AND TipoDC = 2
AND	(TipoCliente + IdentificacionCliente) IN (SELECT 
Cid 
FROM TB_DCAT04_01 DC01
WHERE 
EstadoCredito = 1
AND CONVERT(DATETIME, DC01.OpenDate) < (@FechaReportar)
AND DC01.TypeId IN (590,591,592,596,603,605))
------------------
UPDATE jf77062.TB_DMAT04 SET
PocentajeProvisionEspecifica = CASE ClasificacionRiesgo
	WHEN 'A' THEN '0'
	WHEN 'B' THEN '10'
	WHEN 'C' THEN '30' --SE ACTUALIZO SEGUN BI JF77062
	WHEN 'D' THEN '60'
	WHEN 'E' THEN '95' --SE ACTUALIZO SEGUN BI JF77062
	ELSE '0'
END
WHERE 
TipoDC = 2
------------------
UPDATE jf77062.TB_DMAT04 SET
ProvisionRendimientoCobrar = 	(((CONVERT(DECIMAL(15,4),replace(RendimientosCobrar,',','')) +CONVERT(DECIMAL(15,4),replace(RendimientosCobrarVencidos,',',''))) * (CONVERT(INTEGER,PocentajeProvisionEspecifica)))/100) * -1  --SE ACTUALIZO SEGUN BI JF77062
WHERE 
TipoDC = 2
AND ProvisionEspecifica = ''
------------------------------
UPDATE jf77062.TB_DMAT04 SET
ProvisionRendimientoCobrar = 	CASE 
	WHEN RendimientosCobrarVencidos= '0' THEN '0'
	WHEN CONVERT(DECIMAL(15,4),replace(RendimientosCobrarVencidos,',','')) > 0.0000 AND CONVERT(DECIMAL(15,4),PocentajeProvisionEspecifica) = 0.0000 THEN -0.01   
	WHEN CONVERT(DECIMAL(15,4),replace(RendimientosCobrarVencidos,',','')) > 0.0000 THEN CONVERT(DECIMAL(17,4),ISNULL(replace(RendimientosCobrarVencidos,',',''),0)) * (CONVERT(INTEGER,PocentajeProvisionEspecifica)/100)* -1

END --YR 14/08/2012
WHERE TipoDC = 2

---------------------------
UPDATE jf77062.TB_DMAT04 SET
	NumeroCuotas = '36'
WHERE NumeroCuotas = '0' AND TipoDC = 2  --YR 14/08/2012
--------------------------

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera Credicheque (Actualizaciones Posteriores) AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 2 Credicheque (Actualizaciones Posteriores)
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada 2 Credicheque (Actualizaciones Posteriores)', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 4 Rewrites 
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,			
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,	
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	
	SELECT 
		DC01.Acct AS 'NumeroCredito',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaLiquidacion',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaSolicitud',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaAprobacion',
	
		CASE 
			WHEN CONVERT(INT,DC01.BranchId) = 1 THEN '02'  
			ELSE ISNULL(CONVERT(INT,DC01.BranchId),-1)
		END AS 'Oficina',--YR 14/08/2012
	
		DC01.CtaLocal AS 'CodigoContable',
		DC01.Acct AS 'NumeroCreditoPrimerDesembolso', --fz
		'1' AS 'NumeroDesembolso', --Valor por defecto
		'1' AS 'CodigoLineaCredito', --Valor por defecto
		'0' AS 'MontoLineaCredito', 
		CONVERT(INT,DC01.EstadoCredito) AS 'EstadoCredito', --fz
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) = '3' THEN '0'  
			ELSE '1'
		END AS 'TipoCredito',--YR 14/08/2012
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) <> 1 THEN '0' --fz
			ELSE DC01.Situacion_Credito
		END AS 'SituacionCredito',
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN 'C' --fz
			ELSE '0'
		END AS 'PlazoCredito',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) <> 1 THEN '0' --fz
			ELSE CONVERT(VARCHAR,DC01.ClaseRiesgo)
		END AS 'ClasificacionRiesgo',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'DestinoCredito',  --fz
		'1' AS 'NaturalezaCliente', --Valor por Defecto
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoCliente',
		SUBSTRING(CId, 2, 20) AS 'IdentificacionCliente',
		REPLACE(LTRIM(RTRIM(UPPER(DC01.FullName))),'''','´') AS 'Nombre_RazonSocial', --fz
			CASE 
			WHEN DC01.Gender IN ('1','2', '0') THEN DC01.Gender --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoClienteRIF',
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) IN ('V','E') THEN SUBSTRING(dbo.GetRif(DC01.CId), 2, 20) --fz
			ELSE SUBSTRING(DC01.CId, 2, 10) --RIGHT(CId, 9) YR
		END AS 'IdentificacionTipoClienteRIF',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'ActividadCliente',  --fz
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) in ('V','J','G') THEN 'VE' --fz
			ELSE ISNULL(UPPER(DC05.Nacionalidad),'XX')
		END AS 'Pais_Nacionalidad',
		DC01.DireccionH AS 'Domicilio_Fiscal', --fz
		'1' AS 'ClienteNuevo', --Valor por Defecto
		'1' AS 'Cooperativa', --Valor por Defecto
		'0' AS 'Sindicado', --Valor por Defecto
		'0' AS 'BancoLiderSindicato', --Valor por Defecto
		'1' AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero', --Valor por Defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por Defecto
		'010109' AS 'CodigoParroquia', --Valor por Defecto
		'0' AS 'PeriodoGraciaCapital', --Valor por Defecto
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) IN (2,3) THEN '0' --fz
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN '8' 
			ELSE '-1'
		END AS 'PeriodicidadPagoCapital',
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) IN (2,3) THEN '0'
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN '8'
			ELSE '-1'
		END AS 'PeriodicidadPagoInteresCredito',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoOriginal',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoActual',
	
		CASE 
			WHEN DC01.CtaLocal NOT LIKE ('132%') THEN '1900/01/01'  
			ELSE CONVERT(VARCHAR(10),CONVERT(DATETIME,DC01.opendate),111)
		END AS 'FechaReestructuracion',--YR 14/08/2012
	
		'0' AS 'CantidadProrroga', --Valor por Defecto
		'1900/01/01' AS 'FechaProrroga', --Valor por Defecto
		CASE
			WHEN DC01.DivisionTypeId='E' THEN CONVERT(VARCHAR(10),CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36)))
			ELSE '0'
		END AS 'CantidadRenovaciones',
		CASE
			WHEN DC01.Divisiontypeid='E' And CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36))>0 THEN CONVERT(VARCHAR(10),DATEADD(MONTH,CONVERT(INTEGER,(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,RecordDate))/36))*36,CONVERT(DATETIME,OpenDate)),111) 
			ELSE '1900/01/01'
		END AS 'FechaUltimaRenovacion',
		ISNULL(SUBSTRING(DC02.P8FCTC,5,4) + '/' +  SUBSTRING(DC02.P8FCTC,3,2) + '/' + SUBSTRING(DC02.P8FCTC,1,2), '1900/01/01') AS 'FechaCancelacionTotal', --YR 14/08/2012
	
		SUBSTRING(DC02.P8FVUC,5,4) + '/' +  SUBSTRING(DC02.P8FVUC,3,2) + '/' + SUBSTRING(DC02.P8FVUC,1,2) AS 'FechaVencimientoUltimaCoutaCapital', --PENDIENTE ACTUALIZAR YR
		SUBSTRING(DC02.P8FCCC,5,4) + '/' +  SUBSTRING(DC02.P8FCCC,3,2) + '/' + SUBSTRING(DC02.P8FCCC,1,2) AS 'UltimaFechaCancelacionCuotaCapital', --PENDIENTE ACTUALIZAR YR
		SUBSTRING(DC02.P8FVUI,5,4) + '/' +  SUBSTRING(DC02.P8FVUI,3,2) + '/' + SUBSTRING(DC02.P8FVUI,1,2) AS 'FechaVencimientoUltimaCuotaInteres', --PENDIENTE ACTUALIZAR YR
		SUBSTRING(DC02.P8FCCI,5,4) + '/' +  SUBSTRING(DC02.P8FCCI,3,2) + '/' + SUBSTRING(DC02.P8FCCI,1,2) AS 'UltimaFechaCancelacionCuotaIntereses', --PENDIENTE ACTUALIZAR YR
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		DC01.Creditlimit AS 'MontoOriginal', --fz
		DC01.Creditlimit AS 'MontoInicial', --fz
		'0' AS 'MontoLiquidadoMes', 
		'0' AS 'EntePublico', --Valor por Defecto
		'0' AS 'MontoInicialTerceros', --Valor por Defecto
	
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito)= '3' THEN CONVERT(DECIMAL(15,4),DC01.SaldoCastigado)
			WHEN CONVERT(INT,DC01.EstadoCredito) = '2' THEN '0'
			WHEN CONVERT(INT,DC01.EstadoCredito) = '1' THEN CONVERT(DECIMAL(15,4),DC01.SaldoCapital)
		END AS 'SALDO',--YR 14/08/2012
		CASE
			WHEN TMPR.SaldoRendXcobrar = @Cero OR TMPR.SaldoRendXcobrar IS NULL
			THEN DC01.SaldoRendimientos
			ELSE TMPR.SaldoRendXcobrar
			END AS 'RendimientosCobrar',
		CASE
			WHEN TMPR.SaldoRendXcobrarVenc = @Cero OR TMPR.SaldoRendXcobrarVenc IS NULL
			THEN CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8RPCV,LEN(DC02.P8RPCV)-2))) + '.' + RIGHT(DC02.P8RPCV,2) 
			ELSE TMPR.SaldoRendXcobrarVenc
			END AS 'RendimientosCobrarVencidos', 
			ISNULL(TMPR.SaldoRendXMora,@Cero) AS 'RendimientosCobrarMora', 
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) = 3 THEN '0'
			ELSE ''
		END AS 'ProvisionEspecifica',		--CAMPO CON ACTUALIZACION AL FINAL
		'' AS 'PocentajeProvisionEspecifica',	--CAMPO CON ACTUALIZACION AL FINAL
		'' AS 'ProvisionRendimientoCobrar',	--CAMPO CON ACTUALIZACION AL FINAL
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8TINC,LEN(DC02.P8TINC)-6))) + '.' + RIGHT(DC02.P8TINC,6), '0') AS 'TasasInteresCobrada', --YR 14/08/2012 ISNULL
		CONVERT(DECIMAL(15,4),ISNULL(DC01.Rate,0)) * 100 AS 'TasasInteresActual',
		'1' AS 'IndicadorTasaPreferencial', --Valor por Defecto
		'0' AS 'TasaComision', 
		'0' AS 'ComisionesCobrar',
		'0' AS 'ComisionesCobradas',
		'0' AS 'ErogacionesRecuperables', --Valor por Defecto
		'10' AS 'TipoGarantiaPrincipal', --Valor por Defecto	
		CASE
			WHEN DC01.Divisiontypeid IN ('R','E','V') THEN 0
			WHEN DC01.Agro=0 THEN DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,MaturityDate))
			ELSE ROUND(DATEDIFF(MONTH,CONVERT(DATETIME,OpenDate),CONVERT(DATETIME,MaturityDate))/6,0)
		END AS NumCuotas,
		ISNULL(CONVERT(INT,DC02.P8NRCV), '0') AS 'NumeroCuotasVencidas', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV30,LEN(DC02.P8MV30)-2))) + '.' + RIGHT(DC02.P8MV30,2), '0') AS 'MontoVencido30dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV60,LEN(DC02.P8MV60)-2))) + '.' + RIGHT(DC02.P8MV60,2), '0') AS 'MontoVencido60dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV90,LEN(DC02.P8MV90)-2))) + '.' + RIGHT(DC02.P8MV90,2), '0') AS 'MontoVencido90dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV12,LEN(DC02.P8MV12)-2))) + '.' + RIGHT(DC02.P8MV12,2), '0') AS 'MontoVencido120dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV18,LEN(DC02.P8MV18)-2))) + '.' + RIGHT(DC02.P8MV18,2), '0') AS 'MontoVencido180dias', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MV1A,LEN(DC02.P8MV1A)-2))) + '.' + RIGHT(DC02.P8MV1A,2), '0') AS 'MontoVencidoUnAno', --fz
		ISNULL(CONVERT(VARCHAR,CONVERT(DECIMAL,LEFT(DC02.P8MVM1,LEN(DC02.P8MVM1)-2))) + '.' + RIGHT(DC02.P8MVM1,2), '0') AS 'MontoVencidoMasUnAno', --fz
		'0' AS 'MontoVencer30dias', --Valor por Defecto
		'0' AS 'MontoVencer60dias', --Valor por Defecto
		'0' AS 'MontoVencer90dias', --Valor por Defecto
		'0' AS 'MontoVencer120dias', --Valor por Defecto
		'0' AS 'MontoVencer180dias', --Valor por Defecto
		'0' AS 'MontoVencerUnAno', --Valor por Defecto
		'0' AS 'MontoVencerMasUnAno', --Valor por Defecto
		'1' AS 'BancaSocial', --Valor por Defecto
		'1' AS 'UnidadProduccionSocial', --Valor por Defecto
		'0' AS 'ModalidadMicrocredito', --Valor por Defecto
		'0' AS 'UsoFinanciero', --Valor por Defecto
		'0' AS 'DestinoRecursosMicrofinancieros', --Valor por Defecto
		'0' AS 'CantidadTrabajadores', --Valor por Defecto
		'0' AS 'VentaAnuales', --Valor por Defecto
		'1900/01/01' AS 'FechaEstadoFinanciero',
		'' AS 'NumeroRTN',
		'' AS 'LicenciaTuristicaNacional',
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica',
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica',
		'0' AS 'NumeroExpedienteConformidadTuristica',
		'' AS 'NombreProyectoUnidadProduccion',
		'' AS 'DireccionProyectoUnidadProduccion',
		'0' AS 'CodigoTipoProyecto',
		'0' AS 'CodigoTipoOperacionesFinanciamiento',
		'0' AS 'CodigoSegmento',
		'0' AS 'TipoZona',
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion',
		'1900/01/01' AS 'FechaUltimaInspeccion',
		'0' AS 'PorcentajeEjecucionProyecto',
		'0' AS 'PagosEfectuadosDuranteMes',
		'0' AS 'MontosLiquidadosFechaCierre',
		'0' AS 'AmortizacionesCapitalAcumuladasFecha',
		'0' AS 'TasaIncentivo',
		'' AS 'NumeroOficioIncentivo',
		'2' AS 'NumeroRegistro_ConstanciaMPPAT',
		'' AS 'TipoRegistro_ConstanciaMPPAT',
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT',
		'0' AS 'TipoSubsector',
		'0' AS 'Rubro',
		'0' AS 'CodigoUso',
		'0' AS 'CantidadUnidades',
		'0' AS 'CodigoUnidadMedida',
		'0' AS 'SectorProduccion',			
		'0' AS 'CantidadHectareas',
		'0' AS 'SuperficieTotalPropiedad',
		'0' AS 'NumeroProductoresBeneficiarios',
		'0' AS 'Prioritario',
		'0' AS 'DestinoManufacturero',
		'0' AS 'DestinoEconomico',
		'0' AS 'TipoBeneficiario',
		'0' AS 'ModalidadHipoteca',
		'0' AS 'IngresoFamiliar',
		'0' AS 'MontoLiquidadoDuranteAnoCurso',
		'0' AS 'SaldoCredito31_12',
		'0' AS 'CantidadViviendasConstruir',
		---------------------
		CASE 
			WHEN DC01.CtaLocal LIKE '132%' 
			THEN TMPR.SaldoRendXcobrar
			ELSE @Cero END  AS 'RendimientosCobrarReestructurados',
		@Cero AS 'RendimientosCobrarAfectosReporto',
		@Cero AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS 'FechaCambioEstatusCapitalTransferido',
		------------------
		4 AS 'TipoDC',
		0 AS 'IdLote',
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM TB_DCAT04_01 DC01
		LEFT JOIN TB_DCAT04_02 DC02 ON DC01.Acct = DC02.P8NOTE or DC01.Acct = DC02.P8PRAN--LNP860
		LEFT JOIN TB_DCAT04_05 DC05 ON DC01.CId = DC05.IdentificadorCliente
		LEFT JOIN tbGavetas GAV on DC01.Acct = GAV.[Número de Crédito]
		LEFT JOIN TMP_Rendimiento TMPR on TMPR.acct = DC01.Acct
		LEFT JOIN JF77062.TB_CFGEqvSifCiti_Generica Equi ON DC01.ActivityID = Equi.CodigoCiti 
					AND Equi.AtomoSif = 'CTE'
					AND Equi.TablaSif = 'SB10'
					AND Equi.Insumo = 'CORE'
	WHERE
		DC01.TypeId IN (70,90,91,92,93)

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera 4 Rewrites AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 4 Rewrites
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada 4 Rewrites ', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 
-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 4 Rewrites (Actualizaciones Posteriores)
--------------------------
	
UPDATE jf77062.TB_DMAT04 SET
	PocentajeProvisionEspecifica = CASE ClasificacionRiesgo
						WHEN 'A' THEN '0'
						WHEN 'B' THEN '10'
						WHEN 'C' THEN '15'
						WHEN 'D' THEN '60'
						WHEN 'E' THEN '99'
						ELSE '0'
					END
	WHERE 
		TipoDC = 4
----------------

UPDATE jf77062.TB_DMAT04 SET
ProvisionEspecifica = (CONVERT(DECIMAL(17,4),ISNULL(Saldo,0)) * (CONVERT(INTEGER,PocentajeProvisionEspecifica)/100))* -1
WHERE 
TipoDC = 4
AND ProvisionEspecifica = ''
-------------

UPDATE jf77062.TB_DMAT04 SET
ProvisionRendimientoCobrar = (((CONVERT(DECIMAL(15,4),replace(RendimientosCobrar,',','')) + CONVERT(DECIMAL(15,4),replace(RendimientosCobrarVencidos,'',''))) * (CONVERT(INTEGER,PocentajeProvisionEspecifica)))/100) * -1  --SE ACTUALIZO SEGUN BI JF77062
WHERE TipoDC = 4
---------

UPDATE jf77062.TB_DMAT04 SET FechaVencimientoUltimaCoutaCapital = '1900/01/01'
WHERE TipoDC = 4 AND FechaVencimientoUltimaCoutaCapital = '0000/00/00' OR FechaVencimientoUltimaCoutaCapital IS NULL --YR 14/08/2012
---------
UPDATE jf77062.TB_DMAT04 SET UltimaFechaCancelacionCuotaCapital = '1900/01/01'				
WHERE TipoDC = 4 AND UltimaFechaCancelacionCuotaCapital = '0000/00/00' OR UltimaFechaCancelacionCuotaCapital IS NULL --YR 14/08/2012 

---------
UPDATE jf77062.TB_DMAT04 SET FechaVencimientoUltimaCuotaInteres = '1900/01/01'				
WHERE TipoDC = 4 AND FechaVencimientoUltimaCuotaInteres = '0000/00/00' OR FechaVencimientoUltimaCuotaInteres IS NULL --YR 14/08/2012 

---------
UPDATE jf77062.TB_DMAT04 SET UltimaFechaCancelacionCuotaIntereses = '1900/01/01'
WHERE TipoDC = 4 AND UltimaFechaCancelacionCuotaIntereses = '0000/00/00' OR UltimaFechaCancelacionCuotaIntereses IS NULL --YR 14/08/2012


EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera 4 Rewrites (Actualizaciones Posteriores) AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 4 Rewrites (Actualizaciones Posteriores)
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada 4 Rewrites (Actualizaciones Posteriores)', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 5 TDC
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,			
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	
	SELECT 
		DC01.Acct AS 'NumeroCredito',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaLiquidacion',
		CONVERT(VARCHAR(10), DATEADD(DAY,-1,CONVERT(DATETIME, DC01.OpenDate)),111) AS 'FechaSolicitud',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, DC01.OpenDate),111) AS 'FechaAprobacion',
	
		CASE 
			WHEN CONVERT(INT,DC01.BranchId) = 1 THEN '02'  
			ELSE ISNULL(CONVERT(INT,DC01.BranchId),2)
		END AS 'Oficina',--YR 14/08/2012
	
		DC01.CtaLocal AS 'CodigoContable',
		'0' AS 'NumeroCreditoPrimerDesembolso', --Valor por Defecto
		'0' AS 'NumeroDesembolso', --Valor por defecto
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) = '3' THEN '1'  
			ELSE '2'
		END AS 'CodigoLineaCredito',--YR 14/08/2012 
	
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito) = '3' THEN '0'  
			ELSE DC01.Creditlimit
		END AS 'MontoLineaCredito',--YR 14/08/2012 
	
		CONVERT(INT,DC01.EstadoCredito) AS 'EstadoCredito', --YR 14/08/2012
		'1' AS 'TipoCredito',--YR 14/08/2012 PENDIENTE ACTUALIZACION YR  
	
		CONVERT(INT,DC01.Situacion_Credito) AS 'SituacionCredito',  --YR 14/08/2012 PENDIENTE ACTUALIZACION YR  
	
		'C' AS 'PlazoCredito',  --CAMPO QUE NECESITA UNA ACTUALIZACION  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		DC01.ClaseRiesgo AS 'ClasificacionRiesgo', --YR 14/08/2012 PENDIENTE ACTUALIZACION YR  
		'0' AS 'DestinoCredito', --Valor por Defecto
		'1' AS 'NaturalezaCliente', --Valor por Defecto
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoCliente',
		SUBSTRING(CId, 2, 20) AS 'IdentificacionCliente',
		REPLACE(LTRIM(RTRIM(UPPER(DC01.FullName))),'''','´') AS 'Nombre_RazonSocial', --fz
			CASE 
			WHEN DC01.Gender IN ('1','2', '0') THEN DC01.Gender --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoClienteRIF',
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) IN ('V','E') THEN SUBSTRING(dbo.GetRif(DC01.CId), 2, 20) --fz
			ELSE SUBSTRING(DC01.CId, 2, 10)  --RIGHT(CId, 9)  YR
		END AS 'IdentificacionTipoClienteRIF',
		ISNULL(Equi.CodigoSIF, 'XXX') AS 'ActividadCliente',  --YR 14/08/2012 XXX
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) in ('V','J','G') THEN 'VE' --fz
			ELSE ISNULL(UPPER(DC05.Nacionalidad),'XX')
		END AS 'Pais_Nacionalidad',
		DC01.DireccionH AS 'Domicilio_Fiscal', --fz
		'1' AS 'ClienteNuevo',
		'1' AS 'Cooperativa', --Valor por Defecto
		'0' AS 'Sindicado', --Valor por Defecto  YR 14/08/2012 
		'0' AS 'BancoLiderSindicato', --Valor por Defecto
		'1' AS 'RelacionCrediticia', --Valor por Defecto
		'1' AS 'GrupoEconomicoFinanciero', --Valor por Defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por Defecto
		'010109' AS 'CodigoParroquia', --Valor por Defecto
		'7' AS 'PeriodoGraciaCapital', --Valor por Defecto
		
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) IN (2,3) THEN '0'
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN '8'
		END AS 'PeriodicidadPagoCapital', --YR 14/08/2012 
	
		CASE
			WHEN CONVERT(INT,DC01.EstadoCredito) IN (2,3) THEN '0'
			WHEN CONVERT(INT,DC01.EstadoCredito) = 1 THEN '8'
		END AS 'PeriodicidadPagoInteresCredito', --YR 14/08/2012 
	
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoOriginal',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoActual',
		'1900/01/01' AS 'FechaReestructuracion', --Valor por Defecto
		'0' AS 'CantidadProrroga', --Valor por Defecto
		'1900/01/01' AS 'FechaProrroga', --Valor por Defecto
		'0' AS 'CantidadRenovaciones', --Valor por Defecto
		'1900/01/01' AS 'FechaUltimaRenovacion', --Valor por Defecto
		CASE
			WHEN DC01.BlockCodeId1 = 'A' THEN CONVERT(VARCHAR(10),CONVERT(DATETIME,DC01.BlockCode1Date),111)
			ELSE '1900/01/01'
		END AS 'FechaCancelacionTotal',
		'' AS 'FechaVencimientoUltimaCoutaCapital', --Requiere Actualización
		LEFT(REPLACE(DC06.PayDate,'-','/'),10) AS 'UltimaFechaCancelacionCuotaCapital', --47 Requiere Actualización
		'' AS 'FechaVencimientoUltimaCuotaInteres', --Requiere Actualización
		LEFT(REPLACE(DC07.PayDate,'-','/'),10) AS 'UltimaFechaCancelacionCuotaIntereses', --49 Requiere Actualización
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		DC01.Creditlimit AS 'MontoOriginal',
		DC01.Creditlimit AS 'MontoInicial',
		DC01.Purchases AS 'MontoLiquidadoMes', 
		'0' AS 'EntePublico', --Valor por Defecto
		'0' AS 'MontoInicialTerceros', --Valor por Defecto
	
		CASE 
			WHEN CONVERT(INT,DC01.EstadoCredito)= '3' THEN CONVERT(DECIMAL(15,4),DC01.SaldoCastigado)
			WHEN CONVERT(INT,DC01.EstadoCredito) = '2' THEN '0'
			WHEN CONVERT(INT,DC01.EstadoCredito) = '1' THEN CONVERT(DECIMAL(15,4),DC01.SaldoCapital)
		END AS 'SALDO',--YR 14/08/2012

		CASE
			WHEN TMPR.SaldoRendXcobrar = @Cero OR TMPR.SaldoRendXcobrar IS NULL
			THEN DC01.SaldoRendimientos
			ELSE TMPR.SaldoRendXcobrar
		END AS 'RendimientosCobrar', 
		ISNULL(TMPR.SaldoRendXcobrarVenc,@Cero) AS 'RendimientosCobrarVencidos',
		ISNULL(TMPR.SaldoRendXMora,@Cero) AS 'RendimientosCobrarMora', 
		'0' AS 'ProvisionEspecifica', 		
		CASE DC01.ClaseRiesgo
			WHEN 'A' THEN '0'
			WHEN 'B' THEN '10'
			WHEN 'C' THEN '30' --SE ACTUALIZO SEGUN BI JF77062
			WHEN 'D' THEN '60'
			WHEN 'E' THEN '95' --SE ACTUALIZO SEGUN BI JF77062
			ELSE '0'
		END AS 'PocentajeProvisionEspecifica',	 
		'' AS 'ProvisionRendimientoCobrar',   --PENDIENTE ACTUALIZACION YR
		ISNULL(DC01.Rate, '0') AS 'TasasInteresCobrada',--YR 14/08/2012 ISNULL --	CONVERT(DECIMAL(15,4),ISNULL(DC01.Rate,0)) * 100 AS 'TasasInteresCobrada',
		ISNULL(DC01.Rate, '0') AS 'TasasInteresActual', --YR 14/08/2012 ISNULL --	CONVERT(DECIMAL(15,4),ISNULL(DC01.Rate,0)) * 100 AS 'TasasInteresActual',
		'1' AS 'IndicadorTasaPreferencial', --Valor por Defecto
		'0' AS 'TasaComision', --Valor por Defecto
		'0' AS 'ComisionesCobrar', --Valor por Defecto
		ISNULL(REPLACE(DC01.FeePaid,'Bs ',''), '0') AS 'ComisionesCobradas',
		'0' AS 'ErogacionesRecuperables', --Valor por Defecto
		'10' AS 'TipoGarantiaPrincipal', --Valor por Defecto	
		'36' AS 'NumCuotas',
		ISNULL(DC01.NumPmtsPastDue, '0') AS 'NumeroCuotasVencidas',	--CAMPO QUE NECESITA UNA ACTUALIZACION 
		ISNULL(REPLACE(Amt30DPD,'Bs ',''),'0')  AS 'MontoVencido30dias', 
		ISNULL(REPLACE(Amt60DPD,'Bs ',''),'0')  AS 'MontoVencido60dias',
		ISNULL(REPLACE(Amt90DPD,'Bs ',''),'0')  AS 'MontoVencido90dias',
		ISNULL(REPLACE(Amt120DPD,'Bs ',''),'0') AS 'MontoVencido120dias',
		ISNULL(REPLACE(Amt180DPD,'Bs ',''),'0') AS 'MontoVencido180dias',
		'0' AS 'MontoVencidoUnAno', --Valor por Defecto
		'0' AS 'MontoVencidoMasUnAno', --Valor por Defecto
		'0' AS 'MontoVencer30dias', --Valor por Defecto
		'0' AS 'MontoVencer60dias', --Valor por Defecto
		'0' AS 'MontoVencer90dias', --Valor por Defecto
		'0' AS 'MontoVencer120dias', --Valor por Defecto
		'0' AS 'MontoVencer180dias', --Valor por Defecto
		'0' AS 'MontoVencerUnAno', --Valor por Defecto
		'0' AS 'MontoVencerMasUnAno', --Valor por Defecto
		'1' AS 'BancaSocial', --Valor por Defecto
		'1' AS 'UnidadProduccionSocial', --Valor por Defecto
		'0' AS 'ModalidadMicrocredito', --Valor por Defecto
		'0' AS 'UsoFinanciero', --Valor por Defecto
		'0' AS 'DestinoRecursosMicrofinancieros', --Valor por Defecto
		'0' AS 'CantidadTrabajadores', --Valor por Defecto
		'0' AS 'VentaAnuales', --Valor por Defecto
		'1900/01/01' AS 'FechaEstadoFinanciero', --Valor por Defecto
		'' AS 'NumeroRTN', --Valor por Defecto
		'' AS 'LicenciaTuristicaNacional', --Valor por Defecto
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica', --Valor por Defecto
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica', --Valor por Defecto
		'0' AS 'NumeroExpedienteConformidadTuristica', --Valor por Defecto
		'' AS 'NombreProyectoUnidadProduccion', --Valor por Defecto
		'' AS 'DireccionProyectoUnidadProduccion', --Valor por Defecto
		'0' AS 'CodigoTipoProyecto', --Valor por Defecto
		'0' AS 'CodigoTipoOperacionesFinanciamiento', --Valor por Defecto
		'0' AS 'CodigoSegmento', --Valor por Defecto
		'0' AS 'TipoZona', --Valor por Defecto
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion', --Valor por Defecto
		'1900/01/01' AS 'FechaUltimaInspeccion', --Valor por Defecto
		'0' AS 'PorcentajeEjecucionProyecto', --Valor por Defecto
		'0' AS 'PagosEfectuadosDuranteMes', --Valor por Defecto
		'0' AS 'MontosLiquidadosFechaCierre', --Valor por Defecto
		'0' AS 'AmortizacionesCapitalAcumuladasFecha', --Valor por Defecto
		'0' AS 'TasaIncentivo', --Valor por Defecto
		'' AS 'NumeroOficioIncentivo', --Valor por Defecto
		'0' AS 'NumeroRegistro_ConstanciaMPPAT', --Valor por Defecto
		'' AS 'TipoRegistro_ConstanciaMPPAT', --Valor por Defecto
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT', --Valor por Defecto
		'0' AS 'TipoSubsector', --Valor por Defecto 
		'0' AS 'Rubro', --Valor por Defecto
		'0' AS 'CodigoUso', --Valor por Defecto
		'0' AS 'CantidadUnidades', --Valor por Defecto
		'0' AS 'CodigoUnidadMedida', --Valor por Defecto
		'0' AS 'SectorProduccion', --Valor por Defecto			
		'0' AS 'CantidadHectareas', --Valor por Defecto
		'0' AS 'SuperficieTotalPropiedad', --Valor por Defecto
		'0' AS 'NumeroProductoresBeneficiarios', --Valor por Defecto
		'0' AS 'Prioritario', --Valor por Defecto
		'0' AS 'DestinoManufacturero', --Valor por Defecto
		'0' AS 'DestinoEconomico', --Valor por Defecto
		'0' AS 'TipoBeneficiario', --Valor por Defecto
		'0' AS 'ModalidadHipoteca', --Valor por Defecto
		'0' AS 'IngresoFamiliar', --Valor por Defecto
		'0' AS 'MontoLiquidadoDuranteAnoCurso', --Valor por Defecto
		'0' AS 'SaldoCredito31_12', --Valor por Defecto
		'0' AS 'CantidadViviendasConstruir', --Valor por Defecto
		----------------
		CASE 
			WHEN DC01.CtaLocal LIKE '132%' 
			THEN TMPR.SaldoRendXcobrar
			ELSE @Cero 
		END  AS 'RendimientosCobrarReestructurados',
		@Cero AS 'RendimientosCobrarAfectosReporto',
		@Cero AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS 'FechaCambioEstatusCapitalTransferido',
		----------------------
		5 AS TipoDC,
		0 AS IdLote,
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM TB_DCAT04_01 DC01
		LEFT JOIN TB_DCAT04_05 DC05 ON DC01.CId = DC05.IdentificadorCliente
		LEFT JOIN TB_DCAT04_06 DC06 ON DC01.Acct = DC06.CardNumber
		LEFT JOIN TB_DCAT04_07 DC07 ON DC01.Acct = DC07.CardNumber
		LEFT JOIN tbGavetas GAV on DC01.Acct = GAV.[Número de Crédito]		
		LEFT JOIN TMP_Rendimiento TMPR on TMPR.acct = DC01.Acct 
		LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC01.ActivityID = Equi.CodigoCiti 
				AND Equi.AtomoSif = 'CTE'
				AND Equi.TablaSif = 'SB10'
				AND Equi.Insumo = 'CORE'
	WHERE
			DC01.TypeId IN (999) AND Micro = 0 

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera 5 TDC AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 5 TDC
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada  5 TDC', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 


-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 5 TDC (Actualizaciones posteriores)
--------------------------

DELETE FROM jf77062.TB_DMAT04 WHERE CodigoContable like ('0%') or CodigoContable like ('99999%')AND TipoDC = 5
-----------
UPDATE jf77062.TB_DMAT04 SET PlazoCredito = '0' WHERE EstadoCredito IN ('2', '3') AND TipoDC = 5
------------

UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica=(CONVERT(DECIMAL(18,2),ISNULL(PocentajeProvisionEspecifica,0))*CONVERT(DECIMAL(18,2),ISNULL(Saldo,0))/100)*-1
WHERE TipoDC = 5  AND ClasificacionRiesgo NOT IN ('A', '0') --YR 14/08/2012
----------------
UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica= '0' WHERE TipoDC = 5  AND  EstadoCredito in ('2', '3') --YR 14/08/2012
-----

UPDATE jf77062.TB_DMAT04 SET
ProvisionRendimientoCobrar = (((CONVERT(DECIMAL(15,4),replace(RendimientosCobrar,',','')) + CONVERT(DECIMAL(15,4),replace(RendimientosCobrarVencidos,',',''))) * (CONVERT(INTEGER,PocentajeProvisionEspecifica)))/100) * -1  --SE ACTUALIZO SEGUN BI JF77062	
WHERE TipoDC = 5
--------
UPDATE TB_DCAT04_08 SET DueDate = REPLACE(LEFT(DueDate,10),'-','/')
----

UPDATE jf77062.TB_DMAT04
SET FechaVencimientoUltimaCoutaCapital = DC08.DueDate,
FechaVencimientoUltimaCuotaInteres = DC08.DueDate
FROM 
jf77062.TB_DMAT04 DC04 LEFT JOIN TB_DCAT04_08 DC08 ON DC04.NumeroCredito = DC08.ACCT
WHERE 
TIPODC = 5
---
UPDATE jf77062.TB_DMAT04 SET NumeroCuotasVencidas = CASE
WHEN SituacionCredito in ('1', '2', '3', '4') THEN
		CASE
			WHEN DC01.Amt180DPD <> CONVERT(DECIMAL(18,2),0) THEN 6
			WHEN DC01.Amt150DPD <> CONVERT(DECIMAL(18,2),0) THEN 5
			WHEN DC01.Amt120DPD <> CONVERT(DECIMAL(18,2),0) THEN 4
			WHEN DC01.Amt90DPD <> CONVERT(DECIMAL(18,2),0) THEN 3
			WHEN DC01.Amt60DPD <> CONVERT(DECIMAL(18,2),0) THEN 2					
			WHEN DC01.Amt30DPD <> CONVERT(DECIMAL(18,2),0) THEN 1
		ELSE 0
		END
WHEN jf77062.TB_DMAT04.EstadoCredito in ('2','3') THEN 0
ELSE 0
END
FROM jf77062.TB_DMAT04 
inner JOIN TB_DCAT04_01 DC01 ON DC01.Acct = jf77062.TB_DMAT04.NumeroCredito
WHERE 
TIPODC = 5

-----------
UPDATE jf77062.TB_DMAT04 set SituacionCredito = '0' WHERE EstadoCredito in ('2', '3') and TIPODC = 5
--------
UPDATE jf77062.TB_DMAT04 set ClasificacionRiesgo = '0' WHERE EstadoCredito in ('2', '3') and TIPODC = 5
-------
UPDATE jf77062.TB_DMAT04  set TipoCredito = '0' WHERE  EstadoCredito = '3'  and TIPODC = 5
------------

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera 5 TDC AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 5 TDC  (Actualizaciones posteriores)
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada  5 TDC  (Actualizaciones posteriores)', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 
-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 13 Corporativa No Dirigida 
--------------------------
UPDATE TB_DCAT04_04 SET ESNODIRIGIDO = ''
UPDATE TB_DCAT04_04 SET ESNODIRIGIDO = 'X' FROM TB_DCAT04_04 --clientes corporativos.txt
WHERE REFERNO IN (SELECT REFERENCIA FROM TB_CarteraNoDirigidaFINAL) --cartera no dirigida .xls

	INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,			
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	
	SELECT 
		Referno AS 'NumeroCredito',
		CASE WHEN CTRORG = '0000000000'	THEN
			CONVERT(VARCHAR(10), CONVERT(DATETIME, LIQUFECHA), 111)
		ELSE
			CONVERT(VARCHAR(10), CONVERT(DATETIME, ORIGFECHA), 111)
		END AS 'FechaLiquidacion', --YR 14/08/2012 
	
	
		CASE WHEN CTRORG = '0000000000'	THEN
			CONVERT(VARCHAR(10), CONVERT(DATETIME, SOLIFECHA), 111)
		ELSE
			CONVERT(VARCHAR(10), CONVERT(DATETIME, ORIGFECHA), 111)
		END AS 'FechaSolicitud',--YR 14/08/2012 
	
	
		CASE WHEN CTRORG = '0000000000'	THEN
			CONVERT(VARCHAR(10), CONVERT(DATETIME, LIQUFECHA), 111)
		ELSE
			CONVERT(VARCHAR(10), CONVERT(DATETIME, ORIGFECHA), 111) --YR 14/08/2012 
		END AS 'FechaAprobacion',
	
		'02' AS 'Oficina', 
		GENLEDGER AS 'CodigoContable',
		CASE WHEN CTRORG = '0000000000'	THEN
			Referno
		ELSE
			CTRORG
		END AS 'NumeroCreditoPrimerDesembolso',
		'1' AS 'NumeroDesembolso', 
		'1' AS 'CodigoLineaCredito', 
		'0' AS 'MontoLineaCredito',
		'1' AS 'EstadoCredito',
		CASE WHEN PRODCAT = '14046'	THEN '4' --'AGRICOLA'
			WHEN PRODCAT = '14060'	THEN '4' --'AGRICOLA'
			WHEN PRODCAT = '14040'	THEN '2' --'COMERCIAL'
			WHEN PRODCAT = '14061'	THEN '3' --'CONSTRUCCION'
			WHEN PRODCAT = '14240'	THEN '8' --'MANUFACTURA'
			WHEN PRODCAT = '14057'	THEN '6' --'TURISMO'
			ELSE '2' --YR 14/08/2012
		END AS 'TipoCredito',
		CASE WHEN SUBSTRING(GENLEDGER,1,3) = '131'	THEN '1'
			WHEN SUBSTRING(GENLEDGER,1,3) = '132'	THEN '2'
			WHEN SUBSTRING(GENLEDGER,1,3) = '133'	THEN '3'
			WHEN SUBSTRING(GENLEDGER,1,3) = '134'	THEN '4'
			ELSE ''
		END AS 'SituacionCredito',
		CASE WHEN CONVERT(DECIMAL,Plazo/365) <= 3 THEN 'C'
			WHEN CONVERT(DECIMAL,Plazo/365) > 3 AND CONVERT(DECIMAL,Plazo/365) <= 5 THEN 'M'
			WHEN CONVERT(DECIMAL,Plazo/365) > 5 THEN 'L'
			ELSE ''
		END AS 'PlazoCredito',  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		NULL AS 'ClasificacionRiesgo', --manual usuario 
		NULL AS 'DestinoCredito', --manual usuario
		'2' AS 'NaturalezaCliente', 
		SUBSTRING(RIFCLI,1,1) AS 'TipoCliente', 
		SUBSTRING(RIFCLI,2,10) AS 'IdentificacionCliente',
		REPLACE(LTRIM(RTRIM(UPPER(DC04.NOMECLI))),'''','´') AS 'Nombre_RazonSocial',
		'0' AS 'Genero',
		SUBSTRING(RIFCLI,1,1) AS 'TipoClienteRIF',
		SUBSTRING(RIFCLI,2,10) AS 'IdentificacionTipoClienteRIF',
		NULL AS 'ActividadCliente',  --manual usuario SIC VEN
		'VE'AS 'Pais_Nacionalidad',
		RTRIM(ADDRESS3) + ' ' + RTRIM(ADDRESS4) + ' ' + RTRIM(ADDRESS5) + ' ' + RTRIM(ADDRESS6) AS 'Domicilio_Fiscal', 
		'1' AS 'ClienteNuevo', --manual usuario
		'1' AS 'Cooperativa', 
		'0' AS 'Sindicado', 
		'0' AS 'BancoLiderSindicato', 
		'1' AS 'RelacionCrediticia', 
		'2' AS 'GrupoEconomicoFinanciero', --valor manual
		NULL AS 'NombreGrupoEconomicoFinanciero', --valor manual
		'010109' AS 'CodigoParroquia', --valor manual
		'0' AS 'PeriodoGraciaCapital', 
		CASE WHEN CONVERT(DECIMAL,TOTALCUOTAS) = 1 THEN '512'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) > 1 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 7 THEN '1'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 7 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 15 THEN '2'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 15 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 30 THEN '4'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 30 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 60 THEN '8'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 60 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 90 THEN '16'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 90 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 120 THEN '32'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 120 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 180 THEN '64'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 180 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 365 THEN '128'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 365 THEN '256'
			ELSE ''
		END AS 'PeriodicidadPagoCapital', 
		CASE WHEN CONVERT(DECIMAL,TOTALCUOTAS) = 1 THEN '512'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) > 1 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 7 THEN '1'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 7 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 15 THEN '2'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 15 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 30 THEN '4'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 30 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 60 THEN '8'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 60 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 90 THEN '16'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 90 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 120 THEN '32'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 120 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 180 THEN '64'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 180 AND (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) < 365 THEN '128'
			WHEN (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) >= 365 THEN '256'
			ELSE ''
		END AS 'PeriodicidadPagoInteresCredito', 
	
		CASE WHEN QTDREN = '0000' THEN CONVERT(VARCHAR(10), CONVERT(DATETIME, Replace(VCTOFECHA,'00000000', '')), 111)
			ELSE CONVERT(VARCHAR(10), CONVERT(DATETIME, LIQUFECHA) -1, 111)--YR 14/08/2012
		END AS 'FechaVencimientoOriginal',
	
		CONVERT(VARCHAR(10), CONVERT(DATETIME, Replace(VCTOFECHA,'00000000', '')), 111) AS 'FechaVencimientoActual',
	
		CASE WHEN SUBSTRING(GENLEDGER,1,3) = '132' THEN CONVERT(VARCHAR(10), CONVERT(DATETIME, LIQUFECHA), 111)
			ELSE '1900/01/01'	
		END AS 'FechaReestructuracion', 
		CONVERT(DECIMAL,QTDREN) AS 'CantidadProrroga', 
	
		CASE WHEN CONVERT(DECIMAL,QTDREN) = 0 THEN '1900/01/01' 
			WHEN CONVERT(DECIMAL,QTDREN) > 0 THEN CONVERT(VARCHAR(10), CONVERT(DATETIME, LIQUFECHA) +1, 111)
		END AS 'FechaProrroga',--YR 14/08/2012 
	
	
		CONVERT(DECIMAL,QTDREN) AS 'CantidadRenovaciones', 
	
		CASE WHEN CONVERT(DECIMAL,QTDREN) > 0 THEN CONVERT(VARCHAR(10), CONVERT(DATETIME, LIQUFECHA), 111) 
			ELSE CONVERT(VARCHAR(10), CONVERT(DATETIME, Replace(VCTOFECHA,'00000000', '')), 111)  
		END AS 'FechaUltimaRenovacion',--YR 14/08/2012 
	
		'1900/01/01' AS 'FechaCancelacionTotal', --YR 14/08/2012
		CONVERT(VARCHAR(10), CONVERT(DATETIME, Replace(VCTOFECHA,'00000000', '')), 111) AS 'FechaVencimientoUltimaCoutaCapital', 
		
		CASE 
			WHEN VCTOFECHA = '00000000' THEN CONVERT(VARCHAR(10), CONVERT(DATETIME, Replace(VCTOULTPRINC,'00000000', '')), 111)
			WHEN VCTOFECHA IS NULL THEN CASE WHEN CTRORG = '0000000000'	THEN
										CONVERT(VARCHAR(10), CONVERT(DATETIME, LIQUFECHA), 111)
									ELSE
										CONVERT(VARCHAR(10), CONVERT(DATETIME, ORIGFECHA), 111)
									END 
			WHEN CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(SALDOMONTO,1,16))) +  '.' + SUBSTRING(SALDOMONTO,17,2) = CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(ORIGIMONTO,1,16))) +  '.' + SUBSTRING(ORIGIMONTO,17,2) THEN '1900/01/01'
			ELSE CONVERT(VARCHAR(10), CONVERT(DATETIME, VCTOFECHA), 111)
		END AS'UltimaFechaCancelacionCuotaCapital', --YR 14/08/2012
	
		CONVERT(VARCHAR(10), CONVERT(DATETIME, Replace(VCTOFECHA,'00000000', '')), 111) AS 'FechaVencimientoUltimaCuotaInteres', 
	
		CASE WHEN VCTOFECHA = '00000000' THEN CONVERT(VARCHAR(10), CONVERT(DATETIME, Replace(VCTOULTINTER,'00000000', '')), 111)
			WHEN VCTOFECHA IS NULL THEN CASE WHEN CTRORG = '0000000000'	THEN
										CONVERT(VARCHAR(10), CONVERT(DATETIME, LIQUFECHA), 111)
									ELSE
										CONVERT(VARCHAR(10), CONVERT(DATETIME, ORIGFECHA), 111)
									END 		
			WHEN CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(SALDOMONTO,1,16))) +  '.' + SUBSTRING(SALDOMONTO,17,2) = CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(ORIGIMONTO,1,16))) +  '.' + SUBSTRING(ORIGIMONTO,17,2) AND  (CONVERT(DECIMAL,PLAZO)/CONVERT(DECIMAL,TOTALCUOTAS)) IS NOT NULL THEN '1900/01/01'
			ELSE CONVERT(VARCHAR(10), CONVERT(DATETIME, VCTOFECHA), 111)
		END AS'UltimaFechaCancelacionCuotaIntereses', --YR 14/08/2012	
	
		'VEB' AS 'Moneda', 
		'1' AS 'TipoCambioOriginal', 
		'1' AS 'TipoCambioCierreMes',
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(ORIGIMONTO,1,16))) +  '.' + SUBSTRING(ORIGIMONTO,17,2) AS 'MontoOriginal',
	 	CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(ORIGIMONTO,1,16))) +  '.' + SUBSTRING(ORIGIMONTO,17,2) AS 'MontoInicial',
	 	CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(ORIGIMONTO,1,16))) +  '.' + SUBSTRING(ORIGIMONTO,17,2) AS 'MontoLiquidadoMes', 
		'0' AS 'EntePublico', 
		'0' AS 'MontoInicialTerceros', 
	 	CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(SALDOMONTO,1,16))) +  '.' + SUBSTRING(SALDOMONTO,17,2) AS 'Saldo',
		NULL AS 'RendimientosCobrar', 
		NULL AS 'RendimientosCobrarVencidos', 
		'0' AS 'RendimientosCobrarMora', --YR SETEAR 0 POR DEFECTO 
		NULL AS 'ProvisionEspecifica', --depende del riesgo
		TMP.Provision AS 'PocentajeProvisionEspecifica', --depende del riesgo
		NULL AS 'ProvisionRendimientoCobrar',  
	 	CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(INTORIGTASA,1,3))) +  '.' + SUBSTRING(INTORIGTASA,4,3) AS 'TasasInteresCobrada', 
	 	CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(INTORIGTASA,1,3))) +  '.' + SUBSTRING(INTORIGTASA,4,3) AS 'TasasInteresActual', 
		'1' AS 'IndicadorTasaPreferencial', 
		'' AS 'TasaComision',  ---PENDIENTE ACTUALIZACION YR
		'0' AS 'ComisionesCobrar', 
		'0' AS 'ComisionesCobradas',
		'0' AS 'ErogacionesRecuperables', 
		NULL AS 'TipoGarantiaPrincipal', 
		CONVERT(DECIMAL,TOTALCUOTAS) AS 'NumCuotas',
		CONVERT(DECIMAL,VENCIDACUOTAS) AS 'NumeroCuotasVencidas',
		ISNULL(CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N030DMONTOVENCIDO,1,16))) +  '.' + SUBSTRING(N030DMONTOVENCIDO,17,2),'0') AS 'MontoVencido30dias', 
		ISNULL(CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N060DMONTOVENCIDO,1,16))) +  '.' + SUBSTRING(N060DMONTOVENCIDO,17,2),'0') AS 'MontoVencido60dias',
		ISNULL(CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N090DMONTOVENCIDO,1,16))) +  '.' + SUBSTRING(N090DMONTOVENCIDO,17,2),'0') AS 'MontoVencido90dias',
		ISNULL(CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N120DMONTOVENCIDO,1,16))) +  '.' + SUBSTRING(N120DMONTOVENCIDO,17,2),'0') AS 'MontoVencido120dias',
		ISNULL(CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N180DMONTOVENCIDO,1,16))) +  '.' + SUBSTRING(N180DMONTOVENCIDO,17,2),'0') AS 'MontoVencido180dias',
		ISNULL(CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N360DMONTOVENCIDO,1,16))) +  '.' + SUBSTRING(N360DMONTOVENCIDO,17,2),'0') AS 'MontoVencidoUnAno', 
		ISNULL(CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(MA1AMONTOVENCIDO,1,16))) +  '.' + SUBSTRING(MA1AMONTOVENCIDO,17,2),'0') AS 'MontoVencidoMasUnAno',
	
	
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N030DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(N030DMONTOAVENCER,17,2) AS 'MontoVencer30dias', 
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N060DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(N060DMONTOAVENCER,17,2) AS 'MontoVencer60dias', 
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N090DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(N090DMONTOAVENCER,17,2) AS 'MontoVencer90dias', 
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N120DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(N120DMONTOAVENCER,17,2) AS 'MontoVencer120dias', 
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N180DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(N180DMONTOAVENCER,17,2) AS 'MontoVencer180dias', 
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(N360DMONTOAVENCER,1,16))) +  '.' + SUBSTRING(N360DMONTOAVENCER,17,2) AS 'MontoVencerUnAno', 
		CONVERT(VARCHAR(20),CONVERT(DECIMAL,SUBSTRING(MA1AMONTOAVENCER,1,16))) +  '.' + SUBSTRING(MA1AMONTOAVENCER,17,2) AS 'MontoVencerMasUnAno', 
		'1' AS 'BancaSocial', --Valor por Defecto
		'1' AS 'UnidadProduccionSocial', --Valor por Defecto
		'0' AS 'ModalidadMicrocredito', --Valor por Defecto
		'0' AS 'UsoFinanciero', --Valor por Defecto
		'0' AS 'DestinoRecursosMicrofinancieros', --Valor por Defecto
		'0' AS 'CantidadTrabajadores', --Valor por Defecto
		'0' AS 'VentaAnuales', --Valor por Defecto
		'1900/01/01' AS 'FechaEstadoFinanciero', --Valor por Defecto
		'' AS 'NumeroRTN', --Valor por Defecto
		'' AS 'LicenciaTuristicaNacional', --Valor por Defecto
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica', --Valor por Defecto
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica', --Valor por Defecto
		'0' AS 'NumeroExpedienteConformidadTuristica', --Valor por Defecto
		'' AS 'NombreProyectoUnidadProduccion', --Valor por Defecto
		'' AS 'DireccionProyectoUnidadProduccion', --Valor por Defecto
		'0' AS 'CodigoTipoProyecto', --Valor por Defecto
		'0' AS 'CodigoTipoOperacionesFinanciamiento', --Valor por Defecto
		'0' AS 'CodigoSegmento', --Valor por Defecto
		'0' AS 'TipoZona', --Valor por Defecto
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion', --Valor por Defecto
		'1900/01/01' AS 'FechaUltimaInspeccion', --Valor por Defecto
		'0' AS 'PorcentajeEjecucionProyecto', --Valor por Defecto
		'0' AS 'PagosEfectuadosDuranteMes', --Valor por Defecto
		'0' AS 'MontosLiquidadosFechaCierre', --Valor por Defecto
		'0' AS 'AmortizacionesCapitalAcumuladasFecha', --Valor por Defecto
		'0' AS 'TasaIncentivo', --Valor por Defecto
		'' AS 'NumeroOficioIncentivo', --Valor por Defecto
		'0' AS 'NumeroRegistro_ConstanciaMPPAT', --Valor por Defecto
		'' AS 'TipoRegistro_ConstanciaMPPAT', --Valor por Defecto
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT', --Valor por Defecto
		'0' AS 'TipoSubsector', --Valor por Defecto 
		'0' AS 'Rubro', --Valor por Defecto
		'0' AS 'CodigoUso', --Valor por Defecto
		'0' AS 'CantidadUnidades', --Valor por Defecto
		'0' AS 'CodigoUnidadMedida', --Valor por Defecto
		'0' AS 'SectorProduccion', --Valor por Defecto			
		'0' AS 'CantidadHectareas', --Valor por Defecto
		'0' AS 'SuperficieTotalPropiedad', --Valor por Defecto
		'0' AS 'NumeroProductoresBeneficiarios', --Valor por Defecto
		'0' AS 'Prioritario', --Valor por Defecto
		'0' AS 'DestinoManufacturero', --Valor por Defecto
		'0' AS 'DestinoEconomico', --Valor por Defecto
		'0' AS 'TipoBeneficiario', --Valor por Defecto
		'0' AS 'ModalidadHipoteca', --Valor por Defecto
		'0' AS 'IngresoFamiliar', --Valor por Defecto
		'0' AS 'MontoLiquidadoDuranteAnoCurso', --Valor por Defecto
		'0' AS 'SaldoCredito31_12', --Valor por Defecto
		'0' AS 'CantidadViviendasConstruir', --Valor por Defecto
		---------------------
		'0' AS 'RendimientosCobrarReestructurados',
		'0' AS 'RendimientosCobrarAfectosReporto',
		'0' AS 'RendimientosCobrarLitigio',
		ISNULL(GAV.[Intereses Efectivamente Cobrados], ISNULL(TMP.InteresesEfectivamenteCobrados,@Cero)) AS 'InteresEfectivamenteCobrado',
		ISNULL(GAV.[Porcentaje de Comisión FLAT], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(GAV.[Monto Comisión FLAT],ISNULL(TMP.MontoComisionFLAT,'0,00')) AS	'MontoComisionFlat',
		ISNULL(GAV.[Periodicidad de Pago Especial de Capital], ISNULL(TMP.PeriodicidadPagoEspecialCapital,'0')) AS 'PeriocidadPagoEspecialCapital',
		ISNULL(GAV.[Fecha de Cambio de Estatus del Crédito], ISNULL(TMP.FechaCambioEstatusCredito,'19000101')) AS	'FechaCambioEstatusCredito',
		ISNULL(GAV.[Fecha de Registro en Vencida, Litigio o Castigada], ISNULL(TMP.FechaRegistroVencidaLitigioCastigada,ISNULL(SC.[Fecha_Registro_Vencida_Litigio_Castigada],ISNULL(SCS.[Fecha_Registro_Vencida_Litigio_Castigada],'19000101')))) AS 'FechaRegistroVencidaLitigiooCastigada',
		ISNULL(GAV.[Fecha de Exigibilidad de Pago de la última Cuota Pagada], ISNULL(TMP.FechaExigibilidadPagoUltimaCuotaPagada,'19000101')) AS 'FechaExigibilidadPagoUltimaCuotaPagada',
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		'0,00' AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0')AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(GAV.[Capital Transferido], ISNULL(TMP.CapitalTransferido,@Cero)) AS 'CapitalTransferido',
		ISNULL(GAV.[Fecha de Cambio de Estatus Capital Transferido], ISNULL(TMP.FechaCambioEstatusCapitalTransferido,'19000101')) AS	'FechaCambioEstatusCapitalTransferido',
		----------------------
		13 AS TipoDC,
		0 AS IdLote,
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM
		TB_DCAT04_04 DC04		
	LEFT JOIN tbGavetas GAV on DC04.REFERNO = GAV.[Número de Crédito] 
	LEFT JOIN TB_CarteraNoDirigidaFINAL TMP ON  DC04.REFERNO = TMP.REFERENCIA
	LEFT JOIN TMP_SobregirosCorporativo SC ON DC04.REFERNO  = SC.REFERENCIA
	LEFT JOIN TMP_SobregirosConsumer SCS ON  DC04.REFERNO = SCS.ACCT	
	LEFT JOIN TB_DCAT04_01 DC01 ON DC04.REFERNO = DC01.ACCT --LDWH	
		
	WHERE
		EsNoDirigido = 'X'
		
UPDATE jf77062.TB_DMAT04 SET TasaComision = CONVERT(DECIMAL(18,3), TasasInteresActual) - 0.02
WHERE TipoDC = 13

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera 13 Corporativa No Dirigida AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 13 Corporativa No Dirigida 
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada 13 Corporativa No Dirigida ', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 14 CARROS
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	
	SELECT 
		DC01.Acct AS 'NumeroCredito',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaLiquidacion',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaSolicitud',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaAprobacion',
	
		CASE 
			WHEN CONVERT(INT,DC01.BranchId) = 1 THEN '02'  
			ELSE ISNULL(CONVERT(INT,DC01.BranchId),-1)
		END AS 'Oficina',--YR 14/08/2012
	
		DC01.CtaLocal AS 'CodigoContable',
		DC01.Acct AS 'NumeroCreditoPrimerDesembolso', --fz
		'1' AS 'NumeroDesembolso', --Valor por defecto
		'1' AS 'CodigoLineaCredito', --Valor por defecto
		'0' AS 'MontoLineaCredito', 
		'3' AS 'EstadoCredito', --fz
		'0' AS 'TipoCredito', --JR
		'0' AS 'SituacionCredito', --JR
		'0' AS 'PlazoCredito', --JR  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		'0' AS 'ClasificacionRiesgo',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'DestinoCredito',  --fz
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) IN ('V','E','P') THEN '1'  --YR 03/10/2012
			WHEN SUBSTRING(DC01.CId, 1, 1) IN ('J')THEN '2' --YR 03/10/2012
			ELSE '3'
		END AS 'NaturalezaCliente',
	
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoCliente',
		SUBSTRING(CId, 2, 20) AS 'IdentificacionCliente',
		REPLACE(LTRIM(RTRIM(UPPER(DC01.FullName))),'''','´') AS 'Nombre_RazonSocial', --fz
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) NOT IN ('V','E','P') THEN '0'  --YR 14/08/2012
			WHEN DC01.Gender IN ('1','2', '0') THEN DC01.Gender --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoClienteRIF',
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) IN ('V','E') THEN SUBSTRING(dbo.GetRif(DC01.CId), 2, 20) --fz
			ELSE SUBSTRING(DC01.CId, 2, 10)  --RIGHT(CId, 9) YR
		END AS 'IdentificacionTipoClienteRIF',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'ActividadCliente',  --fz
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) in ('V','J','G') THEN 'VE' --fz
			ELSE ISNULL(UPPER(DC05.Nacionalidad),'XX')
		END AS 'Pais_Nacionalidad',
		DC01.DireccionH AS 'Domicilio_Fiscal', --fz
		'1' AS 'ClienteNuevo', --Valor por Defecto
		'1' AS 'Cooperativa', --Valor por Defecto
		'0' AS 'Sindicado', --Valor por Defecto
		'0' AS 'BancoLiderSindicato', --Valor por Defecto
		'1' AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero', --Valor por Defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por Defecto
		'010109' AS 'CodigoParroquia', --Valor por Defecto
		'0' AS 'PeriodoGraciaCapital', --Valor por Defecto
		'0' AS 'PeriodicidadPagoCapital',
		'0' AS 'PeriodicidadPagoInteresCredito',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoOriginal',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoActual',
		'1900/01/01' AS 'FechaReestructuracion', --JR
		'0' AS 'CantidadProrroga', --Valor por Defecto
		'1900/01/01' AS 'FechaProrroga', --Valor por Defecto
		'0' 'CantidadRenovaciones',
		'1900/01/01' AS 'FechaUltimaRenovacion',--JR
		'1900/01/01' AS 'FechaCancelacionTotal', --JR
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaVencimientoUltimaCoutaCapital', --JR
		'1900/01/01' AS 'UltimaFechaCancelacionCuotaCapital', --JR
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaVencimientoUltimaCuotaInteres', --JR
		'1900/01/01' AS 'UltimaFechaCancelacionCuotaIntereses', --JR
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		CONVERT(DECIMAL(18,2),DC09.CapitalCastigado) AS 'MontoOriginal', --JR
		CONVERT(DECIMAL(18,2),DC09.CapitalCastigado) AS 'MontoInicial', --JR
		'0' AS 'MontoLiquidadoMes', 
		'0' AS 'EntePublico', --Valor por Defecto
		'0' AS 'MontoInicialTerceros', --Valor por Defecto
		CONVERT(DECIMAL(18,2),DC01.SaldoCastigado) AS 'Saldo',
		ISNULL(TMPR.SaldoRendXcobrar,@Cero) AS 'RendimientosCobrar',--JR
		ISNULL(TMPR.SaldoRendXcobrarVenc,@Cero)  AS 'RendimientosCobrarVencidos', --JR
		ISNULL(TMPR.SaldoRendXMora,@Cero) AS 'RendimientosCobrarMora', --JR
		'0' AS 'ProvisionEspecifica',	--JR
		'0' AS 'PocentajeProvisionEspecifica',	--JR
		'0' AS 'ProvisionRendimientoCobrar',	--JR
		'0' AS 'TasasInteresCobrada', --JR
		CONVERT(DECIMAL(15,4),ISNULL(DC01.Rate,0)) * 100 AS 'TasasInteresActual',
		'1' AS 'IndicadorTasaPreferencial', --Valor por Defecto
		'0' AS 'TasaComision', 
		'0' AS 'ComisionesCobrar',
		'0' AS 'ComisionesCobradas',
		'0' AS 'ErogacionesRecuperables', --Valor por Defecto
		'10' AS 'TipoGarantiaPrincipal', --Valor por Defecto	
		CASE
			WHEN DC01.Divisiontypeid IN ('R','E','V') THEN 0
			WHEN DC01.Agro=0 THEN DATEDIFF(MONTH,CONVERT(DATETIME,DC01.OpenDate),CONVERT(DATETIME,DC01.MaturityDate))
			ELSE ROUND(DATEDIFF(MONTH,CONVERT(DATETIME,DC01.OpenDate),CONVERT(DATETIME,DC01.MaturityDate))/6,0)
		END AS NumCuotas,
		'0' AS 'NumeroCuotasVencidas', --JR
		'0' AS 'MontoVencido30dias', --JR
		'0' AS 'MontoVencido60dias', --JR
		'0' AS 'MontoVencido90dias', --JR
		'0' AS 'MontoVencido120dias', --JR
		'0' AS 'MontoVencido180dias',--JR
		'0' AS 'MontoVencidoUnAno', --JR
		'0' AS 'MontoVencidoMasUnAno', --JR
		'0' AS 'MontoVencer30dias', --Valor por Defecto
		'0' AS 'MontoVencer60dias', --Valor por Defecto
		'0' AS 'MontoVencer90dias', --Valor por Defecto
		'0' AS 'MontoVencer120dias', --Valor por Defecto
		'0' AS 'MontoVencer180dias', --Valor por Defecto
		'0' AS 'MontoVencerUnAno', --Valor por Defecto
		'0' AS 'MontoVencerMasUnAno', --Valor por Defecto
		'1' AS 'BancaSocial', --Valor por Defecto
		'1' AS 'UnidadProduccionSocial', --Valor por Defecto
		'0' AS 'ModalidadMicrocredito', --Valor por Defecto
		'0' AS 'UsoFinanciero', --Valor por Defecto
		'0' AS 'DestinoRecursosMicrofinancieros', --Valor por Defecto
		'0' AS 'CantidadTrabajadores', --Valor por Defecto
		'0' AS 'VentaAnuales', --Valor por Defecto
		'1900/01/01' AS 'FechaEstadoFinanciero',
		'' AS 'NumeroRTN',
		'' AS 'LicenciaTuristicaNacional',
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica',
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica',
		'0' AS 'NumeroExpedienteConformidadTuristica',
		'' AS 'NombreProyectoUnidadProduccion',
		'' AS 'DireccionProyectoUnidadProduccion',
		'0' AS 'CodigoTipoProyecto',
		'0' AS 'CodigoTipoOperacionesFinanciamiento',
		'0' AS 'CodigoSegmento',
		'0' AS 'TipoZona',
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion',
		'1900/01/01' AS 'FechaUltimaInspeccion',
		'0' AS 'PorcentajeEjecucionProyecto',
		'0' AS 'PagosEfectuadosDuranteMes',
		'0' AS 'MontosLiquidadosFechaCierre',
		'0' AS 'AmortizacionesCapitalAcumuladasFecha',
		'0' AS 'TasaIncentivo',
		'' AS 'NumeroOficioIncentivo',
		'0' AS 'NumeroRegistro_ConstanciaMPPAT',
		'' AS 'TipoRegistro_ConstanciaMPPAT',
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT',
		'0' AS 'TipoSubsector',
		'0' AS 'Rubro',
		'0' AS 'CodigoUso',
		'0' AS 'CantidadUnidades',
		'0' AS 'CodigoUnidadMedida',
		'0' AS 'SectorProduccion',			
		'0' AS 'CantidadHectareas',
		'0' AS 'SuperficieTotalPropiedad',
		'0' AS 'NumeroProductoresBeneficiarios',
		'0' AS 'Prioritario',
		'0' AS 'DestinoManufacturero',
		'0' AS 'DestinoEconomico',
		'0' AS 'TipoBeneficiario',
		'0' AS 'ModalidadHipoteca',
		'0' AS 'IngresoFamiliar',
		'0' AS 'MontoLiquidadoDuranteAnoCurso',
		'0' AS 'SaldoCredito31_12',
		'0' AS 'CantidadViviendasConstruir',
		-----------------
		CASE 
			WHEN DC01.CtaLocal LIKE '132%' 
			THEN TMPR.SaldoRendXcobrar
			ELSE @Cero END  AS 'RendimientosCobrarReestructurados',
		@Cero AS 'RendimientosCobrarAfectosReporto',
		@Cero AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS 'FechaCambioEstatusCapitalTransferido',
		
		-----------------
		14 AS 'TipoDC',
		0 AS 'IdLote',
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM TB_DCAT04_01 DC01 --QUERY DWH
		LEFT JOIN TB_DCAT04_05 DC05 ON DC01.CId = DC05.IdentificadorCliente  --CLIENTES CONSUMER 05
		LEFT JOIN tbGavetas GAV on DC01.Acct = GAV.[Número de Crédito]
		LEFT JOIN TMP_Rendimiento TMPR on TMPR.acct = DC01.Acct
		LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC01.ActivityID = Equi.CodigoCiti 
					AND Equi.AtomoSif = 'CTE'
					AND Equi.TablaSif = 'SB10'
					AND Equi.Insumo = 'CORE'
		INNER JOIN TB_DCAT04_09 DC09 ON DC01.Acct = DC09.ACCT   --ACCOUNT HISTORY
					AND DC09.Appid = '50' 
					AND DC09.TypeId IN (25, 27, 52, 56, 57, 597, 20, 21, 22, 23, 24, 26, 28, 29, 30, 31, 34, 40, 41)
	WHERE
		DC01.TypeId IN (25, 27, 52, 56, 57, 597, 20, 21, 22, 23, 24, 26, 28, 29, 30, 31, 34, 40, 41) 
		and DC01.CtaLocal in ('8190310200') --CARROS
		and DC01.EstadoCredito = '3'  --castigados

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera CARROS AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 14 CARROS
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada  Cartera CARROS', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 15 PIL SEGUROS
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
	
	SELECT 
		DC01.Acct AS 'NumeroCredito',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaLiquidacion',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaSolicitud',
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaAprobacion',
	
		CASE 
			WHEN CONVERT(INT,DC01.BranchId) = 1 THEN '2'  
			ELSE ISNULL(CONVERT(INT,DC01.BranchId),-1)
		END AS 'Oficina',--YR 14/08/2012
	
		DC01.CtaLocal AS 'CodigoContable',
		DC01.Acct AS 'NumeroCreditoPrimerDesembolso', --fz
		'1' AS 'NumeroDesembolso', --Valor por defecto
		'1' AS 'CodigoLineaCredito', --Valor por defecto
		'0' AS 'MontoLineaCredito',
		'3' AS 'EstadoCredito', --fz
		'0' AS 'TipoCredito', --JR
		'0' AS 'SituacionCredito', --JR
		'0' AS 'PlazoCredito', --JR  --PENDIENTE ACTUALIZACION YR AL FINAL DEL QUERY APLICA A TODAS LAS CARTERAS
		'0' AS 'ClasificacionRiesgo',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'DestinoCredito',  --fz
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) NOT IN ('V','E','P') THEN '2'  --YR 14/08/2012
			ELSE '1' --YR 14/08/2012
		END AS 'NaturalezaCliente', --JR
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoCliente',
		SUBSTRING(CId, 2, 20) AS 'IdentificacionCliente',
		REPLACE(LTRIM(RTRIM(UPPER(DC01.FullName))),'''','´') AS 'Nombre_RazonSocial', --fz
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) NOT IN ('V','E','P') THEN '0'  --YR 14/08/2012
			WHEN DC01.Gender IN ('1','2', '0') THEN DC01.Gender --YR 14/08/2012
			ELSE '3'
		END AS 'Genero',
		SUBSTRING(DC01.CId, 1, 1) AS 'TipoClienteRIF',
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) IN ('V','E') THEN SUBSTRING(dbo.GetRif(DC01.CId), 2, 20) --fz
			ELSE SUBSTRING(DC01.CId, 2, 10)  --RIGHT(CId, 9) YR
		END AS 'IdentificacionTipoClienteRIF',
		ISNULL(Equi.CodigoSIF, 'G45') AS 'ActividadCliente',  --fz
		CASE 
			WHEN SUBSTRING(DC01.CId, 1, 1) in ('V','J','G') THEN 'VE' --fz
			ELSE ISNULL(UPPER(DC05.Nacionalidad),'XX')
		END AS 'Pais_Nacionalidad',
		DC01.DireccionH AS 'Domicilio_Fiscal', --fz
		'1' AS 'ClienteNuevo', --Valor por Defecto
		'1' AS 'Cooperativa', --Valor por Defecto
		'0' AS 'Sindicado', --Valor por Defecto
		'0' AS 'BancoLiderSindicato', --Valor por Defecto
		'1' AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero', --Valor por Defecto
		'' AS 'NombreGrupoEconomicoFinanciero', --Valor por Defecto
		'010109' AS 'CodigoParroquia', --Valor por Defecto
		'0' AS 'PeriodoGraciaCapital', --Valor por Defecto
		'0' AS 'PeriodicidadPagoCapital',
		'0' AS 'PeriodicidadPagoInteresCredito',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoOriginal',
		CASE 								
			WHEN DC01.DivisionTypeId Not In ('R','E','V','C') THEN CONVERT(VARCHAR(10),CONVERT(DATETIME, DC01.MaturityDate),111)
			WHEN DC01.DivisionTypeId In ('E') THEN CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.opendate)),111)
			ELSE CONVERT(VARCHAR(10),DATEADD(MONTH,36,CONVERT(DATETIME,DC01.recorddate)),111)
		END AS 'FechaVencimientoActual',
		'1900/01/01' AS 'FechaReestructuracion', --JR
		'0' AS 'CantidadProrroga', --Valor por Defecto
		'1900/01/01' AS 'FechaProrroga', --Valor por Defecto
		'0' 'CantidadRenovaciones',
		'1900/01/01' AS 'FechaUltimaRenovacion',--JR
		'1900/01/01' AS 'FechaCancelacionTotal', --JR
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaVencimientoUltimaCoutaCapital', --JR
		'1900/01/01' AS 'UltimaFechaCancelacionCuotaCapital', --JR
		CONVERT(VARCHAR(10), CONVERT(DATETIME, ISNULL(DC01.OrigOpenDate,DC01.OpenDate)),111) AS 'FechaVencimientoUltimaCuotaInteres', --JR
		'1900/01/01' AS 'UltimaFechaCancelacionCuotaIntereses', --JR
		'VEB' AS 'Moneda', -- Valor por Defecto
		'1' AS 'TipoCambioOriginal', -- Valor por Defecto
		'1' AS 'TipoCambioCierreMes', -- Valor por Defecto
		CONVERT(DECIMAL(18,2),DC09.CapitalCastigado) AS 'MontoOriginal', --JR
		CONVERT(DECIMAL(18,2),DC09.CapitalCastigado) AS 'MontoInicial', --JR 
		'0' AS 'MontoLiquidadoMes', 
		'0' AS 'EntePublico', --Valor por Defecto
		'0' AS 'MontoInicialTerceros', --Valor por Defecto
		CONVERT(DECIMAL(18,2),DC01.SaldoCastigado) AS 'Saldo',
		ISNULL(TMPR.SaldoRendXcobrar,@Cero) AS 'RendimientosCobrar',--JR
		ISNULL(TMPR.SaldoRendXcobrarVenc,@Cero)  AS 'RendimientosCobrarVencidos', --JR
		ISNULL(TMPR.SaldoRendXMora,@Cero) AS 'RendimientosCobrarMora', --JR
		'0' AS 'ProvisionEspecifica',	--JR
		'0' AS 'PocentajeProvisionEspecifica',	--JR
		'0' AS 'ProvisionRendimientoCobrar',	--JR
		'0' AS 'TasasInteresCobrada', --JR
		CONVERT(DECIMAL(15,4),ISNULL(DC01.Rate,0)) * 100 AS 'TasasInteresActual',
		'1' AS 'IndicadorTasaPreferencial', --Valor por Defecto
		'0' AS 'TasaComision', 
		'0' AS 'ComisionesCobrar',
		'0' AS 'ComisionesCobradas',
		'0' AS 'ErogacionesRecuperables', --Valor por Defecto
		'10' AS 'TipoGarantiaPrincipal', --Valor por Defecto	
		CASE
			WHEN DC01.Divisiontypeid IN ('R','E','V') THEN 0
			WHEN DC01.Agro=0 THEN DATEDIFF(MONTH,CONVERT(DATETIME,DC01.OpenDate),CONVERT(DATETIME,DC01.MaturityDate))
			ELSE ROUND(DATEDIFF(MONTH,CONVERT(DATETIME,DC01.OpenDate),CONVERT(DATETIME,DC01.MaturityDate))/6,0)
		END AS NumCuotas,  --PENDIENTE POR ACTUALIZAR YR
		'0' AS 'NumeroCuotasVencidas', --JR
		'0' AS 'MontoVencido30dias', --JR
		'0' AS 'MontoVencido60dias', --JR
		'0' AS 'MontoVencido90dias', --JR
		'0' AS 'MontoVencido120dias', --JR
		'0' AS 'MontoVencido180dias',--JR
		'0' AS 'MontoVencidoUnAno', --JR
		'0' AS 'MontoVencidoMasUnAno', --JR
		'0' AS 'MontoVencer30dias', --Valor por Defecto
		'0' AS 'MontoVencer60dias', --Valor por Defecto
		'0' AS 'MontoVencer90dias', --Valor por Defecto
		'0' AS 'MontoVencer120dias', --Valor por Defecto
		'0' AS 'MontoVencer180dias', --Valor por Defecto
		'0' AS 'MontoVencerUnAno', --Valor por Defecto
		'0' AS 'MontoVencerMasUnAno', --Valor por Defecto
		'1' AS 'BancaSocial', --Valor por Defecto
		'1' AS 'UnidadProduccionSocial', --Valor por Defecto
		'0' AS 'ModalidadMicrocredito', --Valor por Defecto
		'0' AS 'UsoFinanciero', --Valor por Defecto
		'0' AS 'DestinoRecursosMicrofinancieros', --Valor por Defecto
		'0' AS 'CantidadTrabajadores', --Valor por Defecto
		'0' AS 'VentaAnuales', --Valor por Defecto
		'1900/01/01' AS 'FechaEstadoFinanciero',
		'' AS 'NumeroRTN',
		'' AS 'LicenciaTuristicaNacional',
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica',
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica',
		'0' AS 'NumeroExpedienteConformidadTuristica',
		'' AS 'NombreProyectoUnidadProduccion',
		'' AS 'DireccionProyectoUnidadProduccion',
		'0' AS 'CodigoTipoProyecto',
		'0' AS 'CodigoTipoOperacionesFinanciamiento',
		'0' AS 'CodigoSegmento',
		'0' AS 'TipoZona',
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion',
		'1900/01/01' AS 'FechaUltimaInspeccion',
		'0' AS 'PorcentajeEjecucionProyecto',
		'0' AS 'PagosEfectuadosDuranteMes',
		'0' AS 'MontosLiquidadosFechaCierre',
		'0' AS 'AmortizacionesCapitalAcumuladasFecha',
		'0' AS 'TasaIncentivo',
		'' AS 'NumeroOficioIncentivo',
		'0' AS 'NumeroRegistro_ConstanciaMPPAT',
		'' AS 'TipoRegistro_ConstanciaMPPAT',
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT',
		'0' AS 'TipoSubsector',
		'0' AS 'Rubro',
		'0' AS 'CodigoUso',
		'0' AS 'CantidadUnidades',
		'0' AS 'CodigoUnidadMedida',
		'0' AS 'SectorProduccion',			
		'0' AS 'CantidadHectareas',
		'0' AS 'SuperficieTotalPropiedad',
		'0' AS 'NumeroProductoresBeneficiarios',
		'0' AS 'Prioritario',
		'0' AS 'DestinoManufacturero',
		'0' AS 'DestinoEconomico',
		'0' AS 'TipoBeneficiario',
		'0' AS 'ModalidadHipoteca',
		'0' AS 'IngresoFamiliar',
		'0' AS 'MontoLiquidadoDuranteAnoCurso',
		'0' AS 'SaldoCredito31_12',
		'0' AS 'CantidadViviendasConstruir',
		----------------
		CASE 
		WHEN DC01.CtaLocal LIKE '132%' 
		THEN TMPR.SaldoRendXcobrar
		ELSE @Cero END  AS 'RendimientosCobrarReestructurados',
		@Cero AS 'RendimientosCobrarAfectosReporto',
		@Cero AS 'RendimientosCobrarLitigio',
		ISNULL(DC01.Int_Efectivamente_Cobrado, @Cero) AS 'InteresEfectivamenteCobrado',
		ISNULL(DC01.[%Comsion_Flat], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(DC01.Monto_Comision_Flat, '0,00') AS	'MontoComisionFlat',
		ISNULL(DC01.Periodicidad_Pago_Especial_Capital, '0') AS 'PeriocidadPagoEspecialCapital',
		ISNULL(DC01.Fecha_Cambio_Status, '19000101') AS	'FechaCambioEstatusCredito',
		ISNULL(DC01.Fecha_Reg_Venc_Lit_cast, '19000101') AS 'FechaRegistroVencidaLitigiooCastigada',
		'' AS 'FechaExigibilidadPagoUltimaCuotaPagada',----PENDIENTE***************
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE*****************
		'1490310000' AS	'CuentaContableProvisionRendimiento',
		'8190410400' AS 'CuentaContableInteresCuentaOrden',
		ISNULL(DC01.SaldoRendimientos, '0,00') AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0') AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(DC01.Capital_Trasferido, '0,00') AS 'CapitalTransferido',
		REPLACE(ISNULL(DC01.Fecha_cambio_Capital_Transferido, '19000101'),'/','') AS 'FechaCambioEstatusCapitalTransferido',
		----------------
		15 AS 'TipoDC',
		0 AS 'IdLote',
		'Manual' AS 'Usuario' --@Usuario AS 'Usuario'
	FROM TB_DCAT04_01 DC01 --QUERY DWH
		LEFT JOIN TB_DCAT04_05 DC05 ON DC01.CId = DC05.IdentificadorCliente  --CLIENTES CONSUMER 05
		LEFT JOIN tbGavetas GAV on DC01.Acct = GAV.[Número de Crédito] 
		LEFT JOIN TMP_Rendimiento TMPR on TMPR.acct = DC01.Acct
		LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON DC01.ActivityID = Equi.CodigoCiti 
					AND Equi.AtomoSif = 'CTE'
					AND Equi.TablaSif = 'SB10'
					AND Equi.Insumo = 'CORE'
		INNER JOIN TB_DCAT04_09 DC09 ON DC01.Acct = DC09.ACCT   --ACCOUNT HISTORY
					AND DC09.Appid = '50' 
					AND DC09.TypeId IN (25, 27, 52, 56, 57, 597, 20, 21, 22, 23, 24, 26, 28, 29, 30, 31, 34, 40, 41)
	WHERE
		DC01.TypeId IN (25, 27, 52, 56, 57, 597, 20, 21, 22, 23, 24, 26, 28, 29, 30, 31, 34, 40, 41) 
		and DC01.CtaLocal in ('8190310400') --PIL SEGUROS 
							  
		and DC01.EstadoCredito = '3'  --castigado
		
UPDATE jf77062.TB_DMAT04 SET
NumeroCuotas = '36'
WHERE NumeroCuotas = '0' AND TipoDC = 15 --YR 14/08/2012
	
EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera PIL SEGUROS AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 15 PIL SEGUROS
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada  Cartera PIL SEGUROS', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 



-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 16 SOBREGIROS CORPORATIVOS
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,			
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
SELECT 
		SC.Referencia AS 'NumeroCredito',
		CONVERT(VARCHAR(10), CONVERT(DATETIME,FechaFinal),111) AS 'FechaLiquidacion', --queda igual
		CONVERT(VARCHAR,CONVERT(DATETIME,DATEADD(DAY,DATEDIFF(DAY,0,FechaInicio)-7,0),103),111) AS 'FechASolicitud', --7 diAS antes de fecha aprobacion Orden dada por Julycer Gonzalez 
		CONVERT(VARCHAR(10), CONVERT(DATETIME,FechaInicio),111) AS 'FechaAprobacion', ---fecha inicio
		'2' AS 'Oficina',
		Cuenta AS 'CodigoContable',
		SC.Referencia AS 'NumeroCreditoPrimerDesembolso',
		'1' AS 'NumeroDesembolso',
		'1' AS 'CodigoLineaCredito',
		'0' AS 'MontoLineaCredito',
		'1' AS 'EstadoCredito',
		'2' AS 'TipoCredito',
		'3' AS 'SituacionCredito',
		'C' AS 'PlazoCredito',
		'A' AS 'ClASificacionRiesgo',
		'XXX' AS 'DestinoCredito',
		'2' AS 'NaturalezaCliente',
		'' AS 'TipoCliente', --Se debe buscar en el insumo de sobregiro de meses anteriores
		'' AS 'IdentificacionCliente', --Se debe buscar en el insumo de sobregiro de meses anteriores
		Descripcion AS 'Nombre_RazonSocial',
		'0' AS 'Genero',
		'' AS 'TipoClienteRIF',--Se debe buscar en el insumo de sobregiro de meses anteriores
		'' AS 'IdentificacionTipoClienteRIF',--Se debe buscar en el insumo de sobregiro de meses anteriores
		'XXX' AS 'ActividadCliente',
		'VE' AS 'PaisNacionalidad',
		'' AS 'DomicilioFiscal', --Se debe buscar en el insumo de sobregiro de meses anteriores
		'1' AS 'ClienteNuevo',
		'1' AS 'Cooperativa',
		'0' AS 'Sindicado',
		'0' AS 'BancoLiderSindicato',
		'1' AS 'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero',
		'' AS 'NombreGrupoEconomicoFinanciero',
		'010109' AS 'CodigoParroquia',
		'0' AS 'PeriodoGraciaCapital',
		'8' AS 'PeriodicidadPagoCapital',
		'8' AS 'PeriodicidadPagoInteresCredito',
		convert(varchar,DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE()),0)),111) AS 'FechaVencimientoOriginal',
		convert(varchar,DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE()),0)),111) AS 'FechaVencimientoActual',
		'1900/01/01' AS 'FechaReestructuracion',
		'0' AS 'CantidadProrroga',
		'1900/01/01' AS 'FechaProrroga',
		'0' AS 'CantidadRenovaciones',
		'1900/01/01' AS 'FechaUltimaRenovacion',
		'1900/01/01' AS 'FechaCancelacionTotal',
		convert(varchar,DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE()),0)),111) AS 'FechaVencimientoUltimaCoutaCapital',
		'1900/01/01' AS 'UltimaFechaCancelacionCuotaCapital',
		convert(varchar,DATEADD(s,-1,DATEADD(mm, DATEDIFF(m,0,GETDATE()),0)),111) AS 'FechaVencimientoUltimaCuotaInteres',
		'1900/01/01' AS 'UltimaFechaCancelacionCuotaIntereses',
		'VEB' AS 'Moneda',
		'1' AS 'TipoCambioOriginal',
		'1' AS 'TipoCambioCierreMes',
		convert(decimal(18,2),replace(Saldo,',','')) AS 'MontoOriginal',
		convert(decimal(18,2),replace(Saldo,',','')) AS 'MontoInicial',
		'0' AS 'MontoLiquidadoMes',
		'0' AS 'EntePublico',
		'0' AS 'MontoInicialTerceros',
		convert(decimal(18,2),replace(Saldo,',','')) AS 'Saldo',
		'0' AS 'RendimientosCobrar',
		'0' AS 'RendimientosCobrarVencidos',
		'0' AS 'RendimientosCobrarMora',
		'0' AS 'ProvisionEspecifica',
		'100.0000' AS 'PocentajeProvisionEspecifica',
		'0' AS 'ProvisionRendimientoCobrar',
		'24' AS 'TASASInteresCobrada',
		'24' AS 'TASASInteresActual',
		'1' AS 'IndicadorTASaPreferencial',
		'22' AS 'TASaComision',
		'0' AS 'ComisionesCobrar',
		'0' AS 'ComisionesCobradAS',
		'0' AS 'ErogacionesRecuperables',
		'10' AS 'TipoGarantiaPrincipal',
		'1' AS 'NumeroCuotAS',
		CASE 
			WHEN cuenta LIKE ('133%') THEN '1' 
			ELSE '0'
		END AS 'NumeroCuotASVencidAS',
		'0' AS 'MontoVencido30diAS',
		'0' AS 'MontoVencido60diAS',
		'0' AS 'MontoVencido90diAS',
		'0' AS 'MontoVencido120diAS',
		'0' AS 'MontoVencido180diAS',
		'0' AS 'MontoVencidoUnAno',
		'0' AS 'MontoVencidoMASUnAno',
		'0' AS 'MontoVencer30diAS',
		'0' AS 'MontoVencer60diAS',
		'0' AS 'MontoVencer90diAS',
		'0' AS 'MontoVencer120diAS',
		'0' AS 'MontoVencer180diAS',
		'0' AS 'MontoVencerUnAno',
		'0' AS 'MontoVencerMASUnAno',
		'1' AS 'BancASocial',
		'1' AS 'UnidadProduccionSocial',
		'0' AS 'ModalidadMicrocredito',
		'0' AS 'UsoFinanciero',
		'0' AS 'DestinoRecursosMicrofinancieros',
		'0' AS 'CantidadTrabajadores',
		'0' AS 'VentaAnuales',
		'1900/01/01' AS 'FechaEstadoFinanciero',
		'' AS 'NumeroRTN',
		'' AS 'LicenciaTuristicaNacional',
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica',
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica',
		'0' AS 'NumeroExpedienteConformidadTuristica',
		'' AS 'NombreProyectoUnidadProduccion',
		'' AS 'DireccionProyectoUnidadProduccion',
		'0' AS 'CodigoTipoProyecto',
		'0' AS 'CodigoTipoOperacionesFinanciamiento',
		'0' AS 'CodigoSegmento',
		'0' AS 'TipoZona',
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion',
		'1900/01/01' AS 'FechaUltimaInspeccion',
		'0' AS 'PorcentajeEjecucionProyecto',
		'0' AS 'PagosEfectuadosDuranteMes',
		'0' AS 'MontosLiquidadosFechaCierre',
		'0' AS 'AmortizacionesCapitalAcumuladASFecha',
		'0' AS 'TASaIncentivo',
		'' AS 'NumeroOficioIncentivo',
		'0' AS 'NumeroRegistro_ConstanciaMPPAT',
		'' AS 'TipoRegistro_ConstanciaMPPAT',
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT',
		'0' AS 'TipoSubsector',
		'0' AS 'Rubro',
		'0' AS 'CodigoUso',
		'0' AS 'CantidadUnidades',
		'0' AS 'CodigoUnidadMedida',
		'0' AS 'SectorProduccion',
		'0' AS 'CantidadHectareAS',
		'0' AS 'SuperficieTotalPropiedad',
		'0' AS 'NumeroProductoresBeneficiarios',
		'0' AS 'Prioritario',
		'0' AS 'DestinoManufacturero',
		'0' AS 'DestinoEconomico',
		'0' AS 'TipoBeneficiario',
		'0' AS 'ModalidadHipoteca',
		'0' AS 'IngresoFamiliar',
		'0' AS 'MontoLiquidadoDuranteAnoCurso',
		'0' AS 'SaldoCredito31_12',
		'0' AS 'CantidadViviendASConstruir',	-----------------------
		'0' AS 'RendimientosCobrarReestructurados',
		'0' AS 'RendimientosCobrarAfectosReporto',
		'0' AS 'RendimientosCobrarLitigio',
		ISNULL(GAV.[Intereses Efectivamente Cobrados], ISNULL(TMP.InteresesEfectivamenteCobrados,@Cero)) AS 'InteresEfectivamenteCobrado',
		ISNULL(GAV.[Porcentaje de Comisión FLAT], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(GAV.[Monto Comisión FLAT],ISNULL(TMP.MontoComisionFLAT,'0,00')) AS	'MontoComisionFlat',
		ISNULL(GAV.[Periodicidad de Pago Especial de Capital], ISNULL(TMP.PeriodicidadPagoEspecialCapital,'0')) AS 'PeriocidadPagoEspecialCapital',
		ISNULL(GAV.[Fecha de Cambio de Estatus del Crédito], ISNULL(TMP.FechaCambioEstatusCredito,'19000101')) AS	'FechaCambioEstatusCredito',
		ISNULL(GAV.[Fecha de Registro en Vencida, Litigio o Castigada], ISNULL(TMP.FechaRegistroVencidaLitigioCastigada,ISNULL(SC.[Fecha_Registro_Vencida_Litigio_Castigada],'19000101'))) AS 'FechaRegistroVencidaLitigiooCastigada',
		ISNULL(GAV.[Fecha de Exigibilidad de Pago de la última Cuota Pagada], ISNULL(TMP.FechaExigibilidadPagoUltimaCuotaPagada,'19000101')) AS 'FechaExigibilidadPagoUltimaCuotaPagada',
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE
		'0' AS	'CuentaContableProvisionRendimiento',
		'0' AS 'CuentaContableInteresCuentaOrden',
		'0,00' AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0')AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],'0') AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],'19000101') AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(GAV.[Capital Transferido], ISNULL(TMP.CapitalTransferido,@Cero)) AS 'CapitalTransferido',
		ISNULL(GAV.[Fecha de Cambio de Estatus Capital Transferido], ISNULL(TMP.FechaCambioEstatusCapitalTransferido,'19000101')) AS	'FechaCambioEstatusCapitalTransferido',
		'16' AS TipoDC,
		0 AS IdLote,
		'Manual' AS Usuario		 
	FROM  TMP_SobregirosCorporativo SC
	LEFT JOIN tbGavetas GAV ON SC.Referencia = GAV.[Número de Crédito] 
	LEFT JOIN TB_CarteraNoDirigidaFINAL TMP ON  SC.Referencia = TMP.REFERENCIA


EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera SOBREGIROS CORPORATIVOS AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 16 SOBREGIROS CORPORATIVOS
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada  Cartera SOBREGIROS CORPORATIVOS', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 
-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC 16 SOBREGIROS CONSUMER
--------------------------
INSERT INTO jf77062.TB_DMAT04 (
		NumeroCredito,
		FechaLiquidacion,
		FechaSolicitud,
		FechaAprobacion,
		Oficina,
		CodigoContable,
		NumeroCreditoPrimerDesembolso,
		NumeroDesembolso,
		CodigoLineaCredito,
		MontoLineaCredito,
		EstadoCredito,
		TipoCredito,
		SituacionCredito,
		PlazoCredito,
		ClasificacionRiesgo,
		DestinoCredito,
		NaturalezaCliente,
		TipoCliente,
		IdentificacionCliente,
		Nombre_RazonSocial,
		Genero,
		TipoClienteRIF,
		IdentificacionTipoClienteRIF,
		ActividadCliente,
		PaisNacionalidad,
		DomicilioFiscal,
		ClienteNuevo,
		Cooperativa,
		Sindicado,
		BancoLiderSindicato,
		RelacionCrediticia,
		GrupoEconomicoFinanciero,
		NombreGrupoEconomicoFinanciero,
		CodigoParroquia,
		PeriodoGraciaCapital,
		PeriodicidadPagoCapital,
		PeriodicidadPagoInteresCredito,
		FechaVencimientoOriginal,
		FechaVencimientoActual,
		FechaReestructuracion,
		CantidadProrroga,
		FechaProrroga,
		CantidadRenovaciones,
		FechaUltimaRenovacion,
		FechaCancelacionTotal,
		FechaVencimientoUltimaCoutaCapital,
		UltimaFechaCancelacionCuotaCapital,
		FechaVencimientoUltimaCuotaInteres,
		UltimaFechaCancelacionCuotaIntereses,
		Moneda,
		TipoCambioOriginal,
		TipoCambioCierreMes,
		MontoOriginal,
		MontoInicial,
		MontoLiquidadoMes,
		EntePublico,
		MontoInicialTerceros,
		Saldo,
		RendimientosCobrar,
		RendimientosCobrarVencidos,
		RendimientosCobrarMora,
		ProvisionEspecifica,
		PocentajeProvisionEspecifica,
		ProvisionRendimientoCobrar,
		TasasInteresCobrada,
		TasasInteresActual,
		IndicadorTasaPreferencial,
		TasaComision,
		ComisionesCobrar,
		ComisionesCobradas,
		ErogacionesRecuperables,
		TipoGarantiaPrincipal,
		NumeroCuotas,
		NumeroCuotasVencidas,
		MontoVencido30dias,
		MontoVencido60dias,
		MontoVencido90dias,
		MontoVencido120dias,
		MontoVencido180dias,
		MontoVencidoUnAno,
		MontoVencidoMasUnAno,
		MontoVencer30dias,
		MontoVencer60dias,
		MontoVencer90dias,
		MontoVencer120dias,
		MontoVencer180dias,
		MontoVencerUnAno,
		MontoVencerMasUnAno,
		BancaSocial,
		UnidadProduccionSocial,
		ModalidadMicrocredito,
		UsoFinanciero,
		DestinoRecursosMicrofinancieros,
		CantidadTrabajadores,
		VentaAnuales,
		FechaEstadoFinanciero,
		NumeroRTN,
		LicenciaTuristicaNacional,
		FechaEmisionFactibilidadSociotecnica_ConformidadTuristica,
		NumeroExpedienteFactibilidadSociotecnica,
		NumeroExpedienteConformidadTuristica,
		NombreProyectoUnidadProduccion,
		DireccionProyectoUnidadProduccion,
		CodigoTipoProyecto,
		CodigoTipoOperacionesFinanciamiento,
		CodigoSegmento,
		TipoZona,
		FechaAutenticacionProtocolizacion,
		FechaUltimaInspeccion,
		PorcentajeEjecucionProyecto,
		PagosEfectuadosDuranteMes,
		MontosLiquidadosFechaCierre,
		AmortizacionesCapitalAcumuladasFecha,
		TasaIncentivo,
		NumeroOficioIncentivo,
		NumeroRegistro_ConstanciaMPPAT,
		TipoRegistro_ConstanciaMPPAT,
		FechaVencimientoRegistro_ConstanciaMPPAT,
		TipoSubsector,
		Rubro,
		CodigoUso,
		CantidadUnidades,
		CodigoUnidadMedida,
		SectorProduccion,			
		CantidadHectareas,
		SuperficieTotalPropiedad,
		NumeroProductoresBeneficiarios,
		Prioritario,
		DestinoManufacturero,
		DestinoEconomico,
		TipoBeneficiario,
		ModalidadHipoteca,
		IngresoFamiliar,
		MontoLiquidadoDuranteAnoCurso,
		SaldoCredito31_12,
		CantidadViviendasConstruir,
		RendimientosCobrarReestructurados,
		RendimientosCobrarAfectosReporto,
		RendimientosCobrarLitigio,
		InteresEfectivamenteCobrado,
		PorcentajeComisionFlat,
		MontoComisionFlat,
		PeriocidadPagoEspecialCapital,
		FechaCambioEstatusCredito,
		FechaRegistroVencidaLitigiooCastigada,
		FechaExigibilidadPagoUltimaCuotaPagada,
		CuentaContableProvisionEspecifica,
		CuentaContableProvisionRendimiento,
		CuentaContableInteresCuentaOrden,
		MontoInteresCuentaOrden,
		TipoIndustria,
		TipoBeneficiarioSectorManufacturero,
		TipoBeneficiarioSectorTurismo,
		BeneficiarioEspecial,
		FechaEmisionCertificacionBeneficiarioEspecial,
		TipoVivienda,
		FechaFinPeriodoGraciaPagoInteres,
		CapitalTransferido,
		FechaCambioEstatusCapitalTransferido,
		TipoDC,
		IdLote,
		Usuario)
SELECT 
		SOBC.Acct AS 'NumeroCredito',
		CONVERT(VARCHAR(10), CONVERT(DATETIME,SOBC.OpenDate),111)AS 'FechaLiquidacion',
		CONVERT(VARCHAR,CONVERT(DATETIME,DATEADD(DAY,DATEDIFF(DAY,0,SOBC.opendate)-12,0),103),111) AS 'FechASolicitud', 
		CONVERT(VARCHAR(10), CONVERT(DATETIME,SOBC.OpenDate),111) AS 'FechaAprobacion', 
		SOBC.BranchId AS 'Oficina',
		'1330210000' AS 'CodigoContable',
		SOBC.Acct AS 'NumeroCreditoPrimerDesembolso',
		'1' AS 'NumeroDesembolso',
		'1' AS 'CodigoLineaCredito',
		'0' AS 'MontoLineaCredito',
		'1' AS 'EstadoCredito',
		'2' AS 'TipoCredito',
		'3' AS 'SituacionCredito',
		'C' AS 'PlazoCredito',
		'A' AS 'ClASificacionRiesgo',
		Equi.CodigoSIF AS 'DestinoCredito', 
		'1' AS 'NaturalezaCliente',
		SUBSTRING(SOBC.CID,1,1) AS 'TipoCliente', 
		SUBSTRING(SOBC.CID,2,LEN(SOBC.CID))  AS 'IdentificacionCliente',
		Nombre AS 'Nombre_RazonSocial',
		CASE 
			WHEN Sex = 'M' THEN '2'
			WHEN Sex = 'F' THEN '1'
			ELSE '3'
		END AS 'Genero',
		SUBSTRING(SOBC.CId,1,1) AS 'TipoClienteRIF',
		CASE 
			WHEN SUBSTRING(SOBC.CId,1,1) IN ('V','E') THEN SUBSTRING(dbo.GetRif(SOBC.CId), 2, 20) --fz
			ELSE SUBSTRING(SOBC.CId,2,LEN(SOBC.CId))  
		END AS 'IdentificacionTipoClienteRIF',
		Equi.CodigoSIF AS 'ActividadCliente',
		CASE 
			WHEN SUBSTRING(SOBC.CId,1,1) IN ('V') THEN 'VE' --fz
			ELSE 'XX'  
		END AS 'PaisNacionalidad',
		NA2 AS 'DomicilioFiscal',
		'1' AS 'ClienteNuevo',
		'1' AS 'Cooperativa',
		'0' AS 'Sindicado',
		'0' AS 'BancoLiderSindicato',
		CASE 
			WHEN SOBC.TypeId = '22' THEN '2'
			ELSE '1'  
		END AS  'RelacionCrediticia',
		'1' AS 'GrupoEconomicoFinanciero',
		'' AS 'NombreGrupoEconomicoFinanciero',
		'' AS 'CodigoParroquia',
		'0' AS 'PeriodoGraciaCapital',
		'8' AS 'PeriodicidadPagoCapital',
		'8' AS 'PeriodicidadPagoInteresCredito',
		CONVERT(VARCHAR(10), CONVERT(DATETIME,SOBC.RecordDate),111) AS 'FechaVencimientoOriginal',
		CONVERT(VARCHAR(10), CONVERT(DATETIME,SOBC.RecordDate),111) AS 'FechaVencimientoActual',
		'1900/01/01' AS 'FechaReestructuracion',
		'0' AS 'CantidadProrroga',
		'1900/01/01' AS 'FechaProrroga',
		'0' AS 'CantidadRenovaciones',
		'1900/01/01' AS 'FechaUltimaRenovacion',
		'1900/01/01' AS 'FechaCancelacionTotal',
		CONVERT(VARCHAR(10), CONVERT(DATETIME,SOBC.RecordDate),111) AS 'FechaVencimientoUltimaCoutaCapital',
		'1900/01/01' AS 'UltimaFechaCancelacionCuotaCapital', 
		CONVERT(VARCHAR(10), CONVERT(DATETIME,SOBC.RecordDate),111)AS 'FechaVencimientoUltimaCuotaInteres',
		'1900/01/01' AS 'UltimaFechaCancelacionCuotaIntereses',
		'VEB' AS 'Moneda',
		'1' AS 'TipoCambioOriginal',
		'1' AS 'TipoCambioCierreMes',
		convert(decimal(18,2),REPLACE(Overdraft, 'Bs.F.', '')) AS 'MontoOriginal',
		convert(decimal(18,2),REPLACE(Overdraft, 'Bs.F.', '')) AS 'MontoInicial',
		'0' AS 'MontoLiquidadoMes',
		'0' AS 'EntePublico',
		'0' AS 'MontoInicialTerceros',
		convert(decimal(18,2),REPLACE(Overdraft, 'Bs.F.', '')) AS 'Saldo',
		'0' AS 'RendimientosCobrar',
		'0' AS 'RendimientosCobrarVencidos',
		'0' AS 'RendimientosCobrarMora',
		'0' AS 'ProvisionEspecifica',
		'100.0000' AS 'PocentajeProvisionEspecifica',
		'0' AS 'ProvisionRendimientoCobrar',
		'24' AS 'TASASInteresCobrada',
		'24' AS 'TASASInteresActual',
		'1' AS 'IndicadorTASaPreferencial',
		'22' AS 'TASaComision',
		'0' AS 'ComisionesCobrar',
		'0' AS 'ComisionesCobradAS',
		'0' AS 'ErogacionesRecuperables',
		'10' AS 'TipoGarantiaPrincipal',
		'1' AS 'NumeroCuotAS',
		'1' AS 'NumeroCuotASVencidAS',
		'0' AS 'MontoVencido30diAS',
		'0' AS 'MontoVencido60diAS',
		'0' AS 'MontoVencido90diAS',
		'0' AS 'MontoVencido120diAS',
		'0' AS 'MontoVencido180diAS',
		'0' AS 'MontoVencidoUnAno',
		'0' AS 'MontoVencidoMASUnAno',
		'0' AS 'MontoVencer30diAS',
		'0' AS 'MontoVencer60diAS',
		'0' AS 'MontoVencer90diAS',
		'0' AS 'MontoVencer120diAS',
		'0' AS 'MontoVencer180diAS',
		'0' AS 'MontoVencerUnAno',
		'0' AS 'MontoVencerMASUnAno',
		'1' AS 'BancASocial',
		'1' AS 'UnidadProduccionSocial',
		'0' AS 'ModalidadMicrocredito',
		'0' AS 'UsoFinanciero',
		'0' AS 'DestinoRecursosMicrofinancieros',
		'0' AS 'CantidadTrabajadores',
		'0' AS 'VentaAnuales',
		'1900/01/01' AS 'FechaEstadoFinanciero',
		'' AS 'NumeroRTN',
		'' AS 'LicenciaTuristicaNacional',
		'1900/01/01' AS 'FechaEmisionFactibilidadSociotecnica_ConformidadTuristica',
		'0' AS 'NumeroExpedienteFactibilidadSociotecnica',
		'0' AS 'NumeroExpedienteConformidadTuristica',
		'' AS 'NombreProyectoUnidadProduccion',
		'' AS 'DireccionProyectoUnidadProduccion',
		'0' AS 'CodigoTipoProyecto',
		'0' AS 'CodigoTipoOperacionesFinanciamiento',
		'0' AS 'CodigoSegmento',
		'0' AS 'TipoZona',
		'1900/01/01' AS 'FechaAutenticacionProtocolizacion',
		'1900/01/01' AS 'FechaUltimaInspeccion',
		'0' AS 'PorcentajeEjecucionProyecto',
		'0' AS 'PagosEfectuadosDuranteMes',
		'0' AS 'MontosLiquidadosFechaCierre',
		'0' AS 'AmortizacionesCapitalAcumuladASFecha',
		'0' AS 'TASaIncentivo',
		'' AS 'NumeroOficioIncentivo',
		'0' AS 'NumeroRegistro_ConstanciaMPPAT',
		'' AS 'TipoRegistro_ConstanciaMPPAT',
		'1900/01/01' AS 'FechaVencimientoRegistro_ConstanciaMPPAT',
		'0' AS 'TipoSubsector',
		'0' AS 'Rubro',
		'0' AS 'CodigoUso',
		'0' AS 'CantidadUnidades',
		'0' AS 'CodigoUnidadMedida',
		'0' AS 'SectorProduccion',
		'0' AS 'CantidadHectareAS',
		'0' AS 'SuperficieTotalPropiedad',
		'0' AS 'NumeroProductoresBeneficiarios',
		'0' AS 'Prioritario',
		'0' AS 'DestinoManufacturero',
		'0' AS 'DestinoEconomico',
		'0' AS 'TipoBeneficiario',
		'0' AS 'ModalidadHipoteca',
		'0' AS 'IngresoFamiliar',
		'0' AS 'MontoLiquidadoDuranteAnoCurso',
		'0' AS 'SaldoCredito31_12',
		'0' AS 'CantidadViviendASConstruir',-----
		'0' AS 'RendimientosCobrarReestructurados',
		'0' AS 'RendimientosCobrarAfectosReporto',
		'0' AS 'RendimientosCobrarLitigio',
		ISNULL(GAV.[Intereses Efectivamente Cobrados], ISNULL(TMP.InteresesEfectivamenteCobrados,'0.00')) AS 'InteresEfectivamenteCobrado',
		ISNULL(GAV.[Porcentaje de Comisión FLAT], '0,0000') AS 'PorcentajeComisionFlat',
		ISNULL(GAV.[Monto Comisión FLAT],ISNULL(TMP.MontoComisionFLAT,'0,00')) AS	'MontoComisionFlat',
		ISNULL(GAV.[Periodicidad de Pago Especial de Capital], ISNULL(TMP.PeriodicidadPagoEspecialCapital,'0')) AS 'PeriocidadPagoEspecialCapital',
		ISNULL(GAV.[Fecha de Cambio de Estatus del Crédito], ISNULL(TMP.FechaCambioEstatusCredito,'19000101')) AS	'FechaCambioEstatusCredito',
		ISNULL(GAV.[Fecha de Registro en Vencida, Litigio o Castigada], ISNULL(TMP.FechaRegistroVencidaLitigioCastigada,ISNULL(SOBC.[Fecha_Registro_Vencida_Litigio_Castigada],'19000101'))) AS 'FechaRegistroVencidaLitigiooCastigada',
		ISNULL(GAV.[Fecha de Exigibilidad de Pago de la última Cuota Pagada], ISNULL(TMP.FechaExigibilidadPagoUltimaCuotaPagada,'19000101')) AS 'FechaExigibilidadPagoUltimaCuotaPagada',
		'0' AS 'CuentaContableProvisionEspecifica',--HACER EL CASE
		'0' AS	'CuentaContableProvisionRendimiento',
		'0' AS 'CuentaContableInteresCuentaOrden',
		'0,00' AS 'MontoInteresCuentaOrden',
		ISNULL(GAV.[Tipo de Industria],'0')AS 'TipoIndustria',
		ISNULL(GAV.[Tipo de Beneficiario Sector Manufacturero],'0') AS 'TipoBeneficiarioSectorManufacturero',
		ISNULL(GAV.[Tipo de Beneficiario Sector Turismo],'0') AS 'TipoBeneficiarioSectorTurismo',
		ISNULL(GAV.[Beneficiario Especial],'0') AS 'BeneficiarioEspecial',
		ISNULL(GAV.[Fecha de Emisión Certificación de Beneficiario Especial],'19000101') AS 'FechaEmisionCertificacionBeneficiarioEspecial',
		ISNULL(GAV.[Tipo de Vivienda],ISNULL(DC01.Tipo_Vivienda,'0')) AS 'TipoVivienda',
		ISNULL(GAV.[Fecha Fin de Periodo de Gracia de Pago de Interés],ISNULL(DC01.[Fecha_Fin_Periodo_Gracia_Pago_interes],'19000101')) AS 'FechaFinPeriodoGraciaPagoInteres',
		ISNULL(GAV.[Capital Transferido], ISNULL(TMP.CapitalTransferido,'0.00')) AS 'CapitalTransferido',
		ISNULL(GAV.[Fecha de Cambio de Estatus Capital Transferido], ISNULL(TMP.FechaCambioEstatusCapitalTransferido,'19000101')) AS	'FechaCambioEstatusCapitalTransferido',
		'16' as TipoDC,
		0 as IdLote,
		'Manual' as Usuario		 
	from  TMP_SobregirosConsumer SOBC
	LEFT JOIN tbGavetas GAV on SOBC.Acct = GAV.[Número de Crédito] 
	LEFT JOIN TB_CarteraNoDirigidaFINAL TMP ON  SOBC.Acct = TMP.REFERENCIA
	--LEFT JOIN TMP_SobregirosCorporativo SC ON SOBC.Acct  = SC.REFERENCIA
	LEFT JOIN TB_DCAT04_01 DC01 ON SOBC.Acct = DC01.ACCT --LDWH
	LEFT JOIN jf77062.TB_CFGEqvSifCiti_Generica Equi ON SOBC.ACTI = Equi.CodigoCiti 
			AND Equi.AtomoSif = 'CTE'
			AND Equi.TablASif = 'SB10'
			AND Equi.Insumo = 'CORE'	


EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó cartera SOBREGIROS CONSUMER AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC 16 SOBREGIROS CONSUMER
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada  Cartera SOBREGIROS CONSUMER', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 
-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC Actualizaciones Puntuales
--------------------------

UPDATE jf77062.TB_DMAT04 SET 
	situacioncredito = '0',
	plazocredito = '0', 
	clasificacionriesgo = '0', 
	periodicidadpagocapital = '0',  
	periodicidadpagointerescredito = '0', 
	fechacancelaciontotal = '1900/01/01', 
	provisionespecifica = '0', 
	pocentajeprovisionespecifica = '0', 
	numerocuotasvencidas = '0' 
WHERE
	EstadoCredito = 3 --Castigados 
	

UPDATE jf77062.TB_DMAT04 SET 
	situacioncredito = '0', 
	plazocredito = '0', 
	clasificacionriesgo = '0',  
	periodicidadpagocapital = '0', 
	periodicidadpagointerescredito = '0',  
	saldo = '0', 
	provisionespecifica = '0', 
	pocentajeprovisionespecifica = '0', 
	numerocuotasvencidas = '0'
WHERE
	EstadoCredito = 2 --Cancelados
	
UPDATE jf77062.TB_DMAT04 SET RendimientosCobrar = '0', 
				RendimientosCobrarVencidos = '0' ,
				RendimientosCobrarMora = '0' 
WHERE CodigoContable LIKE ('819%')

--UPDATE jf77062.TB_DMAT04 SET RendimientosCobrarMora = '0' 	

UPDATE jf77062.TB_DMAT04 SET RendimientosCobrarVencidos =  CONVERT(DECIMAL(18,2),ISNULL(replace(RendimientosCobrarVencidos,',',''),0))+ 
				CONVERT(DECIMAL(18,2),ISNULL(replace(RendimientosCobrar,',',''),0))
WHERE CodigoContable LIKE ('133%') and CodigoContable <> '1330210000' 

UPDATE jf77062.TB_DMAT04 SET RendimientosCobrar = '0' 
WHERE CodigoContable LIKE ('133%') and CodigoContable <> '1330210000' 

UPDATE jf77062.TB_DMAT04 SET PlazoCredito = '0' WHERE EstadoCredito IN ('2','3') 
-----
-----CAMPO CuentaContableProvisionEspecifica
--Ver tabla 1 (Ubicar la cuenta contable donde esta registrado el 
---crédito y en función de la cuenta contable colocar lo indicado
--- en la columna "Cuenta Contable Provión Especifica") --tabla TB_EQAT04CtaContableProvEspc
UPDATE 	JF77062.TB_DMAT04 
SET 	CuentaContableProvisionEspecifica = '1390110000'
where 	SUBSTRING(codigocontable,1,3)='131' and
		SUBSTRING(codigocontable,1,6)<>'131281'
UPDATE 	JF77062.TB_DMAT04 
SET 	CuentaContableProvisionEspecifica = '1390210000' 
where 	SUBSTRING(codigocontable,1,3)='132' and
		SUBSTRING(codigocontable,1,6)<>'132281'
 
UPDATE 	JF77062.TB_DMAT04 
SET 	CuentaContableProvisionEspecifica = '1390310000'
where 	SUBSTRING(codigocontable,1,3)='133' and 
		SUBSTRING(codigocontable,1,6)<>'133281'

UPDATE 	JF77062.TB_DMAT04 
SET 	CuentaContableProvisionEspecifica = '1390410000'
where 	SUBSTRING(codigocontable,1,3)='134' and
		SUBSTRING(codigocontable,1,6)<>'134281'

UPDATE 	JF77062.TB_DMAT04 
SET 	CuentaContableProvisionEspecifica = '1390610100'
where 	SUBSTRING(codigocontable,1,6)='131281'

UPDATE 	JF77062.TB_DMAT04 
SET 	CuentaContableProvisionEspecifica = '1390610200'
where 	SUBSTRING(codigocontable,1,6)='132281'

UPDATE 	JF77062.TB_DMAT04 
SET 	CuentaContableProvisionEspecifica = '1390610300'
where 	SUBSTRING(codigocontable,1,6)='133281'

UPDATE 	JF77062.TB_DMAT04 
SET 	CuentaContableProvisionEspecifica = '1390610400'
where 	SUBSTRING(codigocontable,1,6)='134281'

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó Actualizaciones Puntuales AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC Actualizaciones Puntuales
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada  Actualizaciones Puntuales', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 

-----------------------------------------------------------------------------------------------------------------------------------------------
--------------------------
BEGIN TRY -- Tipo DC Actualizaciones Puntuales De Rendimientos Consumer
--------------------------
	UPDATE jf77062.TB_DMAT04 SET RENDIMIENTOSCOBRAR = TMPR.SALDORENDXCOBRAR,
		RENDIMIENTOSCOBRARVENCIDOS = TMPR.SALDORENDXCOBRARVENC,
		RENDIMIENTOSCOBRARMORA = TMPR.SALDORENDXMORA,
		RENDIMIENTOSCOBRARREESTRUCTURADOS =     CASE  WHEN DM.CODIGOCONTABLE LIKE '132%' THEN TMPR.SALDORENDXCOBRAR 
												ELSE @Cero END,
		RENDIMIENTOSCOBRARAFECTOSREPORTO=@Cero,
		RENDIMIENTOSCOBRARLITIGIO=@Cero
	FROM jf77062.TB_DMAT04 DM
		INNER JOIN TMP_MIGRADOS M ON M.OLDACCT = DM.NUMEROCREDITO
		INNER JOIN TMP_RENDIMIENTO TMPR ON TMPR.ACCT = M.NEWACCT
	WHERE TIPODC IN ('1','2','3','4','5','6','9','12','14','15')
	--------------- CASO PUNTUAL DE QUERY ORIGINAL
	UPDATE jf77062.TB_DMAT04 SET RENDIMIENTOSCOBRAR = TMPR.SALDORENDXCOBRAR,
				 RENDIMIENTOSCOBRARVENCIDOS = TMPR.SALDORENDXCOBRARVENC,
				 RENDIMIENTOSCOBRARMORA = TMPR.SALDORENDXMORA,
				 RENDIMIENTOSCOBRARREESTRUCTURADOS =     CASE  WHEN DM.CODIGOCONTABLE LIKE '132%' THEN TMPR.SALDORENDXCOBRAR 
											ELSE @Cero END,
				 RENDIMIENTOSCOBRARAFECTOSREPORTO=@Cero,
				 RENDIMIENTOSCOBRARLITIGIO=@Cero
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN TMP_RENDIMIENTO TMPR ON TMPR.ACCT = '6900000371'
	WHERE DM.NUMEROCREDITO = '6000000371'
	AND  DM.TIPODC IN ('1','2','3','4','5','6','9','12','14','15') --1
	
	
	UPDATE jf77062.TB_DMAT04 SET ProvisionEspecifica  = C.PROVISION_ESPECIFICA,
	PocentajeProvisionEspecifica  = C.PORCENTAJE_PROVISION_ESPECIFICA,
	ProvisionRendimientoCobrar  = C.PROVISION_RENDIMIENTO_X_COBRAR
	FROM jf77062.TB_DMAT04 DM
	INNER JOIN  C ON C.NUM_CREDITO =  DM.NUMEROCREDITO 
	AND  DM.TIPODC IN ('1','2','3','4','5','6','9','12','14','15') --1

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó Actualizaciones Puntuales De Rendimientos Consumer AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC Actualizaciones Puntuales De RPT_STG_Dirigidas_TURISMORendimientos Consumer
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada  Actualizaciones Puntuales De Rendimientos Consumer', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 
-----------------------------------------------------------------------------------------------------------------------------------------------
----------------------------
BEGIN TRY -- Actualizaciones Puntuales De fecha nacimiento
--------------------------

-------------------------------FECHAS DE NACIMIENTO--------------------------------------
UPDATE JF77062.TB_DMAT04 SET	FechaNacimiento = ISNULL(Fe.Fecha_de_nacimiento,'19000101')							
FROM JF77062.TB_DMAT04 DM
INNER JOIN tb_AT04FechasNac Fe ON Fe.IdentificacionCliente = DM.IdentificacionCliente

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó Actualizaciones Puntuales De De fecha nacimiento AT04 - ', NULL, NULL, 'ATOMATICO'
--------------------------
END TRY -- Fin Tipo DC Actualizaciones Puntuales De fecha nacimiento
--------------------------
BEGIN CATCH  
	SELECT  @SpProcess = 'DB.SP_AT04Transformada  Actualizaciones Puntuales De De fecha nacimiento', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
	RETURN -1
END CATCH 



-----------------------------------------------------------------------------------------------------------------------------------------------
----------------------------
--BEGIN TRY -- Tipo DC Actualizaciones Puntuales De Rendimientos Corporativo
----------------------------

---------------------------------RENDIMIENTOS VIGENTES--------------------------------------
--UPDATE JF77062.TB_DMAT04 SET	RENDIMIENTOSCOBRAR = ISNULL(TMPRC.SALDO,@Cero), 
--								RENDIMIENTOSCOBRARVENCIDOS = @Cero , 
--								RENDIMIENTOSCOBRARMORA = @Cero
--FROM JF77062.TB_DMAT04 DM
--INNER JOIN TMP_RENDIMIENTOS_CORPORATIVO TMPRC ON TMPRC.REFERENCIA = DM.NUMEROCREDITO
--WHERE TMPRC.DESCRIPCION IN ('Vigente' ,'Reestructurado')
--AND TIPODC IN ('8', '11', '10', '7', '13', '16')

---------------------------------RENDIMIENTOS VENCIDOS--------------------------------------
--UPDATE JF77062.TB_DMAT04 SET	RendimientosCobrar = @Cero, 
--								RendimientosCobrarVencidos = ISNULL(TMPRC.Saldo,@Cero) , 
--								RendimientosCobrarMora = @Cero
--FROM JF77062.TB_DMAT04 DM
--INNER JOIN TMP_Rendimientos_Corporativo TMPRC on TMPRC.referencia = DM.NumeroCredito
--WHERE TMPRC.Descripcion = 'Vencido' AND tipodc in ('8', '11', '10', '7', '13', '16')

---------------------------------RENDIMIENTOS MORA--------------------------------------
--UPDATE JF77062.TB_DMAT04 SET	RendimientosCobrar = @Cero, 
--								RendimientosCobrarVencidos = @Cero, 
--								RendimientosCobrarMora = ISNULL(TMPRC.Saldo,@Cero)
--from JF77062.TB_DMAT04 DM
--Inner join TMP_Rendimientos_Corporativo TMPRC on TMPRC.referencia = DM.NumeroCredito
--where TMPRC.Descripcion = 'Mora' 
--and tipodc in ('8', '11', '10', '7', '13', '16')

---------------------------------RENDIMIENTOS REESTRUCTURADOS--------------------------------------
--UPDATE JF77062.TB_DMAT04 SET RendimientosCobrarReestructurados = ISNULL(TMPRC.Saldo,@Cero)
--from JF77062.TB_DMAT04 DM
--Inner join TMP_Rendimientos_Corporativo TMPRC on TMPRC.referencia = DM.NumeroCredito
--where TMPRC.Descripcion = 'Reestructurado' 
--and tipodc in ('8', '11', '10', '7', '13', '16')

---------------------------------RENDIMIENTOS AFECTOS REPORTO--------------------------------------
--UPDATE JF77062.TB_DMAT04 SET RendimientosCobrarAfectosReporto = ISNULL(TMPRC.Saldo,@Cero)
--from JF77062.TB_DMAT04 DM
--Inner join TMP_Rendimientos_Corporativo TMPRC on TMPRC.referencia = DM.NumeroCredito
--where TMPRC.Descripcion = 'Efectos' 
--and tipodc in ('8', '11', '10', '7', '13', '16')

---------------------------------RENDIMIENTOS RendimientosCobrarLitigio--------------------------------------

--UPDATE JF77062.TB_DMAT04 SET RendimientosCobrarLitigio = ISNULL(TMPRC.Saldo,@Cero)
--from JF77062.TB_DMAT04 DM
--Inner join TMP_Rendimientos_Corporativo TMPRC on TMPRC.referencia = DM.NumeroCredito
--where TMPRC.Descripcion = 'Litigio' 
--and tipodc in ('8', '11', '10', '7', '13', '16')


--EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Se procesó Actualizaciones Puntuales De Rendimientos Corporativo AT04 - ', NULL, NULL, 'ATOMATICO'
----------------------------
--END TRY -- Fin Tipo DC Actualizaciones Puntuales De Rendimientos Corporativo
----------------------------
--BEGIN CATCH  
--	SELECT  @SpProcess = 'DB.SP_AT04Transformada  Actualizaciones Puntuales De Rendimientos Corporativo', @ErrorSeverity = CONVERT(VARCHAR(4000), ERROR_SEVERITY()), @ErrorState = CONVERT(VARCHAR(4000),ERROR_STATE()), @ErrorLine = CONVERT(VARCHAR(100),ERROR_LINE());         
--	SELECT  @ErrorMessage = '[SP]: ' + @SpProcess + '. [Error Número]: ' + CONVERT(VARCHAR(4000),ERROR_NUMBER()) + '. [Descripción]: '  +  ERROR_MESSAGE() + '. [Severidad]: ' + @ErrorSeverity + '. [Estado]: ' + @ErrorState + '. [Línea]: ' + @ErrorLine;
--   	EXECUTE SIF_SP_RegistrarEvento 10, 0, NULL,'E', @ErrorMessage, NULL, NULL, 'ATOMATICO' 
--	RETURN -1
--END CATCH 


-------------------------------------------------------------------------------------------------------------------------------------------------
----COMMIT TRANSACTION GenerarDM
-------------------------------------------------------------------------------------------------------------------------------------------------	

EXECUTE SIF_SP_RegistrarEvento 10 , 0, NULL , 'I' ,'Finaliza el proceso de ejecución de transformada del AT04 - ', NULL, NULL, 'ATOMATICO'

RETURN

SET NOCOUNT OFF;--  
-------------------------------------------------------------------------------------------------------------------------------------------------------------
SET ANSI_NULLS ON


